package net.cosmoscraft.nova

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import net.cosmoscraft.nova.local.FileNode
import net.cosmoscraft.nova.local.PcmSource
import net.cosmoscraft.nova.local.Platform
import java.io.IOException
import java.nio.ByteOrder

/** FLAC, MP3, AAC/M4A, OGG/Opus ... through the phone's own decoders; tags and cover art through MediaMetadataRetriever. */
class AndroidPlatform(private val ctx: Context) : Platform {

    override fun open(file: FileNode): PcmSource {
        val node = file as? SafNode ?: throw IOException("not a picked file")
        return MediaCodecPcmSource(ctx, node)
    }

    override fun tags(file: FileNode): Platform.Tags? {
        val node = file as? SafNode ?: return null
        val t = Platform.Tags()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, node.uri)
            t.title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }
            t.artist = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST))?.takeIf { it.isNotBlank() }
            t.album = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)?.takeIf { it.isNotBlank() }
        } catch (e: Exception) {
            DebugOverlay.emit("LocalLibrary", "tags unreadable for ${node.name()}: ${e.message}")
        } finally { try { r.release() } catch (e: Exception) { /* nothing to release */ } }
        val ex = MediaExtractor()
        try {
            ex.setDataSource(ctx, node.uri, null)
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/") && f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) { t.numChannels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT); break }
            }
        } catch (e: Exception) { /* channel count is optional */ } finally { ex.release() }
        return t
    }

    override fun artwork(file: FileNode): ByteArray? {
        val node = file as? SafNode ?: return null
        val r = MediaMetadataRetriever()
        return try { r.setDataSource(ctx, node.uri); r.embeddedPicture } catch (e: Exception) { null } finally { try { r.release() } catch (e: Exception) { /* nothing to release */ } }
    }
}

/**
 * Decodes one audio file with MediaExtractor + MediaCodec into 16-bit interleaved PCM. Seeking jumps to the sync point before
 * the wanted position, then decodes and drops samples until the exact frame (output timestamps say where decoding really is).
 * The length comes from the container's duration, so for some VBR MP3s it can be off by a few frames.
 */
class MediaCodecPcmSource(private val ctx: Context, private val node: SafNode) : PcmSource {
    private val extractor = MediaExtractor()
    private var codec: MediaCodec? = null
    private var rate = 44100
    private var ch = 2
    private var frames = 0L
    private var float = false
    private var inputDone = false
    private var outputDone = false
    private val info = MediaCodec.BufferInfo()

    // the decoded buffer being handed out
    private var pend: ShortArray = ShortArray(0)
    private var pendOff = 0           // in shorts
    private var dropFrames = 0L       // frames still to discard after a seek
    private var position = 0L         // frame number of the next frame handed out
    private var needStartPts = true      // true until the first output after a seek (or the start) says where the decoder is
    private var wantedFrame = 0L

    init {
        try {
            extractor.setDataSource(ctx, node.uri, null)
            var idx = -1
            for (i in 0 until extractor.trackCount) if ((extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { idx = i; break }
            if (idx < 0) throw IOException("no audio track in ${node.name()}")
            extractor.selectTrack(idx)
            val f = extractor.getTrackFormat(idx)
            rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val durUs = if (f.containsKey(MediaFormat.KEY_DURATION)) f.getLong(MediaFormat.KEY_DURATION) else 0L
            frames = Math.round(durUs * rate / 1_000_000.0)
            val c = MediaCodec.createDecoderByType(f.getString(MediaFormat.KEY_MIME)!!)
            c.configure(f, null, null, 0)
            c.start()
            codec = c
        } catch (e: Exception) {
            close()
            throw if (e is IOException) e else IOException("cannot decode ${node.name()}: ${e.message}", e)
        }
    }

    override fun sampleRate() = rate
    override fun channels() = ch
    override fun totalFrames() = frames

    override fun seek(frame: Long) {
        val target = frame.coerceIn(0L, frames)
        extractor.seekTo(target * 1_000_000L / rate, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        codec?.flush()
        inputDone = false; outputDone = false
        pend = ShortArray(0); pendOff = 0
        position = target
        dropFrames = -1                  // not known until the first output buffer says where the decoder landed
        needStartPts = true
        wantedFrame = target
    }

    override fun read(out: ShortArray, maxFrames: Int): Int {
        val c = codec ?: return -1
        var written = 0
        while (written < maxFrames) {
            if (pendOff >= pend.size) {
                if (!fillPending(c)) break
                continue
            }
            val availFrames = (pend.size - pendOff) / ch
            val n = minOf(availFrames, maxFrames - written)
            System.arraycopy(pend, pendOff, out, written * ch, n * ch)
            pendOff += n * ch; written += n; position += n
        }
        return if (written == 0) -1 else written
    }
    /** Pulls the next decoded buffer into `pend`, discarding frames before the wanted position. False at the end. */
    private fun fillPending(c: MediaCodec): Boolean {
        while (true) {
            if (!inputDone) {
                val ii = c.dequeueInputBuffer(5_000)
                if (ii >= 0) {
                    val ib = c.getInputBuffer(ii)!!
                    val n = extractor.readSampleData(ib, 0)
                    if (n < 0) { c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputDone = true }
                    else { c.queueInputBuffer(ii, 0, n, extractor.sampleTime, 0); extractor.advance() }
                }
            }
            if (outputDone) return false
            val oi = c.dequeueOutputBuffer(info, 5_000)
            when {
                oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    val f = c.outputFormat
                    if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    float = f.containsKey(MediaFormat.KEY_PCM_ENCODING) && f.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                }
                oi >= 0 -> {
                    val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    var shorts: ShortArray? = null
                    if (info.size > 0) {
                        val bb = c.getOutputBuffer(oi)!!.order(ByteOrder.nativeOrder())
                        bb.position(info.offset); bb.limit(info.offset + info.size)
                        if (float) {
                            val fb = bb.asFloatBuffer(); val a = ShortArray(fb.remaining())
                            for (i in a.indices) a[i] = Math.floor(fb.get(i) * 32768.0 + 0.5).coerceIn(-32768.0, 32767.0).toInt().toShort()
                            shorts = a
                        } else {
                            val sb = bb.asShortBuffer(); val a = ShortArray(sb.remaining()); sb.get(a); shorts = a
                        }
                    }
                    val pts = info.presentationTimeUs
                    c.releaseOutputBuffer(oi, false)
                    if (eos) outputDone = true
                    if (shorts != null && shorts.isNotEmpty()) {
                        if (needStartPts) {                 // where did the decoder actually land after the seek?
                            val landed = Math.round(pts * rate / 1_000_000.0)
                            dropFrames = maxOf(0L, wantedFrame - landed)
                            needStartPts = false
                        }
                        var arr: ShortArray = shorts
                        if (dropFrames > 0) {
                            val f = arr.size / ch
                            val d = minOf(dropFrames, f.toLong()).toInt()
                            dropFrames -= d
                            if (d >= f) continue
                            arr = arr.copyOfRange(d * ch, arr.size)
                        }
                        pend = arr; pendOff = 0
                        return true
                    }
                    if (eos) return false
                }
                else -> { /* INFO_TRY_AGAIN_LATER: loop to feed more input */ }
            }
        }
    }

    override fun close() {
        try { codec?.stop() } catch (e: Exception) { /* already stopped */ }
        try { codec?.release() } catch (e: Exception) { /* already released */ }
        codec = null
        try { extractor.release() } catch (e: Exception) { /* already released */ }
    }
}
