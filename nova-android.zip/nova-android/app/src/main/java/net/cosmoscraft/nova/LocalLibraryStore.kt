package net.cosmoscraft.nova

import android.content.Context
import android.content.Intent
import android.net.Uri
import net.cosmoscraft.nova.local.FileNode
import net.cosmoscraft.nova.local.Library
import org.json.JSONArray
import org.json.JSONObject

/**
 * The folders and individual files chosen for "files on this phone". Each is stored as the URI the file picker returned
 * (with a persistable read grant, so it still works after a restart) and shown to the player as a top-level entry:
 * every folder under its own name, all hand-picked files together under "Selected files".
 */
class LocalLibraryStore(private val ctx: Context) {
    data class Entry(val kind: String, val uri: String, val name: String)   // kind: "folder" | "file"

    private val prefs = ctx.getSharedPreferences("nova_local_library", Context.MODE_PRIVATE)

    fun list(): List<Entry> {
        val arr = try { JSONArray(prefs.getString("entries", "[]")) } catch (e: Exception) { JSONArray() }
        return (0 until arr.length()).map { arr.getJSONObject(it) }.map { Entry(it.optString("kind"), it.optString("uri"), it.optString("name")) }
    }

    private fun save(list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("kind", it.kind).put("uri", it.uri).put("name", it.name)) }
        prefs.edit().putString("entries", arr.toString()).apply()
    }

    private fun grant(uri: Uri) {
        try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        catch (e: Exception) { DebugOverlay.emit("LocalLibrary", "could not keep access to $uri after a restart: ${e.message}") }
    }

    fun addFolder(uri: Uri) {
        grant(uri)
        val name = SafNode.folder(ctx, uri).name()
        val cur = list()
        if (cur.any { it.uri == uri.toString() }) return
        save(cur + Entry("folder", uri.toString(), name))
    }

    fun addFiles(uris: List<Uri>) {
        val cur = list().toMutableList()
        for (u in uris) {
            grant(u)
            if (cur.any { it.uri == u.toString() }) continue
            val node = SafNode.file(ctx, u) ?: continue
            cur.add(Entry("file", u.toString(), node.name()))
        }
        save(cur)
    }

    fun remove(uri: String) {
        try { ctx.contentResolver.releasePersistableUriPermission(Uri.parse(uri), Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { /* already gone */ }
        save(list().filter { it.uri != uri })
    }

    fun isEmpty(): Boolean = list().isEmpty()

    /** What the player sees at the top level. Entries that can no longer be opened (permission lost, folder deleted) are left out. */
    fun roots(): List<Library.Root> {
        val roots = ArrayList<Library.Root>()
        val used = HashSet<String>()
        val files = ArrayList<FileNode>()
        val usedFileNames = HashSet<String>()
        for (e in list()) {
            try {
                if (e.kind == "folder") {
                    var name = e.name.ifBlank { "Folder" }; var n = 2
                    while (!used.add(name)) name = "${e.name} ($n)".also { n++ }
                    roots.add(Library.Root.folder(name, SafNode.folder(ctx, Uri.parse(e.uri))))
                } else {
                    SafNode.file(ctx, Uri.parse(e.uri))?.let { node ->
                        // two picked files can share a name (01 Intro.flac from two albums); the player finds files by name, so tell them apart
                        var name = node.name(); var n = 2
                        while (!usedFileNames.add(name)) { val dot = node.name().lastIndexOf('.'); name = if (dot > 0) node.name().substring(0, dot) + " ($n)" + node.name().substring(dot) else node.name() + " ($n)"; n++ }
                        files.add(if (name == node.name()) node else RenamedNode(node, name))
                    }
                }
            } catch (ex: Exception) {
                DebugOverlay.emit("LocalLibrary", "skipping ${e.name}: ${ex.message}")
            }
        }
        if (files.isNotEmpty()) roots.add(Library.Root.files(if (used.add("Selected files")) "Selected files" else "Selected files (2)", files))
        return roots
    }
}

/** The same file under another name. */
private class RenamedNode(private val inner: FileNode, private val newName: String) : FileNode by inner {
    override fun name(): String = newName
}
