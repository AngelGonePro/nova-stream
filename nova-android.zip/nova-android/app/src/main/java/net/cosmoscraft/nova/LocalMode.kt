package net.cosmoscraft.nova

import android.content.Context
import net.cosmoscraft.nova.local.Library
import net.cosmoscraft.nova.local.LocalServer
import net.cosmoscraft.nova.local.LocalStore
import java.io.File
import java.io.FileNotFoundException
import java.io.InputStream

/**
 * "Files on this phone": the app's own copy of the NOVA player (bundled in assets/local-ui) served from a small
 * server on 127.0.0.1 over the folders and files the user picked. See local/LocalServer.java.
 */
object LocalMode {
    private var server: LocalServer? = null
    private var library: Library? = null
    private var store: LocalLibraryStore? = null

    @Synchronized
    fun start(context: Context): LocalServer {
        server?.let { return it }
        val app = context.applicationContext
        val picks = LocalLibraryStore(app)
        val lib = Library()
        lib.setRoots(picks.roots())
        val srv = LocalServer(
            lib,
            LocalStore(File(app.filesDir, "local/state.json")),
            object : LocalServer.Assets {
                override fun open(path: String): InputStream? = try { app.assets.open("local-ui/$path") } catch (e: FileNotFoundException) { null }
            },
            AndroidPlatform(app),
            { line -> DebugOverlay.emit("LocalServer", line) },
            "This phone"
        )
        srv.start(ServerConfig.localPort(app))
        ServerConfig.setLocalPort(app, srv.port())
        server = srv; library = lib; store = picks
        return srv
    }

    @Synchronized
    fun stop() { server?.stop(); server = null; library = null; store = null }

    /** Re-reads the picked folders and files after they changed; the player sees the new top level at once. */
    @Synchronized
    fun refreshRoots() { val s = store ?: return; library?.setRoots(s.roots()) }
}
