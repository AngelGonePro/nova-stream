package net.cosmoscraft.nova

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

/**
 * NOT tested — I have no Android SDK or emulator available in the environment
 * I wrote this in, so nothing past a syntax-level read-through has verified
 * this. Real device testing (which I cannot do myself) will very likely
 * surface things that need adjusting — buffer sizes in NativeAudioEngine
 * especially, per that file's own comment.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var siteOrigin: String
    // Where the page is loaded from. Same as siteOrigin for a server; for "files on this phone" it is the one-time entry
    // address that hands the page its access key.
    private lateinit var startUrl: String
    private var localLibrary = false

    private lateinit var webView: WebView
    private lateinit var engine: NativeAudioEngine
    private var bridge: NativeAudioBridge? = null
    private lateinit var debugText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // The server is chosen by the user, not built in: on first start ask for it, then remember it.
        localLibrary = ServerConfig.isLocal(this)
        val savedOrigin = ServerConfig.get(this)
        if (!localLibrary && savedOrigin == null) {
            promptForServer(true)
            return
        }
        if (localLibrary) {
            // The player runs from this phone: start its server (loopback only) before the page is loaded.
            try {
                val srv = LocalMode.start(this)
                siteOrigin = srv.origin()
                startUrl = srv.entryUrl()
            } catch (e: Exception) {
                android.util.Log.e("MainActivity", "local library server failed to start: ${e.message}", e)
                android.widget.Toast.makeText(this, "Could not start the on-phone library: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                promptForServer(true)
                return
            }
        } else {
            siteOrigin = savedOrigin!!
            startUrl = savedOrigin
        }

        // The actual completion of the crash-survives-restart fix — see
        // NovaApplication's own comment for the full design. Checked as the
        // very first thing in this activity's own lifecycle, before
        // anything else runs, so a crash from the PREVIOUS launch is the
        // first thing visible in the debug panel on this one. Emitted here
        // (before DebugOverlay's listener is even attached below) is still
        // safe — emit() appends to its own in-memory buffer regardless of
        // whether a listener is attached yet, and setListener immediately
        // replays the full accumulated buffer the moment it IS attached.
        try {
            val crashFile = java.io.File(filesDir, NovaApplication.CRASH_FILE_NAME)
            if (crashFile.exists()) {
                val crashText = crashFile.readText()
                DebugOverlay.emit("CRASH-FROM-PREVIOUS-LAUNCH", crashText)
                crashFile.delete() // shown once — don't keep re-showing the same old crash on every future launch
            }
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Failed to read/display previous crash file: ${e.message}", e)
        }

        // Real gap: I'd suggested chrome://inspect without ever actually
        // enabling it here — WebView debugging is off by default and has to
        // be turned on explicitly, or a desktop Chrome browser has nothing
        // to connect to at all. Fixed now, so that suggestion is actually
        // usable if wanted later: with the phone plugged in via USB (same
        // setup already used for Android Studio) and this app running, a
        // DESKTOP Chrome browser (not the phone) can go to chrome://inspect
        // in its own address bar and see this WebView listed there, with a
        // real DevTools console/network tab. Genuinely optional — the
        // on-device debug panel already covers the same ground now that
        // it's comprehensive.
        android.webkit.WebView.setWebContentsDebuggingEnabled(true)

        // Direct response to a real, repeated obstacle: Logcat access
        // through Android Studio's UI has been hard to find across several
        // rounds of troubleshooting. This on-screen panel sidesteps that
        // entirely — every diagnostic line the native code already logs also
        // shows up here, directly on the phone, no IDE needed at all. A
        // small, scrollable text strip docked at the top; the WebView takes
        // the rest of the screen below it. Meant purely as a stopgap for
        // getting real visibility quickly — not a permanent UI feature.
        debugText = TextView(this).apply {
            setBackgroundColor(Color.BLACK)
            setTextColor(Color.GREEN)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
            setPadding(12, 8, 12, 8)
            movementMethod = ScrollingMovementMethod()
            maxLines = 8
            text = "Debug log will appear here once playback starts… (long-press to copy)"
            // Direct fix for a reported "no way to copy them" complaint —
            // long-press copies the full log text (not just what's visible
            // in this small 8-line window) to the clipboard, so it can be
            // pasted anywhere without retyping or screenshotting.
            setOnLongClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Nova debug log", text.toString()))
                android.widget.Toast.makeText(this@MainActivity, "Debug log copied", android.widget.Toast.LENGTH_SHORT).show()
                true
            }
        }
        webView = WebView(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(debugText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(140)))
            addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)

        DebugOverlay.setListener { text ->
            // Real, direct fix for a confirmed "still crashing with no
            // logs" complaint — traced to this exact listener, the final,
            // terminal step of the entire logging pipeline. debugText.layout
            // can still reference the PREVIOUS text's layout immediately
            // after .text is assigned just above — re-layout happens on the
            // next draw pass, not synchronously on assignment — while
            // debugText.lineCount already reflects the NEW, just-set text.
            // getLineTop() against a stale layout with an out-of-range line
            // index throws. This runs on every single log line, including
            // every one of the try-catch blocks added elsewhere in this app
            // specifically to report a caught exception — meaning a crash
            // here could take down the app in the middle of trying to
            // display the very log that would have explained the original
            // problem, leaving nothing behind. This is the last stage in
            // the pipeline with nothing further downstream to catch it, so
            // it's wrapped directly rather than trying to fix the
            // underlying Android timing issue itself.
            try {
                debugText.text = text
                // Auto-scroll to the bottom so the newest line is always visible
                // without the person needing to manually scroll a tiny panel.
                val layout = debugText.layout
                if (layout != null) {
                    val scrollAmount = layout.getLineTop(debugText.lineCount) - debugText.height
                    debugText.scrollTo(0, if (scrollAmount > 0) scrollAmount else 0)
                }
            } catch (e: Exception) {
                // Deliberately Log.e only, NOT DebugOverlay.emit — calling
                // back into the exact mechanism that just crashed, from
                // inside its own failure handler, risks a genuine infinite
                // loop rather than a fix.
                android.util.Log.e("MainActivity", "DebugOverlay listener CRASHED (caught, not fatal): ${e.message}", e)
            }
        }

        engine = NativeAudioEngine(cacheDir)
        engine.start()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            // Real, direct fix for a reported "I deployed the fix but it's
            // still not showing up" complaint. The server already sends
            // Cache-Control: no-store on every response (confirmed directly
            // in server.js, added specifically for this exact scenario) —
            // but WebView has its OWN separate cache setting, independent of
            // HTTP headers, and never explicitly setting it here left it at
            // whatever the platform default happens to be, which is not
            // guaranteed consistent across every Android version/OEM skin.
            // Set explicitly rather than trusted to line up with the
            // server's own headers — this WebView never has a legitimate
            // reason to serve a locally cached copy of a page that changes
            // as often as this one does.
            cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (url.startsWith(siteOrigin)) return false
                startActivity(Intent(Intent.ACTION_VIEW, request.url))
                return true
            }

            // Real, direct diagnostic added from a reported pattern: two
            // full sequences of startup/entry logs appearing back-to-back,
            // each restarting from the very beginning, with the second one
            // getting one step further (reaching the loop condition check)
            // before going silent again — and DebugOverlay (a process-wide
            // singleton, unlike the WebView's own JS state) showing BOTH
            // sequences accumulated together rather than one being
            // overwritten. That specific pattern is consistent with the
            // WebView's own renderer process crashing and Android silently
            // reloading the page — the host app process (and this
            // singleton) survives, but the page's JS runtime (generation
            // tokens, in-flight state, all of it) does not. This callback
            // exists specifically to detect that scenario; if it never
            // fires, this theory is wrong and something else is happening
            // instead — either way, this makes it visible instead of guessed.
            override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
                DebugOverlay.emit("MainActivity", "WEBVIEW RENDERER PROCESS CRASHED — didCrash=${detail.didCrash()}, rendererPriorityAtExit=${detail.rendererPriorityAtExit()}")
                // Returning true here means "I've handled it" — without a
                // new WebView instance, the OS would otherwise kill the
                // whole host app. Reloading the same URL is the simplest
                // recovery; it's also exactly why the page's JS state
                // resets silently instead of the app visibly closing.
                view.loadUrl(siteOrigin)
                return true
            }
        }

        // Real, direct response to a fair, completely valid complaint: every
        // previous round of diagnosis required adding one specific log line,
        // rebuilding, and waiting for the next report — reactive, one blind
        // spot at a time. This is the other half of the fix (the JS-side
        // half routes through bufferClientError, already wired to
        // nativeDebugLog) — WebChromeClient.onConsoleMessage catches every
        // console.log/warn/error the page ever produces at the WebView
        // level itself, including ones that might never reach the JS-side
        // interception at all. Between this and the bufferClientError
        // change, essentially everything the page does that's worth seeing
        // now shows up on-device automatically, with no future patch needed
        // per new investigation.
        webView.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onConsoleMessage(message: android.webkit.ConsoleMessage): Boolean {
                DebugOverlay.emit("Console", "[${message.messageLevel()}] ${message.message()} (${message.sourceId()}:${message.lineNumber()})")
                return true
            }
        }

        registerBridgeIfSupported()

        // Real, direct fix for the same "crashing without logs" class of
        // bug found in PlaybackService's safe wrapper — that wrapper's own
        // try-catch only covers the synchronous call into this lambda, not
        // the actual work, which happens inside runOnUiThread's separately
        // posted runnable. An exception in webView.evaluateJavascript
        // itself (a torn-down WebView, most plausibly, given these calls
        // can be triggered by the system at unpredictable times via
        // PlaybackService's media session callbacks) would still crash
        // uncaught, entirely outside that outer try-catch's scope. Caught
        // here instead, at the point the real work actually happens.
        PlaybackService.evaluateJs = { js ->
            runOnUiThread {
                try {
                    webView.evaluateJavascript(js, null)
                } catch (e: Exception) {
                    android.util.Log.e("MainActivity", "evaluateJs runOnUiThread block CRASHED (caught, not fatal): ${e.message}", e)
                }
            }
        }
        startForegroundService(Intent(this, PlaybackService::class.java))
        // Runs on the main thread (service callbacks do). Tearing down and
        // finishing here is the same thing onDestroy does, for the case where
        // the system removes the task without running it.
        PlaybackService.onTaskRemovedHook = { teardown(); finish() }

        webView.loadUrl(startUrl)
        // First time in "files on this phone": nothing to play until some folders or files are chosen.
        if (localLibrary && LocalLibraryStore(this).isEmpty()) webView.post { manageLibrary() }
    }

    /**
     * Asks for the server address. First start: no way to dismiss it, because the app cannot do anything without a
     * server. From settings: cancelable, and the current address is filled in. A valid answer is stored and the
     * activity restarts so the page, the bridge and the allowed origin all use it.
     */
    fun promptForServer(firstStart: Boolean) {
        val input = android.widget.EditText(this).apply {
            hint = "https://your-server.example.com"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
            if (!firstStart) setText(ServerConfig.get(this@MainActivity) ?: ServerConfig.lastServer(this@MainActivity) ?: "")
        }
        val pad = dpToPx(20)
        val box = FrameLayout(this).apply {
            setPadding(pad, dpToPx(8), pad, 0)
            addView(input, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("NOVA server")
            .setMessage(if (firstStart) "Enter the address of the NOVA server you want to use." else "Enter the address of the server to switch to.")
            .setView(box)
            .setCancelable(!firstStart)
            .setPositiveButton("Connect", null)
            .setNeutralButton("Files on this phone", null)
            .apply { if (!firstStart) setNegativeButton("Cancel", null) }
            .create()
        dialog.setOnShowListener {
            // No server needed: play music stored on this phone, with the same player.
            dialog.getButton(android.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                ServerConfig.setLocal(this)
                dialog.dismiss()
                recreate()
            }
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val origin = ServerConfig.normalize(input.text.toString())
                if (origin == null) {
                    input.error = "Enter a https:// address, e.g. https://music.example.com"
                } else {
                    ServerConfig.set(this, origin)
                    dialog.dismiss()
                    recreate()
                }
            }
        }
        dialog.show()
    }

    // ---- "Files on this phone": choosing what to play ----
    private val REQ_FOLDER = 7101
    private val REQ_FILES = 7102
    private var libraryDialog: android.app.AlertDialog? = null

    /** Lists the chosen folders and files, with buttons to add or remove them. */
    fun manageLibrary() {
        if (!localLibrary || isFinishing) return
        libraryDialog?.dismiss()
        val store = LocalLibraryStore(this)
        val entries = store.list()
        val pad = dpToPx(16)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, dpToPx(8), pad, 0) }
        if (entries.isEmpty()) {
            box.addView(TextView(this).apply { text = "Nothing chosen yet. Add a folder to play everything in it (with sub-folders), or pick individual files."; setPadding(0, dpToPx(8), 0, dpToPx(8)) })
        }
        for (e in entries) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = (if (e.kind == "folder") "\uD83D\uDCC1 " else "\uD83C\uDFB5 ") + e.name; setSingleLine(true); ellipsize = android.text.TextUtils.TruncateAt.MIDDLE }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(android.widget.Button(this).apply {
                text = "Remove"
                setOnClickListener { store.remove(e.uri); libraryChanged(); manageLibrary() }
            })
            box.addView(row)
        }
        val scroll = android.widget.ScrollView(this).apply { addView(box) }
        libraryDialog = android.app.AlertDialog.Builder(this)
            .setTitle("Music on this phone")
            .setView(scroll)
            .setPositiveButton("Add folder…") { _, _ ->
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), REQ_FOLDER)
            }
            .setNeutralButton("Add files…") { _, _ ->
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                    .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), REQ_FILES)
            }
            .setNegativeButton("Done", null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_FOLDER && requestCode != REQ_FILES) return
        if (resultCode == RESULT_OK && data != null) {
            val store = LocalLibraryStore(this)
            try {
                if (requestCode == REQ_FOLDER) data.data?.let { store.addFolder(it) }
                else {
                    val uris = ArrayList<android.net.Uri>()
                    data.data?.let { uris.add(it) }
                    data.clipData?.let { clip -> for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { uris.add(it) } }
                    store.addFiles(uris)
                }
                libraryChanged()
            } catch (e: Exception) {
                android.widget.Toast.makeText(this, "Could not add that: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            }
        }
        manageLibrary()
    }

    /** The server sees the new list straight away; the page goes back to the top of the library without interrupting playback. */
    private fun libraryChanged() {
        LocalMode.refreshRoots()
        if (::webView.isInitialized) webView.evaluateJavascript("(document.querySelector('#breadcrumbs .crumb')||{click(){}}).click()", null)
    }

    private fun dpToPx(dp: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), resources.displayMetrics).toInt()

    private fun registerBridgeIfSupported() {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            val b = NativeAudioBridge(webView, engine, siteOrigin, localLibrary)
            bridge = b
            WebViewCompat.addWebMessageListener(
                webView,
                NativeAudioBridge.JS_OBJECT_NAME,
                setOf(siteOrigin),
                b
            )
        } else {
            DebugOverlay.emit("MainActivity", "WEB_MESSAGE_LISTENER not supported on this WebView — native audio bridge NOT registered, falling back to normal web playback")
        }
    }

    // Idempotent: reachable from onDestroy AND from PlaybackService's
    // onTaskRemoved hook (some Android versions / OEM skins don't reliably run
    // Activity.onDestroy when the task is swiped away while a foreground
    // service is alive — and "closing the app" must always stop playback).
    private var tornDown = false

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun teardown() {
        if (tornDown) return
        tornDown = true
        PlaybackService.onTaskRemovedHook = null
        DebugOverlay.setListener(null)
        // Real, direct fix for a confirmed, serious bug: audio kept playing —
        // and even started on its own — after the app was closed, until the
        // app was force-stopped in system settings. Cause: this method used
        // to stop only the audio hardware. The WebView was never destroyed,
        // so the page's JavaScript kept running in the background, still
        // driving its queue and still able to send messages to a native
        // bridge and engine that were never actually shut down; and
        // PlaybackService.evaluateJs still pointed at that dead page, so a
        // headset / Bluetooth / lock-screen "play" press was delivered
        // straight into it. Order matters: cut the lock-screen route first,
        // then make the bridge and engine permanently inert, THEN destroy the
        // page so nothing is left running that could reach them.
        PlaybackService.evaluateJs = null
        libraryDialog?.dismiss()
        bridge?.shutdown()
        if (::engine.isInitialized) engine.shutdown()
        if (!::webView.isInitialized) { stopService(Intent(this, PlaybackService::class.java)); LocalMode.stop(); return }
        try { WebViewCompat.removeWebMessageListener(webView, NativeAudioBridge.JS_OBJECT_NAME) } catch (e: Exception) { /* feature may be unsupported; the bridge is already inert */ }
        try {
            webView.stopLoading()
            webView.loadUrl("about:blank")
            webView.onPause()
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.removeAllViews()
            webView.destroy()
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "WebView teardown failed (non-fatal): ${e.message}", e)
        }
        LocalMode.stop()
        stopService(Intent(this, PlaybackService::class.java))
    }
}
