package net.cosmoscraft.nova

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.tanh

/**
 * The actual fix this whole app exists for. Every discontinuity/crackle bug
 * chased across the web player this session traced back to one structural
 * fact: Web Audio API plays audio by scheduling discrete, separately-created
 * AudioBufferSourceNode objects end-to-end, and stitching two of those
 * together — however carefully — always has a real seam. This class has no
 * such seam by construction: one [AudioTrack] in streaming mode, fed by a
 * single continuous queue of PCM byte chunks, written with blocking
 * [AudioTrack.write] calls on one dedicated thread for as long as a track is
 * playing. There is no "segment boundary" concept here at all — chunks are
 * just bytes appended to one ongoing stream, the same way piping raw audio to
 * `aplay` or `ffplay -f s16le -` never audibly clicks between reads.
 *
 * Deliberately NOT responsible for fetching, retrying, or deciding what to
 * play next — see NativeAudioBridge and the "isFirstOfTrack" parameter below
 * for why: the JS side keeps every bit of the fetch/retry/prefetch/quality-
 * selection logic that was already mature and well-tested before this app
 * existed. This class's only job is turning a stream of already-correct PCM
 * bytes into sound without introducing a new seam of its own.
 *
 * NOT tested on a real device — I have no way to compile or run this code
 * myself in the environment I'm working in. Buffer sizing, in particular
 * (see MIN_BUFFER_MULTIPLIER below), is a reasonable starting point from
 * documented Android audio guidance, not a number verified against real
 * hardware. Expect to need to tune it.
 */
/**
 * The actual architecture change requested directly: instead of treating
 * every seek as a full network re-fetch plus an audio-hardware cycle, this
 * holds one track's ENTIRE decoded PCM data in a single growable buffer,
 * downloaded once, sequentially, in the background — completely decoupled
 * from playback position. A seek to anywhere already downloaded becomes a
 * pure in-memory operation: move a read cursor, nothing else. This is the
 * same fundamental approach real streaming apps (Apple Music, Amazon
 * Music, anything built on ExoPlayer) use — confirmed directly from an
 * ExoPlayer engineer's own writeup: seeking within an already-buffered
 * window "becomes a lot less destructive... we can simply move the
 * playback position back in time and the data source... remain untouched."
 * Every previous fix in this session tried to make the OLD, always-
 * destructive seek safer; this removes the need for it to be destructive
 * at all, for the common case.
 */
class TrackBuffer(val trackId: String, val sampleRate: Int, val channels: Int, cacheDir: java.io.File) {
    // Real, direct architecture change requested explicitly, after the
    // in-memory version's own real OutOfMemoryError crash: same design as
    // before (download once, seek freely within what's downloaded, no
    // network re-fetch or audio-hardware cycle for an in-buffer seek) —
    // only the storage layer underneath changes, from a growable ByteArray
    // held entirely in RAM to a file on disk. Two SEPARATE file handles on
    // the same file — one for the download thread's own sequential
    // appends, one for the playback thread's own arbitrary-offset reads —
    // rather than one shared handle, specifically because RandomAccessFile
    // tracks its own file-position as internal, mutable state: a shared
    // handle would mean one thread's seek() could be silently clobbered by
    // the other's, corrupting reads or writes with no exception to signal
    // it. Separate file descriptors on the same underlying file don't have
    // this hazard — each has its own independent position, and standard
    // POSIX file semantics guarantee a write through one descriptor is
    // visible to a read through another on the same file, no explicit
    // flush/fsync required for that visibility.
    val file: java.io.File = java.io.File(cacheDir, "nova_trackbuf_${System.nanoTime()}_${Math.abs(trackId.hashCode())}.pcm")
    private val writer: java.io.RandomAccessFile = java.io.RandomAccessFile(file, "rw")
    private val reader: java.io.RandomAccessFile = java.io.RandomAccessFile(file, "r")

    // How many bytes have actually been written and are safe to read —
    // everything from here onward in the file is not yet valid.
    @Volatile var downloadedBytes: Int = 0
    // Real, direct architectural fix for a confirmed "still buffering"
    // report — traced to a genuine race: readCursorBytes used to be a
    // single, shared, engine-level field, meaning a stale thread still
    // finishing up for a PREVIOUS track and a fresh thread just starting
    // for a NEW one were reading and writing the exact same field,
    // capable of racing each other — the same class of bug as
    // limiterGainState's own cross-track carryover, just for playback
    // position instead of gain. Moved here, onto the buffer itself, so
    // each TrackBuffer instance owns its own independent cursor — a
    // stale thread still holding a reference to an OLD buffer instance
    // can no longer possibly corrupt a DIFFERENT, newer buffer's cursor,
    // because they're now genuinely separate fields on separate objects,
    // not one shared value two different threads could both touch.
    @Volatile var cursorBytes: Int = 0
    // Set once the server reports the track's real total size — null until
    // then, since there's no way yet to know the actual track length.
    @Volatile var totalBytes: Int? = null

    private val lock = Any()
    // Real, direct fix for a confirmed EBADF crash, caught directly in a
    // production log at the exact moment of a track restart: close() never
    // acquired writeLock at all, so it could run WHILE append() or
    // truncateTo() were genuinely mid-operation on a different thread (the
    // old, about-to-be-abandoned download thread, still writing to this
    // exact buffer right as a restart calls close() on it) — closing the
    // file descriptor out from under an in-flight write, which is exactly
    // what "lseek failed: EBADF" and "ftruncate failed: EBADF" are. Worse,
    // readAt() — the ACTUAL AUDIO PLAYBACK PATH — had no synchronization
    // against this at all either, meaning a real, in-progress audio read
    // could race against a concurrent close() the exact same way. Replaced
    // writeLock with a single lock shared by every operation — append,
    // read, truncate, and close all now serialize against each other
    // completely, so none of them can ever observe a half-closed file.
    @Volatile private var closed = false
    // Real, direct fix for a genuine build break I caused: this constant
    // was declared right alongside writeLock before the EBADF fix rewrote
    // that section, and got dropped when writeLock became lock — the code
    // that USES it (append, right below) was carried over correctly, but
    // the declaration itself wasn't. Restored with its original value and
    // reasoning: a confirmed OutOfMemoryError once traced to exactly this
    // class (a 229MB allocation, far beyond what any single track should
    // need) — moving to a real file removed that specific RAM failure
    // mode, but the cap stays as a structural bound against the same
    // class of bug (a stale download nothing stopped) filling up device
    // storage instead. ~350MB comfortably covers even a long track at
    // this app's highest realistic streaming quality with real headroom.
    private val MAX_BUFFER_BYTES = 350 * 1024 * 1024

    /** Appends newly-downloaded bytes to the end of the file. Safe to call from the download thread while the playback thread concurrently reads up to [downloadedBytes] through its own, separate file handle. */
    fun append(bytes: ByteArray) {
        synchronized(lock) {
            // A buffer whose owner has already discarded it (a restart, a
            // seamless swap moving on) silently ignores further appends
            // from whatever stale thread is still trying — that thread is
            // about to notice it's stale and stop on its own anyway; this
            // just prevents it from ever touching a file that's gone.
            if (closed) return
            val needed = downloadedBytes + bytes.size
            if (needed > MAX_BUFFER_BYTES) {
                android.util.Log.w("TrackBuffer", "append() for trackId=$trackId would exceed the $MAX_BUFFER_BYTES byte safety cap (needed=$needed) — dropping this append rather than risk filling device storage. This should not happen in normal operation; if it does, something upstream isn't stopping a download it should have.")
                return
            }
            writer.seek(downloadedBytes.toLong())
            writer.write(bytes)
            downloadedBytes += bytes.size
        }
    }

    /** Reads exactly [length] bytes starting at [offset]. Caller (the playback loop) is responsible for never requesting beyond [downloadedBytes] — this class doesn't re-check that here, the same way the in-memory version's direct array access didn't either. Only ever called from the single playback thread that owns this instance at a time for its own reads, but now synchronized against append/truncate/close too, all of which can genuinely happen concurrently from other threads. */
    fun readAt(offset: Int, length: Int): ByteArray {
        val buf = ByteArray(length)
        // Real, direct resilience fix added after a reported "audio just
        // stopped, timeline froze" complaint immediately following this
        // file-backed rewrite — the most direct explanation available: this
        // had no error handling at all, so any transient read failure
        // (a real, if rare, possibility for a separate file descriptor
        // reading data another descriptor just wrote — POSIX generally
        // guarantees visibility here, but this hasn't been verified on
        // real Android storage yet) would throw straight up into the
        // playback loop's own outer try-catch, which would silently catch
        // it and exit the whole loop — audio stops, and with it, the one
        // thing that was still driving position updates forward. A single
        // short retry, rather than treating any read failure as fatal, is
        // what actually determines whether this is genuinely fatal (the
        // download is stuck, the file is gone) versus a transient blip
        // that resolves itself a few milliseconds later.
        var lastError: Exception? = null
        for (attempt in 0 until 3) {
            synchronized(lock) {
                if (closed) {
                    lastError = java.io.IOException("readAt called on a closed TrackBuffer for trackId=$trackId")
                    return@synchronized
                }
                try {
                    reader.seek(offset.toLong())
                    reader.readFully(buf)
                    return buf
                } catch (e: Exception) {
                    lastError = e
                }
            }
            android.util.Log.w("TrackBuffer", "readAt(offset=$offset, length=$length) failed on attempt ${attempt + 1}/3 for trackId=$trackId: ${lastError?.message}")
            if (closed) break // a buffer that's actually been discarded won't recover on retry — no point sleeping through all 3
            try { Thread.sleep(15) } catch (ie: InterruptedException) { throw lastError!! }
        }
        throw lastError ?: java.io.IOException("readAt failed with no captured exception")
    }

    /**
     * Real, direct fix for a confirmed "skipped back, sounded worse
     * quality" bug — traced directly to a genuine gap: a download attempt
     * that fails partway through (an exception mid-read) left whatever it
     * had already appended permanently in the file, with no rollback. The
     * retry that follows targets the exact same position again, so its
     * own full copy of that segment lands right after the truncated
     * partial one already sitting there — the same audio duplicated back
     * to back. Playback plays through the good part, hits the partial
     * attempt's abrupt cutoff (audible as a real discontinuity — the
     * "worse quality"), then continues into the retry's copy of content
     * it already just played (the "skipped back"). Called from the
     * download loop's own catch block, rewinding the file back to exactly
     * where it stood before this specific attempt began, so the retry
     * starts clean instead of appending on top of a partial leftover.
     */
    fun truncateTo(bytes: Int) {
        synchronized(lock) {
            if (closed) return
            if (bytes >= downloadedBytes) return // nothing to roll back — this attempt hadn't written anything yet, or already rolled back
            downloadedBytes = bytes
            writer.setLength(bytes.toLong())
        }
    }

    /** Real, direct addition for the file-backed rewrite — the in-memory version had nothing to clean up when a buffer was discarded (garbage collection handled it silently); a real file on disk needs an explicit close and delete, or cache storage leaks the exact same way the old in-memory version could leak RAM. Safe to call more than once — now genuinely idempotent under concurrency too, not just in sequential code, since the closed check and the actual close both happen under the same lock every other operation now shares. */
    fun close() {
        synchronized(lock) {
            if (closed) return
            closed = true
            try { writer.close() } catch (e: Exception) {}
            try { reader.close() } catch (e: Exception) {}
            try { file.delete() } catch (e: Exception) {}
        }
    }
}


class NativeAudioEngine(private val cacheDir: java.io.File) {
    companion object {
        private const val TAG = "NovaAudioEngine"

        // AudioTrack's own getMinBufferSize() returns the smallest buffer that
        // won't underrun under ideal conditions — real devices, especially
        // under the kind of network jitter this whole app is meant to survive,
        // need real margin above that floor. 4x is a starting point grounded in
        // common guidance for streamed (not one-shot) playback, not a number
        // measured on real hardware — this is one of the first things worth
        // tuning once this actually runs on a phone.
        private const val MIN_BUFFER_MULTIPLIER = 4

        // Same fixed, small safety trim as the web client's own
        // LOUDNESS_SAFETY_TRIM_DB (-1dB) — real per-track normalization is
        // already baked into the PCM server-side (see nova-server's
        // populateCacheInBackground); this is headroom, not a second
        // normalization pass.
        private const val SAFETY_TRIM = 0.8912509f // 10^(-1/20)

        // Same downmix coefficients already measured and tuned in the web
        // player's own connectWithDownmix (see app.js) — reused here rather
        // than re-derived, since those numbers were already verified against
        // real multichannel content earlier this session. Applied correctly
        // per-sample here, unlike a channel-index-parity shortcut.
        private const val DOWNMIX_SIDE = 1.0f
        private const val DOWNMIX_CENTER = 0.707f
        private const val DOWNMIX_SURROUND = 0.707f
        private const val DOWNMIX_LFE = 0.5f

        // Same transfer curve as the web client's own softClip WaveShaperNode:
        // fully transparent below 0.9, a tanh taper above it approaching but
        // never reaching 1.0. A safety net for the rare case a downmix sum (or
        // a not-yet-server-cached first play, still using a quick, bounded
        // gain estimate rather than the full-track one) pushes a sample past
        // full scale — not expected to engage often.
        private fun softClip(x: Float): Float {
            val ax = abs(x)
            if (ax <= 0.9f) return x
            val over = (ax - 0.9f) / (1f - 0.9f)
            val shaped = 0.9f + 0.1f * (tanh(over * 2f) / tanh(2f)).toFloat()
            return if (x < 0) -shaped else shaped
        }
    }

    // Chunk = one piece of raw PCM bytes queued for playback, tagged with
    // whether it's the first chunk of a brand new track (see below for why
    // that matters) and the format it was decoded at, since format can only
    // change at a track boundary, never mid-track.
    private data class Chunk(val bytes: ByteArray, val sampleRate: Int, val channels: Int, val isFirstOfTrack: Boolean, val isLastOfTrack: Boolean = false)

    // Bounded, not unbounded — a producer (the fetch thread) that's allowed to
    // run arbitrarily far ahead of actual playback defeats the purpose of
    // wanting tight control over buffering. 64 chunks at typical network-chunk
    // sizes is generous slack without being unbounded; put() blocks the fetch
    // thread (not the playback thread) once full, which is the correct
    // backpressure direction.
    // Real, direct fix for a reported "no seamless queue tracks, next track
    // should start loading in the background" complaint. The actual math:
    // 64 chunks at up to 32KB each is at most ~2MB — at this track's own
    // bitrate (8ch/32kHz/16-bit = 512,000 bytes/sec), that's only about 4
    // seconds of real playback buffer. playNextInQueue already fires the
    // instant the current track's LAST segment finishes downloading, not
    // once it finishes playing — but with only 4 seconds of slack, any
    // fetch for the next track's first segment slower than that (a real,
    // common case on the connection this session has repeatedly shown
    // struggling) empties the queue before that data can arrive, producing
    // an audible gap regardless of how early the fetch started. Raised to
    // hold roughly 25-30 seconds of buffer even at full-quality bitrates —
    // real memory cost (tens of MB), but a reasonable one on a modern phone
    // for what it actually buys: enough slack that a genuinely slow
    // transition has real room to complete before the queue runs dry.
    private val queue = ArrayBlockingQueue<Chunk>(600)
    private var playbackThread: Thread? = null
    private val running = AtomicBoolean(false)
    private var audioTrack: AudioTrack? = null
    private var currentSampleRate = 0
    private var currentChannels = 0
    @Volatile private var volumeMultiplier = 1.0f
    @Volatile var onUnderrun: (() -> Unit)? = null
    @Volatile var onTrackBoundaryReached: (() -> Unit)? = null
    // The actual fix for "gapless but wait until the song before it is
    // done" — fires only once a chunk explicitly marked as a track's LAST
    // one has been fully, actually written out to the AudioTrack — not
    // when it was fetched, not when it was queued, but once real audio
    // delivery of it is complete. This is the one moment it's genuinely
    // safe to let a following track's audio start.
    @Volatile var onTrackEndReached: (() -> Unit)? = null
    // Real, direct addition for a confirmed "timeline keeps going past the
    // track's actual end" report — traced to a genuine gap: the displayed
    // position is computed purely from wall-clock time elapsed since
    // playback started, with nothing pausing it during a genuine buffering
    // stall (the "still waiting for more download data" state, which this
    // whole session's logs show happening repeatedly, sometimes for
    // several seconds at a time). Every one of those stalls is real time
    // the display clock kept counting through with no actual audio
    // advancing — the cumulative drift across several stalls in one track
    // is exactly what put the displayed position seconds past the track's
    // own known duration despite it still genuinely playing. This tells JS
    // precisely when a stall starts and ends so it can freeze and resume
    // its own wall-clock-based timer to match, rather than assuming
    // playback always advances in lockstep with real time.
    // Real, direct fix for a confirmed report: quality was dropping on a
    // connection confirmed good, traced to the actual numbers in a real
    // log — a restart at only 9 seconds into the very first track of a
    // session, meaning every "struggle signal" that led to it fired during
    // that track's own unavoidable startup ramp-up, before any real data
    // could possibly have arrived yet. That's true of any connection, good
    // or bad — there was never a way to tell "nothing has downloaded yet
    // because downloading anything takes a moment" apart from "downloading
    // stopped after it had been working." The second parameter is that
    // distinction: whether this track has ever successfully started real
    // playback before (mirrors needsPrebuffer's own meaning at each call
    // site) — false during the initial ramp-up, true for a genuine
    // mid-playback interruption. Only the latter should ever count toward
    // a quality decision.
    @Volatile var onBufferingStateChanged: ((Boolean, Boolean) -> Unit)? = null
    // Real, direct addition for a confirmed follow-up: the prebuffer and
    // buffering-state signals above only address a track's START and
    // actual, complete stalls — they say nothing about a margin that's
    // continuously thin THROUGHOUT playback without ever quite hitting
    // zero. If the download's sustained rate genuinely can't stay ahead
    // of real-time playback, any head start just gets consumed over time
    // and the same stall happens again later, merely delayed once. This
    // fires as an early warning — the margin is getting low, playback
    // hasn't actually run dry yet — specifically so adaptive quality can
    // react BEFORE an audible gap, not only after one has already
    // happened enough times to count as a pattern. Deliberately separate
    // from onBufferingStateChanged, which drives the display clock
    // freeze — freezing the clock over a merely-thin margin, with no
    // actual stall, would be wrong; this is purely a proactive signal for
    // adaptive quality to act on.
    @Volatile var onBufferMarginLow: (() -> Unit)? = null
    // Real, direct fix for a confirmed, severe bug: a non-seamless
    // transition happening reliably after 2 songs, traced directly in a
    // production log to browser/WebView timer throttling — Chrome (and
    // Android's Chromium-based WebView) aggressively throttles JS
    // setTimeout when the page is backgrounded (confirmed by the log's
    // own console warning about throttled background requests), which is
    // exactly the mechanism the next-track prefetch was scheduled with.
    // Confirmed directly: a prefetch scheduled 5 seconds into a track
    // didn't actually fire until nearly 190 seconds later — right as the
    // NEXT track was already starting, far too late to ever help. The
    // quality-adaptation system never had this problem because it's
    // driven entirely by native callbacks, not a JS timer — this callback
    // gives the prefetch scheduling the same immunity, by having native's
    // own playback thread (never subject to WebView timer throttling)
    // periodically nudge JS to check whether it's time to prefetch yet,
    // rather than trusting a JS-side setTimeout to fire on schedule.
    @Volatile var onPlaybackHeartbeat: (() -> Unit)? = null


    /** Called from the fetch thread as network chunks arrive — never blocks the caller for long (bounded queue aside), never touches the AudioTrack directly. */
    fun enqueue(bytes: ByteArray, sampleRate: Int, channels: Int, isFirstOfTrack: Boolean, isRetry: Boolean = false, isLastOfTrack: Boolean = false) {
        // Real, direct correction of my own previous fix. That fix (flush
        // on isFirstOfTrack) was built on a false assumption: that
        // isFirstOfTrack==true only ever meant "genuinely fresh stream,
        // queue is already empty anyway" or "retry of a failed attempt,
        // needs a flush." It missed a third, real case — a gapless
        // continuation's first chunk is ALSO isFirstOfTrack==true, but the
        // queue is DELIBERATELY non-empty right then, still holding the
        // previous track's final, legitimately-unplayed seconds. A device
        // log confirmed this directly: the flush fired at exactly that
        // moment and discarded the outgoing track's real ending. Reverted
        // to an explicit isRetry signal instead, set by JS only when this
        // really is a retry of a previously failed attempt at the same
        // position (see the fetch loop's own retry logic) — the one case
        // this was ever meant to handle, now the only case it actually
        // triggers on.
        if (isRetry) queue.clear()
        queue.put(Chunk(bytes, sampleRate, channels, isFirstOfTrack, isLastOfTrack))
    }

    fun setVolume(v: Float) {
        volumeMultiplier = v.coerceIn(0f, 1.5f)
    }

    fun start() {
        if (running.getAndSet(true)) return
        // See playbackEpoch's own comment above for the full design this
        // is part of — incremented here, exactly once per genuinely new
        // thread (not on the no-op path above, which is the correct
        // gapless-continuation case where the existing thread should keep
        // running under its own, still-valid epoch).
        playbackEpoch++
        // Real, direct fix for a subtle bug found on review, before it
        // ever shipped this way: capturing this value on the new thread
        // ITSELF (inside playbackLoop) rather than here is wrong —
        // Thread.start() is asynchronous, so there's a real gap between
        // incrementing this counter and the new thread actually beginning
        // to run. If another stop+start happened in that gap and bumped
        // the epoch again before this thread got scheduled, it would read
        // the NEWER value and wrongly believe itself current. Captured
        // here instead, on the main thread, at the exact moment this
        // specific thread is being created for — this is the value that
        // actually corresponds to this thread's own generation.
        val myEpoch = playbackEpoch
        Log.i(TAG, "start() called — creating playback thread")
        DebugOverlay.emit(TAG, "start() called — creating playback thread")
        try {
            val t = Thread({ playbackLoop(myEpoch) }, "NovaPlaybackThread")
            // Real, plausible risk found on review after a reported "nothing
            // plays" complaint: Thread.MAX_PRIORITY (10) is an extreme value —
            // a plain java.lang.Thread's priority is capped by its
            // ThreadGroup's own max, and behavior at the very top of that
            // range isn't guaranteed consistent across every Android version/
            // OEM. Not confirmed as THE cause without a real device log, but
            // it's a real, unnecessary risk for a benefit (a few priority
            // levels) that a much safer boost already provides. Dropped to a
            // modest, non-extreme boost above normal instead.
            t.priority = Thread.NORM_PRIORITY + 2
            playbackThread = t
            t.start()
            Log.i(TAG, "Playback thread started successfully")
            DebugOverlay.emit(TAG, "Playback thread started successfully")
        } catch (e: Throwable) {
            // Real gap this whole block fixes: if thread creation/priority
            // assignment ever throws, 'running' was already set true above,
            // permanently locking out any future start() call (the
            // getAndSet(true) guard would keep returning early) while no
            // thread actually exists to consume the queue — every enqueue()
            // after this point would eventually block forever once the
            // bounded queue fills, with nothing in the log to explain why.
            // Catching, logging loudly, and resetting the flag turns a
            // silent, permanent hang into a visible, recoverable failure.
            Log.e(TAG, "FAILED to start playback thread", e)
            DebugOverlay.emit(TAG, "FAILED to start playback thread")
            running.set(false)
        }
    }

    // Real, direct fix for a confirmed, severe bug: "AudioTrack.write error
    // code=-3" (ERROR_INVALID_OPERATION) appeared directly in a device log
    // during rapid seeking, and traced to an actual, confirmed cause —
    // stopAndFlush() is called from the 'start' message handler, which
    // WebViewCompat's bridge invokes on the main/UI thread, while
    // track.write() runs on this class's own dedicated playback thread —
    // with NO synchronization between them at all. A seek arriving while
    // the playback thread is mid-write can release the exact AudioTrack
    // instance that write() is actively writing to, out from under it. This
    // lock is what actually closes that race: every access to audioTrack
    // itself — creating it, writing to it, releasing it — now holds this
    // same lock, so those operations can never interleave. write() blocking
    // briefly under this lock is an acceptable, bounded cost (chunks are
    // ~32KB now, ~60ms of audio) — genuinely audible corruption from an
    // unsynchronized release is not.
    private val trackLock = Any()

    /** Stops playback and discards anything still queued — used for seek and track-switch, where whatever was queued is now stale. */
    // Real, direct correction of my own previous fix, which made things
    // worse: Thread.join() BLOCKS the calling thread until the target
    // exits (or the timeout hits) — and stopAndFlush runs on the main/UI
    // thread. If the old playback thread was genuinely stuck inside a
    // blocking AudioTrack.write() (which can happen for real — writing to
    // a PAUSED track's buffer, once full, never drains, since nothing is
    // consuming it), that join call froze the entire app's UI for up to
    // 500ms on every single pause/resume, repeatedly. Not the infinite
    // deadlock a join timeout is supposed to prevent, but a real,
    // confirmed regression on its own. Replaced with a non-blocking
    // design that achieves the same guarantee — no two playback threads
    // ever writing to the AudioTrack at once — without the calling thread
    // ever waiting on anything. Every playback thread captures its own
    // epoch number at creation; incrementing this on every start() makes
    // any previous thread's epoch instantly stale, and it checks that
    // before every single write — so a superseded thread stops writing
    // the moment it notices, on its own, with nothing else needing to
    // wait for or confirm it.
    @Volatile private var playbackEpoch = 0

    fun stopAndFlush(reason: String = "unspecified") {
        DebugOverlay.emit(TAG, "stopAndFlush called, reason=$reason")
        running.set(false)
        queue.clear()
        playbackThread?.interrupt()
        playbackThread = null
        // Real, direct addition for the new buffered playback path — this
        // function is the one shared "stop whatever's currently playing"
        // entry point (used by pause, and by a hard track switch), so it
        // needs to correctly stop EITHER kind of playback thread, not just
        // the original queue-based one. The buffered thread already checks
        // running.get() in its own loop condition, so setting that above is
        // enough for it to notice and exit on its own — interrupt() here
        // additionally unblocks it immediately if it's in its Thread.sleep
        // poll-wait rather than leaving it to wake up on the next poll.
        bufferedPlaybackThread?.interrupt()
        bufferedPlaybackThread = null
        // Real, direct fix for a suspected crash after "prev" started a
        // brand new track: this is the one shared entry point for a hard
        // track switch, but it never cleared a next-track prefetch left
        // over from whatever was playing before. That prefetch keeps
        // running on its own background thread regardless — without
        // clearing it here, it could still be actively writing bytes for
        // a track that's no longer relevant at all, and worse, could
        // still be sitting there ready to be swapped in by the NEW
        // track's own natural end, mixing in audio from a completely
        // different, stale track. A hard switch should always start with
        // a clean slate for this.
        //
        // Real, direct fix found and added here, alongside the file-backed
        // rewrite: this used to clear nextTrackBuffer unconditionally, on
        // EVERY call — including a plain pause, which also routes through
        // this same shared function. That wasted RAM before (an unrelated,
        // valid prefetch discarded and needing a full re-download later
        // for no real reason); with real files now backing this, the same
        // unconditional clear would mean deleting a perfectly good,
        // partially-downloaded file and re-fetching it over the network
        // from scratch every single time someone pauses and resumes. A
        // pause doesn't change which track comes next — only reasons that
        // genuinely represent switching to a different track should
        // discard this.
        if (reason != "nativePause") {
            nextTrackBuffer?.close()
            nextTrackBuffer = null
        }
        // Real, direct fix for a confirmed "static" complaint — a
        // spectrogram of an actual recording showed full-spectrum noise
        // (not distorted music, genuine noise) landing exactly during rapid
        // seeking, and the screen recording confirmed audio was already
        // coming out of the speaker before the new seek's real data had
        // even arrived. This used to fully RELEASE the AudioTrack on every
        // single seek, then build a brand new one moments later —
        // repeatedly tearing down and recreating the actual hardware audio
        // session, sometimes multiple times per second during rapid
        // seeking. Rapid AudioTrack create/destroy churn is a known stress
        // point for Android's audio HAL, particularly with
        // PERFORMANCE_MODE_LOW_LATENCY, which uses a limited, dedicated
        // hardware resource on many devices — a plausible, real source of
        // exactly this kind of noise. Pausing and flushing without
        // releasing keeps the same hardware session alive across a seek;
        // ensureTrackFor already only recreates when the format has
        // genuinely changed, so this doesn't affect that case at all —
        // only the seek-to-same-format case, which is by far the common
        // one, stops needlessly cycling the hardware every time.
        synchronized(trackLock) { pauseAndFlushTrack() }
    }

    // Real, direct addition after a confirmed report: skipping back
    // immediately after a track had JUST auto-advanced landed two
    // legitimate, distinct hardware transitions back-to-back within a
    // fraction of a second — the auto-advance's own cycle, then the skip's.
    // Neither is a duplicate to debounce away (both are real, intentional
    // actions), but back-to-back cycling this close together is the same
    // confirmed stress on Android's audio HAL as the rapid-seeking and
    // rapid-tapping cases already fixed. A brief, bounded wait here — only
    // when the hardware was cycled very recently — gives it a moment to
    // settle before doing it again, without ever dropping or ignoring the
    // action itself the way a debounce would.
    private var lastTrackCycleMs = 0L
    private val MIN_CYCLE_INTERVAL_MS = 120L

    private fun waitOutMinCycleInterval() {
        val sinceLast = System.currentTimeMillis() - lastTrackCycleMs
        if (sinceLast in 0 until MIN_CYCLE_INTERVAL_MS) {
            try { Thread.sleep(MIN_CYCLE_INTERVAL_MS - sinceLast) } catch (e: InterruptedException) { /* fine to proceed immediately if interrupted */ }
        }
        lastTrackCycleMs = System.currentTimeMillis()
    }

    private fun pauseAndFlushTrack() {
        waitOutMinCycleInterval()
        try {
            audioTrack?.let {
                it.pause()
                it.flush()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error pausing/flushing AudioTrack (non-fatal, proceeding)", e)
        }
    }

    private fun releaseTrack() {
        try {
            audioTrack?.let {
                it.pause()
                it.flush()
                it.release()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing AudioTrack (non-fatal, proceeding)", e)
        }
        audioTrack = null
        currentSampleRate = 0
        currentChannels = 0
    }

    private fun channelMaskFor(channels: Int): Int = when (channels) {
        1 -> AudioFormat.CHANNEL_OUT_MONO
        2 -> AudioFormat.CHANNEL_OUT_STEREO
        else -> AudioFormat.CHANNEL_OUT_STEREO // downmixed to stereo before reaching AudioTrack — see mixToStereo below
    }

    // Callers already hold trackLock (see the playback loop and
    // stopAndFlush) — this is never called on its own from outside that
    // lock, so it doesn't take it itself (would deadlock on re-entry
    // otherwise, since Kotlin's `synchronized` here isn't reentrant-safe
    // across a shared helper unless every caller already holds it).
    // Real, defensive addition after a second, unconfirmed static report
    // with no video evidence to pin down this time — reasoning through the
    // risk this fix's own predecessor introduced: keeping the same
    // AudioTrack alive across many seeks (the pause-instead-of-release
    // fix) avoids rapid create/destroy churn, but an instance paused,
    // flushed, and resumed many times in a row over a long session is
    // itself a usage pattern Android's AudioTrack isn't necessarily built
    // or tested for — state drift over many cycles is a real, unruled-out
    // possibility. This caps how many consecutive reuses one instance gets
    // before a genuine release+recreate, trading a small amount of the
    // churn-avoidance benefit for a periodic clean reset — a middle ground
    // between "recreate every time" (confirmed HAL stress) and "never
    // recreate" (unconfirmed but plausible long-run drift).
    private var trackReuseCount = 0
    private val MAX_TRACK_REUSES = 8

    private fun ensureTrackFor(sampleRate: Int, channels: Int) {
        val outChannels = if (channels > 2) 2 else channels // multichannel is downmixed in software before writing, see mixToStereo
        if (audioTrack != null && currentSampleRate == sampleRate && currentChannels == outChannels && trackReuseCount < MAX_TRACK_REUSES) {
            // The other half of the pause-instead-of-release fix above:
            // stopAndFlush leaves the track paused, not released, when the
            // format matches — but a paused AudioTrack silently accepts
            // write() calls into its buffer without ever actually making
            // sound until it's explicitly told to play again. Without this,
            // every seek would go fully silent forever after the first one
            // reused this same instance — checked directly against the
            // hardware's own play state rather than a separately tracked
            // flag that could drift out of sync with it.
            //
            // Real, severe bug just found and fixed here: trackReuseCount
            // used to increment on every call that reached this branch —
            // but this function runs once per ~32KB CHUNK, not once per
            // seek/resume. A single 60s segment is 900+ chunks, so the
            // reuse cap (8) was being hit within the first handful of
            // chunks of ANY playback, forcing a full release+recreate,
            // resetting to zero, and hitting the cap again moments later —
            // constantly, even during completely normal, uninterrupted
            // playback with no seeking involved at all. That's what
            // produced hundreds of rapid recreations and total silence.
            // Fixed by only counting an actual PAUSED-to-PLAYING
            // transition as a "reuse" — the one thing that genuinely
            // corresponds to a real pause/resume cycle — not every chunk
            // written while already playing normally.
            val track = audioTrack
            if (track != null && track.playState != AudioTrack.PLAYSTATE_PLAYING) {
                trackReuseCount++
                try { track.play() } catch (e: Exception) { Log.w(TAG, "Error resuming paused AudioTrack (non-fatal, proceeding)", e) }
            }
            return
        }
        trackReuseCount = 0
        waitOutMinCycleInterval()
        // Format actually changed (a new track with a different sample rate,
        // e.g. 44100 vs 48000, or mono vs stereo source) — AudioTrack can't be
        // reconfigured in place, a new one is required. This is the one place
        // true sample-accurate gaplessness isn't achievable even natively: a
        // brand new AudioTrack has its own brief hardware startup. Real,
        // measured precedent for this exact tradeoff (a small non-zero gap at
        // a format-changing track boundary, everything else genuinely gapless)
        // exists in real bit-perfect Android players — not something invented
        // for this app, but an honest, documented limit of the platform.
        releaseTrack()
        val channelMask = channelMaskFor(outChannels)
        val minBuf = AudioTrack.getMinBufferSize(sampleRate, channelMask, AudioFormat.ENCODING_PCM_16BIT)
        val bufSize = if (minBuf > 0) minBuf * MIN_BUFFER_MULTIPLIER else sampleRate * outChannels * 2 // 1s fallback if getMinBufferSize itself fails (documented as possible, e.g. unsupported format on some hardware)
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(channelMask)
                    .build()
            )
            .setBufferSizeInBytes(bufSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        track.play()
        audioTrack = track
        currentSampleRate = sampleRate
        currentChannels = outChannels
        Log.i(TAG, "AudioTrack (re)created: ${sampleRate}Hz, ${outChannels}ch out (source had $channels ch), bufSize=$bufSize")
        DebugOverlay.emit(TAG, "AudioTrack (re)created: ${sampleRate}Hz, ${outChannels}ch out (source had $channels ch), bufSize=$bufSize")
    }

    // Real, serious bug found from a direct report and confirmed with real
    // numbers from a device log: "First chunk received: 3565 bytes... 8ch"
    // — 3565 isn't a multiple of 16 (8 channels x 2 bytes/frame). Network
    // reads have no reason to land on audio frame boundaries; nothing here
    // ever accounted for that. Every chunk's leftover partial-frame bytes
    // were silently discarded, and the NEXT chunk started frame alignment
    // fresh from ITS byte 0 — which is actually partway into what should
    // have been a continuous frame. That shifts which bytes map to which
    // channel from that point on, repeatedly, at every single chunk
    // boundary throughout playback (not just once at the start) — scrambled
    // channel data exactly matches what "insane amounts of static" sounds
    // like, and explains why it persisted through two rounds of gain-stage
    // fixes that were never actually the problem. Carried across calls (not
    // reset per-chunk) and cleared specifically on a track/format change
    // (ensureTrackFor already detects that), since leftover bytes from a
    // different channel count would be meaningless to prepend to a new
    // stream.
    // ==================== Buffered (whole-track) playback ====================
    // See TrackBuffer's own class comment for the full design. This is a
    // parallel path to the queue-based one above — kept separate rather
    // than surgically rewritten into it, specifically to avoid risking the
    // many hard-won fixes already in the queue path (trackLock, the epoch
    // system, frame alignment) by entangling them with a fundamentally
    // different data source. Both paths share ensureTrackFor, processChunk,
    // and trackLock — only WHERE the bytes come from differs.
    @Volatile private var currentTrackBuffer: TrackBuffer? = null
    // Real, direct addition for a confirmed, evidence-backed bug: two
    // separate reports of a quality-triggered restart landing at the wrong
    // position — once replaying audio already heard, once skipping audio
    // never heard. Both traced to the same root cause: the JS side has no
    // way to know the true playback position except by extrapolating from
    // its own wall-clock guess, gated by a buffering-state signal that (per
    // a direct diagnostic log from the same investigation) can desync from
    // what native is actually doing during a stall. This exposes the one
    // thing that's never ambiguous — how many bytes of the CURRENT buffer
    // have actually been consumed — so a caller can compute the real
    // position directly, instead of trusting an extrapolation that depends
    // on a signal proven unreliable under real, evidenced conditions.
    fun getCurrentBufferCursorInfo(): Triple<Int, Int, Int>? {
        val buf = currentTrackBuffer ?: return null
        return Triple(buf.cursorBytes, buf.sampleRate, buf.channels)
    }
    @Volatile private var bufferedPlaybackThread: Thread? = null
    // Real, direct addition for true gapless playback, requested
    // explicitly: while the current track plays, the next one's audio can
    // be downloaded into this SEPARATE buffer ahead of time. When the
    // current one reaches its real end, the playback loop below checks
    // here FIRST — if this is ready, it swaps directly to it as the new
    // current buffer and keeps writing to the exact same AudioTrack,
    // same thread, no pause, no flush, no recreation. That's what makes
    // the transition genuinely seamless rather than merely correct.
    @Volatile private var nextTrackBuffer: TrackBuffer? = null
    @Volatile var onSeamlessTrackSwap: ((String, Int, Int, Int?) -> Unit)? = null

    /** Called to begin downloading the NEXT track's audio ahead of time, while the current one is still playing — does not affect what's currently playing at all. */
    fun prepareNextTrackBuffer(trackId: String, sampleRate: Int, channels: Int) {
        // Real, direct addition for the file-backed rewrite — a real file
        // needs an explicit close/delete or it leaks on disk exactly the
        // way the old in-memory version could leak RAM. Closes whatever
        // was here before (an abandoned prior prefetch, most likely)
        // before replacing it.
        nextTrackBuffer?.close()
        nextTrackBuffer = TrackBuffer(trackId, sampleRate, channels, cacheDir)
    }

    /** Called repeatedly as the next track's bytes arrive — silently ignored if trackId no longer matches (a stale, abandoned or already-consumed prefetch). */
    fun appendToNextTrackBuffer(trackId: String, bytes: ByteArray) {
        val buf = nextTrackBuffer
        if (buf == null || buf.trackId != trackId) return
        buf.append(bytes)
    }

    fun setNextTrackBufferTotalBytes(trackId: String, totalBytes: Int) {
        val buf = nextTrackBuffer
        if (buf == null || buf.trackId != trackId) return
        buf.totalBytes = totalBytes
    }

    /**
     * Real, direct fix for a confirmed "audio just stops, never advances,
     * UI never updates" report — traced to a real structural gap: totalBytes
     * only ever gets set from an X-PCM-Total-Frames response header, and if
     * that header is ever missing on every segment of a download for any
     * reason, there was NO OTHER WAY for the "reached the real end" check
     * to ever fire — the playback loop would poll forever with complete,
     * correctly-downloaded audio already sitting there, never able to
     * detect that nothing more was coming. This is a guaranteed fallback
     * that doesn't depend on that header at all: called when the download
     * loop independently confirms, from the actual data stream itself
     * (a genuinely empty response), that it's reached the real end — sets
     * totalBytes to whatever was actually downloaded, but ONLY if nothing
     * already set it correctly from the header, so a value that already
     * came from a legitimate, precise source is never overwritten.
     */
    fun ensureNextTrackBufferHasTotalBytes(trackId: String) {
        val buf = nextTrackBuffer
        if (buf == null || buf.trackId != trackId) return
        if (buf.totalBytes == null) buf.totalBytes = buf.downloadedBytes
    }

    /** Real, direct additions for the download-retry rollback fix — see TrackBuffer.truncateTo's own comment for the full design. Silently ignored if trackId no longer matches (the same staleness guard every other TrackBuffer accessor here already uses). */
    fun getNextTrackBufferDownloadedBytes(trackId: String): Int? {
        val buf = nextTrackBuffer
        if (buf == null || buf.trackId != trackId) return null
        return buf.downloadedBytes
    }
    fun truncateNextTrackBufferTo(trackId: String, bytes: Int) {
        val buf = nextTrackBuffer
        if (buf == null || buf.trackId != trackId) return
        buf.truncateTo(bytes)
    }

    /** The other half of the OOM/leak fix — explicitly discards whatever prefetch buffer exists, called on every hard track switch regardless of whether a new prefetch immediately follows. Closes and deletes its file, not just drops the reference — a dropped reference alone would leave the file orphaned on disk. */
    fun clearNextTrackBuffer() {
        nextTrackBuffer?.close()
        nextTrackBuffer = null
    }

    // ==================== Seamless mid-track quality swap ====================
    // Real, direct feature requested explicitly: a quality change (auto
    // downgrade/upgrade) used to call startTrackBuffer, which is a full
    // stop-and-restart of the CURRENT track — audible as a real interruption,
    // exactly the "buffers while playing instead of being seamless" complaint.
    // This is a completely SEPARATE, dedicated buffer slot from
    // nextTrackBuffer above — deliberately NOT sharing it, because
    // nextTrackBuffer is already in active use for the genuinely different
    // next QUEUED track's own prefetch for most of any track's playback (it
    // starts a few seconds in). Reusing that same slot for a same-track
    // quality swap would silently destroy whatever real next-track prefetch
    // was already in progress the moment a quality change happened — trading
    // one interruption for a worse one (a broken gapless transition to the
    // actual next song). A dedicated slot means a quality swap and a real
    // next-track prefetch can always coexist without conflict.
    @Volatile private var qualitySwapBuffer: TrackBuffer? = null
    // The position, in the CURRENT buffer's own byte space, at which to swap
    // to qualitySwapBuffer once it's ready — set by the bridge from the
    // JS-requested target position, converted to bytes there (see
    // getCurrentBufferCursorInfo's own comment for why that conversion has
    // to happen relative to this buffer's own start, not an absolute track
    // position).
    @Volatile private var qualitySwapTargetBytes: Int? = null
    // Fired the moment an in-place quality swap actually happens — separate
    // from onSeamlessTrackSwap since this is explicitly NOT a track change:
    // no metadata update, no scrobble reset, no "now playing" side effects,
    // just the audio format itself (sample rate/channels) changing under
    // the same, uninterrupted playback.
    @Volatile var onQualityChanged: ((Int, Int) -> Unit)? = null

    fun setPendingQualitySwapTarget(targetBytes: Int) { qualitySwapTargetBytes = targetBytes }

    /** Mirrors prepareNextTrackBuffer's own design exactly, just for the dedicated quality-swap slot. */
    fun prepareQualitySwapBuffer(trackId: String, sampleRate: Int, channels: Int) {
        qualitySwapBuffer?.close()
        qualitySwapBuffer = TrackBuffer(trackId, sampleRate, channels, cacheDir)
    }
    fun appendToQualitySwapBuffer(trackId: String, bytes: ByteArray) {
        val buf = qualitySwapBuffer
        if (buf == null || buf.trackId != trackId) return
        buf.append(bytes)
    }
    fun setQualitySwapBufferTotalBytes(trackId: String, totalBytes: Int) {
        val buf = qualitySwapBuffer
        if (buf == null || buf.trackId != trackId) return
        buf.totalBytes = totalBytes
    }
    fun ensureQualitySwapBufferHasTotalBytes(trackId: String) {
        val buf = qualitySwapBuffer
        if (buf == null || buf.trackId != trackId) return
        if (buf.totalBytes == null) buf.totalBytes = buf.downloadedBytes
    }
    fun getQualitySwapBufferDownloadedBytes(trackId: String): Int? {
        val buf = qualitySwapBuffer
        if (buf == null || buf.trackId != trackId) return null
        return buf.downloadedBytes
    }
    fun truncateQualitySwapBufferTo(trackId: String, bytes: Int) {
        val buf = qualitySwapBuffer
        if (buf == null || buf.trackId != trackId) return
        buf.truncateTo(bytes)
    }
    // Fired the instant clearQualitySwapBuffer actually had something to
    // cancel — see that function's own comment. Lets the bridge invalidate
    // whatever quality-swap download is currently in flight (its own
    // generation counter, separate from this engine entirely — the engine
    // has no way to reach it directly), so an abandoned swap's download
    // thread actually stops instead of running to completion for no
    // reason once nothing can ever consume what it downloads.
    @Volatile var onQualitySwapCancelled: (() -> Unit)? = null
    /** Called whenever a genuinely new/restarted CURRENT track begins (from startTrackBuffer), a seamless track-to-track swap happens, or a manual seek moves playback to a position a pending swap's target/overshoot math was never computed for — a pending quality swap for whatever was true before any of those is now meaningless and must never be allowed to fire against a position or buffer it no longer relates to. */
    fun clearQualitySwapBuffer() {
        val hadSomethingToCancel = qualitySwapBuffer != null || qualitySwapTargetBytes != null
        qualitySwapBuffer?.close()
        qualitySwapBuffer = null
        qualitySwapTargetBytes = null
        if (hadSomethingToCancel) onQualitySwapCancelled?.invoke()
    }

    /**
     * Starts (or restarts) buffered playback for a track. Creates a fresh
     * TrackBuffer, launches the download-consuming playback thread under a
     * new epoch (same non-blocking staleness mechanism as the queue path —
     * see playbackEpoch's own comment), and points the read cursor at the
     * requested start position. Does NOT itself fetch any bytes — that's
     * driven separately by repeated appendToTrackBuffer calls from the
     * network download thread, decoupled from playback position entirely.
     */
    fun startTrackBuffer(trackId: String, sampleRate: Int, channels: Int, startAtByteOffset: Int) {
        val bytesPerFrame = channels * 2
        val alignedStart = (startAtByteOffset / bytesPerFrame) * bytesPerFrame // frame-aligned, same reasoning as the queue path's own frame alignment
        // Real, direct addition alongside the seamless quality-swap feature —
        // see clearQualitySwapBuffer's own comment. Any pending swap was
        // computed against whatever track/position was playing before this
        // call; once a genuinely new or restarted current track begins, that
        // target is meaningless and must not be allowed to fire later against
        // buffer bytes it was never actually meant for.
        clearQualitySwapBuffer()
        // Real, direct fix for the same reason as prepareNextTrackBuffer
        // above — closes and deletes whatever the PREVIOUS currentTrackBuffer
        // pointed at (an old track, or an earlier position of the same
        // track before a deep-seek restart) before replacing it, so its
        // file doesn't linger on disk once nothing references it anymore.
        currentTrackBuffer?.close()
        // Real, direct fix for a confirmed "volume drops too much partway
        // through" report — limiterGainState is a single, engine-wide
        // variable with no per-stream scope of its own; it was never reset
        // anywhere. Its whole purpose is to remember "how much gain
        // reduction was recently needed" — but that memory stops being
        // meaningful the moment playback jumps to a genuinely different
        // position (a fresh track, or a seek elsewhere in the same one).
        // Carrying over gain reduction from whatever content played right
        // before a restart, into content that may not need any reduction
        // at all, is a real, direct way to make something sound quieter
        // than it should for a period afterward while the release time
        // constant slowly recovers it back toward full volume.
        //
        // Reset to the limiter's own threshold (a modest -6dB headstart),
        // not all the way to 1.0f (no reduction at all) — a confirmed,
        // direct side effect of resetting to full: whatever reduction the
        // PREVIOUS track happened to leave behind was, by accident, also
        // providing the only real protection against a loud transient in
        // the first few milliseconds of a NEW track — a genuine limiter
        // can only react to a peak after it starts arriving, not before,
        // so a hard reset to 1.0f meant the very first samples of a loud
        // track had no protection at all. Starting at the threshold
        // releases back to full within about 100ms if the track turns out
        // to be quiet, while giving real, immediate protection if it's
        // loud right from the start — without reintroducing the original
        // bug of carrying over an arbitrary, unrelated value indefinitely.
        limiterGainState = 0.5012f
        currentTrackBuffer = TrackBuffer(trackId, sampleRate, channels, cacheDir)
        currentTrackBuffer?.cursorBytes = alignedStart
        // Real, direct fix for a confirmed "had to pause and press play to
        // get it to actually play, then crackled" report — traced through
        // to the actual gap: the earlier stopAndFlush that stops whatever
        // was playing before this new track PAUSES the hardware rather
        // than tearing it down (a deliberate, separate fix for a real
        // static/noise issue from rapid AudioTrack recreation) — but
        // nothing then explicitly resumes it for the new track. The only
        // thing that normally does is ensureTrackFor's own play() call,
        // which only runs once the first chunk is actually processed. If
        // this new track's download is at all slow to get going — exactly
        // what happens right after a rapid, back-to-back transition like a
        // track ending with zero real playback duration — the hardware
        // can sit paused indefinitely with nothing to wake it, even once
        // data does start arriving and gets written into it. A manual
        // pause+resume happened to fix this because nativeResume() routes
        // through a seek, and seeking explicitly forces the hardware to
        // play — but a new track starting shouldn't need to depend on
        // that. Explicitly resumed here, immediately, so playback is never
        // waiting on data to arrive before the hardware is even ready to
        // make sound with it — this is also the most direct explanation
        // for the reported crackle: whatever had already been written
        // into a paused AudioTrack's buffer before the user's manual
        // resume forced it to finally start would play back all at once,
        // as a single discontinuous burst, rather than smoothly as it
        // arrived.
        // Real, direct fix for a confirmed static/noise report — found a
        // genuine race in the ORIGINAL version of this fix (see the long
        // comment above): it resumed the EXISTING hardware track
        // unconditionally, with no regard for whether the format about to
        // arrive actually matches it. Adaptive quality's own restart is
        // exactly the case that breaks this — the new track's sample rate
        // can genuinely differ from the old one (a real quality
        // downgrade), which means ensureTrackFor is about to release and
        // recreate this exact same track, on a DIFFERENT thread, the
        // moment the first chunk of new-format data arrives. Resuming a
        // track that's concurrently about to be released is a genuine
        // race, and a very plausible source of an audible burst of noise
        // as the hardware transitions through an inconsistent state.
        // Skipped here whenever the format is changing — ensureTrackFor's
        // own clean release-then-create sequence already handles that
        // case correctly and completely on its own; this resume is only
        // useful, and only safe, when the format staying the same means
        // the SAME track will actually still be used.
        val outChannelsForResumeCheck = if (channels > 2) 2 else channels
        if (currentSampleRate == sampleRate && currentChannels == outChannelsForResumeCheck) {
            synchronized(trackLock) { try { audioTrack?.play() } catch (e: Exception) { Log.w(TAG, "Error resuming AudioTrack for new buffered track (non-fatal, proceeding)", e) } }
        }
        playbackEpoch++
        val myEpoch = playbackEpoch
        running.set(true)
        val t = Thread({ bufferedPlaybackLoop(myEpoch, trackId) }, "NovaBufferedPlaybackThread")
        t.priority = Thread.NORM_PRIORITY + 2
        bufferedPlaybackThread = t
        t.start()
    }

    /** Called repeatedly by the network download thread as bytes arrive — silently ignored if trackId no longer matches the current buffer (a stale, abandoned download). */
    fun appendToTrackBuffer(trackId: String, bytes: ByteArray) {
        val buf = currentTrackBuffer
        if (buf == null || buf.trackId != trackId) return
        buf.append(bytes)
    }

    /** Called once the server reports the track's true total byte count, so end-of-track can be detected precisely rather than only inferred from the download finishing. */
    fun setTrackBufferTotalBytes(trackId: String, totalBytes: Int) {
        val buf = currentTrackBuffer
        if (buf == null || buf.trackId != trackId) return
        buf.totalBytes = totalBytes
    }

    /** The main-buffer counterpart to ensureNextTrackBufferHasTotalBytes above — same guaranteed fallback, same reasoning. */
    fun ensureTrackBufferHasTotalBytes(trackId: String) {
        val buf = currentTrackBuffer
        if (buf == null || buf.trackId != trackId) return
        if (buf.totalBytes == null) buf.totalBytes = buf.downloadedBytes
    }

    /** The main-download counterpart to the two nextTrackBuffer versions above — same design, same reasoning. */
    fun getTrackBufferDownloadedBytes(trackId: String): Int? {
        val buf = currentTrackBuffer
        if (buf == null || buf.trackId != trackId) return null
        return buf.downloadedBytes
    }
    fun truncateTrackBufferTo(trackId: String, bytes: Int) {
        val buf = currentTrackBuffer
        if (buf == null || buf.trackId != trackId) return
        buf.truncateTo(bytes)
    }

    /**
     * The actual fix. If the target position is already downloaded, this
     * is a pure in-memory operation: move the read cursor, flush the
     * AudioTrack's own hardware buffer (still the SAME instance — no
     * release, no recreate, no new thread) so the new position is heard
     * immediately instead of after whatever stale audio was already
     * queued drains first, and return true. Returns false if the target
     * isn't downloaded yet, so the caller can fall back to the old,
     * genuinely-destructive restart path for that one, rarer case.
     */
    fun seekWithinBuffer(trackId: String, byteOffset: Int): Boolean {
        val buf = currentTrackBuffer ?: return false
        if (buf.trackId != trackId) return false
        if (byteOffset > buf.downloadedBytes) return false
        val bytesPerFrame = buf.channels * 2
        buf.cursorBytes = (byteOffset / bytesPerFrame) * bytesPerFrame
        // Real, direct fix for a confirmed, serious gap found by direct
        // request to check exactly this interaction: a pending quality
        // swap's target position and overshoot-correction math are both
        // computed assuming CONTINUOUS, natural playback progression from
        // wherever it was set. A manual seek breaks that assumption
        // entirely — an arbitrary cursor jump with no relationship to the
        // gradual advance the target was chosen against. Left unfixed, a
        // forward seek past a stale target would fire the swap
        // immediately using overshoot math computed against a position
        // that has nothing to do with where the user just jumped to,
        // landing on a wildly wrong, confusing position right after a
        // deliberate seek. Same fix as startTrackBuffer's and the
        // seamless track-swap's own copies of this call — any of the
        // three genuine "position no longer relates to what a pending
        // swap was computed for" events needs it.
        clearQualitySwapBuffer()
        // Real, direct addition for a genuine, separate gap found while
        // investigating a volume report — not the actual root cause of that
        // one (traced instead to a server-side gain mismatch, unrelated to
        // seeking), but a real gap regardless: an in-track seek jumps
        // playback to a position whose audio content is unrelated to
        // whatever was playing right before it, same as a fresh track
        // start or a seamless swap — both of which already reset this for
        // exactly that reason. A seek was the one remaining way to reach a
        // genuinely different position without this reset ever running.
        limiterGainState = 0.5012f
        // Real, direct fix for a confirmed architectural gap, found while
        // investigating a genuine "running became false" report: this used
        // to only move the cursor and flush the hardware, silently
        // assuming the buffered playback thread consuming that cursor was
        // still alive. If it wasn't — paused, or stopped for any other
        // reason — this would still report success while nothing was
        // actually left running to read from the buffer at all: audible
        // silence disguised as a successful seek. Restarting the
        // consuming thread here if it's not running (reusing the same
        // TrackBuffer already in place, not re-downloading anything) is
        // what makes a resume-after-pause through this path actually work
        // instead of silently doing nothing.
        // Real, direct fix for a confirmed static complaint, traced
        // directly to a spectrogram of an actual recording showing sharp
        // transient spikes followed by broadband noise, landing exactly
        // where the matching log shows a fallback restart happening right
        // before a genuine pause — two real hardware cycles back-to-back.
        // This function cycles the SAME AudioTrack hardware (pause/flush/
        // play, or a full thread+track restart) just like every other
        // path that already goes through waitOutMinCycleInterval — this
        // one simply never did, a real gap left over from building this
        // whole buffered path as something separate from the older code.
        if (!running.get()) {
            DebugOverlay.emit(TAG, "seekWithinBuffer: playback thread wasn't running — restarting it for trackId=$trackId")
            waitOutMinCycleInterval()
            playbackEpoch++
            val myEpoch = playbackEpoch
            running.set(true)
            val t = Thread({ bufferedPlaybackLoop(myEpoch, trackId) }, "NovaBufferedPlaybackThread")
            t.priority = Thread.NORM_PRIORITY + 2
            bufferedPlaybackThread = t
            t.start()
            return true
        }
        synchronized(trackLock) {
            waitOutMinCycleInterval()
            try {
                audioTrack?.let { it.pause(); it.flush(); it.play() }
            } catch (e: Exception) {
                Log.w(TAG, "Error flushing AudioTrack during in-buffer seek (non-fatal, proceeding)", e)
            }
        }
        return true
    }

    private fun bufferedPlaybackLoop(myEpoch: Int, trackId: String) {
        Log.i(TAG, "bufferedPlaybackLoop thread running for trackId=$trackId")
        DebugOverlay.emit(TAG, "bufferedPlaybackLoop thread running for trackId=$trackId")
        var firstChunkOfThisThread = true
        // Real, direct addition for a confirmed "constantly skipping out,
        // unbearable to listen to" complaint — traced to a genuine design
        // gap: playback used to begin the instant a single byte arrived,
        // with no safety margin at all built up first. That's fine on a
        // fast, steady connection, but leaves zero cushion against even a
        // brief slowdown — exactly the described symptom. This gate
        // requires a real few seconds of audio to be downloaded before
        // this FRESH thread start begins actually reading and playing —
        // never reset back to true on a seamless swap (see the comment at
        // its reset site below), since by the time a swap happens the next
        // track's own download has typically already been running for
        // this whole track's length and doesn't need an extra gate.
        var needsPrebuffer = true
        // Real, direct fix for a confirmed, serious feedback-loop bug: a
        // quality swap with any real overshoot advances the NEW buffer's
        // own cursor to compensate (see the overshoot-correction comment
        // at its own call site) — but if that advance lands ahead of what
        // the new buffer has actually downloaded so far (confirmed
        // directly in a production log: cursor=1359872 against
        // downloadedBytes=522744, right after a swap), the very next
        // iteration falls into the normal wait-for-data path with
        // needsPrebuffer already false — meaning this entirely
        // self-inflicted, expected catch-up wait got counted as a genuine
        // connection struggle. That's a real feedback loop: an upgrade's
        // own overshoot-correction wait could itself trigger the very next
        // downgrade, on a connection that never actually had a problem.
        // Mirrors needsPrebuffer's own role exactly — true from the moment
        // a swap's overshoot correction lands ahead of the new buffer's
        // downloaded data, cleared the moment a real read actually
        // succeeds, and excluded from struggle-signal counting the entire
        // time, same reasoning as the initial-ramp-up exclusion.
        var needsQualitySwapCatchup = false
        // Real, direct addition for the buffering-stall clock-drift fix —
        // see onBufferingStateChanged's own comment for the full reasoning.
        // Tracks whether THIS thread is currently in the "waiting for more
        // download data" state, so the transition INTO and OUT OF it (not
        // every single poll iteration) is what actually gets reported.
        var isCurrentlyBuffering = false
        val readSize = 32 * 1024
        // Real, direct fix needed for seamless track swaps — this used to
        // check the buffer against the trackId PARAMETER, fixed for the
        // whole life of this thread. A seamless swap changes which track
        // is actually playing out from under this same thread — without
        // tracking that change locally, the very next iteration's own
        // staleness check would see the new buffer's different trackId
        // and incorrectly treat it as "superseded," exiting right after
        // the swap it was supposed to make invisible.
        var activeTrackId = trackId
        var lastWaitingLogMs = 0L
        // Real, direct addition for the proactive low-margin warning —
        // throttled the same way, and for the same reason, as the
        // periodic "still waiting" diagnostic: this fires on every chunk
        // read while the margin stays low, which could otherwise flood
        // both the debug panel and the JS-side handler with far more
        // calls than the signal actually needs.
        var lastMarginLowNotifyMs = 0L
        // Real, direct addition alongside onPlaybackHeartbeat's own
        // comment above — throttled to roughly once every 3 seconds of
        // wall-clock time, same pattern as the other periodic signals in
        // this loop, so it nudges JS often enough to catch a due prefetch
        // promptly without flooding the bridge with a call on every single
        // chunk read.
        var lastHeartbeatMs = 0L
        try {
        while (running.get() && myEpoch == playbackEpoch) {
            // The actual fix — see onPlaybackHeartbeat's own comment above.
            // Checked unconditionally on every loop iteration, regardless
            // of buffering state, since a WebView-backgrounded prefetch
            // timer is exactly as broken during smooth playback as during
            // a stall — this doesn't wait for a buffering signal to piggy-
            // back on, because smooth playback (no buffering signals at
            // all) is precisely the case that starved before.
            val nowHeartbeatMs = System.currentTimeMillis()
            if (nowHeartbeatMs - lastHeartbeatMs > 3000) {
                lastHeartbeatMs = nowHeartbeatMs
                onPlaybackHeartbeat?.invoke()
            }
            val buf = currentTrackBuffer
            if (buf == null || buf.trackId != activeTrackId) {
                // Real, direct diagnostic addition after a confirmed
                // premature-exit report: this loop can exit for four
                // genuinely different reasons, and nothing distinguished
                // between them — this is exactly the kind of ambiguity
                // that leads to another round of guessing instead of
                // fixing the actual cause. Every exit path now logs
                // specifically which condition fired.
                DebugOverlay.emit(TAG, "bufferedPlaybackLoop EXIT REASON: buffer null or trackId mismatch (buf=${buf?.trackId}, expected=$activeTrackId)")
                break
            }
            val cursor = buf.cursorBytes
            // The actual seamless quality-swap trigger — see
            // qualitySwapTargetBytes's own comment for the full design.
            // Checked here, BEFORE the normal available/wait handling
            // below, so a swap can happen the moment its target position
            // is reached regardless of whether the OLD buffer still has
            // more data sitting ahead of it — continuing to drain an
            // already-downloaded backlog at the OLD quality would defeat
            // the point of a downgrade specifically meant to relieve a
            // struggling connection promptly. If the new buffer isn't
            // actually ready yet (still null — its own download hasn't
            // gotten its headers back), this simply falls through to
            // normal playback of the OLD buffer for this iteration and
            // checks again next time, swapping as soon as both the target
            // is reached AND the new buffer exists, whichever is later.
            val qTarget = qualitySwapTargetBytes
            if (qTarget != null && cursor >= qTarget) {
                val swapBuf = qualitySwapBuffer
                if (swapBuf != null && swapBuf.trackId == activeTrackId) {
                    // Real, direct fix for a confirmed, serious flaw caught
                    // by direct request to re-check this exact mechanism
                    // for the same class of bug the old restart path had.
                    // If swapBuf wasn't ready the INSTANT cursor first
                    // reached qTarget, the OLD buffer correctly kept
                    // playing while waiting — but that means cursor can be
                    // well PAST qTarget by the time this actually fires.
                    // swapBuf's own cursor starts at 0, which corresponds
                    // to the ORIGINAL target position, not wherever
                    // playback has actually reached by now — swapping
                    // unconditionally would replay everything played from
                    // the old buffer during that wait, at the new quality.
                    // Fixed by advancing the new buffer's own cursor by
                    // the equivalent overshoot, computed in TIME (seconds)
                    // rather than bytes, since the two buffers can have
                    // entirely different sample rates or channel counts —
                    // a direct byte-for-byte carry-over would be wrong
                    // whenever the quality change actually changes the
                    // format, which is the normal case, not an edge case.
                    val overshootBytes = cursor - qTarget
                    if (overshootBytes > 0) {
                        val oldBytesPerFrame = buf.channels * 2
                        val oldBytesPerSecond = buf.sampleRate * oldBytesPerFrame
                        if (oldBytesPerSecond > 0) {
                            val overshootSeconds = overshootBytes.toDouble() / oldBytesPerSecond
                            val swapBytesPerFrame = swapBuf.channels * 2
                            var swapAdvanceBytes = (overshootSeconds * swapBuf.sampleRate * swapBytesPerFrame).toInt()
                            swapAdvanceBytes = (swapAdvanceBytes / swapBytesPerFrame) * swapBytesPerFrame
                            swapBuf.cursorBytes = swapAdvanceBytes
                            // See needsQualitySwapCatchup's own comment
                            // above — this is the exact moment that
                            // condition can arise: the corrected cursor
                            // landing ahead of what's actually downloaded.
                            if (swapAdvanceBytes > swapBuf.downloadedBytes) {
                                needsQualitySwapCatchup = true
                            }
                            val catchupNote = if (needsQualitySwapCatchup) " — this lands ahead of the new buffer's own downloaded data (downloadedBytes=${swapBuf.downloadedBytes}), so the resulting wait will NOT be counted as a connection struggle" else ""
                            DebugOverlay.emit(TAG, "bufferedPlaybackLoop: quality swap overshoot correction — old buffer overshot target by $overshootBytes bytes (${"%.3f".format(overshootSeconds)}s) while waiting for the new buffer; advancing new buffer's own cursor by $swapAdvanceBytes bytes to compensate, avoiding a repeat$catchupNote")
                        }
                    }
                    DebugOverlay.emit(TAG, "bufferedPlaybackLoop: seamless quality swap for trackId=$activeTrackId at cursor=$cursor (target=$qTarget), new format ${swapBuf.sampleRate}Hz/${swapBuf.channels}ch")
                    buf.close()
                    currentTrackBuffer = swapBuf
                    qualitySwapBuffer = null
                    qualitySwapTargetBytes = null
                    // Same reasoning as every other buffer replacement in
                    // this file — a genuinely different stream (new
                    // sample rate/channel config, new server-side
                    // encode) starting mid-playback needs the same
                    // protection against unprotected first-sample
                    // clipping a fresh track start gets.
                    limiterGainState = 0.5012f
                    onQualityChanged?.invoke(swapBuf.sampleRate, swapBuf.channels)
                    continue
                }
            }
            val available = buf.downloadedBytes - cursor
            if (available <= 0) {
                // Caught up to the download — genuinely done if the total
                // is known and we've reached it, otherwise just waiting on
                // more network data. Polling rather than a blocking queue
                // here specifically because the data source (this same
                // growable array) can change shape (grow) at any time from
                // another thread, which a blocking take() has no way to
                // observe.
                val total = buf.totalBytes
                if (total != null && cursor >= total) {
                    // The actual seamless-swap point. Reaching here is only
                    // possible after every real byte of the CURRENT track
                    // has already been through the blocking AudioTrack.write()
                    // below (this check runs at the top of the next loop
                    // iteration, after that write already returned) — so this
                    // can never fire early, never based on a timer or on the
                    // next track merely being ready. It fires exactly when,
                    // and only when, this track's own last byte has genuinely
                    // been submitted. That guarantee is what makes it safe to
                    // immediately continue into the next track's first bytes
                    // on the same AudioTrack instead of stopping — the two
                    // queue back-to-back in the hardware's own buffer with no
                    // gap, the same principle the old engine's gapless
                    // transitions already relied on.
                    val next = nextTrackBuffer
                    if (next != null) {
                        DebugOverlay.emit(TAG, "bufferedPlaybackLoop: seamless swap to trackId=${next.trackId} (current track's own real end genuinely reached)")
                        // Real, direct addition for the file-backed rewrite —
                        // buf here is the track that JUST finished, about to
                        // be discarded in favor of next. Its file needs an
                        // explicit close/delete, same reasoning as every
                        // other TrackBuffer replacement in this file — a
                        // dropped reference alone would leave it orphaned on
                        // disk.
                        buf.close()
                        currentTrackBuffer = next
                        // Same reset, same reasoning, as startTrackBuffer's
                        // own comment — a seamless swap is a genuinely new
                        // track beginning, just without an audible seam,
                        // and doesn't route through startTrackBuffer at
                        // all, so this needed its own copy of the fix
                        // (including the follow-up fix to reset to the
                        // threshold rather than 1.0f, to avoid unprotected
                        // clipping on this new track's own first samples).
                        limiterGainState = 0.5012f
                        nextTrackBuffer = null
                        // Same reasoning as startTrackBuffer's own copy of
                        // this call — a seamless track-to-track swap is
                        // ALSO a genuinely new track beginning, and doesn't
                        // route through startTrackBuffer at all, so it
                        // needed its own copy of this fix too.
                        clearQualitySwapBuffer()
                        next.cursorBytes = 0
                        activeTrackId = next.trackId
                        firstChunkOfThisThread = true // the next track's own first chunk should still fire onTrackBoundaryReached, for now-playing/metadata updates — just without any audible seam
                        onSeamlessTrackSwap?.invoke(next.trackId, next.sampleRate, next.channels, next.totalBytes)
                        continue
                    }
                    DebugOverlay.emit(TAG, "bufferedPlaybackLoop EXIT REASON: reached known total (cursor=$cursor, total=$total, downloadedBytes=${buf.downloadedBytes}), no next track buffer ready")
                    onTrackEndReached?.invoke()
                    break
                }
                if (!isCurrentlyBuffering) {
                    isCurrentlyBuffering = true
                    onBufferingStateChanged?.invoke(true, !needsPrebuffer && !needsQualitySwapCatchup)
                }
                try { Thread.sleep(30) } catch (e: InterruptedException) {
                    DebugOverlay.emit(TAG, "bufferedPlaybackLoop EXIT REASON: interrupted while waiting for more download (cursor=$cursor, downloadedBytes=${buf.downloadedBytes}, total=$total)")
                    break
                }
                // Real, direct diagnostic addition after a confirmed "still
                // doing it" report where the log simply went silent with no
                // error at all — this specific poll-and-wait branch never
                // logged anything while waiting, only on the way out. If
                // this loop is genuinely stuck here — the download stalled
                // and nothing is arriving — that would look EXACTLY like
                // silence with nothing further in the log, which is what
                // was reported. This makes that state visible instead of
                // indistinguishable from "everything is fine, just idle for
                // a moment" — logged periodically (every ~2s), not every
                // 30ms poll, so it doesn't flood the panel.
                val nowMs = System.currentTimeMillis()
                if (nowMs - lastWaitingLogMs > 2000) {
                    lastWaitingLogMs = nowMs
                    DebugOverlay.emit(TAG, "bufferedPlaybackLoop: still waiting for more download data (cursor=$cursor, downloadedBytes=${buf.downloadedBytes}, total=$total, trackId=$activeTrackId)")
                }
                continue
            }
            val bytesPerFrame = buf.channels * 2
            // The actual prebuffer gate — see needsPrebuffer's own comment
            // above for the full reasoning. Targets a real few seconds of
            // audio, computed from this stream's own actual byte rate
            // (so it scales correctly across sample rates and channel
            // counts, not a fixed byte count that would mean wildly
            // different durations for different streams) — but never
            // waits past a track that's already fully, entirely
            // downloaded and simply shorter than the target itself.
            if (needsPrebuffer) {
                val bytesPerSecond = buf.sampleRate * bytesPerFrame
                // Real, direct fix for a confirmed follow-up: raised from 5
                // to 15 seconds after a real, direct report that skipping
                // was STILL happening at forced full quality, meaning the
                // adaptive-quality system (which only runs under 'auto')
                // wasn't even in play here — this is purely about the
                // margin itself being too thin for how unstable this
                // connection/server has actually been (real 502s, timeouts,
                // and exceptions confirmed in the same logs). A bigger
                // upfront cushion means a slow or flaky stretch has more
                // room to happen without ever actually catching up to
                // playback.
                val prebufferTargetBytes = bytesPerSecond * 15 // ~15 seconds of real cushion before playback begins
                val trackFullyDownloaded = buf.totalBytes != null && buf.downloadedBytes >= buf.totalBytes!!
                if (buf.downloadedBytes < prebufferTargetBytes && !trackFullyDownloaded) {
                    if (!isCurrentlyBuffering) {
                        isCurrentlyBuffering = true
                        onBufferingStateChanged?.invoke(true, false) // always the initial ramp-up by definition — needsPrebuffer is guaranteed true to even be inside this block
                    }
                    try { Thread.sleep(30) } catch (e: InterruptedException) { break }
                    continue
                }
                needsPrebuffer = false
            }
            val toRead = minOf(available, readSize).let { (it / bytesPerFrame) * bytesPerFrame } // frame-aligned read, same reasoning as the queue path
            if (toRead <= 0) { try { Thread.sleep(30) } catch (e: InterruptedException) { break }; continue }
            // See needsQualitySwapCatchup's own comment above — a
            // successful read this point onward means the buffer has
            // genuinely caught up to the overshoot-corrected cursor, so
            // any FUTURE wait is a real, new event again, not the
            // self-inflicted catch-up this flag exists to exclude.
            needsQualitySwapCatchup = false
            if (isCurrentlyBuffering) {
                isCurrentlyBuffering = false
                onBufferingStateChanged?.invoke(false, !needsPrebuffer)
            }
            // The actual proactive check — see onBufferMarginLow's own
            // comment for the full reasoning. Computed fresh here, not
            // reused from the prebuffer's own target, since this needs to
            // reflect this stream's actual current byte rate at the point
            // of an ongoing read, not a one-time startup gate.
            val bytesPerSecondNow = buf.sampleRate * bytesPerFrame
            // Real, direct fix, same follow-up as the prebuffer target
            // above — raised from 5 to 15 seconds so this margin actually
            // matches the bigger upfront cushion; leaving this one small
            // while only raising the prebuffer would have meant a bigger
            // head start that still gets eaten away just as fast once
            // playback is actually underway.
            val lowMarginThresholdBytes = bytesPerSecondNow * 15 // same ~15 second target as the prebuffer gate, but re-armed continuously through playback instead of a one-time startup check
            if (available < lowMarginThresholdBytes) {
                val nowMs = System.currentTimeMillis()
                if (nowMs - lastMarginLowNotifyMs > 3000) {
                    lastMarginLowNotifyMs = nowMs
                    onBufferMarginLow?.invoke()
                }
            }
            val chunkBytes = buf.readAt(cursor, toRead)
            val isFirstChunk = firstChunkOfThisThread
            if (isFirstChunk) {
                onTrackBoundaryReached?.invoke()
                firstChunkOfThisThread = false
            }
            val processed = processChunk(chunkBytes, buf.channels, buf.sampleRate, isFirstChunk)
            synchronized(trackLock) {
                ensureTrackFor(buf.sampleRate, buf.channels)
                val track = audioTrack
                if (track == null) {
                    Log.e(TAG, "audioTrack is null after ensureTrackFor — dropping this chunk, this should never happen")
                    return@synchronized
                }
                var offset = 0
                while (offset < processed.size && running.get() && myEpoch == playbackEpoch) {
                    val written = track.write(processed, offset, processed.size - offset)
                    if (written < 0) {
                        Log.e(TAG, "AudioTrack.write error code=$written")
                        DebugOverlay.emit(TAG, "AudioTrack.write error code=$written")
                        onUnderrun?.invoke()
                        break
                    }
                    offset += written
                }
            }
            // Only advance the cursor by what THIS thread actually wrote —
            // a concurrent seekWithinBuffer call could have moved buf's own
            // cursorBytes out from under this thread while it was blocked
            // inside the write above; re-reading and blindly advancing from
            // the CURRENT value (rather than the `cursor` this iteration
            // started with) would silently un-do that seek. Now checked
            // against buf.cursorBytes specifically (this buffer's own
            // field, not a shared one) — the real, architectural fix for a
            // confirmed "still buffering" report: a stale thread still
            // finishing up for a PREVIOUS, different buffer instance can no
            // longer possibly satisfy this check at all, since it's
            // comparing against a completely different object's field now,
            // not one shared value every track's thread could all touch.
            if (buf.cursorBytes == cursor) buf.cursorBytes = cursor + toRead
        }
        } catch (e: Exception) {
            // Real, direct safety net added after a reported app crash
            // with no log to diagnose it from — this is genuinely new
            // code (the seamless-swap path especially), and I have no way
            // to test it on a real device myself. An uncaught exception on
            // this thread would otherwise take the whole app down with it.
            // Catching it here means a bug in this new code becomes a
            // logged, recoverable stop instead of a crash — the debug
            // panel should now show exactly what threw, which is what the
            // next report actually needs to fix the real cause.
            Log.e(TAG, "bufferedPlaybackLoop CRASHED (caught, not fatal): ${e.message}", e)
            DebugOverlay.emit(TAG, "bufferedPlaybackLoop CRASHED (caught, not fatal): ${e}")
        }
        if (!running.get()) DebugOverlay.emit(TAG, "bufferedPlaybackLoop EXIT REASON: running became false (external stop/pause)")
        else if (myEpoch != playbackEpoch) DebugOverlay.emit(TAG, "bufferedPlaybackLoop EXIT REASON: superseded by a newer epoch (myEpoch=$myEpoch, current=$playbackEpoch)")
        // Real, direct fix for a confirmed misleading log — this used the
        // ORIGINAL trackId parameter, fixed for the whole life of this
        // thread, rather than activeTrackId, which correctly tracks a
        // seamless swap. Confirmed from a real log showing "thread exiting
        // for trackId=Starry Eyes" when the thread had already swapped to
        // and was actually running Loose - ENHYPEN at the time it exited.
        Log.i(TAG, "bufferedPlaybackLoop thread exiting for trackId=$activeTrackId")
        DebugOverlay.emit(TAG, "bufferedPlaybackLoop thread exiting for trackId=$activeTrackId")
    }
    // ==================== End buffered (whole-track) playback ====================

    private var leftoverBytes: ByteArray? = null
    private var leftoverBytesFormatKey = "" // "sampleRate:channels" — cleared alongside a real format change

    private fun playbackLoop(myEpoch: Int) {
        // myEpoch is now passed in, captured on the main thread at the
        // exact moment this thread was created — see start()'s own
        // comment for why reading playbackEpoch directly from inside this
        // thread was the actual bug.
        Log.i(TAG, "playbackLoop thread running, waiting for first chunk")
        DebugOverlay.emit(TAG, "playbackLoop thread running, waiting for first chunk")
        var loggedFirstChunk = false
        while (running.get() && myEpoch == playbackEpoch) {
            val chunk = try {
                queue.take() // blocks — correct: an idle playback thread with nothing queued should genuinely wait, not spin
            } catch (e: InterruptedException) {
                break
            }
            if (!loggedFirstChunk) {
                Log.i(TAG, "First chunk received: ${chunk.bytes.size} bytes, ${chunk.sampleRate}Hz, ${chunk.channels}ch")
                DebugOverlay.emit(TAG, "First chunk received: ${chunk.bytes.size} bytes, ${chunk.sampleRate}Hz, ${chunk.channels}ch")
                loggedFirstChunk = true
            }
            if (chunk.isFirstOfTrack) onTrackBoundaryReached?.invoke()
            ensureTrackFor(chunk.sampleRate, chunk.channels)
            val formatKey = "${chunk.sampleRate}:${chunk.channels}"
            // Real bug in the frame-alignment fix itself, caught before it
            // could cause its own glitch: this only reset leftover bytes on
            // a FORMAT change, but two consecutive tracks can share the
            // exact same format (as these two both do — 8ch/32kHz) while
            // being completely different audio streams. Without also
            // checking isFirstOfTrack, a few leftover bytes from the very
            // end of one track would get prepended onto the start of the
            // next one — a small, real corruption at exactly the boundary
            // this was supposed to make seamless.
            if (formatKey != leftoverBytesFormatKey || chunk.isFirstOfTrack) { leftoverBytes = null; leftoverBytesFormatKey = formatKey }
            val bytesPerFrame = chunk.channels * 2
            val combined = leftoverBytes?.let { it + chunk.bytes } ?: chunk.bytes
            val wholeFrameByteCount = (combined.size / bytesPerFrame) * bytesPerFrame
            leftoverBytes = if (wholeFrameByteCount < combined.size) combined.copyOfRange(wholeFrameByteCount, combined.size) else null
            if (wholeFrameByteCount == 0) continue // not even one whole frame yet — wait for more bytes to accumulate rather than processing nothing
            val processed = processChunk(combined.copyOfRange(0, wholeFrameByteCount), chunk.channels, chunk.sampleRate, chunk.isFirstOfTrack)
            // The actual fix — see trackLock's own comment above for the
            // full race this closes. Everything from ensureTrackFor through
            // the final write() call is now inside the same lock
            // stopAndFlush() takes before it can release this exact
            // AudioTrack instance, so a seek arriving mid-write can no
            // longer pull the track out from under an in-progress write.
            synchronized(trackLock) {
                ensureTrackFor(chunk.sampleRate, chunk.channels)
                val track = audioTrack
                if (track == null) {
                    Log.e(TAG, "audioTrack is null after ensureTrackFor — dropping this chunk, this should never happen")
                    DebugOverlay.emit(TAG, "audioTrack is null after ensureTrackFor — dropping this chunk, this should never happen")
                    return@synchronized
                }
                var offset = 0
                while (offset < processed.size && running.get() && myEpoch == playbackEpoch) {
                    // Blocking write — the entire point. This call parks the thread
                    // until AudioTrack's internal buffer has room, which is exactly
                    // the backpressure that keeps playback timing correct without
                    // any manual scheduling math (the source of every crossfade/
                    // discontinuity bug in the Web Audio version). write() returning
                    // a negative value is a real, documented error path (not just
                    // "wrote 0 bytes"); treated as fatal for this chunk rather than
                    // silently retried forever.
                    val written = track.write(processed, offset, processed.size - offset)
                    if (written < 0) {
                        Log.e(TAG, "AudioTrack.write error code=$written")
                        DebugOverlay.emit(TAG, "AudioTrack.write error code=$written")
                        onUnderrun?.invoke()
                        break
                    }
                    offset += written
                }
                // The actual signal a following track's start is gated on — see
                // onTrackEndReached's own comment. Fires only once every byte of
                // a chunk explicitly marked as a track's last one has actually
                // been handed to the AudioTrack (a few tens of milliseconds of
                // hardware buffer latency aside, this is genuinely close to the
                // real moment this track's audio finishes, not an approximation
                // based on when its data merely finished downloading).
                if (chunk.isLastOfTrack && offset >= processed.size) onTrackEndReached?.invoke()
            }
        }
    }

    /**
     * Converts one chunk's raw s16le PCM bytes to the final output format:
     * downmix to stereo if the source is multichannel, apply the fixed safety
     * trim, run through the soft-clip safety net, then back to s16le bytes.
     * Runs on the playback thread, between a blocking write() and the next —
     * kept simple (no allocations beyond the one output array) since this is
     * real-time-adjacent code where a GC pause here is audible as a stutter.
     */
    // Persists across chunks within one track (not reset per-chunk) — a real
    // limiter's envelope has to carry over between calls or every chunk
    // boundary would re-open the gate, defeating the point. No explicit
    // reset on track change either: a slightly-too-conservative gain
    // carried into a new track's first few samples is inaudible and safe;
    // an under-limited first sample on a new loud track is exactly the
    // failure mode this exists to prevent.
    private var limiterGainState = 1.0f

    /**
     * A real gain-reduction limiter, not just a waveshaper — deliberately
     * conservative rather than trying to precisely replicate the web
     * player's DynamicsCompressorNode curve (which I have no way to verify
     * against on a real device). Threshold matches that path's own tuned
     * value; makeup gain is intentionally NOT applied, unlike the web
     * version's — safety took priority over exactly matching loudness here,
     * since adding gain back in is exactly the kind of thing that needs
     * real-device verification before it can be trusted not to reintroduce
     * this same failure.
     *
     * Real, direct bug found from a reported "still insane amounts of
     * static" complaint after the first version of this shipped: the
     * attack/release coefficients were hardcoded constants (0.4 / 0.002),
     * with no relationship to the actual sample rate at all. At 32kHz that
     * 0.4 attack coefficient converges in about 5 samples — roughly 0.15ms,
     * several times FASTER than the web player's own tuned 1ms attack. A
     * limiter reacting that fast doesn't just catch genuine overshoot
     * transients — it starts tracking the audio waveform's own sample-to-
     * sample amplitude changes, since real audio legitimately varies that
     * quickly too. The gain envelope itself becomes an unwanted, audio-rate
     * signal riding on the output — which is exactly what constant static/
     * distortion sounds like, and would explain it persisting even after
     * the raw overshoot itself was being caught. Coefficients are now
     * computed from the actual sample rate using proper exponential time-
     * constant math, matching the web player's own tuned 1ms attack / 100ms
     * release instead of arbitrary numbers that happened to converge fast
     * in a desktop test.
     */
    private fun applyLimiter(left: Float, right: Float, attackCoeff: Float, releaseCoeff: Float): Pair<Float, Float> {
        val threshold = 0.5012f // -6dB linear — matches the web player's own tuned threshold for this exact downmix path
        val peak = maxOf(abs(left), abs(right))
        val targetGain = if (peak > threshold) (threshold / peak).coerceIn(0.05f, 1f) else 1f
        limiterGainState = if (targetGain < limiterGainState) {
            limiterGainState + (targetGain - limiterGainState) * attackCoeff
        } else {
            limiterGainState + (targetGain - limiterGainState) * releaseCoeff
        }
        return Pair(left * limiterGainState, right * limiterGainState)
    }

    private fun processChunk(bytes: ByteArray, sourceChannels: Int, sampleRate: Int, applyFadeIn: Boolean = false): ByteArray {
        // One-pole exponential smoother time constant: coefficient = 1 -
        // exp(-1 / (T_seconds * sampleRate)). Computed once per chunk (not
        // once per hardcoded guess) so the actual attack/release TIME stays
        // correct regardless of which quality tier's sample rate is
        // currently playing — 1ms attack, 100ms release, matching the web
        // player's own DynamicsCompressorNode settings on this exact path.
        val attackCoeff = (1.0 - kotlin.math.exp(-1.0 / (0.001 * sampleRate))).toFloat()
        val releaseCoeff = (1.0 - kotlin.math.exp(-1.0 / (0.1 * sampleRate))).toFloat()
        val frameCount = bytes.size / 2 / sourceChannels
        val out = ByteArray(frameCount * 2 * if (sourceChannels > 2) 2 else sourceChannels)
        var outIdx = 0
        for (frame in 0 until frameCount) {
            val base = frame * sourceChannels * 2
            if (sourceChannels <= 2) {
                // Direct passthrough (mono/stereo source) — just trim + soft-clip, no mixing.
                for (c in 0 until sourceChannels) {
                    val sampleIdx = base + c * 2
                    val raw = ((bytes[sampleIdx + 1].toInt() shl 8) or (bytes[sampleIdx].toInt() and 0xFF)).toShort()
                    val f = softClip((raw / 32768f) * volumeMultiplier * SAFETY_TRIM)
                    val outSample = (f * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                    out[outIdx++] = (outSample.toInt() and 0xFF).toByte()
                    out[outIdx++] = ((outSample.toInt() shr 8) and 0xFF).toByte()
                }
            } else {
                // Same downmix matrix as the web player's connectWithDownmix:
                // channel order FL, FR, FC, LFE, [rear/side L, rear/side R],
                // [7.1 only: side L, side R]. Applied per-sample here, not via
                // a channel-index shortcut.
                fun sample(ch: Int): Float {
                    if (ch >= sourceChannels) return 0f
                    val i = base + ch * 2
                    val raw = ((bytes[i + 1].toInt() shl 8) or (bytes[i].toInt() and 0xFF)).toShort()
                    return raw / 32768f
                }
                val fl = sample(0); val fr = sample(1); val fc = sample(2); val lfe = sample(3)
                val rl = sample(4); val rr = sample(5); val sl = sample(6); val sr = sample(7)
                var left = fl * DOWNMIX_SIDE + fc * DOWNMIX_CENTER + lfe * DOWNMIX_LFE + rl * DOWNMIX_SURROUND + sl * DOWNMIX_SURROUND
                var right = fr * DOWNMIX_SIDE + fc * DOWNMIX_CENTER + lfe * DOWNMIX_LFE + rr * DOWNMIX_SURROUND + sr * DOWNMIX_SURROUND
                // Real, urgent, physically-harmful bug found from a direct
                // report: this summing (5 channel contributions per side) can
                // reach up to ~3.6x scale in the worst case — the web
                // player's OWN comment on its equivalent path says this
                // explicitly, and that path has a real limiter
                // (DynamicsCompressorNode, threshold -6dB, ratio 20:1,
                // empirically measured to hold worst-case output at
                // -1.4dBFS) specifically because of it. This native path had
                // NO equivalent — only the soft-clip below, which bends the
                // waveform shape at a ceiling rather than actually reducing
                // gain the way a real limiter does. For a signal constantly
                // driven 3x+ over scale, that's sustained, severe distortion:
                // audibly "static," and perceptually far louder/harsher than
                // any real volume setting — which is exactly what was
                // reported. applyLimiter (below) is a real gain-reduction
                // stage with attack/release smoothing, run before softClip
                // rather than instead of it — softClip remains the final,
                // absolute safety net; this is what actually prevents that
                // net from being needed constantly in the first place.
                val (limitedLeft, limitedRight) = applyLimiter(left, right, attackCoeff, releaseCoeff)
                left = softClip(limitedLeft * volumeMultiplier * SAFETY_TRIM)
                right = softClip(limitedRight * volumeMultiplier * SAFETY_TRIM)
                val ls = (left * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                val rs = (right * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                out[outIdx++] = (ls.toInt() and 0xFF).toByte(); out[outIdx++] = ((ls.toInt() shr 8) and 0xFF).toByte()
                out[outIdx++] = (rs.toInt() and 0xFF).toByte(); out[outIdx++] = ((rs.toInt() shr 8) and 0xFF).toByte()
            }
        }
        // Real, direct mitigation for a reported "blasts static" complaint
        // specifically on seek — a standard, well-established technique for
        // exactly this class of problem (an audible discontinuity right at
        // a stream transition point), applied regardless of the precise
        // underlying cause, since it masks any of them: an abrupt AudioTrack
        // cutoff from the outgoing stream, or a genuine sample discontinuity
        // at the seam, both land at the very first few milliseconds of a
        // fresh stream's audio — exactly what this ramps up from silence
        // over, rather than starting instantly at full level. 10ms is short
        // enough to be inaudible as a fade on its own, long enough to smooth
        // over a hard discontinuity. Applied only when explicitly requested
        // (a genuinely fresh stream's first chunk) — never on ordinary
        // mid-stream chunks, where it would have no purpose and only risk
        // an audible dip.
        if (applyFadeIn) {
            val fadeFrames = minOf((sampleRate * 0.01).toInt(), frameCount).coerceAtLeast(1)
            val bytesPerOutFrame = if (sourceChannels > 2) 4 else sourceChannels * 2
            for (frame in 0 until minOf(fadeFrames, out.size / bytesPerOutFrame)) {
                val gain = frame.toFloat() / fadeFrames
                val base = frame * bytesPerOutFrame
                var i = 0
                while (i < bytesPerOutFrame) {
                    val raw = ((out[base + i + 1].toInt() shl 8) or (out[base + i].toInt() and 0xFF)).toShort()
                    val scaled = (raw * gain).toInt().coerceIn(-32768, 32767).toShort()
                    out[base + i] = (scaled.toInt() and 0xFF).toByte()
                    out[base + i + 1] = ((scaled.toInt() shr 8) and 0xFF).toByte()
                    i += 2
                }
            }
        }
        return out
    }
}
