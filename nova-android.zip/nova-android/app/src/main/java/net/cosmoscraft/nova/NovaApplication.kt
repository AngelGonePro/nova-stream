package net.cosmoscraft.nova

import android.app.Application
import android.util.Log
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * The actual, direct fix for a repeated "still crashing with no logs"
 * report, across multiple prior rounds that each guessed at and wrapped one
 * more specific call site in a try-catch. That approach has a structural
 * ceiling: it can only ever catch what it specifically anticipated, on
 * whichever thread that particular code runs on — and DebugOverlay's
 * in-memory ring buffer, however well-guarded now, fundamentally requires
 * the app process to stay alive long enough to display it. A genuine
 * uncaught crash on a thread nothing wrapped, or a native-level crash that
 * bypasses Kotlin exception handling entirely (a real possibility given
 * this app does AudioTrack/native audio work and WebView rendering), takes
 * the whole process down before any in-memory log could ever be shown.
 *
 * This is the actual right tool for that: a single, global handler that
 * catches literally anything uncaught, on any thread, anywhere in the app
 * — no guessing which call site needs a try-catch — and writes the full
 * stack trace straight to a file on disk BEFORE the process dies. A file
 * write survives a process crash in a way an in-memory buffer and a screen
 * update never can. The next launch checks for this file first, before
 * anything else runs, and shows it immediately at the top of the debug
 * panel.
 */
class NovaApplication : Application() {

    companion object {
        private const val TAG = "NovaApplication"
        const val CRASH_FILE_NAME = "last_crash.txt"
    }

    override fun onCreate() {
        super.onCreate()
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val text = "=== CRASH at ${java.util.Date()} on thread '${thread.name}' ===\n$sw"
                File(filesDir, CRASH_FILE_NAME).writeText(text)
                Log.e(TAG, "Uncaught exception written to crash file: ${throwable.message}", throwable)
            } catch (e: Throwable) {
                // Deliberately swallowed — this is the true last line of defense
                // in the entire app. If even writing the crash file itself fails
                // (disk full, storage permission revoked mid-session, anything),
                // there is nothing further downstream to catch it, and the
                // original crash must still be allowed to proceed to the
                // default handler below rather than get stuck here.
                Log.e(TAG, "Failed to write crash file: ${e.message}", e)
            }
            // Always hand off to whatever the real default handler was
            // afterward — this app should still crash normally (and Android
            // should still show its own crash dialog / restart behavior),
            // just with the crash now also durably recorded on disk first.
            defaultHandler?.uncaughtException(thread, throwable)
        }
        // Real, direct addition for the file-backed track-buffer rewrite,
        // requested explicitly — the whole point of moving off RAM was
        // easier size management, and an orphaned cache file left behind
        // by a killed process (no guaranteed onDestroy for that case,
        // unlike a clean app close) would defeat that if nothing ever swept
        // them. Runs here, before anything else in the app — including
        // before NativeAudioEngine ever creates a new one of these files
        // for this session — so a leftover from a prior session can never
        // be mistaken for a fresh one, and can never accumulate across
        // repeated launches.
        try {
            val leftover: List<File> = cacheDir.listFiles()?.filter { it.name.startsWith("nova_trackbuf_") } ?: emptyList<File>()
            if (leftover.isNotEmpty()) {
                var freedBytes = 0L
                for (f in leftover) { freedBytes += f.length(); f.delete() }
                Log.i(TAG, "Cleaned up ${leftover.size} orphaned track-buffer cache file(s) from a previous session, freeing ${freedBytes / 1024}KB")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to clean up orphaned track-buffer cache files: ${e.message}", e)
        }
    }
}
