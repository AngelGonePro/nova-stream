package net.cosmoscraft.nova

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import net.cosmoscraft.nova.local.FileNode
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel

/**
 * A file or folder the user picked through Android's file picker (Storage Access Framework). The app never needs storage
 * permissions: it only touches what was picked, and keeps access to it across restarts through the persistable grant.
 */
class SafNode private constructor(
    private val ctx: Context,
    private val treeUri: Uri?,          // set for folders and what is inside them
    private val docId: String?,
    val uri: Uri,                       // this document
    private val displayName: String,
    private val dir: Boolean,
    private val bytes: Long
) : FileNode {

    @Volatile private var cache: List<FileNode>? = null
    @Volatile private var cachedAt = 0L

    override fun name(): String = displayName
    override fun isDirectory(): Boolean = dir
    override fun size(): Long = bytes

    override fun children(): List<FileNode> {
        val tree = treeUri ?: throw IOException("not a folder")
        val now = System.currentTimeMillis()
        cache?.let { if (now - cachedAt < CACHE_MS) return it }
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val out = ArrayList<FileNode>()
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE
        )
        ctx.contentResolver.query(childrenUri, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                val isDir = c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR
                out.add(SafNode(ctx, tree, id, DocumentsContract.buildDocumentUriUsingTree(tree, id), name, isDir, if (c.isNull(3)) 0L else c.getLong(3)))
            }
        } ?: throw IOException("cannot list folder")
        cache = out; cachedAt = now
        return out
    }

    /** The whole file mapped into memory when the provider gives a seekable descriptor; otherwise copied once into the cache. */
    override fun map(): ByteBuffer {
        try {
            ctx.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                FileInputStream(pfd.fileDescriptor).channel.use { ch -> return ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size()) }
            }
        } catch (e: Exception) {
            DebugOverlay.emit("LocalLibrary", "cannot map $displayName directly (${e.message}); copying it to the cache")
        }
        val copy = File(ctx.cacheDir, "local-copy-" + uri.toString().hashCode().toUInt().toString(16) + "-" + bytes)
        if (!copy.exists() || copy.length() != bytes) {
            val tmp = File(copy.path + ".part")
            ctx.contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } } ?: throw IOException("cannot open $displayName")
            tmp.renameTo(copy)
            trimCopies(copy)
        }
        FileInputStream(copy).channel.use { ch -> return ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size()) }
    }

    override fun open(): InputStream = ctx.contentResolver.openInputStream(uri) ?: throw IOException("cannot open $displayName")

    companion object {
        private const val CACHE_MS = 8000L
        private const val MAX_COPIES = 3

        private fun trimCopies(keep: File) {
            val copies = keep.parentFile?.listFiles { f -> f.name.startsWith("local-copy-") && !f.name.endsWith(".part") }?.sortedByDescending { it.lastModified() } ?: return
            copies.drop(MAX_COPIES).filter { it != keep }.forEach { it.delete() }
        }

        /** The root of a picked folder. */
        fun folder(ctx: Context, treeUri: Uri): SafNode {
            val id = DocumentsContract.getTreeDocumentId(treeUri)
            val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
            var name = id.substringAfterLast(':').substringAfterLast('/')
            ctx.contentResolver.query(docUri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0)?.let { name = it } }
            return SafNode(ctx, treeUri, id, docUri, name, true, 0L)
        }

        /** One hand-picked document. */
        fun file(ctx: Context, docUri: Uri): SafNode? {
            val cols = arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_SIZE)
            ctx.contentResolver.query(docUri, cols, null, null, null)?.use { c ->
                if (c.moveToFirst()) return SafNode(ctx, null, null, docUri, c.getString(0) ?: "track", false, if (c.isNull(1)) 0L else c.getLong(1))
            }
            return null
        }
    }
}
