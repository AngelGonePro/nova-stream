package net.cosmoscraft.nova

/**
 * Decides whether a finished segment response is trustworthy.
 *
 * Why this exists: the server streams audio with no Content-Length, and when
 * something fails AFTER the headers have gone out (the resampling ffmpeg being
 * killed, a decode error), it ends the response cleanly. To the client that is
 * an ordinary HTTP 200 with a short — or completely empty — body, byte-for-byte
 * indistinguishable from success. The download loop used to take a short body
 * as a finished segment (silently dropping the audio up to the next segment)
 * and an empty body as "real end of file" (clamping the track's length, which
 * ends the song). Confirmed against the real server code: killing the
 * resampler mid-stream yields HTTP 200 with the connection closing normally
 * and ~5% of the expected bytes.
 *
 * What makes a check possible: the server reports the track's exact length up
 * front, and measured against the real server for every quality tier (live and
 * cached paths) the delivered bytes match that header total exactly, and every
 * non-final segment is exactly the requested length. So a response that falls
 * meaningfully short of what the header promised is a failure, not an ending.
 *
 * Kept free of Android classes so the rules can be unit-tested on a plain JVM.
 */
internal object SegmentValidation {
    /**
     * Allowed shortfall: 20 ms. Measured against the real server on a 44.1 kHz
     * source, across all four quality tiers on both the live and cached paths,
     * the worst deviation between the promised and delivered length was ONE
     * frame (0.03 ms) — so this is a ~600x margin, while still catching a
     * response that was cut off by even a few dozen milliseconds.
     */
    fun toleranceBytes(bytesPerSecond: Int): Long = (bytesPerSecond / 50).toLong()

    /**
     * A response that delivered bytes, but clearly fewer than the request should have.
     * [bytesRemainingToTotal] is how many bytes the track still had left, per the
     * server's own header total, when this request began; null if the total isn't
     * known, in which case a short body can't be told apart from a legitimate final
     * segment and is accepted as before.
     */
    fun isShortResponse(receivedBytes: Long, requestedSeconds: Int, bytesPerSecond: Int, bytesRemainingToTotal: Long?): Boolean {
        if (bytesRemainingToTotal == null) return false
        val fullRequest = requestedSeconds.toLong() * bytesPerSecond
        val expected = minOf(fullRequest, maxOf(0L, bytesRemainingToTotal))
        return receivedBytes + toleranceBytes(bytesPerSecond) < expected
    }

    /**
     * A response with zero bytes: the genuine end of the file, or a failure that
     * was presented as success? Genuine when everything the header promised has
     * already been downloaded. Otherwise it is accepted only once empty responses
     * have been arriving for [minStreakMillis] (default a full minute) AND there have been at least
     * [maxEmptyBeforeAccepting] of them — so a source file that really is shorter
     * than its header claims still ends, instead of retrying for the whole ten-
     * minute give-up window, but a short burst of failures (a server restart,
     * killed workers) can never end a song. Found by testing against the real
     * server: with a count alone, three empty responses inside a few seconds of
     * heavy faulting cut a song five seconds before its end.
     * [consecutiveEmptyResponses] includes the current one; [emptyStreakMillis] is
     * how long ago the first empty response of this unbroken streak arrived.
     */
    fun isGenuineEndOfFile(
        downloadedBytes: Long,
        totalBytes: Long?,
        bytesPerSecond: Int,
        consecutiveEmptyResponses: Int,
        emptyStreakMillis: Long,
        maxEmptyBeforeAccepting: Int = 10,
        minStreakMillis: Long = 60_000L
    ): Boolean {
        if (totalBytes == null) return true
        if (downloadedBytes + toleranceBytes(bytesPerSecond) >= totalBytes) return true
        return consecutiveEmptyResponses >= maxEmptyBeforeAccepting && emptyStreakMillis >= minStreakMillis
    }
}
