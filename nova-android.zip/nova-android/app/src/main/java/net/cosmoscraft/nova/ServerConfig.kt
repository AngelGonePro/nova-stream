package net.cosmoscraft.nova

import android.content.Context
import java.net.URI

/**
 * Which NOVA server this app talks to. Chosen by the user on first start (and changeable from the app's settings),
 * stored on the device, so anyone who hosts their own server can use the app without a rebuild.
 */
object ServerConfig {
    private const val PREFS = "nova_server"
    private const val KEY = "origin"
    private const val MODE = "mode"           // "server" (default) or "local": play the files on this phone
    private const val LOCAL_PORT = "local_port"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** True when the app plays files stored on this phone instead of talking to a server. */
    fun isLocal(context: Context): Boolean = prefs(context).getString(MODE, null) == "local"

    fun setLocal(context: Context) { prefs(context).edit().putString(MODE, "local").apply() }

    /** The server to talk to, or null when none is chosen yet or the app is set to use the files on this phone. */
    fun get(context: Context): String? =
        if (isLocal(context)) null else prefs(context).getString(KEY, null)?.takeIf { it.isNotBlank() }

    /** The last server address that was set, even while the app is using local files (to pre-fill the dialog). */
    fun lastServer(context: Context): String? = prefs(context).getString(KEY, null)?.takeIf { it.isNotBlank() }

    fun set(context: Context, origin: String) {
        prefs(context).edit().putString(KEY, origin).putString(MODE, "server").apply()
    }

    /** The port the on-phone library listens on. It is remembered so the page's own saved settings (kept per address) survive restarts. */
    fun localPort(context: Context): Int = prefs(context).getInt(LOCAL_PORT, 0)
    fun setLocalPort(context: Context, port: Int) { prefs(context).edit().putInt(LOCAL_PORT, port).apply() }

    /**
     * Turns what the user typed into "https://host[:port]", or null if it cannot be a server address.
     * Only https is accepted (the app does not allow cleartext traffic); a missing scheme is assumed to be https;
     * any path, query or trailing slash is dropped.
     */
    fun normalize(input: String): String? {
        var text = input.trim()
        if (text.isEmpty()) return null
        if (!text.contains("://")) text = "https://$text"
        return try {
            val uri = URI(text)
            val host = uri.host
            if (uri.scheme != "https" || host.isNullOrBlank() || !host.contains('.') && host != "localhost") return null
            if (uri.userInfo != null) return null
            val port = if (uri.port == -1 || uri.port == 443) "" else ":${uri.port}"
            "https://$host$port"
        } catch (e: Exception) {
            null
        }
    }
}
