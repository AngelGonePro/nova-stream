package net.cosmoscraft.nova

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build

/**
 * Decides whether 5.1/7.1 audio should be handed to Android as it is instead of being mixed down to stereo here.
 *
 * That is only worth doing when something downstream actually renders the extra channels:
 *  - Android's Spatializer (Android 12L+) is available for the current output, switched on by the user (Settings >
 *    Sound > Spatial audio), and says it can spatialize a 7.1 PCM track like ours; or
 *  - the current output takes multichannel PCM directly (an HDMI/USB receiver or soundbar).
 * On a phone speaker, or on headphones with spatial audio off, Android would just mix the channels down itself with
 * coarser coefficients and no limiter, so there the app keeps doing its own tuned mix.
 */
object SurroundSupport {
    fun check(context: Context): Pair<Boolean, String> {
        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(48000)
            .setChannelMask(AudioFormat.CHANNEL_OUT_7POINT1_SURROUND)
            .build()
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        if (Build.VERSION.SDK_INT >= 32) {
            try {
                val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val spatializer = audioManager.spatializer
                if (spatializer.immersiveAudioLevel != android.media.Spatializer.SPATIALIZER_IMMERSIVE_LEVEL_NONE &&
                    spatializer.isAvailable && spatializer.isEnabled && spatializer.canBeSpatialized(attributes, format)
                ) return Pair(true, "spatializer")
            } catch (e: Exception) {
                // Some OEM builds throw from the spatializer queries; treat that as "not available".
            }
        }
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                if (AudioTrack.isDirectPlaybackSupported(format, attributes)) return Pair(true, "direct playback")
            } catch (e: Exception) {
            }
        }
        return Pair(false, "no surround output on the current route")
    }
}
