package net.cosmoscraft.nova.local;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;

/** A file or folder the library can show: a real file on a JVM (tests), a Storage Access Framework document on the phone. */
public interface FileNode {
    String name();
    boolean isDirectory();
    long size();
    /** Direct children (folders only). */
    List<FileNode> children() throws IOException;
    /** The whole file as a read-only buffer (memory-mapped where possible, so large files are not copied onto the heap). */
    ByteBuffer map() throws IOException;
    InputStream open() throws IOException;
}
