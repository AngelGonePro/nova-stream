package net.cosmoscraft.nova.local;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

/** FileNode over java.io.File - used by the JVM tests, and for plain files on the phone's storage. */
public final class JavaFileNode implements FileNode {
    private final File f;
    public JavaFileNode(File f) { this.f = f; }
    @Override public String name() { return f.getName(); }
    @Override public boolean isDirectory() { return f.isDirectory(); }
    @Override public long size() { return f.length(); }
    @Override public List<FileNode> children() throws IOException {
        File[] list = f.listFiles();
        if (list == null) throw new IOException("cannot list " + f);
        List<FileNode> out = new ArrayList<>();
        for (File c : list) if (!Files.isSymbolicLink(c.toPath())) out.add(new JavaFileNode(c));
        return out;
    }
    @Override public ByteBuffer map() throws IOException {
        try (FileChannel ch = FileChannel.open(f.toPath(), StandardOpenOption.READ)) {
            return ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size());
        }
    }
    @Override public InputStream open() throws IOException { return new FileInputStream(f); }
}
