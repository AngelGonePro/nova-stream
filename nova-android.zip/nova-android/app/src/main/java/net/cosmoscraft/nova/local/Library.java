package net.cosmoscraft.nova.local;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * The folders and hand-picked files the user chose, presented the way the server's MUSIC_ROOTS mode does: a virtual top level
 * of named roots; track ids are "<root name>/<path inside it>". Paths are resolved by matching names one step at a time,
 * so ".." or any other escape from a root is simply refused.
 */
public final class Library {
    public static final Set<String> AUDIO_EXTENSIONS = new HashSet<>(Arrays.asList(".flac", ".wav", ".wave", ".nova", ".aiff", ".aif", ".ape", ".wv", ".m4a", ".mp3", ".ogg"));

    public static final class Root {
        public final String name; public final FileNode dir; public final List<FileNode> files;
        public Root(String name, FileNode dir, List<FileNode> files) { this.name = name.replace('/', '-').replace('\\', '-'); this.dir = dir; this.files = files; }
        public static Root folder(String name, FileNode dir) { return new Root(name, dir, null); }
        public static Root files(String name, List<FileNode> files) { return new Root(name, null, files); }
    }

    /** code: OUTOFBOUNDS (400), NOENT (404), NOTDIR (400), NOTFILE (400) - the same cases the server distinguishes. */
    public static final class LibraryException extends IOException {
        public final String code;
        public LibraryException(String code, String msg) { super(msg); this.code = code; }
    }

    private volatile List<Root> roots = Collections.emptyList();

    public void setRoots(List<Root> r) { roots = new ArrayList<>(r); }
    public List<Root> roots() { return roots; }

    private static String ext(String name) { int i = name.lastIndexOf('.'); return i <= 0 ? "" : name.substring(i).toLowerCase(Locale.ROOT); }
    private static final Comparator<Map<String, Object>> BY_NAME = (a, b) -> {
        int c = String.CASE_INSENSITIVE_ORDER.compare((String) a.get("name"), (String) b.get("name"));
        return c != 0 ? c : ((String) a.get("name")).compareTo((String) b.get("name"));
    };

    private static String clean(String p) {
        String s = (p == null ? "" : p).replace('\\', '/');
        while (s.startsWith("/")) s = s.substring(1);
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
    private Root rootOf(String first) {
        for (Root r : roots) if (r.name.equals(first)) return r;
        return null;
    }

    /** { path, dirs:[{name,path}], files:[{name,path,sizeBytes,ext}] } */
    public Map<String, Object> list(String relativePath) throws IOException {
        String base = clean(relativePath);
        Map<String, Object> out = new LinkedHashMap<>();
        List<Map<String, Object>> dirs = new ArrayList<>(), files = new ArrayList<>();
        if (base.isEmpty()) {
            for (Root r : roots) dirs.add(Json.obj("name", r.name, "path", r.name));
            dirs.sort(BY_NAME);
            out.put("path", ""); out.put("dirs", dirs); out.put("files", files);
            return out;
        }
        String[] parts = base.split("/");
        Root root = rootOf(parts[0]);
        if (root == null) throw new LibraryException("NOENT", "Not found");
        if (root.files != null) {
            if (parts.length > 1) throw new LibraryException("NOTDIR", "Not a directory");
            for (FileNode f : root.files) files.add(Json.obj("name", f.name(), "path", root.name + "/" + f.name(), "sizeBytes", f.size(), "ext", ext(f.name())));
            files.sort(BY_NAME);
            out.put("path", base); out.put("dirs", dirs); out.put("files", files);
            return out;
        }
        FileNode dir = walk(root.dir, parts, 1);
        if (!dir.isDirectory()) throw new LibraryException("NOTDIR", "Not a directory");
        for (FileNode c : dir.children()) {
            String n = c.name();
            if (n.startsWith(".")) continue;
            if (c.isDirectory()) dirs.add(Json.obj("name", n, "path", base + "/" + n));
            else if (AUDIO_EXTENSIONS.contains(ext(n))) files.add(Json.obj("name", n, "path", base + "/" + n, "sizeBytes", c.size(), "ext", ext(n)));
        }
        dirs.sort(BY_NAME); files.sort(BY_NAME);
        out.put("path", base); out.put("dirs", dirs); out.put("files", files);
        return out;
    }

    private FileNode walk(FileNode from, String[] parts, int start) throws IOException {
        FileNode cur = from;
        for (int i = start; i < parts.length; i++) {
            String seg = parts[i];
            if (seg.isEmpty()) continue;
            if (seg.equals("..") || seg.equals(".")) throw new LibraryException("OUTOFBOUNDS", "Path escapes the library");
            if (!cur.isDirectory()) throw new LibraryException("NOTDIR", "Not a directory");
            FileNode next = null;
            for (FileNode c : cur.children()) if (c.name().equals(seg)) { next = c; break; }
            if (next == null) throw new LibraryException("NOENT", "Not found");
            cur = next;
        }
        return cur;
    }

    /** The file a track id points at. */
    public FileNode file(String relativePath) throws IOException {
        String base = clean(relativePath);
        if (base.isEmpty()) throw new LibraryException("NOTFILE", "Not a file");
        String[] parts = base.split("/");
        Root root = rootOf(parts[0]);
        if (root == null) throw new LibraryException("NOENT", "Not found");
        FileNode f;
        if (root.files != null) {
            if (parts.length != 2) throw new LibraryException("NOENT", "Not found");
            f = null;
            for (FileNode c : root.files) if (c.name().equals(parts[1])) { f = c; break; }
            if (f == null) throw new LibraryException("NOENT", "Not found");
        } else f = walk(root.dir, parts, 1);
        if (f.isDirectory()) throw new LibraryException("NOTFILE", "Not a file");
        return f;
    }
}
