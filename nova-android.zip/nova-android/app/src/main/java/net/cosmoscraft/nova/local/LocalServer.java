package net.cosmoscraft.nova.local;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The NOVA server's API for one person's own files, running inside the app on 127.0.0.1: the bundled web player talks to
 * it exactly as it talks to the online server (browse, tags, cover art, PCM streaming with seeking, playback state,
 * playlists, native-engine settings), so the player is the same one with the same features.
 *
 * Access: loopback only; a request must carry this address in its Host header (DNS rebinding) and the random key issued
 * to the app's own WebView, otherwise it is refused - another app or web page on the phone cannot read the library.
 */
public final class LocalServer {
    public interface Assets { /** null when there is no such file */ InputStream open(String path) throws IOException; }
    public interface Log { void log(String line); }

    public static final String COOKIE = "nova_local_key";
    private static final int MAX_HEADER = 16 * 1024, MAX_BODY = 256 * 1024;

    private final Library library; private final LocalStore store; private final Assets assets; private final Platform platform; private final Log log;
    private final String deviceLabel;
    private final String key;
    private volatile boolean normalize = true;
    private final LinkedHashMap<String, Double> gains = new LinkedHashMap<String, Double>(16, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, Double> e) { return size() > 64; }
    };
    private ServerSocket socket; private ExecutorService pool; private volatile boolean running;
    private int port; private String hostHeader;
    private final LinkedHashMap<String, NovaPcmSource.Track> tracks = new LinkedHashMap<String, NovaPcmSource.Track>(8, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, NovaPcmSource.Track> e) { return size() > 4; }
    };

    public LocalServer(Library library, LocalStore store, Assets assets, Platform platform, Log log, String deviceLabel) {
        this.library = library; this.store = store; this.assets = assets; this.platform = platform; this.log = log == null ? s -> {} : log; this.deviceLabel = deviceLabel;
        byte[] k = new byte[24]; new SecureRandom().nextBytes(k);
        StringBuilder sb = new StringBuilder(); for (byte b : k) sb.append(String.format("%02x", b));
        key = sb.toString();
    }

    /** preferredPort 0 = any. A remembered port keeps the page's own saved settings (browser storage is per address). */
    public void start(int preferredPort) throws IOException {
        InetAddress lo = InetAddress.getByAddress(new byte[]{127, 0, 0, 1});
        try { socket = new ServerSocket(preferredPort, 50, lo); }
        catch (IOException e) { if (preferredPort == 0) throw e; socket = new ServerSocket(0, 50, lo); }
        port = socket.getLocalPort();
        hostHeader = "127.0.0.1:" + port;
        pool = Executors.newCachedThreadPool(r -> { Thread t = new Thread(r, "nova-local-http"); t.setDaemon(true); return t; });
        running = true;
        Thread acc = new Thread(() -> {
            while (running) {
                try { final Socket s = socket.accept(); pool.execute(() -> handle(s)); }
                catch (IOException e) { if (running) log.log("accept failed: " + e.getMessage()); }
            }
        }, "nova-local-accept");
        acc.setDaemon(true); acc.start();
        log.log("Local library server listening on " + origin());
    }
    /** Level matching between tracks (on by default, like the server). */
    public void setNormalize(boolean on) { normalize = on; }
    public void stop() { running = false; try { if (socket != null) socket.close(); } catch (IOException e) { /* closing */ } if (pool != null) pool.shutdownNow(); }
    public int port() { return port; }
    public String origin() { return "http://" + hostHeader; }
    public String key() { return key; }
    public String entryUrl() { return origin() + "/__nova_local?k=" + key; }

    // ------------------------------------------------------------------ HTTP plumbing
    private static final class Req {
        String method, path, rawQuery; Map<String, String> query = new LinkedHashMap<>(); Map<String, String> headers = new LinkedHashMap<>(); byte[] body = new byte[0];
        String q(String name) { return query.get(name); }
    }

    private static String dec(String s) { try { return URLDecoder.decode(s, "UTF-8"); } catch (Exception e) { return s; } }

    private Req parse(InputStream in) throws IOException {
        ByteArrayOutputStream head = new ByteArrayOutputStream();
        int state = 0, b;
        while (state < 4 && (b = in.read()) >= 0) {
            head.write(b);
            if (head.size() > MAX_HEADER) throw new IOException("header too large");
            state = (b == '\r' && (state == 0 || state == 2)) ? state + 1 : (b == '\n' && (state == 1 || state == 3)) ? state + 1 : 0;
        }
        if (state < 4) return null;
        String[] lines = new String(head.toByteArray(), StandardCharsets.ISO_8859_1).split("\r\n");
        String[] rl = lines[0].split(" ");
        if (rl.length < 2) throw new IOException("bad request line");
        Req r = new Req();
        r.method = rl[0];
        String target = rl[1];
        int qi = target.indexOf('?');
        r.path = dec(qi < 0 ? target : target.substring(0, qi));
        r.rawQuery = qi < 0 ? "" : target.substring(qi + 1);
        for (String kv : r.rawQuery.split("&")) {
            if (kv.isEmpty()) continue;
            int e = kv.indexOf('=');
            String k = dec(e < 0 ? kv : kv.substring(0, e)), v = e < 0 ? "" : dec(kv.substring(e + 1));
            if (!r.query.containsKey(k)) r.query.put(k, v);
        }
        for (int i = 1; i < lines.length; i++) { int c = lines[i].indexOf(':'); if (c > 0) r.headers.put(lines[i].substring(0, c).trim().toLowerCase(Locale.ROOT), lines[i].substring(c + 1).trim()); }
        String cl = r.headers.get("content-length");
        if (cl != null) {
            int n = Integer.parseInt(cl);
            if (n < 0 || n > MAX_BODY) throw new IOException("body too large");
            r.body = new byte[n];
            int off = 0; while (off < n) { int k = in.read(r.body, off, n - off); if (k < 0) throw new IOException("short body"); off += k; }
        }
        return r;
    }

    private static final class Out {
        final OutputStream os; boolean sent;
        Out(OutputStream os) { this.os = os; }
        void head(int status, Map<String, String> h) throws IOException {
            StringBuilder b = new StringBuilder("HTTP/1.1 ").append(status).append(' ').append(reason(status)).append("\r\n");
            for (Map.Entry<String, String> e : h.entrySet()) b.append(e.getKey()).append(": ").append(e.getValue()).append("\r\n");
            b.append("Connection: close\r\n\r\n");
            os.write(b.toString().getBytes(StandardCharsets.ISO_8859_1)); sent = true;
        }
        void bytes(int status, String type, byte[] body, String... extra) throws IOException {
            Map<String, String> h = new LinkedHashMap<>();
            h.put("Content-Type", type); h.put("Content-Length", String.valueOf(body.length)); h.put("Cache-Control", "no-store");
            for (int i = 0; i + 1 < extra.length; i += 2) h.put(extra[i], extra[i + 1]);
            head(status, h); os.write(body); os.flush();
        }
        void json(int status, Object v) throws IOException { bytes(status, "application/json; charset=utf-8", Json.stringify(v).getBytes(StandardCharsets.UTF_8)); }
        void error(int status, String msg) throws IOException { json(status, Json.obj("error", msg)); }
    }
    private static String reason(int s) {
        switch (s) { case 200: return "OK"; case 302: return "Found"; case 400: return "Bad Request"; case 403: return "Forbidden"; case 404: return "Not Found"; case 405: return "Method Not Allowed"; default: return s >= 500 ? "Internal Server Error" : "Status"; }
    }

    private boolean keyOk(String given) { return given != null && MessageDigest.isEqual(given.getBytes(StandardCharsets.UTF_8), key.getBytes(StandardCharsets.UTF_8)); }

    private void handle(Socket s) {
        try (Socket sock = s) {
            sock.setSoTimeout(60000);
            InputStream in = new BufferedInputStream(sock.getInputStream());
            OutputStream raw = new BufferedOutputStream(sock.getOutputStream(), 64 * 1024);
            Out out = new Out(raw);
            Req r;
            try { r = parse(in); } catch (IOException | RuntimeException e) { try { out.error(400, "Bad request"); } catch (IOException x) { /* gone */ } return; }
            if (r == null) return;
            try {
                if (!hostHeader.equals(r.headers.get("host"))) { out.bytes(403, "text/plain", "wrong host".getBytes(StandardCharsets.UTF_8)); return; }
                if (r.path.equals("/__nova_local") && keyOk(r.q("k"))) {
                    Map<String, String> h = new LinkedHashMap<>();
                    h.put("Set-Cookie", COOKIE + "=" + key + "; Path=/; HttpOnly; SameSite=Strict"); h.put("Location", "/"); h.put("Content-Length", "0");
                    out.head(302, h); raw.flush(); return;
                }
                String cookie = r.headers.get("cookie");
                boolean authed = false;
                if (cookie != null) for (String c : cookie.split(";\\s*")) { int e = c.indexOf('='); if (e > 0 && c.substring(0, e).equals(COOKIE) && keyOk(c.substring(e + 1))) authed = true; }
                if (!authed) { out.bytes(403, "text/plain", "not allowed".getBytes(StandardCharsets.UTF_8)); return; }
                route(r, out);
            } catch (IOException e) {
                if (!out.sent) { try { out.error(500, "Internal server error"); } catch (IOException x) { /* gone */ } }
            } catch (Throwable t) {
                log.log("request failed: " + r.method + " " + r.path + ": " + t);
                if (!out.sent) { try { out.error(500, "Internal server error"); } catch (IOException x) { /* gone */ } }
            } finally { try { raw.flush(); } catch (IOException e) { /* client left */ } }
        } catch (IOException e) { /* connection closed by the client */ }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> bodyJson(Req r) {
        if (r.body.length == 0) return new LinkedHashMap<>();
        Object o = Json.parse(new String(r.body, StandardCharsets.UTF_8));
        return o instanceof Map ? (Map<String, Object>) o : new LinkedHashMap<>();
    }

    // ------------------------------------------------------------------ routes
    private void route(Req r, Out out) throws IOException {
        final String p = r.path, m = r.method;
        if (p.startsWith("/api/")) {
            try { api(r, out); }
            catch (IllegalArgumentException e) { if (!out.sent) out.error(400, "Bad request"); }
            return;
        }
        if (!m.equals("GET") && !m.equals("HEAD")) { out.error(405, "Method not allowed"); return; }
        staticFile(p.equals("/") ? "/index.html" : p, out);
    }

    private void api(Req r, Out out) throws IOException {
        final String p = r.path, m = r.method;
        boolean get = m.equals("GET"), post = m.equals("POST");
        if (p.equals("/api/health") && get) { out.json(200, Json.obj("ok", true, "local", true)); return; }

        // ---- who am I: one person, signed in automatically
        if (p.equals("/api/auth/me") && get) { out.json(200, Json.obj("username", deviceLabel, "isAdmin", false, "lastfmUsername", null, "lastfmLinked", false, "lastfmScrobbleEnabled", false, "deviceLabel", deviceLabel)); return; }
        if (p.equals("/api/auth/devices") && get) { out.json(200, new ArrayList<>()); return; }
        if (p.equals("/api/auth/logout") && post) { out.json(200, Json.obj("ok", true)); return; }

        // ---- library
        if (p.equals("/api/browse") && get) {
            try { out.json(200, library.list(r.q("path"))); } catch (Library.LibraryException e) { libError(out, e); }
            return;
        }
        if (p.equals("/api/browse/tags") && get) { tags(r, out); return; }
        if (p.equals("/api/browse/artwork") && get) { artwork(r, out); return; }

        // ---- audio
        if (p.equals("/api/stream/pcm") && get) { pcm(r, out); return; }
        if (p.equals("/api/stream/pcm/release") && post) { out.json(200, Json.obj("ok", true, "released", false)); return; }
        if (p.equals("/api/stream/stats") && get) { out.json(200, new ArrayList<>()); return; }

        // ---- settings the native engine and page read at startup
        if (p.equals("/api/native-config") && get) {
            out.json(200, Json.obj("prebufferSeconds", 15L, "rebufferSeconds", 10L, "lowMarginSeconds", 6L, "prefetchLateLeadSeconds", 90L, "surroundOutput", true, "connectionProbes", false));
            return;
        }
        if (p.equals("/api/native-config/probe") && get) {
            int n = 100000; try { n = Math.max(1, Math.min(12000000, Integer.parseInt(r.q("bytes")))); } catch (Exception e) { /* default */ }
            byte[] junk = new byte[n]; new Random().nextBytes(junk);
            out.bytes(200, "application/octet-stream", junk);
            return;
        }

        // ---- playback state
        if (p.equals("/api/state") && get) { out.json(200, store.getState()); return; }
        if (p.equals("/api/state") && post) {
            Map<String, Object> b = bodyJson(r);
            if (!(b.get("queue") instanceof List)) { out.error(400, "queue must be an array"); return; }
            List<Object> q = new ArrayList<>((List<?>) b.get("queue"));
            if (q.size() > 2000) q = new ArrayList<>(q.subList(0, 2000));
            Object rm = b.get("repeatMode"), sm = b.get("sourceMode"), qp = b.get("queuePos"), pos = b.get("positionSeconds");
            Map<String, Object> s = Json.obj(
                "trackId", b.get("trackId") == null || "".equals(b.get("trackId")) ? null : b.get("trackId"),
                "positionSeconds", pos instanceof Number ? pos : (Object) 0L,
                "queue", q,
                "queuePos", qp instanceof Number && ((Number) qp).doubleValue() == Math.rint(((Number) qp).doubleValue()) ? (Object) ((Number) qp).longValue() : (Object) 0L,
                "repeatMode", "off".equals(rm) || "all".equals(rm) || "one".equals(rm) ? rm : "off",
                "shuffleEnabled", Boolean.TRUE.equals(b.get("shuffleEnabled")),
                "sourceMode", "local".equals(sm) || "network".equals(sm) ? sm : "local",
                "isPlaying", Boolean.TRUE.equals(b.get("isPlaying")),
                "updatedAt", System.currentTimeMillis() / 1000,
                "updatedByDevice", deviceLabel);
            store.setState(s);
            out.json(200, Json.obj("ok", true)); return;
        }
        if (p.equals("/api/state/devices") && get) {
            Map<String, Object> st = store.getState();
            List<Object> devs = new ArrayList<>();
            devs.add(Json.obj("deviceLabel", deviceLabel, "lastSeenAt", System.currentTimeMillis() / 1000, "isThisDevice", true));
            out.json(200, Json.obj("devices", devs, "activeDevice", st == null ? null : st.get("updatedByDevice"), "activeTrackId", st == null ? null : st.get("trackId"),
                "activeIsPlaying", st != null && Boolean.TRUE.equals(st.get("isPlaying")), "activeUpdatedAt", st == null ? null : st.get("updatedAt")));
            return;
        }
        if (p.equals("/api/state/throughput") && get) { out.json(200, store.getThroughput()); return; }
        if (p.equals("/api/state/throughput") && post) {
            Object v = bodyJson(r).get("bytesPerSec");
            if (!(v instanceof Number) || ((Number) v).doubleValue() < 0 || Double.isNaN(((Number) v).doubleValue())) { out.error(400, "bytesPerSec must be a non-negative number"); return; }
            store.setThroughput(((Number) v).doubleValue());
            out.json(200, Json.obj("ok", true)); return;
        }

        // ---- playlists
        if (p.equals("/api/playlists") || p.startsWith("/api/playlists/")) { playlists(r, out); return; }

        // ---- Last.fm needs an account and the internet: not part of the on-phone library
        if (p.equals("/api/lastfm/status") && get) {
            out.json(200, Json.obj("configured", false, "apiKey", null, "linked", false, "username", null, "scrobbleEnabled", false, "scrobbleThresholdPercent", 50L)); return;
        }
        if (p.startsWith("/api/lastfm/")) { out.error(400, "Last.fm is not available for files on this phone"); return; }

        // ---- the page's own error reports go to the app's log
        if (p.equals("/api/logs/client-error") && post) {
            Object es = bodyJson(r).get("entries");
            if (!(es instanceof List) || ((List<?>) es).isEmpty()) { out.error(400, "entries must be a non-empty array"); return; }
            int n = 0;
            for (Object e : (List<?>) es) { if (n++ >= 50) break; if (e instanceof Map) log.log("[page " + ((Map<?, ?>) e).get("level") + "] " + ((Map<?, ?>) e).get("message")); }
            out.json(200, Json.obj("ok", true, "accepted", (long) Math.min(n, 50))); return;
        }
        out.error(404, "Not found");
    }

    private void libError(Out out, Library.LibraryException e) throws IOException {
        switch (e.code) {
            case "OUTOFBOUNDS": out.error(400, "Invalid path"); break;
            case "NOENT": out.error(404, "Not found"); break;
            case "NOTDIR": out.error(400, "Not a directory"); break;
            default: out.error(400, "Not a file");
        }
    }

    private static String ext(String name) { int i = name.lastIndexOf('.'); return i <= 0 ? "" : name.substring(i).toLowerCase(Locale.ROOT); }

    private NovaPcmSource.Track trackFor(String id, FileNode f) throws IOException {
        String k = id + "|" + f.size();
        synchronized (tracks) {
            NovaPcmSource.Track t = tracks.get(k);
            if (t == null) { t = NovaPcmSource.newTrack(f.map()); tracks.put(k, t); }
            return t;
        }
    }

    private void tags(Req r, Out out) throws IOException {
        FileNode f;
        try { f = library.file(r.q("path")); } catch (Library.LibraryException e) { libError(out, e); return; }
        String title = null, artist = null, album = null; Object nch = null;
        try {
            if (ext(f.name()).equals(".nova")) {
                NovaDecoder d = new NovaDecoder(f.map());
                nch = (long) d.numChannels;
                if (d.metaJson.length > 0) {
                    Object o = Json.parse(new String(d.metaJson, StandardCharsets.UTF_8));
                    if (o instanceof Map) { Map<?, ?> t = (Map<?, ?>) o; title = str(t.get("title")); artist = str(t.get("artist")); album = str(t.get("album")); }
                }
            } else if (platform != null) {
                Platform.Tags t = platform.tags(f);
                if (t != null) { title = t.title; artist = t.artist; album = t.album; nch = t.numChannels == null ? null : (Object) (long) t.numChannels; }
            }
        } catch (Exception e) { /* unreadable tags still list the file (the page falls back to the file name) */ }
        out.json(200, Json.obj("title", title, "artist", artist, "album", album, "numChannels", nch));
    }
    private static String str(Object o) { return o instanceof String && !((String) o).isEmpty() ? (String) o : null; }

    private void artwork(Req r, Out out) throws IOException {
        FileNode f;
        try { f = library.file(r.q("path")); } catch (Library.LibraryException e) { if (e.code.equals("OUTOFBOUNDS")) out.error(400, "Invalid path"); else if (e.code.equals("NOENT")) out.error(404, "Not found"); else out.error(400, "Not a file"); return; }
        byte[] pic = null; String mime = "image/jpeg";
        try {
            if (ext(f.name()).equals(".nova")) { NovaDecoder d = new NovaDecoder(f.map()); pic = d.pictureBytes(); if (d.pictureMime != null && !d.pictureMime.isEmpty()) mime = d.pictureMime; }
            else if (platform != null) { pic = platform.artwork(f); }
        } catch (Exception e) { pic = null; }
        if (pic == null || pic.length == 0) { out.bytes(404, "text/plain", new byte[0]); return; }
        if (!ext(f.name()).equals(".nova")) mime = pic.length > 8 && (pic[0] & 0xFF) == 0x89 && pic[1] == 0x50 && pic[2] == 0x4e && pic[3] == 0x47 ? "image/png" : "image/jpeg";
        out.bytes(200, mime, pic, "Cache-Control", "private, max-age=86400");
    }

    private void pcm(Req r, Out out) throws IOException {
        FileNode f;
        try { f = library.file(r.q("path")); } catch (Library.LibraryException e) { libError(out, e); return; }
        double skip = 0; Double max = null;
        try { skip = Math.max(0, Double.parseDouble(r.q("skipToSeconds"))); } catch (Exception e) { skip = 0; }
        if (Double.isNaN(skip)) skip = 0;
        try { String mv = r.q("maxDurationSeconds"); if (mv != null && !mv.isEmpty()) { double d = Double.parseDouble(mv); if (!Double.isNaN(d) && d != 0) max = Math.max(1, d); } } catch (Exception e) { max = null; }
        String quality = r.q("quality");
        boolean stereo = quality != null && quality.startsWith("stereo");
        PcmSource src;
        try {
            String e = ext(f.name());
            if (e.equals(".nova")) src = new NovaPcmSource(trackFor(r.q("path"), f));
            else if (e.equals(".wav") || e.equals(".wave")) src = new WavPcmSource(f.map());
            else if (platform != null) src = platform.open(f);
            else throw new IOException("no decoder for " + e);
        } catch (Exception e) {
            log.log("stream/pcm: cannot open " + r.q("path") + ": " + e);
            out.error(500, "Failed to decode/stream audio"); return;
        }
        double gain = 1;
        if (normalize) {
            String gk = r.q("path") + "|" + f.size();
            Double known; synchronized (gains) { known = gains.get(gk); }
            if (known == null) {
                try { known = Loudness.analyze(src); } catch (IOException e) { log.log("loudness analysis failed for " + r.q("path") + ": " + e); known = 1.0; }
                synchronized (gains) { gains.put(gk, known); }
            }
            gain = known;
        }
        try {
            PcmStreamer.stream(src, skip, max, stereo, gain, (rate, ch, bits, total, skipSamples) -> {
                Map<String, String> h = new LinkedHashMap<>();
                h.put("Content-Type", "text/event-stream"); h.put("Cache-Control", "no-store");
                h.put("X-PCM-Sample-Rate", String.valueOf(rate)); h.put("X-PCM-Channels", String.valueOf(ch)); h.put("X-PCM-Bit-Depth", String.valueOf(bits));
                h.put("X-PCM-Total-Frames", String.valueOf(total)); h.put("X-PCM-Skip-Samples", String.valueOf(skipSamples));
                h.put("Access-Control-Expose-Headers", "X-PCM-Sample-Rate, X-PCM-Channels, X-PCM-Bit-Depth, X-PCM-Total-Frames, X-PCM-Skip-Samples");
                out.head(200, h);
            }, out.os);
            out.os.flush();
        } catch (IOException e) {
            if (!out.sent) { log.log("stream/pcm failed: " + e); out.error(500, "Failed to decode/stream audio"); }
            // after the headers are out, a failure is almost always the client leaving (a seek, a skip): nothing to report
        } finally { try { src.close(); } catch (IOException e) { /* ignore */ } }
    }

    private void playlists(Req r, Out out) throws IOException {
        String[] seg = r.path.substring("/api/playlists".length()).split("/");
        // seg: ["", id, "tracks", position|"move"]
        final String m = r.method;
        if (seg.length <= 1) {
            if (m.equals("GET")) { out.json(200, store.listPlaylists()); return; }
            if (m.equals("POST")) {
                Object n = bodyJson(r).get("name");
                String name = n instanceof String ? ((String) n).trim() : "";
                if (name.isEmpty()) { out.error(400, "Playlist name is required"); return; }
                if (name.length() > 200) { out.error(400, "Playlist name is too long"); return; }
                out.json(200, store.createPlaylist(name)); return;
            }
            out.error(405, "Method not allowed"); return;
        }
        long id;
        try { id = Long.parseLong(seg[1]); } catch (NumberFormatException e) { out.error(404, "Playlist not found"); return; }
        if (seg.length == 2) {
            if (m.equals("GET")) { Map<String, Object> p = store.getPlaylist(id); if (p == null) out.error(404, "Playlist not found"); else out.json(200, p); return; }
            if (m.equals("PATCH")) {
                Object n = bodyJson(r).get("name");
                String name = n instanceof String ? ((String) n).trim() : "";
                if (name.isEmpty()) { out.error(400, "Playlist name is required"); return; }
                Map<String, Object> p = store.renamePlaylist(id, name); if (p == null) out.error(404, "Playlist not found"); else out.json(200, p); return;
            }
            if (m.equals("DELETE")) { if (store.deletePlaylist(id)) out.json(200, Json.obj("ok", true)); else out.error(404, "Playlist not found"); return; }
        } else if (seg[2].equals("tracks")) {
            if (seg.length == 3 && m.equals("POST")) {
                if (store.getPlaylist(id) == null) { out.error(404, "Playlist not found"); return; }
                Object tp = bodyJson(r).get("trackPath");
                if (!(tp instanceof String) || ((String) tp).isEmpty()) { out.error(400, "trackPath is required"); return; }
                try { library.file((String) tp); } catch (Library.LibraryException e) { out.error(400, "That file could not be found in your music library"); return; }
                out.json(200, store.addTrack(id, (String) tp)); return;
            }
            if (seg.length == 4 && seg[3].equals("move") && m.equals("POST")) {
                if (store.getPlaylist(id) == null) { out.error(404, "Playlist not found"); return; }
                Map<String, Object> b = bodyJson(r);
                try {
                    if (!(b.get("from") instanceof Number) || !(b.get("to") instanceof Number)) throw new IllegalArgumentException();
                    out.json(200, store.moveTrack(id, ((Number) b.get("from")).intValue(), ((Number) b.get("to")).intValue()));
                } catch (IllegalArgumentException e) { out.error(400, "from and to must be positions inside the playlist"); }
                return;
            }
            if (seg.length == 4 && m.equals("DELETE")) {
                if (store.getPlaylist(id) == null) { out.error(404, "Playlist not found"); return; }
                int pos; try { pos = Integer.parseInt(seg[3]); } catch (NumberFormatException e) { pos = -1; }
                out.json(200, store.removeTrackAt(id, pos)); return;
            }
        }
        out.error(404, "Not found");
    }

    private void staticFile(String path, Out out) throws IOException {
        if (path.contains("..") || path.contains("\\")) { out.error(404, "Not found"); return; }
        InputStream in = assets == null ? null : assets.open(path.substring(1));
        if (in == null) { out.bytes(404, "text/plain", "Not found".getBytes(StandardCharsets.UTF_8)); return; }
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try { byte[] buf = new byte[16384]; int n; while ((n = in.read(buf)) > 0) bo.write(buf, 0, n); } finally { in.close(); }
        String e = ext(path), type;
        switch (e) {
            case ".html": type = "text/html; charset=utf-8"; break; case ".js": type = "text/javascript; charset=utf-8"; break;
            case ".css": type = "text/css; charset=utf-8"; break; case ".json": type = "application/json"; break;
            case ".png": type = "image/png"; break; case ".svg": type = "image/svg+xml"; break; case ".ico": type = "image/x-icon"; break;
            case ".woff2": type = "font/woff2"; break; default: type = "application/octet-stream";
        }
        out.bytes(200, type, bo.toByteArray());
    }
}
