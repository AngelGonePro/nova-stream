package net.cosmoscraft.nova.local;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Playback state, learned throughput and playlists, kept in one JSON file (the on-phone equivalent of the server's database). */
public final class LocalStore {
    private final File file;
    private Map<String, Object> data;

    public LocalStore(File file) {
        this.file = file;
        try {
            if (file.exists()) {
                Object o = Json.parse(new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8));
                if (o instanceof Map) { @SuppressWarnings("unchecked") Map<String, Object> m = (Map<String, Object>) o; data = m; }
            }
        } catch (Exception e) { data = null; /* unreadable: start fresh rather than refuse to run */ }
        if (data == null) data = Json.obj("state", null, "throughput", null, "playlists", new ArrayList<>(), "nextId", 1L);
        if (!(data.get("playlists") instanceof List)) data.put("playlists", new ArrayList<>());
    }

    private void save() {
        try {
            File tmp = new File(file.getPath() + ".tmp");
            File parent = file.getParentFile(); if (parent != null) parent.mkdirs();
            Files.write(tmp.toPath(), Json.stringify(data).getBytes(StandardCharsets.UTF_8));
            Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) { /* best effort: the next change tries again */ }
    }
    private static long now() { return System.currentTimeMillis() / 1000; }

    // ---- playback state
    @SuppressWarnings("unchecked") public synchronized Map<String, Object> getState() { return (Map<String, Object>) data.get("state"); }
    public synchronized void setState(Map<String, Object> s) { data.put("state", s); save(); }
    @SuppressWarnings("unchecked") public synchronized Map<String, Object> getThroughput() { return (Map<String, Object>) data.get("throughput"); }
    public synchronized void setThroughput(double bytesPerSec) { data.put("throughput", Json.obj("bytesPerSec", bytesPerSec, "atMs", System.currentTimeMillis())); save(); }

    // ---- playlists
    @SuppressWarnings("unchecked") private List<Map<String, Object>> pls() { return (List<Map<String, Object>>) (List<?>) data.get("playlists"); }
    private Map<String, Object> find(long id) { for (Map<String, Object> p : pls()) if (((Number) p.get("id")).longValue() == id) return p; return null; }
    @SuppressWarnings("unchecked") private static List<Object> tracks(Map<String, Object> p) { return (List<Object>) p.get("trackPaths"); }
    private Map<String, Object> view(Map<String, Object> p) {
        return Json.obj("id", p.get("id"), "name", p.get("name"), "createdAt", p.get("createdAt"), "updatedAt", p.get("updatedAt"), "trackPaths", new ArrayList<>(tracks(p)));
    }

    public synchronized List<Object> listPlaylists() {
        List<Map<String, Object>> sorted = new ArrayList<>(pls());
        sorted.sort((a, b) -> {
            int c = Long.compare(((Number) b.get("updatedAt")).longValue(), ((Number) a.get("updatedAt")).longValue());
            return c != 0 ? c : Long.compare(((Number) b.get("id")).longValue(), ((Number) a.get("id")).longValue());
        });
        List<Object> out = new ArrayList<>();
        for (Map<String, Object> p : sorted) out.add(Json.obj("id", p.get("id"), "name", p.get("name"), "createdAt", p.get("createdAt"), "updatedAt", p.get("updatedAt"), "trackCount", (long) tracks(p).size()));
        return out;
    }
    public synchronized Map<String, Object> createPlaylist(String name) {
        long id = ((Number) data.get("nextId")).longValue();
        data.put("nextId", id + 1);
        Map<String, Object> p = Json.obj("id", id, "name", name, "createdAt", now(), "updatedAt", now(), "trackPaths", new ArrayList<>());
        pls().add(p); save();
        return view(p);
    }
    public synchronized Map<String, Object> getPlaylist(long id) { Map<String, Object> p = find(id); return p == null ? null : view(p); }
    public synchronized Map<String, Object> renamePlaylist(long id, String name) { Map<String, Object> p = find(id); if (p == null) return null; p.put("name", name); p.put("updatedAt", now()); save(); return view(p); }
    public synchronized boolean deletePlaylist(long id) { Map<String, Object> p = find(id); if (p == null) return false; pls().remove(p); save(); return true; }
    public synchronized Map<String, Object> addTrack(long id, String path) { Map<String, Object> p = find(id); if (p == null) return null; tracks(p).add(path); p.put("updatedAt", now()); save(); return view(p); }
    /** null: no such playlist; throws IllegalArgumentException for positions outside the playlist. */
    public synchronized Map<String, Object> moveTrack(long id, int from, int to) {
        Map<String, Object> p = find(id); if (p == null) return null;
        List<Object> t = tracks(p);
        if (from < 0 || to < 0 || from >= t.size() || to >= t.size()) throw new IllegalArgumentException("from and to must be positions inside the playlist");
        if (from != to) { Object m = t.remove(from); t.add(to, m); p.put("updatedAt", now()); save(); }
        return view(p);
    }
    public synchronized Map<String, Object> removeTrackAt(long id, int position) {
        Map<String, Object> p = find(id); if (p == null) return null;
        List<Object> t = tracks(p);
        if (position >= 0 && position < t.size()) t.remove(position);
        p.put("updatedAt", now()); save();
        return view(p);
    }
}
