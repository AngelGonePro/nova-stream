package net.cosmoscraft.nova.local;

import java.io.IOException;

/**
 * Level matching, the same as the server's: each track gets one fixed gain that moves its average level (RMS of the first
 * 15 seconds) towards -16 dBFS, boosting by at most 4 dB and cutting by at most 9 dB, never letting the peak go above 0.85.
 */
public final class Loudness {
    private Loudness() {}
    public static final double ANALYSIS_SECONDS = 15;
    private static final int STRIDE = 4;

    public static double gainFromStats(double sumSquares, double peakAbs, long sampleCount) {
        final double target = Math.pow(10, -16.0 / 20), maxBoost = Math.pow(10, 4.0 / 20), maxCut = Math.pow(10, -9.0 / 20);
        if (sampleCount == 0) return 1;
        double rms = Math.sqrt(sumSquares / sampleCount);
        if (rms < 1e-6) return 1;
        double gain = Math.min(target / rms, maxBoost);
        gain = Math.max(gain, maxCut);
        if (peakAbs > 0 && peakAbs * gain > 0.85) gain = 0.85 / peakAbs;
        return gain;
    }

    /** Reads the start of the track (every 4th frame, every channel) and returns its gain. Leaves the source at an undefined position. */
    public static double analyze(PcmSource src) throws IOException {
        final int ch = src.channels();
        final long want = (long) (ANALYSIS_SECONDS * src.sampleRate());
        short[] buf = new short[4096 * ch];
        double sum = 0, peak = 0; long count = 0, seen = 0;
        src.seek(0);
        while (seen < want) {
            int n = src.read(buf, 4096);
            if (n <= 0) break;
            for (int f = 0; f < n; f += STRIDE) for (int c = 0; c < ch; c++) {
                double v = buf[f * ch + c] / 32768.0;
                sum += v * v; count++;
                double av = Math.abs(v); if (av > peak) peak = av;
            }
            seen += n;
        }
        // the server hands ffmpeg the gain with six decimals
        return Double.parseDouble(String.format(java.util.Locale.ROOT, "%.6f", gainFromStats(sum, peak, count)));
    }

    public static boolean audible(double gain) { return Math.abs(gain - 1) > 0.005; }
}
