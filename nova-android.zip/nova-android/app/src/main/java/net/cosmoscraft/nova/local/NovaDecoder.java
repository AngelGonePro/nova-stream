package net.cosmoscraft.nova.local;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Streaming decoder for the NOVA lossless format: a line-for-line port of createStreamingDecoder() in nova-server's
 * lib/novaCodec.js. The arithmetic mirrors the JavaScript exactly (doubles where JS uses numbers, modular 32-bit
 * wrap where JS stores into an Int32Array), and test/NovaDecoderTest checks the output sample for sample against the
 * JS decoder, including decoding from the middle of a file via snapshot()/resume.
 *
 * The file is read through a ByteBuffer (a memory-mapped file on the phone), so a large multichannel track is not
 * copied onto the Java heap.
 */
public final class NovaDecoder {
    public static final int BLOCK = 4096;
    private static final int LPC_ORDER = 8;
    private static final int STREAM_HISTORY = 32;
    private static final int METHOD_LPC = 4;
    private static final int QUOT_MAX = 40;
    private static final int PROB_BITS = 14;
    private static final int PROB_SCALE = 1 << PROB_BITS;
    private static final long RANS_L = 1L << 16;
    private static final int LMS_WEIGHT_CLAMP = 1 << 12;
    private static final int[] LMS1 = {16, 9}, LMS2 = {8, 9}, LMS_BIG = {128, 14}, LMS_A = {192, 14}, LMS_B = {96, 13};

    public final int sampleRate, numChannels, bitsPerSample;
    public final int numFrames;
    public final byte[] metaJson;
    public final String pictureMime;
    private final ByteBuffer buf;
    private final int picOffset, picLen;

    // ---- state shared by the channels
    private final int[] crossFlags;
    private final int numBlocksTotal;
    private int nextBlockIdx = 0;

    /** The decoded samples of one chunk: out[channel][i], covering global samples [startSample, endSample). */
    public static final class Chunk {
        public final int[][] channels;
        public final int startSample, endSample;
        public final boolean done;
        Chunk(int[][] c, int s, int e, boolean d) { channels = c; startSample = s; endSample = e; done = d; }
        public int frames() { return endSample - startSample; }
    }

    /** Everything needed to carry on decoding from a block boundary. */
    public static final class Snapshot {
        public int blockIdx, startSample;
        ChannelSnap[] channels;
        public long approxBytes() {
            long n = 64;
            for (ChannelSnap c : channels) n += 64 + c.xTail.length * 4L + (c.lms == null ? 0 : c.lms.length * 700L);
            return n;
        }
    }
    static final class ChannelSnap {
        int ransPos; long ransX; int extraPos, extraBit, lpcIdx;
        Lms[] lms; // in stage order of the mode; null when mode 0
        int[] xTail; int xTailStart;
    }

    private static final class Lms {
        final int order, shift;
        final int[] w; final double[] h; // h is doubled (h[k] == h[k + order]) so the newest `order` samples are contiguous
        int pos;
        Lms(int[] spec) { order = spec[0]; shift = spec[1]; w = new int[order]; h = new double[order * 2]; }
        Lms copy() { Lms l = new Lms(new int[]{order, shift}); System.arraycopy(w, 0, l.w, 0, order); System.arraycopy(h, 0, l.h, 0, order * 2); l.pos = pos; return l; }
        void load(Lms o) { System.arraycopy(o.w, 0, w, 0, order); System.arraycopy(o.h, 0, h, 0, order * 2); pos = o.pos; }

        double[] inverse(double[] e) {
            final int n = e.length;
            final double[] d = new double[n];
            final double div = Math.pow(2, shift);
            for (int i = 0; i < n; i++) {
                // newest sample first: h[pos + order - 1 - j]
                final int base = pos + order - 1;
                double pred = 0;
                for (int j = 0; j < order; j++) pred += w[j] * h[base - j];
                pred = Math.floor(pred / div);
                final double err = e[i];
                final double input = err + pred;
                d[i] = input;
                if (err != 0) {
                    final int s = err > 0 ? 1 : -1;
                    for (int j = 0; j < order; j++) {
                        final double hv = h[base - j];
                        if (hv == 0) continue;
                        int nw = w[j] + (hv > 0 ? s : -s);
                        w[j] = nw > LMS_WEIGHT_CLAMP ? LMS_WEIGHT_CLAMP : (nw < -LMS_WEIGHT_CLAMP ? -LMS_WEIGHT_CLAMP : nw);
                    }
                }
                h[pos] = input; h[pos + order] = input;
                pos = (pos + 1) % order;
            }
            return d;
        }
    }

    // channel parse results are kept in a small holder so the Channel fields can stay final
    private static final class Parsed {
        int mode, numBlocks; int[] orders, riceKs, lpcShift; int[][] lpcQ; int[] freq, cum; int ransBase, ransLen, extraBase, extraLen;
    }
    private final class Ch {
        final Parsed p; final byte[] slot2sym = new byte[PROB_SCALE];
        int ransPos; long ransX; int extraPos, extraBit, lpcIdx;
        final Lms[] lms; int[] x; int xBase = 0;
        Ch(Parsed p) {
            this.p = p;
            switch (p.mode) {
                case 0: lms = new Lms[0]; break;
                case 1: lms = new Lms[]{new Lms(LMS1)}; break;
                case 3: lms = new Lms[]{new Lms(LMS1), new Lms(LMS2), new Lms(LMS_BIG)}; break;
                case 4: lms = new Lms[]{new Lms(LMS1), new Lms(LMS2), new Lms(LMS_B), new Lms(LMS_A)}; break;
                default: lms = new Lms[]{new Lms(LMS2), new Lms(LMS1)}; break;
            }
            for (int s = 0; s < p.freq.length; s++) for (int j = p.cum[s]; j < p.cum[s] + p.freq[s]; j++) slot2sym[j] = (byte) s;
            // rANS init: first four bytes, big endian
            long x0 = 0; for (int i = 0; i < 4; i++) x0 = (x0 << 8) | rb(p.ransBase, p.ransLen, i);
            ransX = x0; ransPos = 4;
            x = new int[Math.min(numFrames, 30 * BLOCK + STREAM_HISTORY)];
        }
        int rb(int base, int len, int i) { return i < len ? (buf.get(base + i) & 0xFF) : 0; }
    }
    private final Ch[] chs;

    /** One worker per core (at most 8) shared by every decoder; null on a single-core device. */
    private static final java.util.concurrent.ExecutorService POOL;
    static {
        int n = Math.min(8, Runtime.getRuntime().availableProcessors());
        POOL = n > 1 ? java.util.concurrent.Executors.newFixedThreadPool(n, r -> { Thread t = new Thread(r, "nova-decode"); t.setDaemon(true); return t; }) : null;
    }

    public NovaDecoder(ByteBuffer file) { this(file, null); }

    public NovaDecoder(ByteBuffer file, Snapshot resume) {
        buf = file.duplicate();
        ByteBuffer le = buf.duplicate().order(ByteOrder.LITTLE_ENDIAN);
        int p = 0;
        long magic = buf.duplicate().order(ByteOrder.BIG_ENDIAN).getInt(0) & 0xFFFFFFFFL;
        if (magic != 0x4E4F5641L) throw new IllegalArgumentException("Bad magic / not a NOVA file");
        p += 4;
        int version = le.get(p) & 0xFF; p += 1;
        sampleRate = le.getInt(p); p += 4;
        numChannels = le.get(p) & 0xFF; p += 1;
        bitsPerSample = le.get(p) & 0xFF; p += 1;
        long nf = le.getInt(p) & 0xFFFFFFFFL; p += 4;
        if (nf > Integer.MAX_VALUE) throw new IllegalArgumentException("file too long");
        numFrames = (int) nf;
        int metaLen = le.getInt(p); p += 4;
        int mimeLen = 0, picLen_ = 0;
        if (version >= 2) { mimeLen = le.get(p) & 0xFF; p += 1; picLen_ = le.getInt(p); p += 4; }
        int[] flags = new int[0];
        int[] modes = new int[numChannels];
        if (version >= 7) {
            int fl = le.get(p) & 0xFF; p += 1;
            flags = new int[Math.max(0, numChannels - 1)];
            for (int i = 0; i < flags.length; i++) flags[i] = ((le.get(p + (i >> 3)) & 0xFF) >> (i & 7)) & 1;
            p += fl;
            for (int i = 0; i < numChannels; i++) { modes[i] = le.get(p) & 0xFF; p += 1; }
        }
        crossFlags = flags;
        if (version >= 8) p += numChannels * 4;
        metaJson = new byte[metaLen];
        for (int i = 0; i < metaLen; i++) metaJson[i] = buf.get(p + i);
        p += metaLen;
        if (mimeLen > 0) {
            byte[] m = new byte[mimeLen]; for (int i = 0; i < mimeLen; i++) m[i] = buf.get(p + i);
            pictureMime = new String(m, StandardCharsets.ISO_8859_1); p += mimeLen;
            picOffset = p; picLen = picLen_; p += picLen_;
        } else { pictureMime = null; picOffset = 0; picLen = 0; }

        int nb = 0;
        for (int s = 0; s < numFrames; s += BLOCK) nb++;
        if (nb == 0) nb = 1;
        numBlocksTotal = nb;

        chs = new Ch[numChannels];
        for (int c = 0; c < numChannels; c++) {
            Parsed pc = new Parsed();
            pc.mode = modes[c];
            int numBlocks = le.getInt(p); p += 4;
            pc.numBlocks = numBlocks;
            pc.orders = new int[numBlocks]; pc.riceKs = new int[numBlocks];
            for (int i = 0; i < numBlocks; i++) pc.orders[i] = buf.get(p++) & 0xFF;
            for (int i = 0; i < numBlocks; i++) pc.riceKs[i] = buf.get(p++) & 0xFF;
            int lpcBytesLen = le.getInt(p); p += 4;
            int alphabet = le.get(p) & 0xFF; p += 1;
            pc.freq = new int[alphabet]; pc.cum = new int[alphabet + 1];
            for (int s = 0; s < alphabet; s++) { pc.freq[s] = le.getShort(p) & 0xFFFF; p += 2; }
            for (int s = 0; s < alphabet; s++) pc.cum[s + 1] = pc.cum[s] + pc.freq[s];
            int ransLen = le.getInt(p); p += 4;
            int extraLen = le.getInt(p); p += 4;
            int nLpc = lpcBytesLen / (1 + LPC_ORDER * 2);
            pc.lpcShift = new int[nLpc]; pc.lpcQ = new int[nLpc][LPC_ORDER];
            int lp = p;
            for (int i = 0; i < nLpc; i++) {
                pc.lpcShift[i] = buf.get(lp++) & 0xFF;
                for (int j = 0; j < LPC_ORDER; j++) { pc.lpcQ[i][j] = le.getShort(lp); lp += 2; }
            }
            p += lpcBytesLen;
            pc.ransBase = p; pc.ransLen = ransLen; p += ransLen;
            pc.extraBase = p; pc.extraLen = extraLen; p += extraLen;
            chs[c] = new Ch(pc);
        }

        if (resume != null) {
            if (resume.channels == null || resume.channels.length != numChannels) throw new IllegalArgumentException("checkpoint does not match this file");
            nextBlockIdx = resume.blockIdx;
            for (int c = 0; c < numChannels; c++) {
                Ch cs = chs[c]; ChannelSnap sc = resume.channels[c];
                cs.ransPos = sc.ransPos; cs.ransX = sc.ransX; cs.extraPos = sc.extraPos; cs.extraBit = sc.extraBit; cs.lpcIdx = sc.lpcIdx;
                for (int k = 0; k < cs.lms.length; k++) cs.lms[k].load(sc.lms[k]);
                cs.xBase = sc.xTailStart;
                System.arraycopy(sc.xTail, 0, cs.x, 0, sc.xTail.length);
            }
        }
    }

    public boolean isDone() { return nextBlockIdx >= numBlocksTotal; }
    public int nextBlockIndex() { return nextBlockIdx; }
    public int nextSample() { return nextBlockIdx < numBlocksTotal ? nextBlockIdx * BLOCK : numFrames; }
    public byte[] pictureBytes() {
        if (picLen <= 0) return null;
        byte[] b = new byte[picLen]; for (int i = 0; i < picLen; i++) b[i] = buf.get(picOffset + i); return b;
    }

    public Snapshot snapshot() {
        int rangeStart = nextBlockIdx < numBlocksTotal ? nextBlockIdx * BLOCK : numFrames;
        Snapshot s = new Snapshot();
        s.blockIdx = nextBlockIdx; s.startSample = rangeStart;
        s.channels = new ChannelSnap[numChannels];
        for (int c = 0; c < numChannels; c++) {
            Ch cs = chs[c]; ChannelSnap o = new ChannelSnap();
            int tail = Math.min(STREAM_HISTORY, rangeStart);
            int from = rangeStart - tail - cs.xBase;
            o.ransPos = cs.ransPos; o.ransX = cs.ransX; o.extraPos = cs.extraPos; o.extraBit = cs.extraBit; o.lpcIdx = cs.lpcIdx;
            o.lms = new Lms[cs.lms.length];
            for (int k = 0; k < cs.lms.length; k++) o.lms[k] = cs.lms[k].copy();
            o.xTailStart = rangeStart - tail;
            o.xTail = new int[tail];
            System.arraycopy(cs.x, from, o.xTail, 0, tail);
            s.channels[c] = o;
        }
        return s;
    }

    // ---- bits
    private long readBits(Ch cs, int n) {
        long v = 0;
        final int base = cs.p.extraBase, len = cs.p.extraLen;
        while (n > 0) {
            int avail = 8 - cs.extraBit;
            int take = Math.min(avail, n);
            int b = cs.extraPos < len ? (buf.get(base + cs.extraPos) & 0xFF) : 0;
            int bits = (b >> (avail - take)) & ((1 << take) - 1);
            v = (v << take) | bits;
            cs.extraBit += take;
            if (cs.extraBit == 8) { cs.extraBit = 0; cs.extraPos++; }
            n -= take;
        }
        return v;
    }
    private long readEscape(Ch cs) {
        int bitLen = (int) readBits(cs, 6);
        if (bitLen == 0) return 0;
        if (bitLen > 16) { long hi = readBits(cs, bitLen - 16), lo = readBits(cs, 16); return hi * 65536L + lo; }
        return readBits(cs, bitLen);
    }

    /** Decodes the next numBlocksPerChunk blocks of every channel; null when the file is finished. */
    public Chunk decodeNextChunk(int numBlocksPerChunk) {
        if (nextBlockIdx >= numBlocksTotal) return null;
        final int startBlockIdx = nextBlockIdx;
        final int endBlockIdx = Math.min(startBlockIdx + numBlocksPerChunk, numBlocksTotal);
        final int rangeStart = startBlockIdx * BLOCK;
        final int rangeEnd = endBlockIdx < numBlocksTotal ? endBlockIdx * BLOCK : numFrames;
        final int rangeLen = rangeEnd - rangeStart;

        final int[][] crossed = new int[numChannels][];
        if (numChannels > 1 && POOL != null) {
            // the channels are independent until the cross-channel step, so they decode side by side
            @SuppressWarnings("unchecked") java.util.concurrent.Future<int[]>[] jobs = new java.util.concurrent.Future[numChannels];
            for (int c = 0; c < numChannels; c++) { final int cc = c; jobs[c] = POOL.submit(() -> decodeChannel(cc, startBlockIdx, endBlockIdx, rangeStart, rangeEnd)); }
            for (int c = 0; c < numChannels; c++) {
                try { crossed[c] = jobs[c].get(); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IllegalStateException("decoding interrupted", e); }
                catch (java.util.concurrent.ExecutionException e) { Throwable t = e.getCause(); if (t instanceof RuntimeException) throw (RuntimeException) t; throw new IllegalStateException(t); }
            }
        } else {
            for (int c = 0; c < numChannels; c++) crossed[c] = decodeChannel(c, startBlockIdx, endBlockIdx, rangeStart, rangeEnd);
        }
        int[][] decoded = crossInverse(crossed, crossFlags);
        nextBlockIdx = endBlockIdx;
        return new Chunk(decoded, rangeStart, rangeEnd, nextBlockIdx >= numBlocksTotal);
    }

    private int[] decodeChannel(int c, int startBlockIdx, int endBlockIdx, int rangeStart, int rangeEnd) {
        Ch cs = chs[c];
        final int rangeLen = rangeEnd - rangeStart;
        // rANS symbols for the range
        byte[] sym = new byte[rangeLen];
        {
            final byte[] s2s = cs.slot2sym; final int[] freq = cs.p.freq, cum = cs.p.cum;
            final int base = cs.p.ransBase, len = cs.p.ransLen;
            int pos = cs.ransPos; long x = cs.ransX;
            for (int i = 0; i < rangeLen; i++) {
                int slot = (int) (x & (PROB_SCALE - 1));
                int s = s2s[slot] & 0xFF;
                x = freq[s] * (x >>> PROB_BITS) + slot - cum[s];
                while (x < RANS_L) { x = (x * 256) + (pos < len ? (buf.get(base + pos) & 0xFF) : 0); pos++; }
                sym[i] = (byte) s;
            }
            cs.ransPos = pos; cs.ransX = x;
        }
        // rice join
        double[] refined = new double[rangeLen];
        for (int b = startBlockIdx; b < endBlockIdx; b++) {
            int start = b * BLOCK, end = b + 1 < numBlocksTotal ? (b + 1) * BLOCK : numFrames;
            int k = cs.p.riceKs[b];
            double div = Math.pow(2, k);
            for (int i = start; i < end; i++) {
                int sy = sym[i - rangeStart] & 0xFF;
                long u;
                if (sy == QUOT_MAX) u = readEscape(cs);
                else {
                    long rem = 0;
                    if (k > 0) {
                        if (k > 24) { long hi = readBits(cs, k - 16), lo = readBits(cs, 16); rem = hi * 65536L + lo; }
                        else rem = readBits(cs, k);
                    }
                    u = (long) (sy * div) + rem;
                }
                refined[i - rangeStart] = (u & 1) == 1 ? -(double) ((u + 1) / 2) : (double) (u / 2);
            }
        }
        // LMS cascade
        double[] res = refined;
        for (Lms l : cs.lms) res = l.inverse(res);
        // slide the history window
        int windowStart = Math.max(0, rangeStart - STREAM_HISTORY);
        if (windowStart > cs.xBase) {
            System.arraycopy(cs.x, windowStart - cs.xBase, cs.x, 0, rangeStart - windowStart);
            cs.xBase = windowStart;
        }
        int needed = rangeEnd - cs.xBase;
        if (cs.x.length < needed) {
            int[] bigger = new int[needed];
            System.arraycopy(cs.x, 0, bigger, 0, rangeStart - cs.xBase);
            cs.x = bigger;
        }
        predictChunk(cs, res, startBlockIdx, endBlockIdx, rangeStart);
        int[] out = new int[rangeLen];
        System.arraycopy(cs.x, rangeStart - cs.xBase, out, 0, rangeLen);
        return out;
    }

    private void predictChunk(Ch cs, double[] res, int startBlock, int endBlock, int globalStart) {
        final int[] x = cs.x; final int xBase = cs.xBase;
        for (int b = startBlock; b < endBlock; b++) {
            final int start = b * BLOCK, end = Math.min(start + BLOCK, numFrames);
            final int method = cs.p.orders[b];
            if (method == METHOD_LPC) {
                final int[] q = cs.p.lpcQ[cs.lpcIdx]; final double div = Math.pow(2, cs.p.lpcShift[cs.lpcIdx]); cs.lpcIdx++;
                for (int i = start; i < end; i++) {
                    final int xi = i - xBase;
                    double acc = 0;
                    for (int j = 0; j < q.length; j++) acc += (double) q[j] * x[xi - 1 - j];
                    x[xi] = (int) (long) (res[i - globalStart] + Math.floor(acc / div));
                }
                continue;
            }
            for (int i = start; i < end; i++) {
                final int xi = i - xBase;
                if (start < method) { x[xi] = (int) (long) res[i - globalStart]; continue; }
                long pred;
                switch (method) {
                    case 0: pred = 0; break;
                    case 1: pred = x[xi - 1]; break;
                    case 2: pred = 2L * x[xi - 1] - x[xi - 2]; break;
                    default: pred = 3L * x[xi - 1] - 3L * x[xi - 2] + x[xi - 3]; break;
                }
                x[xi] = (int) (long) (res[i - globalStart] + pred);
            }
        }
    }

    // ---- cross-channel inverse (recursive mid/side un-lifting)
    static int[][] crossInverse(int[][] t, int[] flags) {
        final int n = t.length;
        if (n <= 1) return t.clone();
        final int numMids = (n + 1) / 2, numSides = n - numMids;
        int[][] reduced = new int[numMids][]; System.arraycopy(t, 0, reduced, 0, numMids);
        int[][] sides = new int[numSides][]; System.arraycopy(t, numMids, sides, 0, numSides);
        int[] pairFlags = new int[numSides];
        for (int i = 0; i < numSides; i++) pairFlags[i] = i < flags.length ? flags[i] : 0;
        int subLen = Math.max(0, flags.length - numSides);
        int[] subFlags = new int[subLen];
        System.arraycopy(flags, Math.min(numSides, flags.length), subFlags, 0, subLen);
        int[][] mids = crossInverse(reduced, subFlags);
        int[][] result = new int[n][];
        int sideIdx = 0;
        for (int i = 0; i < n; i += 2) {
            if (i + 1 < n) {
                if (pairFlags[sideIdx] == 1) {
                    int[] mid = mids[i / 2], side = sides[sideIdx];
                    int len = mid.length;
                    int[] L = new int[len], R = new int[len];
                    for (int k = 0; k < len; k++) { int r = mid[k] - (side[k] >> 1); R[k] = r; L[k] = r + side[k]; }
                    result[i] = L; result[i + 1] = R;
                } else { result[i] = mids[i / 2]; result[i + 1] = sides[sideIdx]; }
                sideIdx++;
            } else result[i] = mids[i / 2];
        }
        return result;
    }
}
