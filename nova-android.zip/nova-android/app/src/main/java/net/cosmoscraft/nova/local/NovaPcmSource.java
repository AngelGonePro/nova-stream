package net.cosmoscraft.nova.local;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Map;
import java.util.TreeMap;

/**
 * A .nova track as PCM. Decoding a NOVA file is sequential, so playing from the middle would mean decoding everything
 * before it; instead the decoder's state is remembered at block boundaries (every few seconds of what has been decoded,
 * and just before the point where a segment stopped). Seeking, and the next 60-second segment of the same track, resume
 * from the nearest remembered point. The remembered points live in {@link Track} and are shared between requests.
 */
public final class NovaPcmSource implements PcmSource {
    private static final int BLOCKS_PER_CHUNK = 4;
    private static final double CHECKPOINT_EVERY_SECONDS = 5;

    /** What is remembered about one file between requests. */
    public static final class Track {
        final ByteBuffer file;
        final TreeMap<Integer, NovaDecoder.Snapshot> checkpoints = new TreeMap<>();
        Track(ByteBuffer file) { this.file = file; }
        synchronized Map.Entry<Integer, NovaDecoder.Snapshot> floor(int sample) { return checkpoints.floorEntry(sample); }
        synchronized void put(NovaDecoder.Snapshot s) { checkpoints.put(s.startSample, s); }
        synchronized long approxBytes() { long n = 0; for (NovaDecoder.Snapshot s : checkpoints.values()) n += s.approxBytes(); return n; }
        public synchronized int checkpointCount() { return checkpoints.size(); }
    }

    private final Track track;
    private final NovaDecoder probe;
    private final double maxVal;
    private NovaDecoder dec;
    private NovaDecoder.Chunk chunk;
    private int chunkOff;            // next frame inside `chunk`
    private int lastCheckpointSample = Integer.MIN_VALUE;
    private long stopHint = Long.MAX_VALUE;
    private NovaDecoder.Snapshot beforeLastChunk;

    public NovaPcmSource(Track track) {
        this.track = track;
        this.probe = new NovaDecoder(track.file);
        this.maxVal = Math.pow(2, probe.bitsPerSample - 1);
    }

    public static Track newTrack(ByteBuffer file) { return new Track(file); }
    public NovaDecoder header() { return probe; }

    @Override public int sampleRate() { return probe.sampleRate; }
    @Override public int channels() { return probe.numChannels; }
    @Override public long totalFrames() { return probe.numFrames; }
    @Override public void hintStop(long frame) { stopHint = frame; }

    @Override public void seek(long frame) {
        int target = (int) Math.min(frame, probe.numFrames);
        Map.Entry<Integer, NovaDecoder.Snapshot> cp = track.floor(target);
        dec = cp == null ? new NovaDecoder(track.file) : new NovaDecoder(track.file, cp.getValue());
        chunk = null; chunkOff = 0;
        lastCheckpointSample = dec.nextSample();
        // decode and drop everything before the target (the decoder is sequential, so every chunk has to be decoded)
        while (!dec.isDone()) {
            NovaDecoder.Chunk c = decodeOne();
            if (c.endSample > target) { chunk = c; chunkOff = target - c.startSample; return; }
        }
    }

    private NovaDecoder.Chunk decodeOne() {
        int at = dec.nextSample();
        if (at - lastCheckpointSample >= CHECKPOINT_EVERY_SECONDS * probe.sampleRate) { NovaDecoder.Snapshot s = dec.snapshot(); track.put(s); lastCheckpointSample = at; }
        if (at + 2L * BLOCKS_PER_CHUNK * NovaDecoder.BLOCK > stopHint) beforeLastChunk = dec.snapshot();
        return dec.decodeNextChunk(BLOCKS_PER_CHUNK);
    }

    @Override public int read(short[] out, int maxFrames) {
        if (dec == null) seek(0);
        final int nc = probe.numChannels;
        int written = 0;
        while (written < maxFrames) {
            if (chunk == null || chunkOff >= chunk.frames()) {
                if (dec.isDone()) break;
                chunk = decodeOne(); chunkOff = 0;
            }
            int n = Math.min(maxFrames - written, chunk.frames() - chunkOff);
            for (int i = 0; i < n; i++) {
                for (int c = 0; c < nc; c++) {
                    double v = Math.floor(chunk.channels[c][chunkOff + i] / maxVal * 32767 + 0.5); // JS Math.round
                    out[(written + i) * nc + c] = (short) (v > 32767 ? 32767 : (v < -32768 ? -32768 : v));
                }
            }
            chunkOff += n; written += n;
        }
        return written == 0 ? -1 : written;
    }

    @Override public void close() {
        if (beforeLastChunk != null) { track.put(beforeLastChunk); beforeLastChunk = null; }
        dec = null; chunk = null;
    }
}
