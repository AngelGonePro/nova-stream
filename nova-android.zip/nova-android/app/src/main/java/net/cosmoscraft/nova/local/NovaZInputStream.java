package net.cosmoscraft.nova.local;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Reads the server's "nova-z" stream (/api/stream/pcm?enc=z): a series of [u32 big-endian length][NOVA file] blocks, each
 * a few seconds of lossless-compressed audio, and presents it as the plain 16-bit little-endian interleaved PCM the rest of
 * the engine already consumes. A background thread reads and decodes ahead, so the network and the decoder overlap.
 */
public final class NovaZInputStream extends InputStream {
    private static final byte[] EOF = new byte[0];
    private final InputStream src;
    private final BlockingQueue<Object> queue = new ArrayBlockingQueue<>(3);
    private final Thread reader;
    private volatile boolean closed;
    private byte[] cur = EOF;
    private int pos = 0;
    private boolean finished = false;
    private final Runnable onDecoderFailure;

    /** onDecoderFailure runs when a block arrives intact but cannot be decoded (a decoder problem, not a network one). */
    public NovaZInputStream(InputStream source, Runnable onDecoderFailure) {
        this.src = source;
        this.onDecoderFailure = onDecoderFailure;
        reader = new Thread(this::pump, "nova-z-reader");
        reader.setDaemon(true);
        reader.start();
    }

    private void put(Object o) throws InterruptedException {
        while (!closed) { if (queue.offer(o, 200, TimeUnit.MILLISECONDS)) return; }
    }

    private void pump() {
        try {
            byte[] head = new byte[4];
            while (!closed) {
                int n = readFullyOrEof(head, 4);
                if (n == 0) { put(EOF); return; }
                if (n < 4) throw new EOFException("nova-z stream ended inside a block header");
                int len = ((head[0] & 0xFF) << 24) | ((head[1] & 0xFF) << 16) | ((head[2] & 0xFF) << 8) | (head[3] & 0xFF);
                if (len <= 0 || len > 64 * 1024 * 1024) throw new IOException("nova-z: bad block length " + len);
                byte[] blob = new byte[len];
                if (readFullyOrEof(blob, len) < len) throw new EOFException("nova-z stream ended inside a block");
                put(decode(blob));
            }
        } catch (Throwable t) {
            if (!(t instanceof IOException) && onDecoderFailure != null) { try { onDecoderFailure.run(); } catch (Throwable ignored) {} }
            try { put(t instanceof IOException ? t : new IOException("nova-z: " + t, t)); } catch (InterruptedException ignored) {}
        }
    }

    private int readFullyOrEof(byte[] b, int len) throws IOException {
        int got = 0;
        while (got < len) {
            int r = src.read(b, got, len - got);
            if (r < 0) break;
            got += r;
        }
        return got;
    }

    /** One NOVA block -> interleaved 16-bit little-endian PCM. */
    static byte[] decode(byte[] blob) {
        NovaDecoder dec = new NovaDecoder(ByteBuffer.wrap(blob));
        final int ch = dec.numChannels, frames = dec.numFrames;
        byte[] out = new byte[frames * ch * 2];
        int written = 0;
        while (!dec.isDone()) {
            NovaDecoder.Chunk c = dec.decodeNextChunk(8);
            int f = c.frames();
            int base = c.startSample * ch * 2;
            for (int i = 0; i < f; i++) {
                int o = base + i * ch * 2;
                for (int k = 0; k < ch; k++) {
                    int v = c.channels[k][i];
                    out[o++] = (byte) v;
                    out[o++] = (byte) (v >> 8);
                }
            }
            written += f;
        }
        if (written != frames) throw new IllegalStateException("nova-z: decoded " + written + " of " + frames + " frames");
        return out;
    }

    private boolean fill() throws IOException {
        if (finished) return false;
        while (true) {
            if (closed) throw new IOException("closed");
            Object o;
            try { o = queue.poll(500, TimeUnit.MILLISECONDS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IOException("interrupted"); }
            if (o == null) continue;
            if (o == EOF) { finished = true; return false; }
            if (o instanceof IOException) { finished = true; throw (IOException) o; }
            cur = (byte[]) o; pos = 0;
            if (cur.length > 0) return true;
        }
    }

    @Override public int read() throws IOException {
        if (pos >= cur.length && !fill()) return -1;
        return cur[pos++] & 0xFF;
    }

    @Override public int read(byte[] b, int off, int len) throws IOException {
        if (len == 0) return 0;
        if (pos >= cur.length && !fill()) return -1;
        int n = Math.min(len, cur.length - pos);
        System.arraycopy(cur, pos, b, off, n);
        pos += n;
        return n;
    }

    @Override public int available() { return cur.length - pos; }

    @Override public void close() throws IOException {
        closed = true;
        reader.interrupt();
        src.close();
    }
}
