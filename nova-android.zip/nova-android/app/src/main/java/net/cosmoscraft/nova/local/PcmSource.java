package net.cosmoscraft.nova.local;

import java.io.Closeable;
import java.io.IOException;

/** Decoded audio of one track as 16-bit interleaved samples, readable from any position. */
public interface PcmSource extends Closeable {
    int sampleRate();
    int channels();
    long totalFrames();
    /** Positions the next read() at this frame (0 .. totalFrames). */
    void seek(long frame) throws IOException;
    /** Tells the source where this request will stop, so it can leave a resume point there (optional). */
    default void hintStop(long frame) {}
    /** Fills out[] with whole frames; returns the number of frames written, or -1 at the end. */
    int read(short[] out, int maxFrames) throws IOException;
}
