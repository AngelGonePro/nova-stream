package net.cosmoscraft.nova.local;

import java.io.IOException;
import java.io.OutputStream;

/**
 * The body of /api/stream/pcm: the same contract as the server (lib/pcmStream.js) - 16-bit little-endian interleaved
 * samples starting at skipToSeconds and ending after maxDurationSeconds (or at the end of the track), with the track's
 * format and position in X-PCM-* headers.
 */
public final class PcmStreamer {
    private PcmStreamer() {}

    public interface HeaderSink { void headers(int sampleRate, int channels, int bitDepth, long totalFrames, long skipSamples) throws IOException; }

    /** Same mix the server and the phone's engine use: FL/FR 1.0, centre and each surround pair 0.707, LFE 0.5 (order FL FR FC LFE BL BR SL SR). */
    static void downmix(short[] in, int frames, int srcCh, short[] out) {
        for (int i = 0; i < frames; i++) {
            int b = i * srcCh;
            double l = 0, r = 0;
            l += in[b]; r += in[b + 1];
            if (srcCh > 2) { l += 0.707 * in[b + 2]; r += 0.707 * in[b + 2]; }
            if (srcCh > 3) { l += 0.5 * in[b + 3]; r += 0.5 * in[b + 3]; }
            if (srcCh > 4) l += 0.707 * in[b + 4];
            if (srcCh > 5) r += 0.707 * in[b + 5];
            if (srcCh > 6) l += 0.707 * in[b + 6];
            if (srcCh > 7) r += 0.707 * in[b + 7];
            // a soft knee instead of the server's compressor: the summed channels must not wrap or hard-clip
            out[i * 2] = limit(l); out[i * 2 + 1] = limit(r);
        }
    }
    private static short limit(double v) {
        double a = Math.abs(v), knee = 16384;
        if (a > knee) { double over = a - knee; a = knee + (32767 - knee) * Math.tanh(over / (32767 - knee)); }
        return (short) Math.round(v < 0 ? -a : a);
    }

    public static void stream(PcmSource src, double skipToSeconds, Double maxDurationSeconds, boolean stereoDownmix, double gain, HeaderSink headers, OutputStream out) throws IOException {
        final int rate = src.sampleRate(), srcCh = src.channels();
        final long total = src.totalFrames();
        final int outCh = stereoDownmix && srcCh > 2 ? 2 : srcCh;
        long skip = Math.min((long) Math.floor(Math.max(0, skipToSeconds) * rate + 0.5), total);
        long stop = maxDurationSeconds == null ? total : Math.min(skip + (long) Math.floor(maxDurationSeconds * rate + 0.5), total);
        headers.headers(rate, outCh, 16, total, skip);
        if (skip >= stop) return;
        src.hintStop(stop);
        src.seek(skip);
        final int per = 8192;
        short[] buf = new short[per * srcCh], mixed = outCh != srcCh ? new short[per * outCh] : null;
        byte[] bytes = new byte[per * outCh * 2];
        long left = stop - skip;
        while (left > 0) {
            int n = src.read(buf, (int) Math.min(per, left));
            if (n <= 0) break;
            if (Loudness.audible(gain)) for (int i = 0; i < n * srcCh; i++) { long v = (long) Math.floor(buf[i] * gain + 0.5); buf[i] = (short) (v > 32767 ? 32767 : (v < -32768 ? -32768 : v)); }
            short[] data = buf;
            if (mixed != null) { downmix(buf, n, srcCh, mixed); data = mixed; }
            int samples = n * outCh;
            for (int i = 0; i < samples; i++) { bytes[i * 2] = (byte) data[i]; bytes[i * 2 + 1] = (byte) (data[i] >> 8); }
            out.write(bytes, 0, samples * 2);
            left -= n;
        }
    }
}
