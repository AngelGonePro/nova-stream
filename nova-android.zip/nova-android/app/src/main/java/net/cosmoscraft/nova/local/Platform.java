package net.cosmoscraft.nova.local;

import java.io.IOException;

/** The few things that need the phone's own media framework (everything but NOVA and WAV, tags and cover art of those). */
public interface Platform {
    /** Opens a non-NOVA, non-WAV file as PCM, or throws. */
    PcmSource open(FileNode file) throws IOException;
    /** Tags and channel count, any field may be null. */
    Tags tags(FileNode file);
    /** Embedded cover art bytes, or null. */
    byte[] artwork(FileNode file);

    final class Tags {
        public String title, artist, album; public Integer numChannels;
    }
}
