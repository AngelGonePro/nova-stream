package net.cosmoscraft.nova.local;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** RIFF/WAVE (PCM 8/16/24/32-bit and 32/64-bit float, incl. WAVE_FORMAT_EXTENSIBLE) read straight from the file. */
public final class WavPcmSource implements PcmSource {
    private final ByteBuffer b;
    private int sampleRate, channels, bits, format, dataOff, blockAlign;
    private long frames;
    private long pos;

    public WavPcmSource(ByteBuffer file) throws IOException {
        b = file.duplicate().order(ByteOrder.LITTLE_ENDIAN);
        if (b.limit() < 12 || b.getInt(0) != 0x46464952 || b.getInt(8) != 0x45564157) throw new IOException("not a WAV file");
        int p = 12; boolean haveFmt = false, haveData = false; long dataLen = 0;
        while (p + 8 <= b.limit()) {
            int id = b.getInt(p); long len = b.getInt(p + 4) & 0xFFFFFFFFL;
            if (id == 0x20746d66) { // "fmt "
                format = b.getShort(p + 8) & 0xFFFF; channels = b.getShort(p + 10) & 0xFFFF; sampleRate = b.getInt(p + 12);
                blockAlign = b.getShort(p + 20) & 0xFFFF; bits = b.getShort(p + 22) & 0xFFFF;
                if (format == 0xFFFE && len >= 26) format = b.getShort(p + 32) & 0xFFFF; // sub-format GUID starts with the real format tag
                haveFmt = true;
            } else if (id == 0x61746164) { // "data"
                dataOff = p + 8; dataLen = Math.min(len, b.limit() - dataOff); haveData = true; break;
            }
            p += 8 + (int) len + (int) (len & 1);
        }
        if (!haveFmt || !haveData) throw new IOException("WAV file has no audio");
        if (!(format == 1 && (bits == 8 || bits == 16 || bits == 24 || bits == 32)) && !(format == 3 && (bits == 32 || bits == 64))) throw new IOException("unsupported WAV format " + format + "/" + bits);
        if (channels < 1 || blockAlign < 1) throw new IOException("bad WAV header");
        frames = dataLen / blockAlign;
    }

    @Override public int sampleRate() { return sampleRate; }
    @Override public int channels() { return channels; }
    @Override public long totalFrames() { return frames; }
    @Override public void seek(long frame) { pos = Math.max(0, Math.min(frame, frames)); }

    @Override public int read(short[] out, int maxFrames) {
        int n = (int) Math.min(maxFrames, frames - pos);
        if (n <= 0) return -1;
        int bytes = bits / 8;
        int o = 0;
        for (int i = 0; i < n; i++) {
            int base = dataOff + (int) ((pos + i) * blockAlign);
            for (int c = 0; c < channels; c++) {
                int q = base + c * bytes;
                long v; // the sample scaled to 16 bit the way ffmpeg's s16 conversion does it: 16-bit passes through untouched, deeper ones round
                if (format == 3) { double f = bits == 32 ? b.getFloat(q) : b.getDouble(q); v = (long) Math.floor(f * 32768 + 0.5); }
                else if (bits == 8) v = ((b.get(q) & 0xFF) - 128) << 8;
                else if (bits == 16) v = b.getShort(q);
                else if (bits == 24) v = ((((b.get(q + 2) << 16) | ((b.get(q + 1) & 0xFF) << 8) | (b.get(q) & 0xFF))) + 128) >> 8;
                else v = ((long) b.getInt(q) + 32768) >> 16;
                out[o++] = (short) (v > 32767 ? 32767 : (v < -32768 ? -32768 : v));
            }
        }
        pos += n;
        return n;
    }

    @Override public void close() {}
}
