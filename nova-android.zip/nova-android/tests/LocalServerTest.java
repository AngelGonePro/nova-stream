import net.cosmoscraft.nova.local.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;

/** Runs the on-phone server over real files and compares its answers with the real NOVA server's (recorded by ref-server.js). */
public class LocalServerTest {
    static int failures = 0, checks = 0;
    static void check(boolean ok, String what) { checks++; if (!ok) { failures++; System.out.println("FAIL: " + what); } }

    static LocalServer srv; static String cookie;
    static final class Resp { int status; Map<String, List<String>> headers; byte[] body; String header(String n) { for (Map.Entry<String, List<String>> e : headers.entrySet()) if (e.getKey() != null && e.getKey().equalsIgnoreCase(n)) return e.getValue().get(0); return null; } }

    static Resp http(String method, String path, String body, String cookieHeader, String host) throws IOException {
        if (method.equals("PATCH") || host != null) return raw(method, path, body, cookieHeader, host);
        HttpURLConnection c = (HttpURLConnection) new URL("http://127.0.0.1:" + srv.port() + path).openConnection();
        c.setInstanceFollowRedirects(false);
        c.setRequestMethod(method);
        if (cookieHeader != null) c.setRequestProperty("Cookie", cookieHeader);
        if (host != null) c.setRequestProperty("Host", host);
        if (body != null) { c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json"); try (OutputStream o = c.getOutputStream()) { o.write(body.getBytes("UTF-8")); } }
        Resp r = new Resp(); r.status = c.getResponseCode(); r.headers = c.getHeaderFields();
        InputStream in = r.status >= 400 ? c.getErrorStream() : c.getInputStream();
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        if (in != null) { byte[] b = new byte[65536]; int n; while ((n = in.read(b)) > 0) bo.write(b, 0, n); }
        r.body = bo.toByteArray();
        return r;
    }
    /** Plain-socket request, for what HttpURLConnection will not send (PATCH, a forged Host header). */
    static Resp raw(String method, String path, String body, String cookieHeader, String host) throws IOException {
        try (Socket s = new Socket("127.0.0.1", srv.port())) {
            byte[] b = body == null ? new byte[0] : body.getBytes("UTF-8");
            StringBuilder h = new StringBuilder(method + " " + path + " HTTP/1.1\r\nHost: " + (host == null ? "127.0.0.1:" + srv.port() : host) + "\r\n");
            if (cookieHeader != null) h.append("Cookie: ").append(cookieHeader).append("\r\n");
            if (body != null) h.append("Content-Type: application/json\r\nContent-Length: ").append(b.length).append("\r\n");
            h.append("\r\n");
            OutputStream o = s.getOutputStream(); o.write(h.toString().getBytes("ISO-8859-1")); o.write(b); o.flush();
            ByteArrayOutputStream all = new ByteArrayOutputStream(); InputStream in = s.getInputStream(); byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) > 0) all.write(buf, 0, n);
            byte[] raw = all.toByteArray(); int he = 0; while (he + 3 < raw.length && !(raw[he] == 13 && raw[he + 1] == 10 && raw[he + 2] == 13 && raw[he + 3] == 10)) he++;
            String head = new String(raw, 0, he, "ISO-8859-1");
            Resp r = new Resp(); r.status = Integer.parseInt(head.split(" ")[1]); r.headers = new LinkedHashMap<>();
            for (String line : head.split("\r\n")) { int c = line.indexOf(':'); if (c > 0) r.headers.put(line.substring(0, c), new ArrayList<>(Arrays.asList(line.substring(c + 1).trim()))); }
            r.body = Arrays.copyOfRange(raw, Math.min(raw.length, he + 4), raw.length);
            return r;
        }
    }
    static Resp get(String path) throws IOException { return http("GET", path, null, cookie, null); }
    static Object json(Resp r) { return Json.parse(new String(r.body, "UTF-8".equals("") ? null : java.nio.charset.StandardCharsets.UTF_8)); }

    public static void main(String[] a) throws Exception {
        Path data = Paths.get(a[0]), ref = Paths.get(a[1]), refGain = Paths.get(a[2]), work = Files.createTempDirectory("nova-local-test");
        Library lib = new Library();
        lib.setRoots(Arrays.asList(
            Library.Root.folder("Music", new JavaFileNode(data.toFile())),
            Library.Root.files("Picked", Arrays.asList(new JavaFileNode(data.resolve("s51.nova").toFile()), new JavaFileNode(data.resolve("mono.nova").toFile())))));
        LocalStore store = new LocalStore(work.resolve("store.json").toFile());
        List<String> logs = new ArrayList<>();
        srv = new LocalServer(lib, store, p -> p.equals("index.html") ? new ByteArrayInputStream("<html>hi</html>".getBytes()) : null, null, logs::add, "This phone");
        srv.start(0);
        srv.setNormalize(false);

        // ---- access control
        check(http("GET", "/api/browse", null, null, null).status == 403, "no cookie is refused");
        check(http("GET", "/api/browse", null, "nova_local_key=wrong", null).status == 403, "wrong key is refused");
        check(http("GET", "/__nova_local?k=nope", null, null, null).status == 403, "wrong entry key is refused");
        Resp entry = http("GET", "/__nova_local?k=" + srv.key(), null, null, null);
        check(entry.status == 302 && "/".equals(entry.header("Location")), "entry key redirects to /");
        String sc = entry.header("Set-Cookie");
        check(sc != null && sc.contains("HttpOnly") && sc.contains("SameSite=Strict"), "cookie is HttpOnly + SameSite=Strict: " + sc);
        cookie = sc.split(";")[0];
        check(http("GET", "/api/browse", null, cookie, "evil.example:" + srv.port()).status == 403, "foreign Host header is refused (DNS rebinding)");
        check(new String(get("/").body).contains("hi"), "page is served");
        check(get("/nothing.js").status == 404, "unknown static file is 404");

        // ---- same answers as the real server
        List<Object> idx = (List<Object>) Json.parse(new String(Files.readAllBytes(ref.resolve("index.json"))));
        int compared = 0;
        for (Object o : idx) {
            Map<String, Object> e = (Map<String, Object>) o;
            String url = (String) e.get("url"); int i = ((Number) e.get("i")).intValue();
            if (url.startsWith("/api/stream/stats") || url.startsWith("/api/auth/me")) continue;
            Resp r = get(url);
            byte[] want = Files.readAllBytes(ref.resolve(i + ".body"));
            check(r.status == ((Number) e.get("status")).intValue(), url + " status " + r.status + " vs " + e.get("status"));
            Map<String, Object> wh = (Map<String, Object>) e.get("headers");
            for (Map.Entry<String, Object> h : wh.entrySet()) if (h.getKey().startsWith("x-pcm")) check(h.getValue().equals(r.header(h.getKey())), url + " header " + h.getKey() + " " + r.header(h.getKey()) + " vs " + h.getValue());
            String ct = (String) wh.get("content-type");
            if (ct != null && ct.startsWith("application/json")) check(Json.stringify(Json.parse(new String(r.body, "UTF-8"))).equals(Json.stringify(Json.parse(new String(want, "UTF-8")))), url + " JSON body\n   got  " + new String(r.body, "UTF-8") + "\n   want " + new String(want, "UTF-8"));
            else check(Arrays.equals(r.body, want), url + " body bytes (" + r.body.length + " vs " + want.length + ")");
            compared++;
        }
        System.out.println(compared + " responses compared with the real server (level matching off, sample-exact)");

        // ---- level matching on: same samples as the server's, up to the one fixed gain each track gets
        srv.setNormalize(true);
        List<Object> idxG = (List<Object>) Json.parse(new String(Files.readAllBytes(refGain.resolve("index.json"))));
        int gained = 0, skippedQuirk = 0;
        Set<String> seenTracks = new HashSet<>();
        for (Object o : idxG) {
            Map<String, Object> e = (Map<String, Object>) o;
            String url = (String) e.get("url"); int i = ((Number) e.get("i")).intValue();
            if (!url.startsWith("/api/stream/pcm") || ((Number) e.get("status")).intValue() != 200 || ((Number) e.get("bytes")).intValue() == 0) continue;
            // the real server plays a track that is first requested mid-song at unity gain (it has no analysis yet); this one analyses first
            String trackPath = url.replaceAll(".*path=([^&]*).*", "$1");
            boolean firstMid = seenTracks.add(trackPath) && url.matches(".*skipToSeconds=(?!0(\\.0*)?(&|$))[0-9.]+.*");
            if (firstMid) { skippedQuirk++; continue; }
            Resp r = get(url);
            byte[] want = Files.readAllBytes(refGain.resolve(i + ".body"));
            check(r.body.length == want.length, url + " (level matched) length");
            java.nio.ShortBuffer mine = java.nio.ByteBuffer.wrap(r.body).order(java.nio.ByteOrder.LITTLE_ENDIAN).asShortBuffer(), theirs = java.nio.ByteBuffer.wrap(want).order(java.nio.ByteOrder.LITTLE_ENDIAN).asShortBuffer();
            double sab = 0, sbb = 0; int n = Math.min(mine.limit(), theirs.limit());
            for (int k = 0; k < n; k++) { sab += (double) mine.get(k) * theirs.get(k); sbb += (double) theirs.get(k) * theirs.get(k); }
            double g = sbb == 0 ? 1 : sab / sbb, res = 0;
            for (int k = 0; k < n; k++) { double d = mine.get(k) - g * theirs.get(k); res += d * d; }
            double rms = n == 0 ? 0 : Math.sqrt(res / n);
            check(Math.abs(g - 1) < 0.01 && rms < 4, url + " level matched: ratio to the server's " + g + ", residual " + rms);
            gained++;
        }
        System.out.println(gained + " level-matched streams compared (ratio to the server's within 1%), " + skippedQuirk + " skipped (server plays a mid-song first request at unity gain)");
        srv.setNormalize(false);

        // ---- stereo downmix quality: two channels out, right length
        Resp st = get("/api/stream/pcm?path=Music/s51.nova&quality=stereo&skipToSeconds=0&maxDurationSeconds=1");
        check("2".equals(st.header("X-PCM-Channels")) && st.body.length == 48000 * 4, "stereo quality sends a 2-channel mix");

        // ---- state
        check("null".equals(new String(get("/api/state").body)), "no state yet");
        check(http("POST", "/api/state", "{\"queue\":5}", cookie, null).status == 400, "queue must be an array");
        check(http("POST", "/api/state", "{\"trackId\":\"Music/st16.nova\",\"positionSeconds\":2.5,\"queue\":[\"Music/st16.nova\",\"Music/mono.nova\"],\"queuePos\":1,\"repeatMode\":\"all\",\"shuffleEnabled\":true,\"sourceMode\":\"bogus\",\"isPlaying\":true}", cookie, null).status == 200, "state saved");
        Map<String, Object> s = (Map<String, Object>) json(get("/api/state"));
        check("Music/st16.nova".equals(s.get("trackId")) && ((Number) s.get("positionSeconds")).doubleValue() == 2.5 && ((List<?>) s.get("queue")).size() == 2 && ((Number) s.get("queuePos")).intValue() == 1 && "all".equals(s.get("repeatMode")) && Boolean.TRUE.equals(s.get("shuffleEnabled")) && "local".equals(s.get("sourceMode")) && Boolean.TRUE.equals(s.get("isPlaying")), "state read back: " + Json.stringify(s));
        Map<String, Object> dv = (Map<String, Object>) json(get("/api/state/devices"));
        check("This phone".equals(dv.get("activeDevice")) && "Music/st16.nova".equals(dv.get("activeTrackId")), "devices reflect the state");
        check("null".equals(new String(get("/api/state/throughput").body)), "no throughput yet");
        check(http("POST", "/api/state/throughput", "{\"bytesPerSec\":-1}", cookie, null).status == 400, "negative throughput refused");
        http("POST", "/api/state/throughput", "{\"bytesPerSec\":123456}", cookie, null);
        check(((Number) ((Map<String, Object>) json(get("/api/state/throughput"))).get("bytesPerSec")).doubleValue() == 123456, "throughput saved");

        // ---- playlists
        check(http("POST", "/api/playlists", "{\"name\":\"  \"}", cookie, null).status == 400, "empty name refused");
        Map<String, Object> pl = (Map<String, Object>) json(http("POST", "/api/playlists", "{\"name\":\" Mine \"}", cookie, null));
        long id = ((Number) pl.get("id")).longValue();
        check("Mine".equals(pl.get("name")) && ((List<?>) pl.get("trackPaths")).isEmpty(), "playlist created, name trimmed");
        check(http("POST", "/api/playlists/" + id + "/tracks", "{\"trackPath\":\"Music/missing.nova\"}", cookie, null).status == 400, "missing file refused");
        for (String t : new String[]{"Music/st16.nova", "Music/mono.nova", "Picked/s51.nova", "Music/st16.nova"}) check(http("POST", "/api/playlists/" + id + "/tracks", "{\"trackPath\":\"" + t + "\"}", cookie, null).status == 200, "added " + t);
        pl = (Map<String, Object>) json(http("POST", "/api/playlists/" + id + "/tracks/move", "{\"from\":3,\"to\":0}", cookie, null));
        check(Json.stringify(pl.get("trackPaths")).equals("[\"Music/st16.nova\",\"Music/st16.nova\",\"Music/mono.nova\",\"Picked/s51.nova\"]"), "moved: " + Json.stringify(pl.get("trackPaths")));
        check(http("POST", "/api/playlists/" + id + "/tracks/move", "{\"from\":9,\"to\":0}", cookie, null).status == 400, "move outside the playlist refused");
        pl = (Map<String, Object>) json(http("DELETE", "/api/playlists/" + id + "/tracks/1", null, cookie, null));
        check(Json.stringify(pl.get("trackPaths")).equals("[\"Music/st16.nova\",\"Music/mono.nova\",\"Picked/s51.nova\"]"), "track removed by position");
        List<Object> all = (List<Object>) json(get("/api/playlists"));
        check(all.size() == 1 && ((Number) ((Map<String, Object>) all.get(0)).get("trackCount")).intValue() == 3, "playlist list shows track count");
        check(((Map<String, Object>) json(http("PATCH", "/api/playlists/" + id, "{\"name\":\"Renamed\"}", cookie, null))).get("name").equals("Renamed"), "renamed");
        check(get("/api/playlists/999").status == 404, "unknown playlist is 404");

        // ---- everything the page needs at startup exists
        Map<String, Object> nc = (Map<String, Object>) json(get("/api/native-config"));
        check(nc.containsKey("prebufferSeconds") && nc.containsKey("surroundOutput") && Boolean.FALSE.equals(nc.get("connectionProbes")), "native-config");
        check(get("/api/lastfm/status").status == 200 && http("POST", "/api/lastfm/connect", "{}", cookie, null).status == 400, "Last.fm reports not available");
        check(http("POST", "/api/logs/client-error", "{\"entries\":[{\"level\":\"error\",\"message\":\"boom\"}]}", cookie, null).status == 200 && logs.toString().contains("boom"), "page error reports reach the log");
        check(http("POST", "/api/stream/pcm/release", "{\"path\":\"Music/st16.nova\"}", cookie, null).status == 200, "release is accepted");

        // ---- a seek that was just asked for resumes from a remembered point (segment N+1 right after segment N)
        long t0 = System.nanoTime();
        for (int k = 0; k < 3; k++) {
            long skipF = Math.round(k * 0.6 * 48000);
            Resp seg = get("/api/stream/pcm?path=Music/s71hc.nova&skipToSeconds=" + (k * 0.6) + "&maxDurationSeconds=1");
            long wantFrames = Math.min(48000, 88201 - skipF);
            check(seg.status == 200 && seg.body.length == wantFrames * 16, "consecutive segment " + k + ": " + seg.status + " " + seg.body.length + " vs " + wantFrames * 16);
        }
        System.out.println("3 consecutive 7.1 segments in " + (System.nanoTime() - t0) / 1000000 + " ms");

        // ---- persistence: a new server over the same store file sees the playlist and state
        LocalStore again = new LocalStore(work.resolve("store.json").toFile());
        check(again.getPlaylist(id) != null && again.getState() != null, "store survives a restart");

        srv.stop();
        System.out.println(checks + " checks, " + failures + " failures");
        System.exit(failures == 0 ? 0 : 1);
    }
}
