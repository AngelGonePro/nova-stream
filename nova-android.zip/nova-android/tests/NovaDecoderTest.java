import net.cosmoscraft.nova.local.NovaDecoder;
import java.io.*;
import java.nio.*;
import java.nio.channels.FileChannel;
import java.nio.file.*;

/** Compares NovaDecoder with the JavaScript decoder's output (the .ref files written by gen.js), sample for sample. */
public class NovaDecoderTest {
    static int failures = 0, checks = 0;
    static void check(boolean ok, String what) { checks++; if (!ok) { failures++; System.out.println("FAIL: " + what); } }

    static ByteBuffer map(Path p) throws IOException {
        try (FileChannel fc = FileChannel.open(p, StandardOpenOption.READ)) { return fc.map(FileChannel.MapMode.READ_ONLY, 0, fc.size()); }
    }
    static int[][] ref(Path p, int ch, int frames) throws IOException {
        ByteBuffer b = ByteBuffer.wrap(Files.readAllBytes(p)).order(ByteOrder.LITTLE_ENDIAN);
        int[][] r = new int[ch][frames];
        for (int c = 0; c < ch; c++) for (int i = 0; i < frames; i++) r[c][i] = b.getInt((c * frames + i) * 4);
        return r;
    }
    static boolean same(NovaDecoder.Chunk k, int[][] ref) {
        for (int c = 0; c < k.channels.length; c++) for (int i = 0; i < k.frames(); i++) if (k.channels[c][i] != ref[c][k.startSample + i]) {
            System.out.println("  mismatch ch" + c + " sample " + (k.startSample + i) + ": " + k.channels[c][i] + " vs " + ref[c][k.startSample + i]); return false; }
        return true;
    }

    public static void main(String[] a) throws Exception {
        Path dir = Paths.get(a[0]);
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir, "*.nova")) {
            for (Path nova : ds) {
                String name = nova.getFileName().toString().replace(".nova", "");
                ByteBuffer file = map(nova);
                NovaDecoder probe = new NovaDecoder(file);
                int[][] ref = ref(dir.resolve(name + ".ref"), probe.numChannels, probe.numFrames);
                for (int per : new int[]{1, 4, 7, 100}) {
                    NovaDecoder d = new NovaDecoder(file);
                    int covered = 0; boolean ok = true; NovaDecoder.Chunk k;
                    while ((k = d.decodeNextChunk(per)) != null) { ok &= same(k, ref); covered += k.frames(); }
                    check(ok && covered == probe.numFrames, name + " full decode, " + per + " blocks per chunk");
                }
                // resume from the middle: snapshot at several block boundaries, decode the rest from the snapshot
                NovaDecoder d = new NovaDecoder(file);
                java.util.List<NovaDecoder.Snapshot> snaps = new java.util.ArrayList<>();
                int n = 0;
                while (!d.isDone()) { if (n % 3 == 1) snaps.add(d.snapshot()); d.decodeNextChunk(2); n++; }
                int resumed = 0;
                for (NovaDecoder.Snapshot s : snaps) {
                    NovaDecoder r = new NovaDecoder(file, s);
                    check(r.nextSample() == s.startSample, name + " resume position");
                    boolean ok = true; NovaDecoder.Chunk k; int got = 0;
                    while ((k = r.decodeNextChunk(3)) != null) { ok &= same(k, ref); got += k.frames(); }
                    check(ok && s.startSample + got == probe.numFrames, name + " resume from sample " + s.startSample);
                    resumed++;
                }
                NovaDecoder.Chunk first = new NovaDecoder(file).decodeNextChunk(1);
                System.out.println(name + ": " + probe.numChannels + " ch, " + probe.sampleRate + " Hz, " + probe.numFrames + " frames, tags=" + new String(probe.metaJson) + " cover=" + probe.pictureMime + "/" + (probe.pictureBytes() == null ? 0 : probe.pictureBytes().length) + ", " + resumed + " resume points");
            }
        }
        System.out.println(checks + " checks, " + failures + " failures");
        System.exit(failures == 0 ? 0 : 1);
    }
}
