import net.cosmoscraft.nova.local.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Test harness: the on-phone server over real folders, serving the real web player from a directory. Prints "ENTRY <url>". */
public class ServeMain {
    public static void main(String[] a) throws Exception {
        Path music = Paths.get(a[0]), publicDir = Paths.get(a[1]), store = Paths.get(a[2]);
        Library lib = new Library();
        List<Library.Root> roots = new ArrayList<>();
        roots.add(Library.Root.folder("Music", new JavaFileNode(music.toFile())));
        if (a.length > 3) roots.add(Library.Root.files("Selected files", Arrays.asList(new JavaFileNode(Paths.get(a[3]).toFile()))));
        lib.setRoots(roots);
        LocalServer s = new LocalServer(lib, new LocalStore(store.toFile()), p -> { Path f = publicDir.resolve(p).normalize(); return f.startsWith(publicDir) && Files.isRegularFile(f) ? Files.newInputStream(f) : null; }, null, l -> System.err.println("LOG " + l), "This phone");
        s.start(0);
        System.out.println("ENTRY " + s.entryUrl());
        System.out.flush();
        Thread.sleep(Long.MAX_VALUE);
    }
}
