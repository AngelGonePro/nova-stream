import net.cosmoscraft.nova.local.*;
import java.nio.file.*; import java.nio.*;
public class WavTest { public static void main(String[] a) throws Exception {
  int fails = 0;
  for (String n : new String[]{"w16","w24","wf32","w32","w8"}) {
    WavPcmSource s = new WavPcmSource(new JavaFileNode(Paths.get(System.getenv("WORK")+"/wav/"+n+".wav").toFile()).map());
    byte[] ref = Files.readAllBytes(Paths.get(System.getenv("WORK")+"/wav/"+n+".pcm"));
    ByteBuffer rb = ByteBuffer.wrap(ref).order(ByteOrder.LITTLE_ENDIAN);
    short[] buf = new short[4096*s.channels()]; int i = 0, bad = 0, maxd = 0; int n2;
    s.seek(0);
    while ((n2 = s.read(buf, 4096)) > 0) for (int k = 0; k < n2*s.channels(); k++, i++) { int d = Math.abs(buf[k]-rb.getShort(i*2)); if (d>0) bad++; maxd=Math.max(maxd,d);} 
    System.out.println(n+": "+s.channels()+"ch "+s.sampleRate()+"Hz frames="+s.totalFrames()+" samples="+i+" vs "+ref.length/2+" differing="+bad+" maxdiff="+maxd);
    if (i*2 != ref.length || maxd > 1) fails++;
    // mid-file seek
    s.seek(1000); int m = s.read(buf, 10); boolean ok = true; for (int k = 0; k < m*s.channels(); k++) ok &= buf[k]==rb.getShort((1000*s.channels()+k)*2) || Math.abs(buf[k]-rb.getShort((1000*s.channels()+k)*2))<=1; if(!ok){fails++; System.out.println("seek mismatch");}
  }
  System.out.println(fails==0?"WAV OK":"WAV FAIL"); System.exit(fails);
}}
