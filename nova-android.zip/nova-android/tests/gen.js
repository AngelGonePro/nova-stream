const WORK = process.env.WORK || '/tmp/nova-android-tests';
const NovaCodec = require(require('path').join(process.env.NOVA_SERVER, 'lib/novaCodec'));
require('fs').mkdirSync(WORK + '/data', { recursive: true });
const fs = require('fs');
let seed = 12345; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
function make(name, ch, frames, bits, hc, rate = 44100) {
  const channels = [];
  const amp = Math.pow(2, bits - 1) * 0.6;
  for (let c = 0; c < ch; c++) {
    const a = new Int32Array(frames);
    const f1 = 220 * (1 + c * 0.3), f2 = 1330 + c * 17;
    for (let i = 0; i < frames; i++) {
      const env = 0.5 + 0.5 * Math.sin(i / 20000 + c);
      let v = amp * env * (0.6 * Math.sin(2 * Math.PI * f1 * i / rate) + 0.3 * Math.sin(2 * Math.PI * f2 * i / rate)) + (rnd() - 0.5) * amp * 0.05 * (c === 3 ? 0.001 : 1);
      if (i > frames * 0.7 && i < frames * 0.72) v = (rnd() - 0.5) * amp * 1.8; // a noisy burst to hit escapes / big k
      a[i] = Math.max(-Math.pow(2, bits - 1), Math.min(Math.pow(2, bits - 1) - 1, Math.round(v)));
    }
    channels.push(a);
  }
  const wav = { sampleRate: rate, numChannels: ch, bitsPerSample: bits, numFrames: frames, channels };
  const enc = NovaCodec.encode(wav, { tags: { title: name, artist: 'T' }, picture: { mime: 'image/png', data: new Uint8Array([137, 80, 78, 71, 1, 2, 3]) } }, () => {}, { highCompression: hc });
  const bytes = Buffer.from(enc.buffer ? Buffer.from(enc.buffer, enc.byteOffset || 0, enc.byteLength) : enc);
  fs.writeFileSync(`${WORK}/data/${name}.nova`, bytes);
  const dec = NovaCodec.decode(new Uint8Array(bytes));
  // reference: planar int32 LE
  const ref = Buffer.alloc(ch * frames * 4);
  for (let c = 0; c < ch; c++) for (let i = 0; i < frames; i++) ref.writeInt32LE(dec.channels[c][i], (c * frames + i) * 4);
  fs.writeFileSync(`${WORK}/data/${name}.ref`, ref);
  // equal to the source?
  let same = true; for (let c = 0; c < ch; c++) for (let i = 0; i < frames; i++) if (dec.channels[c][i] !== channels[c][i]) same = false;
  const dv = new DataView(bytes.buffer, bytes.byteOffset); const ver = bytes[4]; let p = 5 + 4 + 1 + 1 + 4 + 4; if (ver >= 2) p += 5; let modes = [];
  if (ver >= 7) { const fl = bytes[p]; p += 1 + fl; for (let c = 0; c < ch; c++) modes.push(bytes[p + c]); }
  console.log(name, 'ver', ver, 'bytes', bytes.length, 'roundtrip', same, 'modes', modes.join(','));
}
make('st16', 2, 44100 * 3 + 123, 16, false);
make('st16hc', 2, 44100 * 3 + 777, 16, true);
make('st24hc', 2, 44100 * 2 + 5, 24, true, 96000);
make('mono', 1, 30000, 16, false);
make('s51', 6, 44100 * 2 + 321, 24, false, 48000);
make('s51hc', 6, 44100 * 2 + 99, 24, true, 48000);
make('s71hc', 8, 44100 * 2 + 1, 24, true, 48000);
make('s3', 3, 20000, 16, true);
make('tiny', 2, 100, 16, false);
