// The real NOVA web page (nova-server/public) against the on-phone Java server, in a real browser.
const { chromium } = require(require.resolve('playwright', { paths: ['/opt/npm-tools/node_modules'] }));
const assert = require('assert'), fs = require('fs'), os = require('os'), path = require('path');
const { spawn, execFileSync } = require('child_process');
const { encodeFile } = require(require('path').join(process.env.NOVA_DESKTOP, 'src/toolsCore'));
(async () => {
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-page-')), music = path.join(work, 'Music', 'Album');
  fs.mkdirSync(music, { recursive: true });
  const ff = (...a) => execFileSync('ffmpeg', ['-v', 'error', '-y', ...a]);
  ff('-f', 'lavfi', '-i', 'sine=frequency=330:duration=150:sample_rate=48000', '-ac', '2', '-metadata', 'title=Long Tone', '-metadata', 'artist=Sine', path.join(work, 'long.flac'));
  ff('-f', 'lavfi', '-i', 'sine=frequency=550:duration=5:sample_rate=48000', '-ac', '2', '-metadata', 'title=Short Tone', '-metadata', 'artist=Sine', path.join(work, 'short.flac'));
  await encodeFile({ input: path.join(work, 'long.flac'), output: path.join(music, 'long.nova'), ffmpeg: 'ffmpeg', ffprobe: 'ffprobe' });
  await encodeFile({ input: path.join(work, 'short.flac'), output: path.join(music, 'short.nova'), ffmpeg: 'ffmpeg', ffprobe: 'ffprobe' });
  ff('-f', 'lavfi', '-i', 'sine=frequency=440:duration=8:sample_rate=44100', '-ac', '2', '-c:a', 'pcm_s16le', path.join(music, 'plain.wav'));
  ff('-f', 'lavfi', '-i', 'sine=frequency=660:duration=6:sample_rate=48000', '-ac', '2', '-c:a', 'pcm_s16le', path.join(work, 'picked.wav'));

  const java = spawn('java', ['-cp', process.env.WORK + '/classes', 'ServeMain', path.join(work, 'Music'), require('path').join(process.env.NOVA_SERVER, 'public'), path.join(work, 'store.json'), path.join(work, 'picked.wav')], { stdio: ['ignore', 'pipe', 'pipe'] });
  const logs = []; java.stderr.on('data', (d) => logs.push(String(d)));
  const entry = await new Promise((res, rej) => { let b = ''; java.stdout.on('data', (d) => { b += d; const m = b.match(/ENTRY (\S+)/); if (m) res(m[1]); }); java.on('exit', () => rej(new Error('server exited: ' + logs.join('')))); });
  const browser = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
  try {
    const ctx = await browser.newContext(); const page = await ctx.newPage();
    const errors = []; page.on('pageerror', (e) => errors.push(String(e)));
    const pcm = []; page.on('request', (r) => { if (r.url().includes('/api/stream/pcm')) pcm.push(r.url()); });
    await page.goto(entry);
    await page.waitForSelector('#dirList .dirRow', { timeout: 20000 });
    console.log('top level:', (await page.$$eval('#dirList .dirRow', (e) => e.map((x) => x.textContent.trim()))).join(' | '));
    assert.deepStrictEqual(await page.$$eval('#dirList .dirRow', (e) => e.map((x) => x.textContent.trim())), ['📁 Music', '📁 Selected files']);
    await page.locator('#dirList .dirRow', { hasText: 'Music' }).click(); await page.waitForFunction(() => /Album/.test(document.getElementById('dirList').textContent));
    await page.locator('#dirList .dirRow', { hasText: 'Album' }).click();
    await page.waitForSelector('#trackList .track-row', { timeout: 20000 });
    assert.strictEqual(await page.locator('#trackList .track-row').count(), 3);
    await page.waitForFunction(() => /Long Tone/.test(document.getElementById('trackList').textContent), null, { timeout: 20000 });
    await page.locator('#trackList .track-row', { hasText: 'Long Tone' }).dblclick();
    await page.waitForFunction(() => document.getElementById('timeTotal').textContent !== '0:00' && document.getElementById('timeTotal').textContent.trim() !== '', null, { timeout: 30000 });
    assert.match(await page.textContent('#timeTotal'), /2:30/);
    await page.waitForFunction(() => /^0:0[1-9]/.test(document.getElementById('timeCurrent').textContent), null, { timeout: 30000 });
    console.log('playing', await page.textContent('#timeCurrent') + ' / ' + await page.textContent('#timeTotal'));
    const before = pcm.length;
    await page.evaluate(() => { const b = document.getElementById('seekBar'); b.value = Math.round((+b.max || 1000) * 0.8); b.dispatchEvent(new Event('pointerdown')); b.dispatchEvent(new Event('input')); b.dispatchEvent(new Event('pointerup')); b.dispatchEvent(new Event('change')); });
    await page.waitForFunction(() => { const [m, s] = document.getElementById('timeCurrent').textContent.split(':').map(Number); return m * 60 + s >= 119; }, null, { timeout: 30000 });
    console.log('after seek', await page.textContent('#timeCurrent'), pcm.slice(before).map((u) => u.replace(/.*skipToSeconds=/, 'skip=')).join(' '));
    // the page asks for 60-second segments; on a fast local connection it may already have fetched the later ones before the seek
    assert.ok(pcm.some((u) => /skipToSeconds=120&/.test(u)), 'the later part of the song was requested: ' + pcm.join(' '));
    // a WAV plays too
    await page.locator('#trackList .track-row', { hasText: 'plain' }).dblclick();
    await page.waitForFunction(() => /0:08/.test(document.getElementById('timeTotal').textContent), null, { timeout: 30000 });
    await page.waitForFunction(() => /^0:0[1-9]/.test(document.getElementById('timeCurrent').textContent), null, { timeout: 30000 });
    console.log('wav playing', await page.textContent('#timeCurrent'));
    // search, playlists, saved state
    await page.fill('#searchBox', 'short'); await page.waitForFunction(() => /Short Tone/.test(document.getElementById('trackList').textContent), null, { timeout: 20000 });
    await page.fill('#searchBox', '');
    const created = await page.evaluate(async () => { const r = await fetch('/api/playlists', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'From page' }) }); return r.json(); });
    assert.strictEqual(created.name, 'From page');
    await page.waitForFunction(async () => { const s = await (await fetch('/api/state')).json(); return s && s.trackId; }, null, { timeout: 40000 });
    const st = await page.evaluate(async () => (await fetch('/api/state')).json());
    console.log('saved state:', st.trackId, 'updatedBy', st.updatedByDevice);
    // settings
    await page.click('#settingsToggle'); await page.waitForTimeout(300);
    assert.ok(await page.$('#libraryManageBtn'));
    assert.deepStrictEqual(errors, [], 'no page errors: ' + errors.join('; '));
    console.log('page against the on-phone server: OK');
  } finally { await browser.close(); java.kill(); fs.rmSync(work, { recursive: true, force: true }); }
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
