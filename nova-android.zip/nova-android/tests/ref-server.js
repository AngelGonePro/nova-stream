// Records what the real (desktop-embedded) NOVA server answers for a set of requests, for NovaLocalServerTest to compare against.
const path = require('path'), fs = require('fs'), http = require('http'), os = require('os');
const { startLocalServer } = require(require('path').join(process.env.NOVA_DESKTOP, 'src/local/localServer'));
const WORK = process.env.WORK || '/tmp/nova-android-tests', DATA = WORK + '/data', OUT = process.env.NOGAIN ? WORK + '/ref-nogain' : WORK + '/ref';
(async () => {
  fs.rmSync(OUT, { recursive: true, force: true }); fs.mkdirSync(OUT, { recursive: true });
  const dd = fs.mkdtempSync(path.join(os.tmpdir(), 'ref-data-'));
  const s = await startLocalServer({ dataDir: dd, roots: [{ name: 'Music', dir: DATA }, { name: 'Picked', files: [path.join(DATA, 's51.nova'), path.join(DATA, 'mono.nova')] }], ffmpeg: 'ffmpeg', ffprobe: 'ffprobe' });
  if (process.env.NOGAIN) require(require('path').join(process.env.NOVA_DESKTOP, 'src/local/server/lib/pcmCache')).getProvisionalGain = () => 1; // the server's level matching switched off, for a sample-exact comparison
  const cookie = await new Promise((res) => http.get({ hostname: '127.0.0.1', port: s.port, path: '/__nova_local?k=' + s.key }, (r) => res(r.headers['set-cookie'][0].split(';')[0])));
  const reqs = [
    '/api/browse', '/api/browse?path=', '/api/browse?path=Music', '/api/browse?path=Picked', '/api/browse?path=Music/', '/api/browse?path=Nope', '/api/browse?path=Music/nothing', '/api/browse?path=Music/../x', '/api/browse?path=Picked/s51.nova', '/api/browse?path=Music/st16.nova',
    '/api/browse/tags?path=Music/st16.nova', '/api/browse/tags?path=Music/s71hc.nova', '/api/browse/tags?path=Picked/mono.nova', '/api/browse/tags?path=Music', '/api/browse/tags?path=Zip/a.nova',
    '/api/browse/artwork?path=Music/st16.nova', '/api/browse/artwork?path=Music/nothing.nova',
    '/api/stream/pcm?path=Music/s51.nova&quality=full&skipToSeconds=0&maxDurationSeconds=1',
    '/api/stream/pcm?path=Music/s51.nova&quality=full&skipToSeconds=1.2&maxDurationSeconds=0.7',
    '/api/stream/pcm?path=Music/st16.nova&skipToSeconds=1&maxDurationSeconds=1',
    '/api/stream/pcm?path=Music/st16hc.nova&skipToSeconds=2.5',
    '/api/stream/pcm?path=Music/st24hc.nova&quality=full&skipToSeconds=0.5&maxDurationSeconds=1.5',
    '/api/stream/pcm?path=Music/tiny.nova',
    '/api/stream/pcm?path=Music/mono.nova&skipToSeconds=0.3&maxDurationSeconds=1',
    '/api/stream/pcm?path=Music/s71hc.nova&skipToSeconds=0.4&maxDurationSeconds=1',
    '/api/stream/pcm?path=Music/s3.nova&skipToSeconds=0.2&maxDurationSeconds=3',
    '/api/stream/pcm?path=Music/st16.nova&skipToSeconds=99&maxDurationSeconds=60',
    '/api/stream/pcm?path=Music/s51.nova&skipToSeconds=1.0&maxDurationSeconds=60',
    '/api/stream/pcm?path=Picked/mono.nova&skipToSeconds=0.1&maxDurationSeconds=1',
    '/api/stream/pcm?path=Music/nothing.nova', '/api/stream/pcm?path=Music/../x',
    '/api/stream/stats', '/api/state', '/api/playlists', '/api/auth/me',
  ];
  const get = (u) => new Promise((resolve) => http.get({ hostname: '127.0.0.1', port: s.port, path: u, headers: { Cookie: cookie } }, (r) => { const c = []; r.on('data', (d) => c.push(d)); r.on('end', () => resolve({ status: r.statusCode, headers: r.headers, body: Buffer.concat(c) })); }));
  const index = [];
  for (let i = 0; i < reqs.length; i++) {
    const r = await get(reqs[i]);
    const pcmH = {}; for (const k of Object.keys(r.headers)) if (k.startsWith('x-pcm') || k === 'content-type') pcmH[k] = r.headers[k];
    fs.writeFileSync(path.join(OUT, i + '.body'), r.body);
    index.push({ i, url: reqs[i], status: r.status, headers: pcmH, bytes: r.body.length });
  }
  fs.writeFileSync(path.join(OUT, 'index.json'), JSON.stringify(index, null, 1));
  console.log('recorded', index.length, 'responses');
  await s.close(); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
