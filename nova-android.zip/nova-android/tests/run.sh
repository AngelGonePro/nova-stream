#!/bin/sh
# Tests for the on-phone library (the Java code in app/src/main/java/net/cosmoscraft/nova/local), run on a plain JVM:
#   1. NovaDecoderTest  - the Java NOVA decoder equals the JavaScript decoder sample for sample (incl. decoding from the middle)
#   2. LocalServerTest  - the on-phone server answers like the real NOVA server (browse, tags, cover art, PCM bytes and headers,
#                         seeking, level matching) and handles state, playlists and access control
#   3. WavTest          - WAV files against ffmpeg
#   4. page-test.js     - the real web player, in a browser, playing from the on-phone server (needs Playwright)
# Usage:  NOVA_SERVER=/path/to/nova-server NOVA_DESKTOP=/path/to/nova-desktop tests/run.sh
set -e
: "${NOVA_SERVER:?set NOVA_SERVER to the nova-server folder}"
: "${NOVA_DESKTOP:?set NOVA_DESKTOP to the nova-desktop folder (its embedded server is the reference)}"
export NOVA_SERVER NOVA_DESKTOP
HERE=$(cd "$(dirname "$0")" && pwd)
export WORK=${WORK:-/tmp/nova-android-tests}
SRC="$HERE/../app/src/main/java/net/cosmoscraft/nova/local"
rm -rf "$WORK"; mkdir -p "$WORK/classes"
node "$HERE/gen.js"
(cd "$NOVA_DESKTOP" && NOGAIN=1 node "$HERE/ref-server.js" && node "$HERE/ref-server.js")
javac -nowarn -d "$WORK/classes" "$SRC"/*.java "$HERE"/*.java 2>&1 | grep -v "^Note:\|Picked up" || true
java -cp "$WORK/classes" NovaDecoderTest "$WORK/data" 2>&1 | grep -v "Picked up"
java -cp "$WORK/classes" LocalServerTest "$WORK/data" "$WORK/ref-nogain" "$WORK/ref" 2>&1 | grep -v "Picked up"
mkdir -p "$WORK/wav" && cd "$WORK" && for spec in "w16 pcm_s16le 44100 2" "w24 pcm_s24le 48000 6" "wf32 pcm_f32le 44100 1" "w32 pcm_s32le 44100 1" "w8 pcm_u8 22050 1"; do
  set -- $spec; ffmpeg -v error -y -f lavfi -i "sine=frequency=440:duration=1:sample_rate=$3" -af "aeval=$(yes 'val(0)*0.7' | head -$4 | paste -sd'|')" -c:a $2 wav/$1.wav; ffmpeg -v error -y -i wav/$1.wav -f s16le wav/$1.pcm; done
java -cp "$WORK/classes" WavTest 2>&1 | grep -v "Picked up"
node "$HERE/page-test.js"
