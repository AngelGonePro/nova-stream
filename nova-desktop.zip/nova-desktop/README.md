# NOVA Desktop

An Electron "web wrapper" around the NOVA web UI — the same relationship
the NOVA Android app has to its own WebView. Loads the real server UI
unmodified, and adds native desktop capabilities alongside it: local disk
caching of whole tracks (for instant re-seeking and reduced network use),
per-device audio output selection for as close to bit-perfect playback as
the Web Audio API allows, a local logs panel, and crash logging that
survives even a full process crash.

## Setup

```
npm install
npm start
```

By default this connects to `https://music.cosmoscraft.net`. To point at a
different server, set the `NOVA_SERVER_ORIGIN` environment variable before
starting:

```
NOVA_SERVER_ORIGIN=https://your-server.example npm start
```

## What's actually new here (vs. just loading the site in a browser)

- **Local disk caching.** The background download system is a direct port
  of the Android app's own architecture — same design, same safety fixes
  that were found the hard way there: a hard size cap per track (default
  350MB) so a stuck download can never fill your disk, automatic rollback
  if a download attempt fails partway through (so a retry can never leave
  duplicate/corrupted audio in the cache), and cleanup of any leftover
  cache files from a previous session that didn't shut down cleanly.
- **Gapless prefetch.** The player's own existing web-audio scheduling
  already fetches the next track's data ahead of time to attempt a
  gapless transition — the caching layer detects that ahead-of-time
  fetch specifically (distinguishing "app.js is prefetching while the
  current track is still playing" from "the current track is genuinely
  done") and starts a separate background download for it without
  disturbing the still-relevant current one. When the player actually
  transitions to that track, the already-running download is handed off
  and continues seamlessly rather than restarting from scratch.
- **Output device selection.** Uses `AudioContext.setSinkId()` (native to
  Chromium since version 110 — any current Electron has it) to route
  playback to a specific audio device, picked from the dropdown in the
  bottom-right corner of the window.
- **Logs button**, same corner — opens a separate window showing recent
  activity, live-updating, with a "copy all" button. Capped in memory and
  on disk so logging itself can never become its own storage/RAM leak.
- **Crash survival.** Anything uncaught, anywhere in the app (main process
  or the page itself), gets written to a file on disk *before* the app
  goes down. The next launch checks for that file first, before anything
  else runs, and puts it at the top of the logs.

## How the caching works, without touching the existing web UI

The loaded page's own JavaScript is used completely unmodified — none of
its playback, scheduling, or gapless-transition logic was touched. A small
patch in the preload script intercepts only `fetch()` calls to
`/api/stream/pcm` (every other request — images, other API calls — passes
through untouched) and transparently serves already-downloaded data from
the local cache when available, falling back to a normal network request
otherwise. The existing page has no way to tell the difference.

## What's verified vs. what still needs real-world testing

Verified directly, by actually running this app under Electron (not just
reasoned about from reading the code):
- The app starts, creates its window, and shuts down cleanly with no
  crash.
- Logging writes correctly to disk and persists across restarts.
- The crash handler was deliberately triggered, confirmed to catch the
  exception and write the full stack trace to a durable file, and the
  *next* launch was confirmed to pick that file up, display it, and clear
  it so it doesn't reappear.

**Not yet tested, because the environment this was built in has no real
network access to a live NOVA server, no real audio hardware, and no real
display:**
- The fetch-patch actually serving cached audio during real playback.
- The gapless prefetch logic specifically — distinguishing a real
  ahead-of-time prefetch fetch from an actual track transition depends on
  timing and request patterns from the real player that can't be
  observed without a real server to actually play tracks against.
- The output-device picker with real, physical audio devices.
- The download manager's behavior against a real server over a real
  network (timeouts, retries, actual file growth).

This is worth being direct about: everything above that's marked
"verified" is genuinely confirmed working, not assumed. Everything else is
carried over from a design that was proven correct on Android, applied
carefully to a different platform's constraints, and reasoned through as
rigorously as I could — but a design reasoned about correctly is not the
same claim as one that's actually been run. If something in the untested
list doesn't behave as expected, the logs window (and the crash file
mechanism if it's a hard crash) exist specifically to make that fast to
diagnose rather than another round of guessing in the dark.
