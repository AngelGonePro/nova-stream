# NOVA Desktop

An Electron "web wrapper" around the NOVA web UI — the same relationship
the NOVA Android app has to its own WebView. Loads the real server UI
unmodified, and adds native desktop capabilities alongside it: local disk
caching of whole tracks (for instant re-seeking and reduced network use),
per-device audio output selection for as close to bit-perfect playback as
the Web Audio API allows, a local logs panel, and crash logging that
survives even a full process crash.

## Setup

```
npm install
npm start
```

On first start the app asks which NOVA server to use (an https address) - or you can choose **Play files on this
computer instead** (see below). The choice is remembered. To switch later: **NOVA > Change Server…**, or Settings > Server
in the player. Switching clears the downloaded-track cache (it belongs to the old server).
`NOVA_SERVER_ORIGIN=https://your-server.example npm start` still overrides the stored choice for one launch.

## Local library: your own files in the full NOVA player, no server

Choose "Play files on this computer" and pick folders and/or individual files (**NOVA > Local library: choose folders
and files…**, or Settings > Server > Choose folders and files…). The app then runs the NOVA server code itself on
127.0.0.1 and shows the same player page as the online server, so everything works the same way: browsing and search,
seeking (with a saved seek index, so jumping around in a song you have played is instant), queue with play-next /
add-to-end / reorder / remove, shuffle, repeat, playlists, cover art, tags, loudness normalisation, gapless playback,
Last.fm. FLAC, WAV, MP3, M4A, OGG and the rest play too (decoded with ffmpeg); `.nova` files decode natively and
multichannel goes out as 6/8 channels when the output device has them.

- Folders are read live; nothing is copied or uploaded. Hand-picked files appear together under "Selected files".
- Playlists, the saved queue/position and Last.fm settings are stored in the app's data folder (`local-library/`).
- Only this app can reach the local server: it listens on loopback, checks the Host header and requires a random
  per-launch key.
- The player page and server code under `src/local/server/` are copied from nova-server with
  `npm run sync-server` (expects nova-server next to this folder), so the local player always matches the server's.

## Library Tools (NOVA > Library Tools…, Ctrl/Cmd+Shift+L)

Works on files on this computer, no server involved. Encode and Decode share one **queue**:

- **Encode**: add files or a whole folder (FLAC, WAV, ALAC/M4A, MP3, OGG, OPUS, AIFF, WavPack, APE) and turn them into
  `.nova`. Tags and cover art are carried over, and every file is checked by decoding it again and comparing every
  sample before it is written (can be switched off).
- **Decode**: `.nova` back to **FLAC** (with tags and cover) or WAV, bit-exact.
- **Queue**: every file keeps the options it was added with (high compression, verify, output folder, FLAC/WAV).
  Add more at any time, also while it runs. **Start / Pause / Stop**: Pause lets running files finish and starts no
  new ones; Stop kills the running conversions (including their ffmpeg processes), deletes half-written files and puts
  them back in the queue. Move waiting files up/down, remove them, retry failed ones (the failure reason is on the
  row), clear finished ones. The bar at the top shows overall progress, elapsed time and the estimated time left.
  Threads (default: cores − 1) can be changed while it runs. Waiting and failed files are still there after a restart.
- Everything is logged in **NOVA > Open Logs**: each ffmpeg/ffprobe launch with its full command line, every file read,
  temp file, rename and delete, and each job's start and end.

Conversion uses ffmpeg: `npm install` fetches one (ffmpeg-static); otherwise an `ffmpeg`/`ffprobe` on PATH is used.

Tests: `npm test` (queue and conversions on real files and real worker threads, the queue page, the local library
server, server-address handling). With a display (or `xvfb-run -a`): `node test/electron-smoke.js` and
`node test/electron-local.js` launch the real app (first-start choice, tools window and a real queue, local library
with real playback and seeking).

## What's actually new here (vs. just loading the site in a browser)

- **Local disk caching.** The background download system is a direct port
  of the Android app's own architecture — same design, same safety fixes
  that were found the hard way there: a hard size cap per track (default
  350MB) so a stuck download can never fill your disk, automatic rollback
  if a download attempt fails partway through (so a retry can never leave
  duplicate/corrupted audio in the cache), and cleanup of any leftover
  cache files from a previous session that didn't shut down cleanly.
- **Gapless prefetch.** The player's own existing web-audio scheduling
  already fetches the next track's data ahead of time to attempt a
  gapless transition — the caching layer detects that ahead-of-time
  fetch specifically (distinguishing "app.js is prefetching while the
  current track is still playing" from "the current track is genuinely
  done") and starts a separate background download for it without
  disturbing the still-relevant current one. When the player actually
  transitions to that track, the already-running download is handed off
  and continues seamlessly rather than restarting from scratch.
- **Output device selection.** Uses `AudioContext.setSinkId()` (native to
  Chromium since version 110 — any current Electron has it) to route
  playback to a specific audio device, picked from the dropdown in the
  bottom-right corner of the window.
- **Logs button**, same corner — opens a separate window showing recent
  activity, live-updating, with a "copy all" button. Capped in memory and
  on disk so logging itself can never become its own storage/RAM leak.
- **Crash survival.** Anything uncaught, anywhere in the app (main process
  or the page itself), gets written to a file on disk *before* the app
  goes down. The next launch checks for that file first, before anything
  else runs, and puts it at the top of the logs.

## How the caching works, without touching the existing web UI

The loaded page's own JavaScript is used completely unmodified — none of
its playback, scheduling, or gapless-transition logic was touched. A small
patch in the preload script intercepts only `fetch()` calls to
`/api/stream/pcm` (every other request — images, other API calls — passes
through untouched) and transparently serves already-downloaded data from
the local cache when available, falling back to a normal network request
otherwise. The existing page has no way to tell the difference.

## What's verified vs. what still needs real-world testing

Verified directly, by actually running this app under Electron (not just
reasoned about from reading the code):
- The app starts, creates its window, and shuts down cleanly with no
  crash.
- Logging writes correctly to disk and persists across restarts.
- The crash handler was deliberately triggered, confirmed to catch the
  exception and write the full stack trace to a durable file, and the
  *next* launch was confirmed to pick that file up, display it, and clear
  it so it doesn't reappear.

**Not yet tested, because the environment this was built in has no real
network access to a live NOVA server, no real audio hardware, and no real
display:**
- The fetch-patch actually serving cached audio during real playback.
- The gapless prefetch logic specifically — distinguishing a real
  ahead-of-time prefetch fetch from an actual track transition depends on
  timing and request patterns from the real player that can't be
  observed without a real server to actually play tracks against.
- The output-device picker with real, physical audio devices.
- The download manager's behavior against a real server over a real
  network (timeouts, retries, actual file growth).

This is worth being direct about: everything above that's marked
"verified" is genuinely confirmed working, not assumed. Everything else is
carried over from a design that was proven correct on Android, applied
carefully to a different platform's constraints, and reasoned through as
rigorously as I could — but a design reasoned about correctly is not the
same claim as one that's actually been run. If something in the untested
list doesn't behave as expected, the logs window (and the crash file
mechanism if it's a hard crash) exist specifically to make that fast to
diagnose rather than another round of guessing in the dark.
