'use strict';
// Copies the parts of nova-server that the desktop app's "Local library" runs (lib/, routes/, public/) into
// src/local/server/, so the local player is the same code and the same page as the server's.
// Usage: node scripts/sync-server.js <path to nova-server>
const fs = require('fs'), path = require('path');
const src = path.resolve(process.argv[2] || '');
if (!src || !fs.existsSync(path.join(src, 'lib', 'musicBrowser.js'))) { console.error('usage: node scripts/sync-server.js <path to nova-server>'); process.exit(1); }
const dest = path.join(__dirname, '..', 'src', 'local', 'server');
fs.rmSync(dest, { recursive: true, force: true });
let n = 0;
const copy = (rel, filter) => {
  const from = path.join(src, rel), to = path.join(dest, rel);
  fs.mkdirSync(to, { recursive: true });
  for (const e of fs.readdirSync(from, { withFileTypes: true })) {
    if (e.isDirectory()) copy(path.join(rel, e.name), filter);
    else if (!filter || filter(e.name)) { fs.copyFileSync(path.join(from, e.name), path.join(to, e.name)); n++; }
  }
};
copy('lib'); copy('routes'); copy('public');
// the admin screen needs the server's user management; the single-user local library has none of it
console.log(`synced ${n} files from ${src}`);
