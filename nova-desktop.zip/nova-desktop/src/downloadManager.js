'use strict';
// Real, direct port of the Android app's handleStartTrackDownload — same
// segmented, resilient background download (a hiccup costs one small
// retry, not a redo of everything downloaded so far), same rollback on a
// failed attempt, same explicit, unconditional stop on a track switch
// rather than only an implicit one from the next download superseding it.

const https = require('https');
const http = require('http');
const { URL } = require('url');
const { TrackBuffer } = require('./trackBuffer');

class DownloadManager {
    constructor({ serverOrigin, cacheDir, maxTrackBytes, logFn, getCookieHeader }) {
        this.serverOrigin = serverOrigin;
        this.cacheDir = cacheDir;
        this.maxTrackBytes = maxTrackBytes;
        this.log = logFn;
        // Real, direct fix for a confirmed HTTP 401 report — see this
        // option's own call site in main.js for the full explanation.
        // Optional and defaulted so this class still works standalone
        // (e.g. in tests) without a real Electron session behind it.
        this.getCookieHeader = getCookieHeader || (async () => '');
        this.current = null; // { buffer: TrackBuffer, generation }
        this.next = null;    // same shape, for gapless prefetch
        this.currentGeneration = 0;
        this.nextGeneration = 0;
    }

    /** Stops the current track's download unconditionally — called on every hard track switch, mirroring stopTrackDownload on the Android side. */
    stopCurrent() {
        this.currentGeneration++;
        if (this.current) { this.current.buffer.close(); this.current = null; }
    }

    /** Stops the prefetch download unconditionally — called on every hard track switch, mirroring stopNextTrackDownload. This is the fix for the exact OOM leak found on Android: a stale prefetch that nothing stopped kept downloading indefinitely. */
    stopNext() {
        this.nextGeneration++;
        if (this.next) { this.next.buffer.close(); this.next = null; }
    }

    /** Finds the TrackBuffer (current or next) covering this exact trackId + startAtSeconds combination, if one exists and is still valid. */
    findBuffer(trackId, startAtSeconds) {
        if (this.current && this.current.trackId === trackId && this.current.startAtSeconds === startAtSeconds) return this.current.buffer;
        if (this.next && this.next.trackId === trackId && this.next.startAtSeconds === startAtSeconds) return this.next.buffer;
        return null;
    }

    /**
     * Starts (or restarts) the main download for a track at a given start
     * position. Mirrors startTrackDownload/handleStartTrackDownload —
     * segmented sequential fetch, rollback on retry failure, frame-safe
     * total-bytes accounting relative to the requested start position (not
     * the whole file), reusing the server's own X-PCM-Skip-Samples header
     * the same way the Android fix does.
     */
    startCurrent(trackId, path, quality, startAtSeconds) {
        this.stopCurrent();
        const myGeneration = this.currentGeneration;
        // Real, direct fix carried over from the exact bug just found and
        // fixed on the Android app: a mutable role object, not a fixed
        // closure variable, is what lets promoteNextToCurrent below
        // actually change which generation counter the ALREADY-RUNNING
        // download loop checks — a closure that captured "isNext" and
        // "myGeneration" once, at start time, has no way to be updated
        // later; the loop would stay bound to the wrong counter forever,
        // exactly as it did on Android before this fix.
        const role = { isNext: false, generation: myGeneration };
        const entry = { trackId, startAtSeconds, buffer: null, role, isFinished: false };
        this.current = entry;
        this._runDownloadLoop(entry, path, quality, startAtSeconds, () => (role.isNext ? this.nextGeneration : this.currentGeneration) === role.generation, role);
    }

    /** Starts the gapless prefetch download for the next queued track — mirrors prepareNextTrackDownload. */
    startNext(trackId, path, quality) {
        this.stopNext();
        const myGeneration = this.nextGeneration;
        const role = { isNext: true, generation: myGeneration };
        const entry = { trackId, startAtSeconds: 0, buffer: null, role, isFinished: false };
        this.next = entry;
        this._runDownloadLoop(entry, path, quality, 0, () => (role.isNext ? this.nextGeneration : this.currentGeneration) === role.generation, role);
    }

    /**
     * If the prefetch buffer matches, promotes it to current (used once a
     * gapless transition happens) — mirrors the seamless-swap handoff.
     * Closes whatever the OLD current buffer was first. Critically, also
     * flips role.isNext and re-anchors role.generation to the CURRENT
     * value of currentGeneration — this is what makes the SAME
     * already-running download loop start checking the right counter
     * from this point on, rather than needing to be stopped and
     * restarted (which would lose whatever was already downloaded).
     */
    promoteNextToCurrent() {
        if (this.current) this.current.buffer.close();
        this.current = this.next;
        this.next = null;
        if (this.current) {
            this.current.role.isNext = false;
            this.current.role.generation = this.currentGeneration;
        }
    }

    /** Real, direct addition for wiring up gapless prefetch — lets the fetch-patch tell "current track is still actively playing/downloading" apart from "current track is genuinely done," which is the one signal needed to correctly route a new path to a prefetch instead of prematurely killing the still-relevant current download. */
    isCurrentFinished() {
        return !this.current || this.current.isFinished;
    }

    /**
     * Real, direct addition for a confirmed request-amplification bug —
     * see this method's own call site in main.js for the full reasoning.
     * True when a download for this exact trackId is already running and
     * hasn't given up yet — the one thing fetch-patch needs to know
     * before deciding whether to wait for it instead of starting a
     * competing direct request for the same bytes.
     */
    isActiveFor(trackId) {
        return (this.current && this.current.trackId === trackId && !this.current.isFinished) ||
               (this.next && this.next.trackId === trackId && !this.next.isFinished);
    }

    /** trackId of whatever the download manager currently considers "next," if any — lets the fetch-patch check whether an incoming request matches an already-running prefetch before deciding whether to promote it or start fresh. */
    getNextTrackId() {
        return this.next ? this.next.trackId : null;
    }

    /** Promotes the current prefetch to current ONLY if its trackId matches — a safe, idempotent operation the fetch-patch can call without first having to re-verify anything itself. Returns true if a promotion actually happened. */
    promoteIfMatches(trackId) {
        if (this.next && this.next.trackId === trackId) {
            this.promoteNextToCurrent();
            return true;
        }
        return false;
    }

    async _runDownloadLoop(entry, sourcePath, quality, startAtSeconds, stillValid, role) {
        const segmentSeconds = 60;
        let skipToSeconds = Math.floor(startAtSeconds || 0);
        let reportedTotal = false;

        segmentLoop:
        while (stillValid()) {
            let succeeded = false;
            let rollbackPosition = entry.buffer ? entry.buffer.downloadedBytes : null;
            for (let attempt = 0; attempt < 5; attempt++) {
                if (!stillValid()) break segmentLoop;
                try {
                    const { statusCode, headers, body } = await this._fetchSegment(sourcePath, quality, skipToSeconds, segmentSeconds);
                    if (statusCode < 200 || statusCode >= 300) {
                        this.log('DownloadManager', `[${role.isNext ? "next" : "current"}] segment failed: HTTP ${statusCode} at ${skipToSeconds}s (attempt ${attempt + 1}/5)`);
                        await sleep(Math.min(8000, 500 * Math.pow(2, attempt)));
                        continue;
                    }
                    if (!reportedTotal) {
                        const totalFrames = headers['x-pcm-total-frames'] ? parseInt(headers['x-pcm-total-frames'], 10) : null;
                        const skipSamples = headers['x-pcm-skip-samples'] ? parseInt(headers['x-pcm-skip-samples'], 10) : 0;
                        const headerSampleRate = headers['x-pcm-sample-rate'] ? parseInt(headers['x-pcm-sample-rate'], 10) : 44100;
                        const headerChannels = headers['x-pcm-channels'] ? parseInt(headers['x-pcm-channels'], 10) : 2;
                        if (!entry.buffer) {
                            // Real, direct fix for the exact ordering bug
                            // found on the Android side: the buffer must
                            // exist before totalBytes is set on it, or a
                            // restart's total silently lands on a buffer
                            // about to be discarded. Created first, always.
                            entry.buffer = new TrackBuffer(entry.trackId, headerSampleRate, headerChannels, this.cacheDir, this.maxTrackBytes);
                            entry.buffer.originSamples = skipSamples; // where this buffer's byte 0 sits in the track — see TrackBuffer.originSamples
                            // Real, direct fix, ported from the identical edge case fixed
                            // on Android: rollbackPosition above was captured BEFORE this
                            // buffer existed, so for the track's very first segment it is
                            // still null. If this same attempt then fails partway (a
                            // response cut off after the buffer was created), the rollback
                            // below was skipped and the retry appended a second full copy
                            // after the partial one — measured against the real server:
                            // a cache holding 157s of audio for a 150s track, duplicated
                            // from the first few seconds on. A brand new buffer's
                            // downloadedBytes is always 0, so set it explicitly.
                            rollbackPosition = 0;
                        }
                        if (totalFrames != null) {
                            const remainingFrames = Math.max(0, totalFrames - skipSamples);
                            entry.buffer.totalBytes = remainingFrames * headerChannels * 2;
                            reportedTotal = true;
                        }
                    }
                    let gotAnyBytes = false;
                    // Where in the buffer THIS response's bytes start landing.
                    const requestStartByte = entry.buffer.downloadedBytes;
                    for await (const chunk of body) {
                        if (!stillValid()) break segmentLoop;
                        if (chunk.length === 0) continue;
                        gotAnyBytes = true;
                        entry.buffer.append(chunk, this.log);
                    }
                    // Real, direct fix — the desktop half of the "skipped the whole
                    // song" bug (the Android half is SegmentValidation.kt). A response
                    // that ENDS CLEANLY is not proof it was complete: when something
                    // fails after the headers are out (the server's resampling ffmpeg
                    // killed, a decode error) the server just ends the response, so
                    // this sees a normal HTTP 200 with a short — or empty — body.
                    // That matters more here than it looks, because the cache is read
                    // by byte offset computed from time (main.js: startByte =
                    // relativeSeconds * bytesPerSecond), so it must stay perfectly
                    // time-aligned. One short segment accepted as complete shifts every
                    // later segment's bytes, and from then on the player is served
                    // audio from the wrong part of the song. Checked against the track
                    // length the server itself promised; measured against the real
                    // server the delivered bytes match that total to within one frame,
                    // so 20ms of slack is a ~600x margin. Throwing sends it through the
                    // existing rollback-to-segment-start-and-retry handling.
                    {
                        const bytesPerSecond = entry.buffer.sampleRate * entry.buffer.channels * 2;
                        const tolerance = Math.trunc(bytesPerSecond / 50);
                        const total = entry.buffer.totalBytes;
                        const downloaded = entry.buffer.downloadedBytes;
                        if (total != null) {
                            if (!gotAnyBytes) {
                                if (downloaded + tolerance < total) throw new Error(`empty response at ${skipToSeconds}s but only ${downloaded} of ${total} bytes downloaded — not a real end of file`);
                            } else {
                                const expected = Math.min(segmentSeconds * bytesPerSecond, Math.max(0, total - requestStartByte));
                                const received = downloaded - requestStartByte;
                                if (received + tolerance < expected) throw new Error(`short response at ${skipToSeconds}s: got ${received} bytes of ${expected} expected`);
                            }
                        }
                    }
                    succeeded = true;
                    if (gotAnyBytes) {
                        // Real, direct addition for a confirmed follow-up
                        // request for detail matching the Android app's own
                        // level of logging — this is the actual per-segment
                        // cache-size progress: how much of this track has
                        // been downloaded so far, against its real total
                        // once known.
                        const pct = entry.buffer && entry.buffer.totalBytes != null ? Math.min(100, Math.round((entry.buffer.downloadedBytes / entry.buffer.totalBytes) * 100)) : null;
                        this.log('DownloadManager', `[${role.isNext ? "next" : "current"}] segment at ${skipToSeconds}s succeeded for trackId=${entry.trackId} — downloadedBytes=${entry.buffer ? entry.buffer.downloadedBytes : '?'}${entry.buffer && entry.buffer.totalBytes != null ? `/${entry.buffer.totalBytes} (${pct}%)` : ' (total not yet known)'}`);
                    }
                    if (!gotAnyBytes) {
                        // Real, direct fallback ported from the exact fix
                        // confirmed on Android: totalBytes only ever gets
                        // set from this response header — if it was ever
                        // missing across every segment of this download,
                        // there'd be no other way to know the real total,
                        // and any FUTURE cached response would omit
                        // X-PCM-Total-Frames entirely (a real network
                        // response always includes it), which the player
                        // relies on for the track's real length and end
                        // detection. Guaranteed here independent of the
                        // header, from the actual, confirmed end of the
                        // data stream itself.
                        if (entry.buffer && entry.buffer.totalBytes == null) entry.buffer.totalBytes = entry.buffer.downloadedBytes;
                        this.log('DownloadManager', `[${role.isNext ? "next" : "current"}] reached end of file at ${skipToSeconds}s for trackId=${entry.trackId}`);
                        break segmentLoop;
                    }
                    break;
                } catch (e) {
                    this.log('DownloadManager', `[${role.isNext ? "next" : "current"}] segment exception at ${skipToSeconds}s: ${e.message} (attempt ${attempt + 1}/5)`);
                    // The actual rollback — see TrackBuffer.truncateTo's own
                    // comment. rollbackPosition is null only if the buffer
                    // didn't exist yet when this attempt started, in which
                    // case nothing could have been partially written.
                    if (rollbackPosition != null && entry.buffer) entry.buffer.truncateTo(rollbackPosition);
                    try { await sleep(Math.min(8000, 500 * Math.pow(2, attempt))); } catch (ie) { break segmentLoop; }
                }
            }
            if (!succeeded) {
                // Same guaranteed fallback as the "reached end of file"
                // case above — giving up mid-track (some data WAS
                // downloaded, but no more is coming) is another case where
                // totalBytes would otherwise stay null forever if the
                // header never worked.
                if (entry.buffer && entry.buffer.totalBytes == null) entry.buffer.totalBytes = entry.buffer.downloadedBytes;
                this.log('DownloadManager', `[${role.isNext ? "next" : "current"}] gave up on segment at ${skipToSeconds}s after 5 attempts`);
                break;
            }
            skipToSeconds += segmentSeconds;
        }
        // Real, direct addition for gapless prefetch support — the ONE
        // signal the fetch-patch actually needs to correctly tell "app.js
        // is prefetching the next track while this one is still playing"
        // apart from "this track is genuinely done and something else has
        // moved on." Set here regardless of which exit path was taken
        // (reached the real end, gave up after 5 failed attempts, or got
        // superseded) — all three mean this loop is no longer the one
        // actively feeding new data for this entry.
        entry.isFinished = true;
        this.log('DownloadManager', `[${role.isNext ? "next" : "current"}] download loop finished (or superseded) for trackId=${entry.trackId}`);
    }

    async _fetchSegment(sourcePath, quality, skipToSeconds, maxDurationSeconds) {
        const cookieHeader = await this.getCookieHeader();
        return new Promise((resolve, reject) => {
            const url = new URL('/api/stream/pcm', this.serverOrigin);
            url.searchParams.set('path', sourcePath);
            url.searchParams.set('quality', quality);
            url.searchParams.set('skipToSeconds', String(skipToSeconds));
            url.searchParams.set('maxDurationSeconds', String(maxDurationSeconds));
            const mod = url.protocol === 'https:' ? https : http;
            // Real, direct fix ported from the exact same issue confirmed
            // on Android: later segments require the server to have
            // sequentially decoded further into the file before it can
            // even start responding — a real, recurring pattern where the
            // second segment specifically needs multiple retries at 15s,
            // while the first essentially never does. Raised to give the
            // server's genuinely slower response time here room to
            // actually succeed, rather than repeatedly giving up on a
            // request that would have worked with a few more seconds.
            // Raised from 30s to 120s: measured against the real server, time to first byte
            // for a deep-skip segment is decode time (8.6s for the segment at 120s of an
            // 8-channel track with the server idle, ~26s with three decodes overlapping, which
            // first play of a track always causes). Past the limit the server cancels the
            // decode and the retry restarts it from scratch, so the segment could never succeed.
            const options = { timeout: 120000, headers: {} };
            // Real, direct fix for a confirmed HTTP 401 report — this
            // request had never carried any authentication at all before.
            if (cookieHeader) options.headers.Cookie = cookieHeader;
            const req = mod.get(url, options, (res) => {
                resolve({ statusCode: res.statusCode, headers: res.headers, body: res });
            });
            req.on('timeout', () => req.destroy(new Error('request timeout')));
            req.on('error', reject);
        });
    }
}

function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

module.exports = { DownloadManager };
