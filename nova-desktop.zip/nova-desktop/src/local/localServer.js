'use strict';
// The desktop app's "Local library": the real NOVA server code (src/local/server, synced from nova-server) running inside
// the app on 127.0.0.1, serving the real NOVA web page over folders and files picked on this computer. It is the same
// code path as the online server - library browsing and search, queue, shuffle/repeat, playlists, cover art, seeking with
// the checkpoint index, loudness normalisation, Last.fm - minus accounts: there is one user, signed in automatically.
//
// Safety: it listens on loopback only, refuses any request whose Host header is not its own address (DNS rebinding), and
// requires a random per-launch key that the app's own window presents first and keeps as a SameSite=Strict cookie, so
// neither another program's web page nor another user of the machine can read the library.
const fs = require('fs');
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const Module = require('module');

const SERVER_DIR = path.join(__dirname, 'server');
const COOKIE = 'nova_local_key';

let shim = null, hooked = false;
function hookSqlite() {
  if (hooked) return; hooked = true;
  const load = Module._load;
  Module._load = function (request, ...rest) { return request === 'better-sqlite3' ? shim : load.call(this, request, ...rest); };
}

/**
 * opts: { dataDir, roots, ffmpeg, ffprobe, port }.  roots: [{ name, dir } | { name, files:[...] }]
 * Returns { origin, key, entryUrl, setRoots(list), close() }.
 */
async function startLocalServer(opts) {
  const dataDir = opts.dataDir;
  fs.mkdirSync(dataDir, { recursive: true });
  // The server modules read their settings from the environment when they load.
  const keyFile = path.join(dataDir, 'local-encryption.key');
  let encKey; try { encKey = fs.readFileSync(keyFile, 'utf8').trim(); } catch (e) { encKey = ''; }
  if (!/^[0-9a-f]{64}$/.test(encKey)) { encKey = crypto.randomBytes(32).toString('hex'); fs.writeFileSync(keyFile, encKey, { mode: 0o600 }); }
  Object.assign(process.env, {
    ENCRYPTION_KEY: encKey,
    DB_PATH: path.join(dataDir, 'local.sqlite'),
    LOG_PATH: path.join(dataDir, 'local-server.log'),
    PCM_CACHE_DIR: path.join(dataDir, 'pcm-cache'),
    SPOOL_DIR: path.join(dataDir, 'spool'),
    SEEK_INDEX_DIR: path.join(dataDir, 'seek-index'), // kept between runs so seeking in a song you have played is instant
    MUSIC_ROOTS: JSON.stringify(opts.roots || []),
    NATIVE_SURROUND: 'off',
  });
  if (opts.ffmpeg) process.env.FFMPEG_PATH = opts.ffmpeg;
  if (opts.ffprobe) process.env.FFPROBE_PATH = opts.ffprobe;

  shim = require('./sqliteShim');
  await shim.init();
  hookSqlite();

  const req = (rel) => require(path.join(SERVER_DIR, rel));
  const express = require('express');
  const cookieParser = require('cookie-parser');
  const db = req('lib/db');
  const auth = req('lib/auth');
  const logger = req('lib/logger');
  const musicBrowser = req('lib/musicBrowser');

  // the one user
  let row = db.prepare('SELECT id FROM users WHERE username = ?').get('local');
  if (!row) {
    db.prepare('INSERT INTO users (username, password_hash, is_admin) VALUES (?, ?, 1)').run('local', auth.hashPassword(crypto.randomBytes(24).toString('hex')));
    row = db.prepare('SELECT id FROM users WHERE username = ?').get('local');
  }
  const userId = row.id;
  const localUser = () => {
    const u = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
    return { id: userId, username: 'This computer', deviceLabel: 'This computer', isAdmin: true, lastfmUsername: u.lastfm_username, lastfmLinked: !!u.lastfm_session_key_enc, lastfmScrobbleEnabled: !!u.lastfm_scrobble_enabled };
  };

  const key = crypto.randomBytes(24).toString('hex');
  const app = express();
  app.disable('x-powered-by');
  let hostHeader = null; // set once the port is known

  // 1. only our own address; 2. only with the key
  app.use((request, res, next) => {
    if (request.headers.host !== hostHeader) return res.status(403).end('wrong host');
    const cookies = Object.fromEntries(String(request.headers.cookie || '').split(/;\s*/).filter(Boolean).map((c) => { const i = c.indexOf('='); return [c.slice(0, i), c.slice(i + 1)]; }));
    if (request.path === '/__nova_local' && request.query.k === key) {
      res.setHeader('Set-Cookie', `${COOKIE}=${key}; Path=/; HttpOnly; SameSite=Strict`);
      res.statusCode = 302; res.setHeader('Location', '/'); return res.end();
    }
    if (cookies[COOKIE] !== key) return res.status(403).end('not allowed');
    next();
  });
  app.use(express.json({ limit: '256kb' }));
  app.use(cookieParser());
  app.use((request, res, next) => { request.user = localUser(); next(); });

  app.get('/api/health', (request, res) => res.json({ ok: true, local: true }));
  app.use('/api/auth', req('routes/auth'));
  app.use('/api/browse', auth.requireAuth, req('routes/browse'));
  app.use('/api/stream', auth.requireAuth, req('routes/stream'));
  app.use('/api/state', req('routes/state'));
  app.use('/api/native-config', req('routes/nativeConfig'));
  app.use('/api/lastfm', req('routes/lastfm'));
  app.use('/api/logs', req('routes/logs'));
  app.use('/api/playlists', req('routes/playlists'));
  app.use(express.static(path.join(SERVER_DIR, 'public'), { etag: false, lastModified: false, cacheControl: false, setHeaders: (res) => res.set('Cache-Control', 'no-store') }));
  app.use((err, request, res, next) => {
    logger.error(err.message, { stack: err.stack, path: request.path, method: request.method });
    if (res.headersSent) return next(err);
    res.status(500).json({ error: 'Internal server error' });
  });

  const server = http.createServer(app);
  // The page keeps its settings (volume, quality, shuffle...) in localStorage, which belongs to the address it was loaded
  // from - so the port is remembered and reused. A random port every launch would silently reset them each time.
  const portFile = path.join(dataDir, 'port.txt');
  const listen = (port) => new Promise((resolve, reject) => { const onErr = (e) => reject(e); server.once('error', onErr); server.listen(port, '127.0.0.1', () => { server.removeListener('error', onErr); resolve(); }); });
  let wanted = opts.port || 0;
  if (!wanted) { try { wanted = parseInt(fs.readFileSync(portFile, 'utf8'), 10) || 0; } catch (e) { wanted = 0; } }
  try { await listen(wanted); } catch (e) { if (!wanted) throw e; await listen(0); }
  try { fs.writeFileSync(portFile, String(server.address().port)); } catch (e) { /* not fatal */ }
  const port = server.address().port;
  hostHeader = `127.0.0.1:${port}`;
  const origin = `http://${hostHeader}`;
  return {
    origin, key, port,
    entryUrl: `${origin}/__nova_local?k=${key}`,
    setRoots: (list) => musicBrowser.setRoots(list || []),
    flush: () => { try { db.flush(); } catch (e) {} },
    close: () => new Promise((resolve) => { try { db.close(); } catch (e) {} server.close(() => resolve()); if (server.closeAllConnections) server.closeAllConnections(); }),
  };
}

module.exports = { startLocalServer, COOKIE };
