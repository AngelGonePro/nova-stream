'use strict';
// A drop-in for the part of better-sqlite3 that the NOVA server uses, built on sql.js (SQLite compiled to WebAssembly).
// The desktop app uses it so the real server code can run inside the app without a native module that has to be rebuilt
// for Electron. The database lives in memory and is written to its file shortly after every change.
//
// Supported (everything the server uses): new Database(file), .pragma(), .exec(), .prepare(sql).get/all/run(...),
// positional (?) and named (@name) parameters, .transaction(fn), and run() results { changes, lastInsertRowid }.
const fs = require('fs');
const path = require('path');

let SQL = null;
async function init() {
  if (SQL) return SQL;
  const initSqlJs = require('sql.js');
  const dist = path.dirname(require.resolve('sql.js'));
  SQL = await initSqlJs({ locateFile: (f) => path.join(dist, f) });
  return SQL;
}

const toBindings = (args) => {
  if (args.length === 1 && args[0] && typeof args[0] === 'object' && !Array.isArray(args[0]) && !ArrayBuffer.isView(args[0])) {
    const o = {}; // better-sqlite3 names are bare (`userId`); sql.js wants the prefix used in the SQL (`@userId`)
    for (const [k, v] of Object.entries(args[0])) o['@' + k] = v === undefined ? null : v;
    return o;
  }
  const flat = args.length === 1 && Array.isArray(args[0]) ? args[0] : args;
  return flat.map((v) => (v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : v));
};

class Statement {
  constructor(db, sql) { this.db = db; this.sql = sql; }
  _with(args, fn) {
    const stmt = this.db._sql.prepare(this.sql);
    try { const b = toBindings(args); if (Array.isArray(b) ? b.length : Object.keys(b).length) stmt.bind(b); return fn(stmt); } finally { stmt.free(); }
  }
  get(...args) { return this._with(args, (s) => (s.step() ? s.getAsObject() : undefined)); }
  all(...args) { return this._with(args, (s) => { const rows = []; while (s.step()) rows.push(s.getAsObject()); return rows; }); }
  run(...args) {
    const out = this._with(args, (s) => { s.step(); return null; });
    const changes = this.db._sql.getRowsModified();
    const id = this.db._sql.exec('SELECT last_insert_rowid()')[0].values[0][0];
    this.db._dirty();
    return Object.assign(out || {}, { changes, lastInsertRowid: id });
  }
}

class Database {
  constructor(file) {
    if (!SQL) throw new Error('sqliteShim.init() must finish before a Database is opened');
    this.file = file && file !== ':memory:' ? file : null;
    let data = null;
    if (this.file) { try { data = fs.readFileSync(this.file); } catch (e) { data = null; } }
    this._sql = data ? new SQL.Database(new Uint8Array(data)) : new SQL.Database();
    this._timer = null; this._depth = 0;
    this._sql.run('PRAGMA foreign_keys = ON');
  }
  pragma(text) { try { this._sql.run('PRAGMA ' + text); } catch (e) { /* journal_mode etc. mean nothing for an in-memory database */ } }
  exec(sql) { this._sql.exec(sql); this._dirty(); return this; }
  prepare(sql) { return new Statement(this, sql); }
  transaction(fn) {
    const self = this;
    return function (...args) {
      if (self._depth > 0) return fn.apply(this, args); // nested: join the outer one
      self._sql.run('BEGIN'); self._depth++;
      try { const r = fn.apply(this, args); self._sql.run('COMMIT'); return r; }
      catch (e) { try { self._sql.run('ROLLBACK'); } catch (x) {} throw e; }
      finally { self._depth--; self._dirty(); }
    };
  }
  _dirty() {
    if (!this.file || this._timer) return;
    this._timer = setTimeout(() => { this._timer = null; this.flush(); }, 400);
    if (this._timer.unref) this._timer.unref();
  }
  /** Writes the database to its file now (atomic: temp file, then rename). */
  flush() {
    if (!this.file) return;
    clearTimeout(this._timer); this._timer = null;
    if (this._depth > 0) { this._dirty(); return; }
    // export() closes and reopens the database underneath, which resets per-connection pragmas
    const bytes = this._sql.export();
    this._sql.run('PRAGMA foreign_keys = ON');
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    const tmp = this.file + '.tmp';
    fs.writeFileSync(tmp, Buffer.from(bytes));
    fs.renameSync(tmp, this.file);
  }
  close() { this.flush(); this._sql.close(); }
}

module.exports = Database;
module.exports.init = init;
module.exports.default = Database;
