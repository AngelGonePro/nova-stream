'use strict';
// Which folders and files make up the desktop app's local library. Stored in the app's user-data folder as
// local-library.json: { roots: [{ name, dir } | { name, files: [paths] }] }. Pure file handling, no Electron.
const fs = require('fs');
const path = require('path');
const { AUDIO_EXTS } = require('./toolsPlan');

const FILES_ROOT = 'Selected files';
const fileFor = (dir) => path.join(dir, 'local-library.json');

function load(dir) {
  try {
    const j = JSON.parse(fs.readFileSync(fileFor(dir), 'utf8'));
    return (Array.isArray(j.roots) ? j.roots : []).filter((r) => r && typeof r.name === 'string' && (typeof r.dir === 'string' || Array.isArray(r.files)));
  } catch (e) { return []; }
}
function save(dir, roots) {
  fs.mkdirSync(dir, { recursive: true });
  const tmp = fileFor(dir) + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify({ roots }, null, 1));
  fs.renameSync(tmp, fileFor(dir));
  return roots;
}
const uniqueName = (roots, base) => { let n = base, i = 2; while (roots.some((r) => r.name.toLowerCase() === n.toLowerCase())) n = `${base} (${i++})`; return n; };

/** Adds a folder (and everything under it). Adding the same folder twice does nothing. */
function addFolder(dir, folder) {
  const roots = load(dir);
  const abs = path.resolve(folder);
  if (roots.some((r) => r.dir && path.resolve(r.dir) === abs)) return roots;
  let base = path.basename(abs).replace(/[\\/]/g, '_') || abs.replace(/[^\w]+/g, '_') || 'Music'; // a drive root has no name
  roots.push({ name: uniqueName(roots, base), dir: abs });
  return save(dir, roots);
}
/** Adds hand-picked files; they appear together in one "Selected files" entry. Files that are not audio, or already added, are ignored. */
function addFiles(dir, files) {
  const roots = load(dir);
  let group = roots.find((r) => r.files && r.name === FILES_ROOT);
  if (!group) { group = { name: uniqueName(roots, FILES_ROOT), files: [] }; roots.push(group); }
  const have = new Set(group.files.map((f) => path.resolve(f)));
  for (const f of files || []) {
    const abs = path.resolve(f);
    if (!AUDIO_EXTS.has(path.extname(abs).toLowerCase()) && path.extname(abs).toLowerCase() !== '.nova' && path.extname(abs).toLowerCase() !== '.wave') continue;
    if (!have.has(abs) && fs.existsSync(abs)) { group.files.push(abs); have.add(abs); }
  }
  if (!group.files.length) return save(dir, roots.filter((r) => r !== group));
  return save(dir, roots);
}
function remove(dir, name) {
  return save(dir, load(dir).filter((r) => r.name !== name));
}
/** Removes one file from the hand-picked group. */
function removeFile(dir, file) {
  const roots = load(dir);
  const group = roots.find((r) => r.files);
  if (group) group.files = group.files.filter((f) => path.resolve(f) !== path.resolve(file));
  return save(dir, roots.filter((r) => !r.files || r.files.length));
}
module.exports = { load, save, addFolder, addFiles, remove, removeFile, FILES_ROOT };
