'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('novaLibrary', {
  list: () => ipcRenderer.invoke('nova:lib:list'),
  addFolder: () => ipcRenderer.invoke('nova:lib:addFolder'),
  addFiles: () => ipcRenderer.invoke('nova:lib:addFiles'),
  remove: (name) => ipcRenderer.invoke('nova:lib:remove', name),
  done: () => ipcRenderer.invoke('nova:lib:done'),
});
