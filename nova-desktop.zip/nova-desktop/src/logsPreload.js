'use strict';
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('novaLogs', {
    getRecentLogs: () => ipcRenderer.invoke('nova:getRecentLogs'),
    getLogFilePath: () => ipcRenderer.invoke('nova:getLogFilePath'),
    onLogLine: (callback) => {
        const listener = (event, line) => callback(line);
        ipcRenderer.on('nova-log-line', listener);
        return () => ipcRenderer.removeListener('nova-log-line', listener);
    },
});
