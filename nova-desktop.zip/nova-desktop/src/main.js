'use strict';
// NOVA desktop — Electron main process.
//
// Architecture note: this deliberately mirrors the NOVA Android app's own
// native bridge (NativeAudioBridge.kt + NativeAudioEngine.kt), including
// every safety fix that came out of a long, hard-won debugging history
// there — a file-size cap to prevent a runaway download from filling
// disk, rollback-on-retry so a failed download attempt can never leave
// duplicate/corrupted audio behind, explicit generation counters so a
// stale prefetch can never keep downloading after a track switch, and
// startup cleanup of orphaned cache files from a killed process. These
// aren't decorative comments — each one is a real bug that shipped and
// was found and fixed the hard way; reusing the design is how this stays
// correct without re-earning every one of those lessons from scratch.

const { app, BrowserWindow, ipcMain, shell } = require('electron');
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');

// ==================== Configuration ====================
// The NOVA server this app connects to — same server the Android app and
// browser clients use. Change this to point at a different instance.
const NOVA_SERVER_ORIGIN = process.env.NOVA_SERVER_ORIGIN || 'https://music.cosmoscraft.net';

// Real, direct safety cap, carried over unchanged from the exact fix that
// resolved a genuine OutOfMemoryError on the Android app — a stale
// prefetch download, never explicitly stopped, grew a single track buffer
// past 200MB before crashing. Same class of bug is possible here (a
// runaway download filling disk instead of RAM) — same structural bound
// applies regardless of the specific cause.
const MAX_TRACK_FILE_BYTES = 350 * 1024 * 1024;

// Real, direct cap for the log file specifically, per the explicit request
// that neither audio cache nor logs should be able to overflow storage.
// Ring-buffer style: once exceeded, the oldest half is dropped rather than
// letting the file grow unbounded.
const MAX_LOG_FILE_BYTES = 5 * 1024 * 1024;
const MAX_IN_MEMORY_LOG_LINES = 2000; // mirrors DebugOverlay's MAX_LINES cap on the Android side, for the same reason: an unbounded in-memory log is its own slow leak

let mainWindow = null;
let logsWindow = null;

const userDataDir = app.getPath('userData');
const cacheDir = path.join(userDataDir, 'nova-track-cache');
const logFilePath = path.join(userDataDir, 'nova.log');
const crashFilePath = path.join(userDataDir, 'nova-last-crash.txt');

if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

// ==================== Logging (crash-safe, size-capped) ====================
// Real, direct design carried over from a hard lesson on the Android
// side: the FIRST version of crash-safe logging there still wasn't
// crash-safe, because the in-memory log display itself could throw and
// take the crashing exception's own log message down with it. Kept
// deliberately simple here for the same reason — appendFileSync is
// synchronous and about as close to "cannot itself throw in a way that
// loses the message" as a log write gets; anything fancier (async
// batching, a UI update in the write path) reintroduces exactly the
// failure mode that took several rounds to find and fix there.
const inMemoryLog = [];
function logLine(tag, message) {
    const line = `[${new Date().toISOString()}] [${tag}] ${message}`;
    inMemoryLog.push(line);
    while (inMemoryLog.length > MAX_IN_MEMORY_LOG_LINES) inMemoryLog.shift();
    try {
        fs.appendFileSync(logFilePath, line + '\n');
        maybeTrimLogFile();
    } catch (e) {
        // Deliberately swallowed — logging must never be the thing that
        // crashes the app. If this fails, the in-memory copy above (and
        // whatever the OS-level console shows) is the fallback.
    }
    if (logsWindow && !logsWindow.isDestroyed()) {
        try { logsWindow.webContents.send('nova-log-line', line); } catch (e) { /* logs window may be closing — not fatal */ }
    }
}

let lastTrimCheckMs = 0;
function maybeTrimLogFile() {
    // Only actually check file size periodically, not on every single
    // append — stat()-ing the log file on every log line would be wasteful
    // for something this frequently called.
    const now = Date.now();
    if (now - lastTrimCheckMs < 5000) return;
    lastTrimCheckMs = now;
    try {
        const stat = fs.statSync(logFilePath);
        if (stat.size <= MAX_LOG_FILE_BYTES) return;
        const content = fs.readFileSync(logFilePath, 'utf8');
        const lines = content.split('\n');
        const keep = lines.slice(Math.floor(lines.length / 2)); // drop the oldest half, ring-buffer style
        fs.writeFileSync(logFilePath, keep.join('\n'));
    } catch (e) {
        // Non-fatal — worst case the log file grows past its cap until the
        // next successful trim attempt.
    }
}

// ==================== Global crash handling ====================
// Real, direct port of NovaApplication.kt's own design on the Android
// side — a single handler that catches literally anything uncaught,
// writes it to a file BEFORE the process dies (a crash that takes the
// process down can't be relied on to have finished any async work, like
// updating a UI — a synchronous file write is what actually survives
// that), and the NEXT launch checks for and surfaces that file
// immediately, before anything else runs.
function writeCrashFile(source, error) {
    try {
        const text = `=== CRASH at ${new Date().toISOString()} (${source}) ===\n${error && error.stack ? error.stack : String(error)}\n`;
        fs.writeFileSync(crashFilePath, text);
    } catch (e) {
        // True last line of defense — nothing further downstream to catch
        // this. If even the crash file write fails, there's nothing more
        // to do.
    }
}

process.on('uncaughtException', (error) => {
    logLine('MAIN-CRASH', `Uncaught exception: ${error && error.message}`);
    writeCrashFile('main-process uncaughtException', error);
    // Deliberately does NOT re-throw or exit — an Electron main-process
    // crash takes the whole app down, including every renderer window.
    // Logging and surviving is almost always better for a desktop music
    // player than a hard crash, unless the process is in a truly
    // unrecoverable state.
});
process.on('unhandledRejection', (reason) => {
    logLine('MAIN-CRASH', `Unhandled promise rejection: ${reason}`);
    writeCrashFile('main-process unhandledRejection', reason instanceof Error ? reason : new Error(String(reason)));
});

function checkForPreviousCrash() {
    try {
        if (fs.existsSync(crashFilePath)) {
            const text = fs.readFileSync(crashFilePath, 'utf8');
            logLine('CRASH-FROM-PREVIOUS-LAUNCH', text);
            fs.unlinkSync(crashFilePath); // shown once — don't keep resurfacing the same old crash on every future launch
        }
    } catch (e) {
        logLine('MAIN', `Failed to read/display previous crash file: ${e.message}`);
    }
}

// ==================== Startup cache cleanup ====================
// Real, direct port of the same fix on the Android side — a track buffer
// file left behind by a killed process (no guaranteed cleanup hook for
// that case) would otherwise accumulate on disk indefinitely across
// restarts. Swept here, before anything else creates a new one for this
// session, so a leftover from a prior session is never mistaken for a
// fresh one.
function cleanOrphanedCacheFiles() {
    try {
        const entries = fs.readdirSync(cacheDir);
        let freedBytes = 0;
        let count = 0;
        for (const name of entries) {
            if (!name.startsWith('nova_trackbuf_')) continue;
            const full = path.join(cacheDir, name);
            try {
                const stat = fs.statSync(full);
                freedBytes += stat.size;
                fs.unlinkSync(full);
                count++;
            } catch (e) { /* one bad file shouldn't stop cleanup of the rest */ }
        }
        if (count > 0) logLine('MAIN', `Cleaned up ${count} orphaned track-buffer cache file(s) from a previous session, freeing ${Math.round(freedBytes / 1024)}KB`);
    } catch (e) {
        logLine('MAIN', `Failed to clean up orphaned cache files: ${e.message}`);
    }
}

module.exports = { logLine, NOVA_SERVER_ORIGIN, cacheDir, MAX_TRACK_FILE_BYTES, checkForPreviousCrash, cleanOrphanedCacheFiles, userDataDir, logFilePath, inMemoryLog };

// ==================== Window + app lifecycle ====================
const { DownloadManager } = require('./downloadManager');

let downloadManager = null;

function createDownloadManager() {
    downloadManager = new DownloadManager({
        serverOrigin: NOVA_SERVER_ORIGIN,
        cacheDir,
        maxTrackBytes: MAX_TRACK_FILE_BYTES,
        logFn: logLine,
    });
}

/**
 * The actual caching layer, made transparent to app.js's own, completely
 * unchanged fetch() calls — this is what lets the existing, already-proven
 * web-audio playback path (scheduling, gapless, buffering) just work,
 * benefiting from local caching without a single line of it needing to
 * know that caching exists.
 *
 * Deliberately NOT implemented as a protocol-level or webRequest-level
 * interceptor — that would mean intercepting ALL network traffic for the
 * entire session (every asset, every other API call) to filter down to
 * just the PCM endpoint, and getting that filtering wrong even slightly
 * would break the whole app's networking, not just caching. Implemented
 * instead as a small fetch() patch, installed in the preload script,
 * that only ever looks at requests to /api/stream/pcm — every other
 * fetch call is untouched, calling straight through to the real,
 * original fetch with zero involvement from this at all.
 */
function installCacheInterceptor() {
    // Intentionally a no-op — see fetchPatch.js, injected via preload
    // instead. Kept as a named function so the intent is documented at
    // the call site even though the real mechanism lives elsewhere.
}

function createMainWindow() {
    mainWindow = new BrowserWindow({
        width: 1200,
        height: 800,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: true,
        },
    });
    mainWindow.loadURL(NOVA_SERVER_ORIGIN);
    mainWindow.webContents.on('did-finish-load', () => {
        logLine('MAIN', `Main window finished loading ${NOVA_SERVER_ORIGIN}`);
    });
    mainWindow.webContents.on('render-process-gone', (event, details) => {
        logLine('MAIN-CRASH', `Renderer process gone: reason=${details.reason}, exitCode=${details.exitCode}`);
        writeCrashFile('renderer render-process-gone', new Error(`Renderer gone: ${details.reason}`));
    });
    mainWindow.on('closed', () => { mainWindow = null; });
}

function createLogsWindow() {
    if (logsWindow && !logsWindow.isDestroyed()) { logsWindow.focus(); return; }
    logsWindow = new BrowserWindow({
        width: 700,
        height: 500,
        title: 'NOVA — Logs',
        webPreferences: {
            preload: path.join(__dirname, 'logsPreload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: true,
        },
    });
    logsWindow.loadFile(path.join(__dirname, 'logs.html'));
    logsWindow.on('closed', () => { logsWindow = null; });
}

app.whenReady().then(() => {
    checkForPreviousCrash();
    cleanOrphanedCacheFiles();
    createDownloadManager();
    registerIpcHandlers();
    createMainWindow();

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
    });
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
});

function registerIpcHandlers() {
    // ==================== Buffered download / cache IPC ====================
    // Mirrors the Android bridge's message protocol closely enough to be
    // recognizable, adapted to Electron's request/response IPC instead of
    // Android's fire-and-forget postMessage + separate callback messages.

    ipcMain.handle('nova:startTrackDownload', (event, { trackId, path: sourcePath, quality, startAtSeconds }) => {
        downloadManager.startCurrent(trackId, sourcePath, quality, startAtSeconds || 0);
        return { ok: true };
    });

    ipcMain.handle('nova:prepareNextTrackDownload', (event, { trackId, path: sourcePath, quality }) => {
        downloadManager.startNext(trackId, sourcePath, quality);
        return { ok: true };
    });

    // Real, direct additions for wiring up gapless prefetch — the fetch-patch
    // needs both of these to correctly tell "app.js is prefetching the next
    // track while the current one is still playing" apart from "this is a
    // genuine transition," and to safely hand off an already-running
    // download rather than restarting it from scratch.
    ipcMain.handle('nova:isCurrentTrackFinished', () => downloadManager.isCurrentFinished());
    ipcMain.handle('nova:getNextTrackId', () => downloadManager.getNextTrackId());
    ipcMain.handle('nova:promoteNextTrackDownload', (event, { trackId }) => {
        const promoted = downloadManager.promoteIfMatches(trackId);
        return { promoted };
    });

    ipcMain.handle('nova:stopTrackDownload', () => {
        downloadManager.stopCurrent();
        return { ok: true };
    });

    ipcMain.handle('nova:stopNextTrackDownload', () => {
        downloadManager.stopNext();
        return { ok: true };
    });

    ipcMain.handle('nova:getCacheStatus', (event, { trackId, startAtSeconds }) => {
        const buf = downloadManager.findBuffer(trackId, startAtSeconds || 0);
        if (!buf) return { found: false };
        return {
            found: true,
            downloadedBytes: buf.downloadedBytes,
            totalBytes: buf.totalBytes,
            sampleRate: buf.sampleRate,
            channels: buf.channels,
        };
    });

    // The actual bridge for the fetch() patch (see fetchPatch.js) — given a
    // PCM request's own parameters, checks whether the local cache already
    // covers the requested range and, if so, returns exactly the bytes and
    // headers a real network response would have had. Returns
    // { available: false } for anything not yet downloaded, telling the
    // patch to fall through to a real, normal fetch instead — this can
    // never make a request fail that would otherwise have succeeded, only
    // skip the network for what's already safely on disk.
    ipcMain.handle('nova:readCachedRange', (event, { trackId, bufferStartAtSeconds, skipToSeconds, maxDurationSeconds }) => {
        const buf = downloadManager.findBuffer(trackId, bufferStartAtSeconds || 0);
        if (!buf) return { available: false };
        const bytesPerFrame = buf.channels * 2;
        const bytesPerSecond = buf.sampleRate * bytesPerFrame;
        const relativeSeconds = skipToSeconds - (bufferStartAtSeconds || 0);
        if (relativeSeconds < 0) return { available: false }; // before this buffer's own coverage — let a real fetch handle it
        let startByte = Math.floor(relativeSeconds * bytesPerSecond);
        startByte = Math.floor(startByte / bytesPerFrame) * bytesPerFrame; // frame-aligned, same reasoning as the Android engine's own alignment
        if (startByte > buf.downloadedBytes) return { available: false }; // not downloaded yet — let a real fetch handle it, same as the Android app's own seekWithinBuffer miss case
        let endByte = startByte + Math.ceil(maxDurationSeconds * bytesPerSecond);
        if (buf.totalBytes != null) endByte = Math.min(endByte, buf.totalBytes);
        endByte = Math.min(endByte, buf.downloadedBytes);
        if (endByte <= startByte) {
            // Genuinely at (or past) the end of what this buffer covers —
            // matches the real server's own "endByte <= startByte" empty
            // response for a position past the true end of the track.
            return { available: true, bytes: Buffer.alloc(0), sampleRate: buf.sampleRate, channels: buf.channels, totalBytes: buf.totalBytes, skipSamples: Math.floor(startByte / bytesPerFrame) };
        }
        try {
            const bytes = buf.readAt(startByte, endByte - startByte);
            return {
                available: true,
                bytes,
                sampleRate: buf.sampleRate,
                channels: buf.channels,
                totalBytes: buf.totalBytes,
                skipSamples: Math.floor(startByte / bytesPerFrame),
            };
        } catch (e) {
            logLine('MAIN', `readCachedRange failed, falling back to network: ${e.message}`);
            return { available: false };
        }
    });

    // ==================== Logs IPC ====================
    ipcMain.handle('nova:getRecentLogs', () => inMemoryLog.slice());
    ipcMain.handle('nova:openLogsWindow', () => { createLogsWindow(); return { ok: true }; });
    ipcMain.handle('nova:getLogFilePath', () => logFilePath);
    ipcMain.on('nova:rendererLog', (event, { tag, message }) => { logLine(tag, message); });
    ipcMain.on('nova:rendererCrash', (event, { message, stack }) => {
        logLine('RENDERER-CRASH', `${message}\n${stack || ''}`);
        writeCrashFile('renderer uncaught error', { stack: stack || message });
    });
}
