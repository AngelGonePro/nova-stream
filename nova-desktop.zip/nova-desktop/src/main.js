'use strict';
// NOVA desktop — Electron main process.
//
// Architecture note: this deliberately mirrors the NOVA Android app's own
// native bridge (NativeAudioBridge.kt + NativeAudioEngine.kt), including
// every safety fix that came out of a long, hard-won debugging history
// there — a file-size cap to prevent a runaway download from filling
// disk, rollback-on-retry so a failed download attempt can never leave
// duplicate/corrupted audio behind, explicit generation counters so a
// stale prefetch can never keep downloading after a track switch, and
// startup cleanup of orphaned cache files from a killed process. These
// aren't decorative comments — each one is a real bug that shipped and
// was found and fixed the hard way; reusing the design is how this stays
// correct without re-earning every one of those lessons from scratch.

const { app, BrowserWindow, ipcMain, shell, Menu, net, protocol, session, dialog } = require('electron');
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');

// ==================== Configuration ====================
// The NOVA server this app connects to is chosen by the user on first start (and can be changed from the NOVA menu or
// the page's settings); see serverConfig.js. NOVA_SERVER_ORIGIN in the environment still overrides it.
const serverConfig = require('./serverConfig');
const localLibrary = require('./localLibrary');
let NOVA_SERVER_ORIGIN = null; // set right after userDataDir is known, below
// Local library mode: instead of a server, the app runs the NOVA server code itself over folders/files on this computer (see local/localServer.js).
let LOCAL_MODE = false;
let localServer = null;

// Real, direct safety cap, carried over unchanged from the exact fix that
// resolved a genuine OutOfMemoryError on the Android app — a stale
// prefetch download, never explicitly stopped, grew a single track buffer
// past 200MB before crashing. Same class of bug is possible here (a
// runaway download filling disk instead of RAM) — same structural bound
// applies regardless of the specific cause.
const MAX_TRACK_FILE_BYTES = 350 * 1024 * 1024;

// Real, direct cap for the log file specifically, per the explicit request
// that neither audio cache nor logs should be able to overflow storage.
// Ring-buffer style: once exceeded, the oldest half is dropped rather than
// letting the file grow unbounded.
const MAX_LOG_FILE_BYTES = 5 * 1024 * 1024;
const MAX_IN_MEMORY_LOG_LINES = 2000; // mirrors DebugOverlay's MAX_LINES cap on the Android side, for the same reason: an unbounded in-memory log is its own slow leak

let mainWindow = null;
let logsWindow = null;

const userDataDir = app.getPath('userData');
const cacheDir = path.join(userDataDir, 'nova-track-cache');
const logFilePath = path.join(userDataDir, 'nova.log');
const crashFilePath = path.join(userDataDir, 'nova-last-crash.txt');

if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });
{
    const fromEnv = process.env.NOVA_SERVER_ORIGIN && serverConfig.normalize(process.env.NOVA_SERVER_ORIGIN);
    const choice = serverConfig.loadChoice(userDataDir);
    LOCAL_MODE = !fromEnv && !!choice && choice.kind === 'local';
    NOVA_SERVER_ORIGIN = fromEnv || (choice && choice.kind === 'server' ? choice.origin : null);
}

// ==================== Logging (crash-safe, size-capped) ====================
// Real, direct design carried over from a hard lesson on the Android
// side: the FIRST version of crash-safe logging there still wasn't
// crash-safe, because the in-memory log display itself could throw and
// take the crashing exception's own log message down with it. Kept
// deliberately simple here for the same reason — appendFileSync is
// synchronous and about as close to "cannot itself throw in a way that
// loses the message" as a log write gets; anything fancier (async
// batching, a UI update in the write path) reintroduces exactly the
// failure mode that took several rounds to find and fix there.
const inMemoryLog = [];
function logLine(tag, message) {
    const line = `[${new Date().toISOString()}] [${tag}] ${message}`;
    inMemoryLog.push(line);
    while (inMemoryLog.length > MAX_IN_MEMORY_LOG_LINES) inMemoryLog.shift();
    try {
        fs.appendFileSync(logFilePath, line + '\n');
        maybeTrimLogFile();
    } catch (e) {
        // Deliberately swallowed — logging must never be the thing that
        // crashes the app. If this fails, the in-memory copy above (and
        // whatever the OS-level console shows) is the fallback.
    }
    if (logsWindow && !logsWindow.isDestroyed()) {
        try { logsWindow.webContents.send('nova-log-line', line); } catch (e) { /* logs window may be closing — not fatal */ }
    }
}

let lastTrimCheckMs = 0;
function maybeTrimLogFile() {
    // Only actually check file size periodically, not on every single
    // append — stat()-ing the log file on every log line would be wasteful
    // for something this frequently called.
    const now = Date.now();
    if (now - lastTrimCheckMs < 5000) return;
    lastTrimCheckMs = now;
    try {
        const stat = fs.statSync(logFilePath);
        if (stat.size <= MAX_LOG_FILE_BYTES) return;
        const content = fs.readFileSync(logFilePath, 'utf8');
        const lines = content.split('\n');
        const keep = lines.slice(Math.floor(lines.length / 2)); // drop the oldest half, ring-buffer style
        fs.writeFileSync(logFilePath, keep.join('\n'));
    } catch (e) {
        // Non-fatal — worst case the log file grows past its cap until the
        // next successful trim attempt.
    }
}

// ==================== Global crash handling ====================
// Real, direct port of NovaApplication.kt's own design on the Android
// side — a single handler that catches literally anything uncaught,
// writes it to a file BEFORE the process dies (a crash that takes the
// process down can't be relied on to have finished any async work, like
// updating a UI — a synchronous file write is what actually survives
// that), and the NEXT launch checks for and surfaces that file
// immediately, before anything else runs.
function writeCrashFile(source, error) {
    try {
        const text = `=== CRASH at ${new Date().toISOString()} (${source}) ===\n${error && error.stack ? error.stack : String(error)}\n`;
        fs.writeFileSync(crashFilePath, text);
    } catch (e) {
        // True last line of defense — nothing further downstream to catch
        // this. If even the crash file write fails, there's nothing more
        // to do.
    }
}

process.on('uncaughtException', (error) => {
    logLine('MAIN-CRASH', `Uncaught exception: ${error && error.message}`);
    writeCrashFile('main-process uncaughtException', error);
    // Deliberately does NOT re-throw or exit — an Electron main-process
    // crash takes the whole app down, including every renderer window.
    // Logging and surviving is almost always better for a desktop music
    // player than a hard crash, unless the process is in a truly
    // unrecoverable state.
});
process.on('unhandledRejection', (reason) => {
    logLine('MAIN-CRASH', `Unhandled promise rejection: ${reason}`);
    writeCrashFile('main-process unhandledRejection', reason instanceof Error ? reason : new Error(String(reason)));
});

function checkForPreviousCrash() {
    try {
        if (fs.existsSync(crashFilePath)) {
            const text = fs.readFileSync(crashFilePath, 'utf8');
            logLine('CRASH-FROM-PREVIOUS-LAUNCH', text);
            fs.unlinkSync(crashFilePath); // shown once — don't keep resurfacing the same old crash on every future launch
        }
    } catch (e) {
        logLine('MAIN', `Failed to read/display previous crash file: ${e.message}`);
    }
}

// ==================== Startup cache cleanup ====================
// Real, direct port of the same fix on the Android side — a track buffer
// file left behind by a killed process (no guaranteed cleanup hook for
// that case) would otherwise accumulate on disk indefinitely across
// restarts. Swept here, before anything else creates a new one for this
// session, so a leftover from a prior session is never mistaken for a
// fresh one.
function cleanOrphanedCacheFiles() {
    try {
        const entries = fs.readdirSync(cacheDir);
        let freedBytes = 0;
        let count = 0;
        for (const name of entries) {
            if (!name.startsWith('nova_trackbuf_')) continue;
            const full = path.join(cacheDir, name);
            try {
                const stat = fs.statSync(full);
                freedBytes += stat.size;
                fs.unlinkSync(full);
                count++;
            } catch (e) { /* one bad file shouldn't stop cleanup of the rest */ }
        }
        if (count > 0) logLine('MAIN', `Cleaned up ${count} orphaned track-buffer cache file(s) from a previous session, freeing ${Math.round(freedBytes / 1024)}KB`);
    } catch (e) {
        logLine('MAIN', `Failed to clean up orphaned cache files: ${e.message}`);
    }
}

module.exports = { logLine, NOVA_SERVER_ORIGIN, cacheDir, MAX_TRACK_FILE_BYTES, checkForPreviousCrash, cleanOrphanedCacheFiles, userDataDir, logFilePath, inMemoryLog };

// ==================== Window + app lifecycle ====================
const { DownloadManager } = require('./downloadManager');
const { createPcmRequestHandler } = require('./pcmRequestHandler');

let downloadManager = null;

function createDownloadManager() {
    downloadManager = new DownloadManager({
        serverOrigin: NOVA_SERVER_ORIGIN,
        cacheDir,
        maxTrackBytes: MAX_TRACK_FILE_BYTES,
        logFn: logLine,
        // Real, direct fix for a confirmed report: every background
        // download was failing with HTTP 401 on all 5 attempts before
        // giving up. Root cause: _fetchSegment's raw https.get/http.get
        // call has never attached any authentication at all, in any
        // version of this file — it isn't a regression, it just never hit
        // a real authenticated server until now. Queried fresh on every
        // request (rather than captured once) since a session cookie can
        // be refreshed or change while the app is running.
        getCookieHeader: async () => {
            try {
                const cookies = await session.defaultSession.cookies.get({ url: NOVA_SERVER_ORIGIN });
                return cookies.map((c) => `${c.name}=${c.value}`).join('; ');
            } catch (e) {
                logLine('DownloadManager', `Failed to read session cookies for auth: ${e.message}`);
                return '';
            }
        },
    });
}

/**
 * The actual caching layer, made transparent to app.js's own, completely
 * unchanged fetch() calls — this is what lets the existing, already-proven
 * web-audio playback path (scheduling, gapless, buffering) just work,
 * benefiting from local caching without a single line of it needing to
 * know that caching exists.
 *
 * Deliberately NOT implemented as a protocol-level or webRequest-level
 * interceptor — that would mean intercepting ALL network traffic for the
 * entire session (every asset, every other API call) to filter down to
 * just the PCM endpoint, and getting that filtering wrong even slightly
 * would break the whole app's networking, not just caching. Implemented
 * instead as a small fetch() patch, installed in the preload script,
 * that only ever looks at requests to /api/stream/pcm — every other
 * fetch call is untouched, calling straight through to the real,
 * original fetch with zero involvement from this at all.
 */
function installCacheInterceptor() {
    // Intentionally a no-op — see fetchPatch.js, injected via preload
    // instead. Kept as a named function so the intent is documented at
    // the call site even though the real mechanism lives elsewhere.
}

// ==================== Native menu: Logs + Output Device ====================
// See preload.js's own comment for the full reasoning — this replaces an
// injected HTML panel that both overlapped the app's own UI and, even
// once repositioned, still didn't reliably work. A native menu is
// physically incapable of overlapping page content and is driven by
// direct main-process handlers, sidestepping whatever was actually wrong
// with the renderer-side button.
let latestOutputDevices = [];
let currentOutputDeviceId = '';

function buildApplicationMenu() {
    // Real, direct fix alongside the AudioContext capture rework in
    // FETCH_PATCH_SOURCE — the captured AudioContext instance cannot
    // cross the isolation boundary via IPC at all (it isn't a
    // serializable value), so applying a device selection can't round-
    // trip through the preload script the way it used to. This calls the
    // main-world function directly instead, via executeJavaScript, the
    // same mechanism already used to inject the fetch patch itself.
    function applyOutputDeviceInMainWorld(deviceId) {
        if (!mainWindow || mainWindow.isDestroyed()) return;
        mainWindow.webContents.executeJavaScript(
            `window.__novaApplyOutputDevice && window.__novaApplyOutputDevice(${JSON.stringify(deviceId)});`
        ).catch((e) => logLine('MAIN', `Failed to apply output device in main world: ${e.message}`));
    }
    const deviceItems = latestOutputDevices.length
        ? latestOutputDevices.map(d => ({
            label: d.label,
            type: 'radio',
            checked: currentOutputDeviceId === d.deviceId,
            click: () => {
                currentOutputDeviceId = d.deviceId;
                applyOutputDeviceInMainWorld(d.deviceId);
            },
        }))
        : [{ label: 'No output devices found', enabled: false }];

    const template = [
        {
            label: 'NOVA',
            submenu: [
                {
                    label: 'Library Tools…',
                    accelerator: 'CmdOrCtrl+Shift+L',
                    click: () => tools.open(),
                },
                {
                    label: 'Open Logs',
                    click: () => createLogsWindow(),
                },
                ...(LOCAL_MODE ? [{
                    label: 'Local library: choose folders and files…',
                    click: () => openLibraryManager(),
                }] : []),
                {
                    label: 'Change Server…',
                    click: () => openServerPicker(false),
                },
                { type: 'separator' },
                {
                    label: 'Output Device',
                    submenu: [
                        {
                            label: 'Default',
                            type: 'radio',
                            checked: currentOutputDeviceId === '',
                            click: () => {
                                currentOutputDeviceId = '';
                                applyOutputDeviceInMainWorld('default');
                            },
                        },
                        { type: 'separator' },
                        ...deviceItems,
                    ],
                },
                { type: 'separator' },
                { role: 'quit' },
            ],
        },
        { role: 'editMenu' },
        { role: 'viewMenu' },
        { role: 'windowMenu' },
    ];
    Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// Real, direct fix for the foundational contextIsolation bug — see
// preload.js's own comment for the full explanation and citation. This
// used to also carry a fetch() override, on the theory that app.js's own
// PCM requests happened on the main thread — confirmed FALSE by direct
// log evidence: even a logger catching every distinct fetch path on the
// main thread never once saw /api/stream/pcm. Traced to the actual
// cause: pcmWorker.js calls fetch() from inside a dedicated Web Worker,
// which has its own completely separate global scope — no override of
// window.fetch, in any world, main or isolated, can ever reach a
// worker's own fetch. The ONLY thing that can intercept a worker's
// requests is the network layer itself, below any JavaScript context —
// see installPcmProtocolInterceptor below for the actual fix. This
// script now does ONLY the AudioContext capture, which remains valid:
// app.js creates its AudioContext on the main thread, not in a worker.
const AUDIO_CONTEXT_CAPTURE_SOURCE = `
(function installNovaAudioContextCapture() {
    if (window.__novaAudioContextCaptureInstalled) return;
    window.__novaAudioContextCaptureInstalled = true;
    if (!window.novaDesktop) {
        console.error('[nova] novaDesktop not available on window — AudioContext capture cannot install');
        return;
    }
    const NativeAudioContext = window.AudioContext || window.webkitAudioContext;
    if (!NativeAudioContext) {
        window.novaDesktop.log('audioDevice', 'No Web Audio API available in this environment — output device selection unavailable');
        return;
    }
    let capturedAudioContext = null;
    function WrappedAudioContext(...args) {
        const instance = new NativeAudioContext(...args);
        capturedAudioContext = instance;
        window.novaDesktop.log('audioDevice', 'AudioContext created and captured for output device selection (main world)');
        return instance;
    }
    WrappedAudioContext.prototype = NativeAudioContext.prototype;
    window.AudioContext = WrappedAudioContext;
    if (window.webkitAudioContext) window.webkitAudioContext = WrappedAudioContext;
    window.__novaApplyOutputDevice = async function (deviceId) {
        if (!capturedAudioContext) { window.novaDesktop.log('audioDevice', 'setOutputDevice: no AudioContext has been created by the page yet'); return; }
        if (typeof capturedAudioContext.setSinkId !== 'function') { window.novaDesktop.log('audioDevice', 'setOutputDevice: AudioContext.setSinkId not available in this Electron/Chromium build'); return; }
        try {
            await capturedAudioContext.setSinkId(deviceId);
            window.novaDesktop.log('audioDevice', 'Output device applied: ' + deviceId);
        } catch (e) {
            window.novaDesktop.log('audioDevice', 'setOutputDevice failed: ' + (e && e.message));
        }
    };
})();
`;

/**
 * The actual fix for caching PCM requests that happen inside a Web
 * Worker, where no JavaScript-level override (contextBridge, main-world
 * injection, anything) can ever reach them. Registered on the session's
 * protocol handling for https — this intercepts EVERY https request in
 * this session, from any context, worker or main thread, since they all
 * ultimately go through the same underlying network stack the worker
 * itself has no way to bypass. Deliberately conservative about what it
 * touches: only a request matching the exact configured Nova server
 * origin AND the /api/stream/pcm path is ever handled specially — every
 * other request, including the page's own initial load and every other
 * API call, is proxied through via net.fetch exactly as given, since
 * getting that filtering wrong even slightly would break the whole
 * app's networking, not just this one endpoint.
 */
function installPcmProtocolInterceptor() {
    const novaOrigin = new URL(NOVA_SERVER_ORIGIN).origin;
    // Matches the exact pattern from Electron's own official docs for
    // proxying a request through unmodified — net.fetch's documented
    // proxy example passes url + an explicit {method, headers, body}
    // object rather than the Request instance itself, so this follows
    // that rather than relying on an unconfirmed assumption that
    // passing the Request object directly behaves identically.
    const proxyThrough = (request) => {
        // Real, direct fix for a confirmed crash: "RequestInit: duplex
        // option is required when sending a body." Node's fetch/undici
        // (which net.fetch is built on) requires duplex: 'half' to be set
        // whenever a request carries a body at all — this isn't optional
        // for POST/PUT/etc., it throws synchronously without it. Verified
        // directly: a real POST with a real body, proxied through this
        // exact function, threw this exact error without the flag and
        // succeeded once it was added.
        const hasBody = !(request.method === 'GET' || request.method === 'HEAD');
        return net.fetch(request.url, {
            method: request.method,
            headers: request.headers,
            body: hasBody ? request.body : undefined,
            duplex: hasBody ? 'half' : undefined,
            // Real, direct fix for a confirmed report: PCM downloads were
            // failing with HTTP 401 on every attempt. pcmWorker.js's own
            // original fetch() call used credentials: 'include' to send
            // the session cookie — proxyThrough was dropping that entirely,
            // since neither copying request.headers nor calling net.fetch
            // bare causes it to attach the session's stored cookies on its
            // own. Verified directly: the identical proxying code returned
            // 401 against a cookie-gated endpoint without this option, and
            // 200 with it added, cookie included, matching what a normal
            // page fetch with credentials: 'include' gets.
            credentials: 'include',
            // Confirmed by direct, reproducible testing in a real Electron
            // process: without this flag, net.fetch's own outgoing request is
            // ITSELF routed back through this same protocol.handle('https', ...)
            // handler (this is documented Electron behavior, not a bug), which
            // calls proxyThrough again, which calls net.fetch again — recursing
            // indefinitely. That's confirmed to be exactly what produced the
            // completely blank, permanently-loading window: no error, no
            // crash, just an https request that never resolves. This flag is
            // what tells net.fetch's own request to skip custom protocol
            // handlers, breaking the recursion.
            bypassCustomProtocolHandlers: true,
        });
    };
    // protocol.handle is a top-level Electron module function, NOT a
    // property of session.defaultSession — session objects have no
    // .protocol at all. Per Electron's own docs, calling it here with
    // no session argument applies it to the default session, which is
    // exactly the one this app's single window uses.
    // The actual PCM request logic lives in pcmRequestHandler.js (so it can be tested end to end against the
    // real download manager and server); this only recognizes which requests are PCM requests at all.
    const pcmHandler = createPcmRequestHandler({ getDownloadManager: () => downloadManager, proxyThrough, logLine });
    protocol.handle('https', async (request) => {
        let url;
        try { url = new URL(request.url); } catch (e) { return proxyThrough(request); }
        if (url.origin !== novaOrigin || url.pathname !== '/api/stream/pcm') {
            return proxyThrough(request);
        }
        const sourcePath = url.searchParams.get('path');
        if (!sourcePath) return proxyThrough(request);
        return pcmHandler.handle(request, {
            sourcePath,
            quality: url.searchParams.get('quality') || 'reduced',
            skipToSeconds: parseFloat(url.searchParams.get('skipToSeconds') || '0'),
            maxDurationSeconds: parseFloat(url.searchParams.get('maxDurationSeconds') || '60'),
            // The player marks background prefetch requests (&prefetch=1) so a prefetch can be told apart from the
            // user skipping to a track — see pcmRequestHandler.js.
            isPrefetch: url.searchParams.get('prefetch') === '1',
        });
    });
}

function createMainWindow() {
    mainWindow = new BrowserWindow({
        width: 1200,
        height: 800,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: true,
        },
    });
    mainWindow.loadURL(LOCAL_MODE && localServer ? localServer.entryUrl : NOVA_SERVER_ORIGIN);
    // AudioContext capture still needs main-world injection (app.js
    // creates it on the main thread) — the actual PCM caching no longer
    // depends on this at all, see installPcmProtocolInterceptor above,
    // registered once at startup rather than per-window-load.
    mainWindow.webContents.on('dom-ready', () => {
        mainWindow.webContents.executeJavaScript(AUDIO_CONTEXT_CAPTURE_SOURCE).catch((e) => {
            logLine('MAIN', `Failed to inject AudioContext capture into main world: ${e.message}`);
        });
    });
    mainWindow.webContents.on('did-finish-load', () => {
        logLine('MAIN', `Main window finished loading ${LOCAL_MODE ? 'the local library' : NOVA_SERVER_ORIGIN}`);
    });
    mainWindow.webContents.on('render-process-gone', (event, details) => {
        logLine('MAIN-CRASH', `Renderer process gone: reason=${details.reason}, exitCode=${details.exitCode}`);
        writeCrashFile('renderer render-process-gone', new Error(`Renderer gone: ${details.reason}`));
    });
    mainWindow.on('closed', () => { mainWindow = null; });
}

function createLogsWindow() {
    if (logsWindow && !logsWindow.isDestroyed()) { logsWindow.focus(); return; }
    logsWindow = new BrowserWindow({
        width: 700,
        height: 500,
        title: 'NOVA — Logs',
        webPreferences: {
            preload: path.join(__dirname, 'logsPreload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: true,
        },
    });
    logsWindow.loadFile(path.join(__dirname, 'logs.html'));
    logsWindow.on('closed', () => { logsWindow = null; });
}

// ==================== Server picker ====================
let serverPickerWindow = null;
function openServerPicker(firstStart) {
    if (serverPickerWindow && !serverPickerWindow.isDestroyed()) { serverPickerWindow.focus(); return; }
    serverPickerWindow = new BrowserWindow({
        width: 480, height: 330, resizable: false, minimizable: false, maximizable: false,
        title: 'NOVA — Server',
        webPreferences: { preload: path.join(__dirname, 'serverPickerPreload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true },
    });
    serverPickerWindow.setMenuBarVisibility(false);
    serverPickerWindow.loadFile(path.join(__dirname, 'serverPicker.html'));
    serverPickerWindow.__firstStart = firstStart;
    serverPickerWindow.on('closed', () => { serverPickerWindow = null; if (firstStart && !NOVA_SERVER_ORIGIN && !LOCAL_MODE) app.quit(); });
}
ipcMain.handle('nova:serverPicker:info', () => ({ current: (LOCAL_MODE ? serverConfig.load(userDataDir) : NOVA_SERVER_ORIGIN) || '', firstStart: !!(serverPickerWindow && serverPickerWindow.__firstStart), isLocal: LOCAL_MODE }));
ipcMain.handle('nova:serverPicker:useLocal', () => {
    try { serverConfig.saveLocal(userDataDir); } catch (e) { return { ok: false, error: 'Could not save: ' + e.message }; }
    logLine('MAIN', 'Switched to the local library');
    setTimeout(() => { app.relaunch(); app.exit(0); }, 150);
    return { ok: true };
});
ipcMain.handle('nova:serverPicker:submit', (event, text) => {
    const origin = serverConfig.normalize(text);
    if (!origin) return { ok: false, error: 'Enter a https:// address, e.g. https://music.example.com' };
    const changed = LOCAL_MODE || origin !== NOVA_SERVER_ORIGIN;
    try { serverConfig.save(userDataDir, origin); } catch (e) { return { ok: false, error: 'Could not save: ' + e.message }; }
    logLine('MAIN', `Server set to ${origin}`);
    if (changed) { // tracks cached from the old server do not belong to the new one
        try { for (const f of fs.readdirSync(cacheDir)) { try { fs.unlinkSync(path.join(cacheDir, f)); } catch (e) {} } } catch (e) {}
    }
    setTimeout(() => { app.relaunch(); app.exit(0); }, 150); // restart so the cache, the request interceptor and the window all use the new address
    return { ok: true };
});
ipcMain.handle('nova:serverPicker:cancel', () => {
    if (serverPickerWindow && !serverPickerWindow.isDestroyed()) serverPickerWindow.close();
    return { ok: true };
});
ipcMain.handle('nova:changeServer', () => { openServerPicker(false); return { ok: true }; });

// ==================== Local library ====================
async function startLocal() {
    const { startLocalServer } = require('./local/localServer');
    const ffmpeg = resolveToolBinary('ffmpeg-static', 'ffmpeg'), ffprobe = resolveToolBinary('ffprobe-static', 'ffprobe');
    localServer = await startLocalServer({ dataDir: path.join(userDataDir, 'local-library'), roots: localLibrary.load(userDataDir), ffmpeg, ffprobe });
    NOVA_SERVER_ORIGIN = localServer.origin;
    logLine('LOCAL', `Local library serving ${localServer.origin} (ffmpeg: ${ffmpeg}, ffprobe: ${ffprobe}); folders: ${JSON.stringify(localLibrary.load(userDataDir).map((r) => r.name))}`);
}
function resolveToolBinary(pkg, fallback) {
    try { const p = require(pkg); const bin = typeof p === 'string' ? p : p && p.path; if (bin && fs.existsSync(bin)) return bin; } catch (e) { /* not installed: use the one on PATH */ }
    return fallback;
}
let libraryWindow = null;
function openLibraryManager() {
    if (!LOCAL_MODE) return;
    if (libraryWindow && !libraryWindow.isDestroyed()) { libraryWindow.focus(); return; }
    libraryWindow = new BrowserWindow({
        width: 560, height: 480, title: 'NOVA — Local library', parent: mainWindow || undefined,
        webPreferences: { preload: path.join(__dirname, 'localLibraryPreload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true },
    });
    libraryWindow.setMenuBarVisibility(false);
    libraryWindow.loadFile(path.join(__dirname, 'localLibrary.html'));
    libraryWindow.on('closed', () => { libraryWindow = null; });
}
function libraryChanged(roots) {
    if (localServer) localServer.setRoots(roots);
    logLine('LOCAL', `Library is now: ${JSON.stringify(roots.map((r) => (r.dir ? r.name + ' = ' + r.dir : r.name + ' (' + r.files.length + ' files)')))}`);
    // go back to the top of the library so the new entries show; whatever is playing is not interrupted
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.executeJavaScript(`(document.querySelector('#breadcrumbs .crumb')||{click(){}}).click()`).catch(() => {});
}
ipcMain.on('nova:isLocal', (e) => { e.returnValue = LOCAL_MODE; });
ipcMain.handle('nova:manageLibrary', () => { openLibraryManager(); return { ok: true }; });
ipcMain.handle('nova:lib:list', () => localLibrary.load(userDataDir));
ipcMain.handle('nova:lib:addFolder', async () => {
    const r = await dialog.showOpenDialog(libraryWindow || mainWindow, { properties: ['openDirectory'], title: 'Add a folder to your library' });
    if (r.canceled || !r.filePaths[0]) return localLibrary.load(userDataDir);
    const roots = localLibrary.addFolder(userDataDir, r.filePaths[0]); libraryChanged(roots); return roots;
});
ipcMain.handle('nova:lib:addFiles', async () => {
    const { AUDIO_EXTS } = require('./toolsPlan');
    const r = await dialog.showOpenDialog(libraryWindow || mainWindow, { properties: ['openFile', 'multiSelections'], title: 'Add files to your library', filters: [{ name: 'Audio', extensions: [...AUDIO_EXTS].map((e) => e.slice(1)).concat(['nova']) }] });
    if (r.canceled || !r.filePaths.length) return localLibrary.load(userDataDir);
    const roots = localLibrary.addFiles(userDataDir, r.filePaths); libraryChanged(roots); return roots;
});
ipcMain.handle('nova:lib:remove', (e, name) => { const roots = localLibrary.remove(userDataDir, String(name)); libraryChanged(roots); return roots; });
ipcMain.handle('nova:lib:done', () => { if (libraryWindow && !libraryWindow.isDestroyed()) libraryWindow.close(); return { ok: true }; });

let tools = null;

app.whenReady().then(async () => {
    if (!NOVA_SERVER_ORIGIN && !LOCAL_MODE) { openServerPicker(true); return; } // nothing else starts until a server (or the local library) has been chosen
    tools = require('./toolsMain').createToolsController({ ipcMain, dialog, BrowserWindow, logLine, userDataDir });
    checkForPreviousCrash();
    cleanOrphanedCacheFiles();
    if (LOCAL_MODE) {
        try { await startLocal(); }
        catch (e) {
            logLine('LOCAL', `Could not start the local library: ${e.stack || e.message}`);
            dialog.showErrorBox('NOVA', `The local library could not start:\n\n${e.message}\n\nChoose a server instead from the NOVA menu.`);
            LOCAL_MODE = false;
        }
    }
    if (!LOCAL_MODE) createDownloadManager();
    registerIpcHandlers();
    // Real, direct fix for a confirmed "doesn't show my virtual cables or
    // devices for outputs" report — Electron does not automatically grant
    // media permissions the way a real browser's own permission prompt
    // would; without this, getUserMedia() silently fails and, more
    // importantly, enumerateDevices() has nothing to base real device
    // labels on and falls back to reporting little more than the generic
    // default. Granted here explicitly and unconditionally — this is a
    // trusted, locally-run desktop app the user installed themselves, not
    // arbitrary third-party web content, so there's no other origin this
    // could wrongly be granting access to.
    session.defaultSession.setPermissionRequestHandler((webContents, permission, callback) => {
        // Real, direct fix for a confirmed "Copy all doesn't work" report
        // — traced to this exact handler: it explicitly denies every
        // permission except media, and that denial applies to the whole
        // app (session.defaultSession, not just the main window) — which
        // silently breaks navigator.clipboard.writeText() in the logs
        // window the same way it would have silently broken anything
        // else needing a permission this never anticipated.
        if (permission === 'media' || permission === 'mediaKeySystem' || permission === 'clipboard-read' || permission === 'clipboard-sanitized-write') { callback(true); return; }
        callback(false);
    });
    if (typeof session.defaultSession.setPermissionCheckHandler === 'function') {
        session.defaultSession.setPermissionCheckHandler((webContents, permission) => permission === 'media' || permission === 'mediaKeySystem' || permission === 'clipboard-read' || permission === 'clipboard-sanitized-write');
    }
    buildApplicationMenu();
    // Registered before the window ever loads — this MUST be in place
    // before app.js or its worker ever makes a single request, since a
    // request that slips through before this is registered would just
    // go straight to the real network, uncached, with no way to
    // retroactively catch it.
    if (!LOCAL_MODE) installPcmProtocolInterceptor(); // the local library is on this machine: nothing to download or cache
    createMainWindow();
    if (LOCAL_MODE && !localLibrary.load(userDataDir).length) setTimeout(openLibraryManager, 400); // first run: nothing to play yet

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
    });
});

app.on('before-quit', () => { if (tools && tools.shutdown) tools.shutdown(); if (localServer) localServer.flush(); }); // kills running conversions (and their ffmpeg processes)

app.on('window-all-closed', () => {
    if (serverPickerWindow && !serverPickerWindow.isDestroyed()) return;
    if (process.platform !== 'darwin') app.quit();
});

function registerIpcHandlers() {
    // ==================== Buffered download / cache IPC ====================
    // Mirrors the Android bridge's message protocol closely enough to be
    // recognizable, adapted to Electron's request/response IPC instead of
    // Android's fire-and-forget postMessage + separate callback messages.

    // Real, direct removal: the download-manager IPC handlers that used
    // to live here (startTrackDownload, prepareNextTrackDownload,
    // isCurrentTrackFinished, getNextTrackId, promoteNextTrackDownload,
    // readCachedRange) were only ever called from the renderer-side
    // fetch() patch — which turned out to be structurally incapable of
    // ever seeing the actual PCM requests at all, since those happen
    // inside pcmWorker.js's own Web Worker, a separate JS context no
    // renderer-side override can reach. The real fix lives in
    // installPcmProtocolInterceptor above, which runs directly in this
    // process and calls downloadManager's own methods with no IPC layer
    // in between at all — these handlers are gone because nothing calls
    // them anymore, not because the functionality moved elsewhere via IPC.
    ipcMain.handle('nova:stopTrackDownload', () => {
        if (downloadManager) downloadManager.stopCurrent();
        return { ok: true };
    });

    ipcMain.handle('nova:stopNextTrackDownload', () => {
        if (downloadManager) downloadManager.stopNext();
        return { ok: true };
    });

    // ==================== Logs IPC ====================
    ipcMain.handle('nova:getRecentLogs', () => inMemoryLog.slice());
    ipcMain.handle('nova:openLogsWindow', () => { createLogsWindow(); return { ok: true }; });
    ipcMain.handle('nova:getLogFilePath', () => logFilePath);
    ipcMain.on('nova:rendererLog', (event, { tag, message }) => { logLine(tag, message); });
    // The actual bridge for the native-menu device picker — see
    // buildApplicationMenu's own comment for the full design.
    ipcMain.on('nova:deviceListUpdated', (event, devices) => {
        latestOutputDevices = Array.isArray(devices) ? devices : [];
        buildApplicationMenu();
    });
    ipcMain.on('nova:rendererCrash', (event, { message, stack }) => {
        logLine('RENDERER-CRASH', `${message}\n${stack || ''}`);
        writeCrashFile('renderer uncaught error', { stack: stack || message });
    });
}
