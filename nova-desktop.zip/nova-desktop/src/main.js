'use strict';
// NOVA desktop — Electron main process.
//
// Architecture note: this deliberately mirrors the NOVA Android app's own
// native bridge (NativeAudioBridge.kt + NativeAudioEngine.kt), including
// every safety fix that came out of a long, hard-won debugging history
// there — a file-size cap to prevent a runaway download from filling
// disk, rollback-on-retry so a failed download attempt can never leave
// duplicate/corrupted audio behind, explicit generation counters so a
// stale prefetch can never keep downloading after a track switch, and
// startup cleanup of orphaned cache files from a killed process. These
// aren't decorative comments — each one is a real bug that shipped and
// was found and fixed the hard way; reusing the design is how this stays
// correct without re-earning every one of those lessons from scratch.

const { app, BrowserWindow, ipcMain, shell, Menu, net, protocol, session } = require('electron');
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');

// ==================== Configuration ====================
// The NOVA server this app connects to — same server the Android app and
// browser clients use. Change this to point at a different instance.
const NOVA_SERVER_ORIGIN = process.env.NOVA_SERVER_ORIGIN || 'https://music.cosmoscraft.net';

// Real, direct safety cap, carried over unchanged from the exact fix that
// resolved a genuine OutOfMemoryError on the Android app — a stale
// prefetch download, never explicitly stopped, grew a single track buffer
// past 200MB before crashing. Same class of bug is possible here (a
// runaway download filling disk instead of RAM) — same structural bound
// applies regardless of the specific cause.
const MAX_TRACK_FILE_BYTES = 350 * 1024 * 1024;

// Real, direct cap for the log file specifically, per the explicit request
// that neither audio cache nor logs should be able to overflow storage.
// Ring-buffer style: once exceeded, the oldest half is dropped rather than
// letting the file grow unbounded.
const MAX_LOG_FILE_BYTES = 5 * 1024 * 1024;
const MAX_IN_MEMORY_LOG_LINES = 2000; // mirrors DebugOverlay's MAX_LINES cap on the Android side, for the same reason: an unbounded in-memory log is its own slow leak

let mainWindow = null;
let logsWindow = null;

const userDataDir = app.getPath('userData');
const cacheDir = path.join(userDataDir, 'nova-track-cache');
const logFilePath = path.join(userDataDir, 'nova.log');
const crashFilePath = path.join(userDataDir, 'nova-last-crash.txt');

if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

// ==================== Logging (crash-safe, size-capped) ====================
// Real, direct design carried over from a hard lesson on the Android
// side: the FIRST version of crash-safe logging there still wasn't
// crash-safe, because the in-memory log display itself could throw and
// take the crashing exception's own log message down with it. Kept
// deliberately simple here for the same reason — appendFileSync is
// synchronous and about as close to "cannot itself throw in a way that
// loses the message" as a log write gets; anything fancier (async
// batching, a UI update in the write path) reintroduces exactly the
// failure mode that took several rounds to find and fix there.
const inMemoryLog = [];
function logLine(tag, message) {
    const line = `[${new Date().toISOString()}] [${tag}] ${message}`;
    inMemoryLog.push(line);
    while (inMemoryLog.length > MAX_IN_MEMORY_LOG_LINES) inMemoryLog.shift();
    try {
        fs.appendFileSync(logFilePath, line + '\n');
        maybeTrimLogFile();
    } catch (e) {
        // Deliberately swallowed — logging must never be the thing that
        // crashes the app. If this fails, the in-memory copy above (and
        // whatever the OS-level console shows) is the fallback.
    }
    if (logsWindow && !logsWindow.isDestroyed()) {
        try { logsWindow.webContents.send('nova-log-line', line); } catch (e) { /* logs window may be closing — not fatal */ }
    }
}

let lastTrimCheckMs = 0;
function maybeTrimLogFile() {
    // Only actually check file size periodically, not on every single
    // append — stat()-ing the log file on every log line would be wasteful
    // for something this frequently called.
    const now = Date.now();
    if (now - lastTrimCheckMs < 5000) return;
    lastTrimCheckMs = now;
    try {
        const stat = fs.statSync(logFilePath);
        if (stat.size <= MAX_LOG_FILE_BYTES) return;
        const content = fs.readFileSync(logFilePath, 'utf8');
        const lines = content.split('\n');
        const keep = lines.slice(Math.floor(lines.length / 2)); // drop the oldest half, ring-buffer style
        fs.writeFileSync(logFilePath, keep.join('\n'));
    } catch (e) {
        // Non-fatal — worst case the log file grows past its cap until the
        // next successful trim attempt.
    }
}

// ==================== Global crash handling ====================
// Real, direct port of NovaApplication.kt's own design on the Android
// side — a single handler that catches literally anything uncaught,
// writes it to a file BEFORE the process dies (a crash that takes the
// process down can't be relied on to have finished any async work, like
// updating a UI — a synchronous file write is what actually survives
// that), and the NEXT launch checks for and surfaces that file
// immediately, before anything else runs.
function writeCrashFile(source, error) {
    try {
        const text = `=== CRASH at ${new Date().toISOString()} (${source}) ===\n${error && error.stack ? error.stack : String(error)}\n`;
        fs.writeFileSync(crashFilePath, text);
    } catch (e) {
        // True last line of defense — nothing further downstream to catch
        // this. If even the crash file write fails, there's nothing more
        // to do.
    }
}

process.on('uncaughtException', (error) => {
    logLine('MAIN-CRASH', `Uncaught exception: ${error && error.message}`);
    writeCrashFile('main-process uncaughtException', error);
    // Deliberately does NOT re-throw or exit — an Electron main-process
    // crash takes the whole app down, including every renderer window.
    // Logging and surviving is almost always better for a desktop music
    // player than a hard crash, unless the process is in a truly
    // unrecoverable state.
});
process.on('unhandledRejection', (reason) => {
    logLine('MAIN-CRASH', `Unhandled promise rejection: ${reason}`);
    writeCrashFile('main-process unhandledRejection', reason instanceof Error ? reason : new Error(String(reason)));
});

function checkForPreviousCrash() {
    try {
        if (fs.existsSync(crashFilePath)) {
            const text = fs.readFileSync(crashFilePath, 'utf8');
            logLine('CRASH-FROM-PREVIOUS-LAUNCH', text);
            fs.unlinkSync(crashFilePath); // shown once — don't keep resurfacing the same old crash on every future launch
        }
    } catch (e) {
        logLine('MAIN', `Failed to read/display previous crash file: ${e.message}`);
    }
}

// ==================== Startup cache cleanup ====================
// Real, direct port of the same fix on the Android side — a track buffer
// file left behind by a killed process (no guaranteed cleanup hook for
// that case) would otherwise accumulate on disk indefinitely across
// restarts. Swept here, before anything else creates a new one for this
// session, so a leftover from a prior session is never mistaken for a
// fresh one.
function cleanOrphanedCacheFiles() {
    try {
        const entries = fs.readdirSync(cacheDir);
        let freedBytes = 0;
        let count = 0;
        for (const name of entries) {
            if (!name.startsWith('nova_trackbuf_')) continue;
            const full = path.join(cacheDir, name);
            try {
                const stat = fs.statSync(full);
                freedBytes += stat.size;
                fs.unlinkSync(full);
                count++;
            } catch (e) { /* one bad file shouldn't stop cleanup of the rest */ }
        }
        if (count > 0) logLine('MAIN', `Cleaned up ${count} orphaned track-buffer cache file(s) from a previous session, freeing ${Math.round(freedBytes / 1024)}KB`);
    } catch (e) {
        logLine('MAIN', `Failed to clean up orphaned cache files: ${e.message}`);
    }
}

module.exports = { logLine, NOVA_SERVER_ORIGIN, cacheDir, MAX_TRACK_FILE_BYTES, checkForPreviousCrash, cleanOrphanedCacheFiles, userDataDir, logFilePath, inMemoryLog };

// ==================== Window + app lifecycle ====================
const { DownloadManager } = require('./downloadManager');

let downloadManager = null;

function createDownloadManager() {
    downloadManager = new DownloadManager({
        serverOrigin: NOVA_SERVER_ORIGIN,
        cacheDir,
        maxTrackBytes: MAX_TRACK_FILE_BYTES,
        logFn: logLine,
        // Real, direct fix for a confirmed report: every background
        // download was failing with HTTP 401 on all 5 attempts before
        // giving up. Root cause: _fetchSegment's raw https.get/http.get
        // call has never attached any authentication at all, in any
        // version of this file — it isn't a regression, it just never hit
        // a real authenticated server until now. Queried fresh on every
        // request (rather than captured once) since a session cookie can
        // be refreshed or change while the app is running.
        getCookieHeader: async () => {
            try {
                const cookies = await session.defaultSession.cookies.get({ url: NOVA_SERVER_ORIGIN });
                return cookies.map((c) => `${c.name}=${c.value}`).join('; ');
            } catch (e) {
                logLine('DownloadManager', `Failed to read session cookies for auth: ${e.message}`);
                return '';
            }
        },
    });
}

/**
 * The actual caching layer, made transparent to app.js's own, completely
 * unchanged fetch() calls — this is what lets the existing, already-proven
 * web-audio playback path (scheduling, gapless, buffering) just work,
 * benefiting from local caching without a single line of it needing to
 * know that caching exists.
 *
 * Deliberately NOT implemented as a protocol-level or webRequest-level
 * interceptor — that would mean intercepting ALL network traffic for the
 * entire session (every asset, every other API call) to filter down to
 * just the PCM endpoint, and getting that filtering wrong even slightly
 * would break the whole app's networking, not just caching. Implemented
 * instead as a small fetch() patch, installed in the preload script,
 * that only ever looks at requests to /api/stream/pcm — every other
 * fetch call is untouched, calling straight through to the real,
 * original fetch with zero involvement from this at all.
 */
function installCacheInterceptor() {
    // Intentionally a no-op — see fetchPatch.js, injected via preload
    // instead. Kept as a named function so the intent is documented at
    // the call site even though the real mechanism lives elsewhere.
}

// ==================== Native menu: Logs + Output Device ====================
// See preload.js's own comment for the full reasoning — this replaces an
// injected HTML panel that both overlapped the app's own UI and, even
// once repositioned, still didn't reliably work. A native menu is
// physically incapable of overlapping page content and is driven by
// direct main-process handlers, sidestepping whatever was actually wrong
// with the renderer-side button.
let latestOutputDevices = [];
let currentOutputDeviceId = '';

function buildApplicationMenu() {
    // Real, direct fix alongside the AudioContext capture rework in
    // FETCH_PATCH_SOURCE — the captured AudioContext instance cannot
    // cross the isolation boundary via IPC at all (it isn't a
    // serializable value), so applying a device selection can't round-
    // trip through the preload script the way it used to. This calls the
    // main-world function directly instead, via executeJavaScript, the
    // same mechanism already used to inject the fetch patch itself.
    function applyOutputDeviceInMainWorld(deviceId) {
        if (!mainWindow || mainWindow.isDestroyed()) return;
        mainWindow.webContents.executeJavaScript(
            `window.__novaApplyOutputDevice && window.__novaApplyOutputDevice(${JSON.stringify(deviceId)});`
        ).catch((e) => logLine('MAIN', `Failed to apply output device in main world: ${e.message}`));
    }
    const deviceItems = latestOutputDevices.length
        ? latestOutputDevices.map(d => ({
            label: d.label,
            type: 'radio',
            checked: currentOutputDeviceId === d.deviceId,
            click: () => {
                currentOutputDeviceId = d.deviceId;
                applyOutputDeviceInMainWorld(d.deviceId);
            },
        }))
        : [{ label: 'No output devices found', enabled: false }];

    const template = [
        {
            label: 'NOVA',
            submenu: [
                {
                    label: 'Open Logs',
                    click: () => createLogsWindow(),
                },
                { type: 'separator' },
                {
                    label: 'Output Device',
                    submenu: [
                        {
                            label: 'Default',
                            type: 'radio',
                            checked: currentOutputDeviceId === '',
                            click: () => {
                                currentOutputDeviceId = '';
                                applyOutputDeviceInMainWorld('default');
                            },
                        },
                        { type: 'separator' },
                        ...deviceItems,
                    ],
                },
                { type: 'separator' },
                { role: 'quit' },
            ],
        },
        { role: 'editMenu' },
        { role: 'viewMenu' },
        { role: 'windowMenu' },
    ];
    Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// Real, direct fix for the foundational contextIsolation bug — see
// preload.js's own comment for the full explanation and citation. This
// used to also carry a fetch() override, on the theory that app.js's own
// PCM requests happened on the main thread — confirmed FALSE by direct
// log evidence: even a logger catching every distinct fetch path on the
// main thread never once saw /api/stream/pcm. Traced to the actual
// cause: pcmWorker.js calls fetch() from inside a dedicated Web Worker,
// which has its own completely separate global scope — no override of
// window.fetch, in any world, main or isolated, can ever reach a
// worker's own fetch. The ONLY thing that can intercept a worker's
// requests is the network layer itself, below any JavaScript context —
// see installPcmProtocolInterceptor below for the actual fix. This
// script now does ONLY the AudioContext capture, which remains valid:
// app.js creates its AudioContext on the main thread, not in a worker.
const AUDIO_CONTEXT_CAPTURE_SOURCE = `
(function installNovaAudioContextCapture() {
    if (window.__novaAudioContextCaptureInstalled) return;
    window.__novaAudioContextCaptureInstalled = true;
    if (!window.novaDesktop) {
        console.error('[nova] novaDesktop not available on window — AudioContext capture cannot install');
        return;
    }
    const NativeAudioContext = window.AudioContext || window.webkitAudioContext;
    if (!NativeAudioContext) {
        window.novaDesktop.log('audioDevice', 'No Web Audio API available in this environment — output device selection unavailable');
        return;
    }
    let capturedAudioContext = null;
    function WrappedAudioContext(...args) {
        const instance = new NativeAudioContext(...args);
        capturedAudioContext = instance;
        window.novaDesktop.log('audioDevice', 'AudioContext created and captured for output device selection (main world)');
        return instance;
    }
    WrappedAudioContext.prototype = NativeAudioContext.prototype;
    window.AudioContext = WrappedAudioContext;
    if (window.webkitAudioContext) window.webkitAudioContext = WrappedAudioContext;
    window.__novaApplyOutputDevice = async function (deviceId) {
        if (!capturedAudioContext) { window.novaDesktop.log('audioDevice', 'setOutputDevice: no AudioContext has been created by the page yet'); return; }
        if (typeof capturedAudioContext.setSinkId !== 'function') { window.novaDesktop.log('audioDevice', 'setOutputDevice: AudioContext.setSinkId not available in this Electron/Chromium build'); return; }
        try {
            await capturedAudioContext.setSinkId(deviceId);
            window.novaDesktop.log('audioDevice', 'Output device applied: ' + deviceId);
        } catch (e) {
            window.novaDesktop.log('audioDevice', 'setOutputDevice failed: ' + (e && e.message));
        }
    };
})();
`;

/**
 * The actual fix for caching PCM requests that happen inside a Web
 * Worker, where no JavaScript-level override (contextBridge, main-world
 * injection, anything) can ever reach them. Registered on the session's
 * protocol handling for https — this intercepts EVERY https request in
 * this session, from any context, worker or main thread, since they all
 * ultimately go through the same underlying network stack the worker
 * itself has no way to bypass. Deliberately conservative about what it
 * touches: only a request matching the exact configured Nova server
 * origin AND the /api/stream/pcm path is ever handled specially — every
 * other request, including the page's own initial load and every other
 * API call, is proxied through via net.fetch exactly as given, since
 * getting that filtering wrong even slightly would break the whole
 * app's networking, not just this one endpoint.
 */
function installPcmProtocolInterceptor() {
    const novaOrigin = new URL(NOVA_SERVER_ORIGIN).origin;
    // Matches the exact pattern from Electron's own official docs for
    // proxying a request through unmodified — net.fetch's documented
    // proxy example passes url + an explicit {method, headers, body}
    // object rather than the Request instance itself, so this follows
    // that rather than relying on an unconfirmed assumption that
    // passing the Request object directly behaves identically.
    const proxyThrough = (request) => {
        // Real, direct fix for a confirmed crash: "RequestInit: duplex
        // option is required when sending a body." Node's fetch/undici
        // (which net.fetch is built on) requires duplex: 'half' to be set
        // whenever a request carries a body at all — this isn't optional
        // for POST/PUT/etc., it throws synchronously without it. Verified
        // directly: a real POST with a real body, proxied through this
        // exact function, threw this exact error without the flag and
        // succeeded once it was added.
        const hasBody = !(request.method === 'GET' || request.method === 'HEAD');
        return net.fetch(request.url, {
            method: request.method,
            headers: request.headers,
            body: hasBody ? request.body : undefined,
            duplex: hasBody ? 'half' : undefined,
            // Real, direct fix for a confirmed report: PCM downloads were
            // failing with HTTP 401 on every attempt. pcmWorker.js's own
            // original fetch() call used credentials: 'include' to send
            // the session cookie — proxyThrough was dropping that entirely,
            // since neither copying request.headers nor calling net.fetch
            // bare causes it to attach the session's stored cookies on its
            // own. Verified directly: the identical proxying code returned
            // 401 against a cookie-gated endpoint without this option, and
            // 200 with it added, cookie included, matching what a normal
            // page fetch with credentials: 'include' gets.
            credentials: 'include',
            // Confirmed by direct, reproducible testing in a real Electron
            // process: without this flag, net.fetch's own outgoing request is
            // ITSELF routed back through this same protocol.handle('https', ...)
            // handler (this is documented Electron behavior, not a bug), which
            // calls proxyThrough again, which calls net.fetch again — recursing
            // indefinitely. That's confirmed to be exactly what produced the
            // completely blank, permanently-loading window: no error, no
            // crash, just an https request that never resolves. This flag is
            // what tells net.fetch's own request to skip custom protocol
            // handlers, breaking the recursion.
            bypassCustomProtocolHandlers: true,
        });
    };
    // protocol.handle is a top-level Electron module function, NOT a
    // property of session.defaultSession — session objects have no
    // .protocol at all. Per Electron's own docs, calling it here with
    // no session argument applies it to the default session, which is
    // exactly the one this app's single window uses.
    protocol.handle('https', async (request) => {
        let url;
        try { url = new URL(request.url); } catch (e) { return proxyThrough(request); }
        if (url.origin !== novaOrigin || url.pathname !== '/api/stream/pcm') {
            return proxyThrough(request);
        }

        const sourcePath = url.searchParams.get('path');
        const quality = url.searchParams.get('quality') || 'reduced';
        const skipToSeconds = parseFloat(url.searchParams.get('skipToSeconds') || '0');
        const maxDurationSeconds = parseFloat(url.searchParams.get('maxDurationSeconds') || '60');
        if (!sourcePath) return proxyThrough(request);

        logLine('fetchPatch', `PCM request: path=${sourcePath} quality=${quality} skipToSeconds=${skipToSeconds} maxDurationSeconds=${maxDurationSeconds}`);
        try {
            const isDeepSeekBackWithinSameTrack = sourcePath === trackedPath && skipToSeconds < trackedStartAtSeconds;
            if (sourcePath !== trackedPath || isDeepSeekBackWithinSameTrack) {
                const alreadyMatchesPrefetch = !isDeepSeekBackWithinSameTrack && downloadManager.getNextTrackId();
                if (alreadyMatchesPrefetch === sourcePath) {
                    if (downloadManager.promoteIfMatches(sourcePath)) {
                        trackedPath = sourcePath;
                        trackedStartAtSeconds = 0;
                        logLine('fetchPatch', `Promoted existing prefetch to current: path=${sourcePath}`);
                    }
                } else {
                    const currentFinished = isDeepSeekBackWithinSameTrack ? false : downloadManager.isCurrentFinished();
                    if (isDeepSeekBackWithinSameTrack || currentFinished) {
                        trackedPath = sourcePath;
                        trackedStartAtSeconds = Math.floor(skipToSeconds);
                        logLine('fetchPatch', `Starting new background download: path=${sourcePath} quality=${quality} startAtSeconds=${trackedStartAtSeconds} (${isDeepSeekBackWithinSameTrack ? 'deep seek backward' : 'fresh track or track genuinely finished'})`);
                        downloadManager.startCurrent(sourcePath, sourcePath, quality, trackedStartAtSeconds);
                    } else {
                        logLine('fetchPatch', `Starting gapless prefetch download: path=${sourcePath} quality=${quality} (current track still playing)`);
                        downloadManager.startNext(sourcePath, sourcePath, quality);
                    }
                }
            }

            const buf = downloadManager.findBuffer(sourcePath, trackedStartAtSeconds);
            if (!buf) {
                logLine('fetchPatch', `Cache miss (no buffer yet), falling back to real network request: path=${sourcePath} skipToSeconds=${skipToSeconds}`);
                return proxyThrough(request);
            }
            const bytesPerFrame = buf.channels * 2;
            const bytesPerSecond = buf.sampleRate * bytesPerFrame;
            const relativeSeconds = skipToSeconds - trackedStartAtSeconds;
            if (relativeSeconds < 0) return proxyThrough(request);
            let startByte = Math.floor(relativeSeconds * bytesPerSecond);
            startByte = Math.floor(startByte / bytesPerFrame) * bytesPerFrame;
            // Real, direct fix for a confirmed, severe bug: request-spam and a
            // stuck/paused player, traced to the exact byte math. The old
            // check here only treated a request as a cache miss when
            // startByte was STRICTLY GREATER than downloadedBytes — but a
            // live, in-progress download constantly produces the boundary
            // case where a playback request lands EXACTLY at the byte the
            // download has reached so far (confirmed directly from a real
            // log: skipToSeconds=120 against this file's 8ch/48kHz math is
            // byte 92,160,000 — and downloadedBytes was logged as exactly
            // 92160000, not one byte more). That case fell through as a
            // "cache hit" with zero bytes available, returning an instant,
            // successful, EMPTY response — something the real server could
            // never actually produce, since it always either streams real
            // bytes or blocks until more are ready. This client was never
            // built to handle a fast, successful-but-empty response, and it
            // isn't this cache's place to guess at what it does when given
            // one — the fix is to never manufacture that response shape in
            // the first place: treat this boundary exactly like "not
            // downloaded yet" and fall back to a real, slower network
            // request instead, UNLESS the track has genuinely finished
            // downloading entirely, in which case zero bytes here is the
            // correct, real end of the track, not a stall.
            const isFullyDownloaded = buf.totalBytes != null && buf.downloadedBytes >= buf.totalBytes;
            // Real, direct fix for a confirmed request-amplification bug,
            // found directly in a production log: this used to fall back
            // to a real, SEPARATE network request (proxyThrough) on every
            // single cache miss, immediately, with no awareness that
            // downloadManager was ALREADY, independently downloading this
            // exact content in the background. During a struggling
            // server (confirmed: a real 502 storm in the log), the JS
            // decode loop retries repeatedly — and every one of those
            // retries used to spawn its OWN additional direct request for
            // the same bytes downloadManager was already fetching,
            // multiplying load on a server that was already struggling.
            // The log showed the same segment re-requested via this exact
            // fallback six separate times within about two minutes. Fixed
            // by waiting for the ALREADY-RUNNING download to catch up
            // first — polling its own progress rather than starting a
            // competing request — and only actually falling back to a
            // real network request if there's no active download for
            // this content at all, or the wait genuinely times out
            // (meaning the background download itself is stuck, at which
            // point one additional attempt is a reasonable last resort,
            // not the default first move on every miss).
            if (startByte >= buf.downloadedBytes && !isFullyDownloaded) {
                if (downloadManager.isActiveFor(sourcePath)) {
                    const pollStart = Date.now();
                    const POLL_TIMEOUT_MS = 8000;
                    const POLL_INTERVAL_MS = 200;
                    while (Date.now() - pollStart < POLL_TIMEOUT_MS) {
                        await new Promise(r => setTimeout(r, POLL_INTERVAL_MS));
                        const freshBuf = downloadManager.findBuffer(sourcePath, trackedStartAtSeconds);
                        if (!freshBuf) break; // the download was stopped or superseded while we were waiting — genuinely nothing left to wait for
                        const freshIsFullyDownloaded = freshBuf.totalBytes != null && freshBuf.downloadedBytes >= freshBuf.totalBytes;
                        if (startByte < freshBuf.downloadedBytes || freshIsFullyDownloaded) {
                            logLine('fetchPatch', `Existing download caught up after ${Date.now() - pollStart}ms of waiting: path=${sourcePath} skipToSeconds=${skipToSeconds} — serving from cache instead of a duplicate network request`);
                            return serveFromCache(freshBuf);
                        }
                        if (!downloadManager.isActiveFor(sourcePath)) break; // gave up (e.g. 5 failed attempts) while we were waiting — no point waiting out the rest of the timeout
                    }
                }
                logLine('fetchPatch', `Cache miss (not downloaded yet), falling back to real network request: path=${sourcePath} skipToSeconds=${skipToSeconds}`);
                return proxyThrough(request);
            }
            return serveFromCache(buf);
        } catch (e) {
            logLine('fetchPatch', `Cache layer error, falling back to network: ${e.message}`);
            return proxyThrough(request);
        }

        // Real, direct extraction alongside the wait-for-existing-download
        // fix above — this was inline, one-shot code before; pulling it
        // into its own function lets both the immediate-hit path and the
        // caught-up-after-waiting path serve a buffer identically, rather
        // than duplicating this logic or (worse) re-falling-through into
        // the network fallback after a wait that actually succeeded.
        function serveFromCache(buf) {
            const bytesPerFrame = buf.channels * 2;
            const bytesPerSecond = buf.sampleRate * bytesPerFrame;
            const relativeSeconds = skipToSeconds - trackedStartAtSeconds;
            let startByte = Math.floor(relativeSeconds * bytesPerSecond);
            startByte = Math.floor(startByte / bytesPerFrame) * bytesPerFrame;
            let endByte = startByte + Math.ceil(maxDurationSeconds * bytesPerSecond);
            if (buf.totalBytes != null) endByte = Math.min(endByte, buf.totalBytes);
            endByte = Math.min(endByte, buf.downloadedBytes);
            const skipSamples = Math.floor(startByte / bytesPerFrame);
            let bodyBytes;
            if (endByte <= startByte) {
                bodyBytes = Buffer.alloc(0);
            } else {
                bodyBytes = buf.readAt(startByte, endByte - startByte);
            }
            const percentCached = buf.totalBytes != null ? Math.min(100, Math.round((buf.downloadedBytes / buf.totalBytes) * 100)) : null;
            logLine('fetchPatch', `Served from local cache: path=${sourcePath} bytes=${bodyBytes.length} sampleRate=${buf.sampleRate} channels=${buf.channels} downloadedBytes=${buf.downloadedBytes}${buf.totalBytes != null ? ` totalBytes=${buf.totalBytes} (${percentCached}% of track downloaded)` : ' totalBytes=unknown yet'}`);
            const headers = { 'X-PCM-Sample-Rate': String(buf.sampleRate), 'X-PCM-Channels': String(buf.channels), 'X-PCM-Skip-Samples': String(skipSamples) };
            if (buf.totalBytes != null) {
                const totalFrames = Math.floor(buf.totalBytes / bytesPerFrame) + skipSamples;
                headers['X-PCM-Total-Frames'] = String(totalFrames);
            }
            return new Response(bodyBytes, { status: 200, headers });
        }
    });
}
let trackedPath = null;
let trackedStartAtSeconds = 0;

function createMainWindow() {
    mainWindow = new BrowserWindow({
        width: 1200,
        height: 800,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: true,
        },
    });
    mainWindow.loadURL(NOVA_SERVER_ORIGIN);
    // AudioContext capture still needs main-world injection (app.js
    // creates it on the main thread) — the actual PCM caching no longer
    // depends on this at all, see installPcmProtocolInterceptor above,
    // registered once at startup rather than per-window-load.
    mainWindow.webContents.on('dom-ready', () => {
        mainWindow.webContents.executeJavaScript(AUDIO_CONTEXT_CAPTURE_SOURCE).catch((e) => {
            logLine('MAIN', `Failed to inject AudioContext capture into main world: ${e.message}`);
        });
    });
    mainWindow.webContents.on('did-finish-load', () => {
        logLine('MAIN', `Main window finished loading ${NOVA_SERVER_ORIGIN}`);
    });
    mainWindow.webContents.on('render-process-gone', (event, details) => {
        logLine('MAIN-CRASH', `Renderer process gone: reason=${details.reason}, exitCode=${details.exitCode}`);
        writeCrashFile('renderer render-process-gone', new Error(`Renderer gone: ${details.reason}`));
    });
    mainWindow.on('closed', () => { mainWindow = null; });
}

function createLogsWindow() {
    if (logsWindow && !logsWindow.isDestroyed()) { logsWindow.focus(); return; }
    logsWindow = new BrowserWindow({
        width: 700,
        height: 500,
        title: 'NOVA — Logs',
        webPreferences: {
            preload: path.join(__dirname, 'logsPreload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: true,
        },
    });
    logsWindow.loadFile(path.join(__dirname, 'logs.html'));
    logsWindow.on('closed', () => { logsWindow = null; });
}

app.whenReady().then(() => {
    checkForPreviousCrash();
    cleanOrphanedCacheFiles();
    createDownloadManager();
    registerIpcHandlers();
    // Real, direct fix for a confirmed "doesn't show my virtual cables or
    // devices for outputs" report — Electron does not automatically grant
    // media permissions the way a real browser's own permission prompt
    // would; without this, getUserMedia() silently fails and, more
    // importantly, enumerateDevices() has nothing to base real device
    // labels on and falls back to reporting little more than the generic
    // default. Granted here explicitly and unconditionally — this is a
    // trusted, locally-run desktop app the user installed themselves, not
    // arbitrary third-party web content, so there's no other origin this
    // could wrongly be granting access to.
    session.defaultSession.setPermissionRequestHandler((webContents, permission, callback) => {
        // Real, direct fix for a confirmed "Copy all doesn't work" report
        // — traced to this exact handler: it explicitly denies every
        // permission except media, and that denial applies to the whole
        // app (session.defaultSession, not just the main window) — which
        // silently breaks navigator.clipboard.writeText() in the logs
        // window the same way it would have silently broken anything
        // else needing a permission this never anticipated.
        if (permission === 'media' || permission === 'mediaKeySystem' || permission === 'clipboard-read' || permission === 'clipboard-sanitized-write') { callback(true); return; }
        callback(false);
    });
    if (typeof session.defaultSession.setPermissionCheckHandler === 'function') {
        session.defaultSession.setPermissionCheckHandler((webContents, permission) => permission === 'media' || permission === 'mediaKeySystem' || permission === 'clipboard-read' || permission === 'clipboard-sanitized-write');
    }
    buildApplicationMenu();
    // Registered before the window ever loads — this MUST be in place
    // before app.js or its worker ever makes a single request, since a
    // request that slips through before this is registered would just
    // go straight to the real network, uncached, with no way to
    // retroactively catch it.
    installPcmProtocolInterceptor();
    createMainWindow();

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
    });
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
});

function registerIpcHandlers() {
    // ==================== Buffered download / cache IPC ====================
    // Mirrors the Android bridge's message protocol closely enough to be
    // recognizable, adapted to Electron's request/response IPC instead of
    // Android's fire-and-forget postMessage + separate callback messages.

    // Real, direct removal: the download-manager IPC handlers that used
    // to live here (startTrackDownload, prepareNextTrackDownload,
    // isCurrentTrackFinished, getNextTrackId, promoteNextTrackDownload,
    // readCachedRange) were only ever called from the renderer-side
    // fetch() patch — which turned out to be structurally incapable of
    // ever seeing the actual PCM requests at all, since those happen
    // inside pcmWorker.js's own Web Worker, a separate JS context no
    // renderer-side override can reach. The real fix lives in
    // installPcmProtocolInterceptor above, which runs directly in this
    // process and calls downloadManager's own methods with no IPC layer
    // in between at all — these handlers are gone because nothing calls
    // them anymore, not because the functionality moved elsewhere via IPC.
    ipcMain.handle('nova:stopTrackDownload', () => {
        downloadManager.stopCurrent();
        return { ok: true };
    });

    ipcMain.handle('nova:stopNextTrackDownload', () => {
        downloadManager.stopNext();
        return { ok: true };
    });

    // ==================== Logs IPC ====================
    ipcMain.handle('nova:getRecentLogs', () => inMemoryLog.slice());
    ipcMain.handle('nova:openLogsWindow', () => { createLogsWindow(); return { ok: true }; });
    ipcMain.handle('nova:getLogFilePath', () => logFilePath);
    ipcMain.on('nova:rendererLog', (event, { tag, message }) => { logLine(tag, message); });
    // The actual bridge for the native-menu device picker — see
    // buildApplicationMenu's own comment for the full design.
    ipcMain.on('nova:deviceListUpdated', (event, devices) => {
        latestOutputDevices = Array.isArray(devices) ? devices : [];
        buildApplicationMenu();
    });
    ipcMain.on('nova:rendererCrash', (event, { message, stack }) => {
        logLine('RENDERER-CRASH', `${message}\n${stack || ''}`);
        writeCrashFile('renderer uncaught error', { stack: stack || message });
    });
}
