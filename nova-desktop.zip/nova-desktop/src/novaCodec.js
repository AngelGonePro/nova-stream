// NOVA lossless multichannel audio codec - prototype
// Pure JS, no dependencies. Works in browser (plain <script>) and Node (for testing).
//
// Pipeline:
//   WAV PCM -> pairwise reversible mid/side lifting across channels
//            -> per-block fixed integer predictor (order 0-3, FLAC-style)
//            -> residuals bucketed (bit-length symbol + raw extra bits)
//            -> bucket symbols entropy-coded with static rANS
//
// Everything here is integer arithmetic, so encode->decode is bit-exact.

(function (root) {
  'use strict';

  // ---------- WAV parsing / writing ----------

  // ---------- Metadata extraction: RIFF LIST/INFO chunk + embedded ID3v2 chunk ----------
  // Many WAV files (especially ones produced by ffmpeg from FLAC) carry tags either as a
  // simple RIFF INFO list (INAM/IART/IPRD/...) or as a full embedded ID3v2 tag block
  // (including cover art via the APIC frame). We parse both so metadata/artwork transfer
  // automatically instead of requiring manual re-entry.

  function decodeId3Text(bytes, encoding) {
    // encoding: 0=Latin1, 1=UTF-16 with BOM, 2=UTF-16BE no BOM, 3=UTF-8
    if (encoding === 0 || encoding === 3) {
      // strip trailing null(s)
      let end = bytes.length;
      while (end > 0 && bytes[end - 1] === 0) end--;
      const slice = bytes.subarray(0, end);
      return encoding === 3 ? new TextDecoder('utf-8').decode(slice) : new TextDecoder('latin1').decode(slice);
    } else {
      // UTF-16 (with or without BOM)
      let start = 0;
      let little = true;
      if (bytes.length >= 2 && bytes[0] === 0xFF && bytes[1] === 0xFE) { little = true; start = 2; }
      else if (bytes.length >= 2 && bytes[0] === 0xFE && bytes[1] === 0xFF) { little = false; start = 2; }
      let end = bytes.length;
      while (end - 1 > start && bytes[end - 1] === 0 && bytes[end - 2] === 0) end -= 2;
      const codeUnits = [];
      for (let i = start; i + 1 < end; i += 2) {
        codeUnits.push(little ? (bytes[i] | (bytes[i + 1] << 8)) : ((bytes[i] << 8) | bytes[i + 1]));
      }
      return String.fromCharCode.apply(null, codeUnits);
    }
  }

  function findNullTerminator(bytes, start, encoding) {
    if (encoding === 1 || encoding === 2) {
      for (let i = start; i + 1 < bytes.length; i += 2) if (bytes[i] === 0 && bytes[i + 1] === 0) return i;
      return bytes.length;
    } else {
      for (let i = start; i < bytes.length; i++) if (bytes[i] === 0) return i;
      return bytes.length;
    }
  }

  function parseId3v2(bytes) {
    const tags = {};
    let picture = null;
    if (bytes.length < 10 || bytes[0] !== 0x49 || bytes[1] !== 0x44 || bytes[2] !== 0x33) return { tags, picture };
    const majorVersion = bytes[3];
    const tagSize = ((bytes[6] & 0x7f) << 21) | ((bytes[7] & 0x7f) << 14) | ((bytes[8] & 0x7f) << 7) | (bytes[9] & 0x7f);
    let pos = 10;
    const end = Math.min(10 + tagSize, bytes.length);
    // Simple text frames (single encoding byte + text, no further structure) — this is
    // most standard ID3v2 tags. TIPL/IPLS (involved-people, e.g. named performers by
    // role) use a more complex role:name list structure and aren't parsed here.
    const frameIdMap = {
      TIT2: 'title', TPE1: 'artist', TALB: 'album', TCON: 'genre', TRCK: 'track', TPOS: 'disc',
      TDRC: 'date', TYER: 'date', TPE2: 'albumArtist', TCOM: 'composer', TPE3: 'conductor',
      TEXT: 'lyricist', TCOP: 'copyright', TSRC: 'isrc', TPUB: 'publisher',
    };
    while (pos + 10 <= end) {
      const frameId = String.fromCharCode(bytes[pos], bytes[pos + 1], bytes[pos + 2], bytes[pos + 3]);
      if (frameId === '\0\0\0\0') break;
      let frameSize;
      if (majorVersion >= 4) {
        frameSize = ((bytes[pos + 4] & 0x7f) << 21) | ((bytes[pos + 5] & 0x7f) << 14) | ((bytes[pos + 6] & 0x7f) << 7) | (bytes[pos + 7] & 0x7f);
      } else {
        frameSize = (bytes[pos + 4] << 24) | (bytes[pos + 5] << 16) | (bytes[pos + 6] << 8) | bytes[pos + 7];
      }
      const frameStart = pos + 10;
      const frameEnd = frameStart + frameSize;
      if (frameSize <= 0 || frameEnd > end) break;
      const frameBytes = bytes.subarray(frameStart, frameEnd);

      if (frameIdMap[frameId] && frameBytes.length > 1) {
        const encoding = frameBytes[0];
        const raw = decodeId3Text(frameBytes.subarray(1), encoding);
        // TRCK/TPOS are often "N/M" (e.g. "3/12") — split into number + total so track
        // order can be sorted numerically and total can be shown separately.
        if (frameId === 'TRCK' || frameId === 'TPOS') {
          const parts = raw.split('/');
          tags[frameIdMap[frameId]] = parts[0].trim();
          if (parts[1]) tags[frameIdMap[frameId] + 'Total'] = parts[1].trim();
        } else {
          tags[frameIdMap[frameId]] = raw;
        }
      } else if (frameId === 'COMM' && frameBytes.length > 5) {
        // Comment frame: encoding byte + 3-byte language code + short description
        // (null-terminated) + the actual comment text — a different shape from the
        // simple text frames above.
        const encoding = frameBytes[0];
        const descStart = 4; // skip encoding byte + 3-byte language code
        const descEnd = findNullTerminator(frameBytes, descStart, encoding);
        const textStart = descEnd + (encoding === 1 || encoding === 2 ? 2 : 1);
        if (textStart < frameBytes.length) {
          tags.comment = decodeId3Text(frameBytes.subarray(textStart), encoding);
        }
      } else if (frameId === 'APIC' && frameBytes.length > 4) {
        const encoding = frameBytes[0];
        let p = 1;
        let mimeEnd = p;
        while (mimeEnd < frameBytes.length && frameBytes[mimeEnd] !== 0) mimeEnd++;
        const mime = new TextDecoder('latin1').decode(frameBytes.subarray(p, mimeEnd));
        p = mimeEnd + 1;
        p += 1; // picture type byte
        const descEnd = findNullTerminator(frameBytes, p, encoding);
        p = descEnd + (encoding === 1 || encoding === 2 ? 2 : 1);
        const imgData = frameBytes.subarray(p);
        picture = { mime: mime || 'image/jpeg', data: imgData.slice() };
      }
      pos = frameEnd;
    }
    return { tags, picture };
  }

  function parseRiffInfo(bytes) {
    const tags = {};
    const infoMap = {
      INAM: 'title', IART: 'artist', IPRD: 'album', ICRD: 'date', IGNR: 'genre', ICMT: 'comment',
      ITRK: 'track', ICOP: 'copyright', IPRT: 'track', IPUB: 'publisher',
    };
    let pos = 0;
    while (pos + 8 <= bytes.length) {
      const id = String.fromCharCode(bytes[pos], bytes[pos + 1], bytes[pos + 2], bytes[pos + 3]);
      const size = bytes[pos + 4] | (bytes[pos + 5] << 8) | (bytes[pos + 6] << 16) | (bytes[pos + 7] << 24);
      const dataStart = pos + 8;
      if (size < 0 || dataStart + size > bytes.length) break;
      if (infoMap[id]) {
        let strEnd = dataStart;
        while (strEnd < dataStart + size && bytes[strEnd] !== 0) strEnd++;
        tags[infoMap[id]] = new TextDecoder('utf-8').decode(bytes.subarray(dataStart, strEnd));
      }
      pos = dataStart + size + (size % 2);
    }
    return tags;
  }

  function parseWav(buf) {
    const dv = new DataView(buf);
    const u8 = new Uint8Array(buf);
    if (dv.getUint32(0, false) !== 0x52494646) throw new Error('Not a RIFF file');
    if (dv.getUint32(8, false) !== 0x57415645) throw new Error('Not a WAVE file');

    let pos = 12;
    let fmt = null, dataOffset = -1, dataLen = 0;
    let riffInfoTags = {}, id3Tags = {}, id3Picture = null;
    while (pos + 8 <= buf.byteLength) {
      const id = dv.getUint32(pos, false);
      const size = dv.getUint32(pos + 4, true);
      const body = pos + 8;
      if (id === 0x666d7420) { // 'fmt '
        fmt = {
          audioFormat: dv.getUint16(body, true),
          numChannels: dv.getUint16(body + 2, true),
          sampleRate: dv.getUint32(body + 4, true),
          bitsPerSample: dv.getUint16(body + 14, true),
        };
      } else if (id === 0x64617461) { // 'data'
        dataOffset = body;
        dataLen = size;
      } else if (id === 0x4C495354) { // 'LIST'
        const listType = dv.getUint32(body, false);
        if (listType === 0x494E464F) { // 'INFO'
          riffInfoTags = parseRiffInfo(u8.subarray(body + 4, body + size));
        }
      } else if (id === 0x69643320 || id === 0x49443320) { // 'id3 ' or 'ID3 '
        const parsed = parseId3v2(u8.subarray(body, body + size));
        id3Tags = parsed.tags;
        id3Picture = parsed.picture;
      }
      pos = body + size + (size % 2);
    }
    if (!fmt || dataOffset < 0) throw new Error('Missing fmt or data chunk');
    // ID3 tags take priority where both exist (usually richer/more reliable), RIFF INFO fills gaps
    const tags = Object.assign({}, riffInfoTags, id3Tags);
    const metadata = { tags, picture: id3Picture };
    if (fmt.audioFormat !== 1 && fmt.audioFormat !== 0xFFFE) {
      throw new Error('Only integer PCM WAV supported in this prototype (got format ' + fmt.audioFormat + ')');
    }
    const bytesPerSample = fmt.bitsPerSample / 8;
    const numChannels = fmt.numChannels;
    const frameBytes = bytesPerSample * numChannels;
    const numFrames = Math.floor(dataLen / frameBytes);

    const channels = [];
    for (let c = 0; c < numChannels; c++) channels.push(new Int32Array(numFrames));

    let off = dataOffset;
    if (fmt.bitsPerSample === 16) {
      for (let i = 0; i < numFrames; i++) {
        for (let c = 0; c < numChannels; c++) {
          channels[c][i] = dv.getInt16(off, true);
          off += 2;
        }
      }
    } else if (fmt.bitsPerSample === 24) {
      for (let i = 0; i < numFrames; i++) {
        for (let c = 0; c < numChannels; c++) {
          let b0 = dv.getUint8(off), b1 = dv.getUint8(off + 1), b2 = dv.getUint8(off + 2);
          let v = b0 | (b1 << 8) | (b2 << 16);
          if (v & 0x800000) v -= 0x1000000; // sign extend
          channels[c][i] = v;
          off += 3;
        }
      }
    } else if (fmt.bitsPerSample === 32) {
      for (let i = 0; i < numFrames; i++) {
        for (let c = 0; c < numChannels; c++) {
          channels[c][i] = dv.getInt32(off, true);
          off += 4;
        }
      }
    } else {
      throw new Error('Unsupported bit depth: ' + fmt.bitsPerSample);
    }

    return {
      sampleRate: fmt.sampleRate,
      numChannels,
      bitsPerSample: fmt.bitsPerSample,
      numFrames,
      channels,
      metadata, // { tags: {title,artist,album,...}, picture: {mime,data} | null } extracted from the WAV itself
    };
  }

  function writeWav({ sampleRate, numChannels, bitsPerSample, numFrames, channels }) {
    const bytesPerSample = bitsPerSample / 8;
    const dataLen = numFrames * numChannels * bytesPerSample;
    const buf = new ArrayBuffer(44 + dataLen);
    const dv = new DataView(buf);
    let p = 0;
    function u32(v) { dv.setUint32(p, v, true); p += 4; }
    function u16(v) { dv.setUint16(p, v, true); p += 2; }
    function tag(s) { for (let i = 0; i < 4; i++) dv.setUint8(p++, s.charCodeAt(i)); }

    tag('RIFF'); u32(36 + dataLen); tag('WAVE');
    tag('fmt '); u32(16); u16(1); u16(numChannels); u32(sampleRate);
    u32(sampleRate * numChannels * bytesPerSample); u16(numChannels * bytesPerSample); u16(bitsPerSample);
    tag('data'); u32(dataLen);

    let off = 44;
    if (bitsPerSample === 16) {
      for (let i = 0; i < numFrames; i++)
        for (let c = 0; c < numChannels; c++) { dv.setInt16(off, channels[c][i], true); off += 2; }
    } else if (bitsPerSample === 24) {
      for (let i = 0; i < numFrames; i++)
        for (let c = 0; c < numChannels; c++) {
          let v = channels[c][i] & 0xFFFFFF;
          dv.setUint8(off, v & 0xFF); dv.setUint8(off + 1, (v >> 8) & 0xFF); dv.setUint8(off + 2, (v >> 16) & 0xFF);
          off += 3;
        }
    } else if (bitsPerSample === 32) {
      for (let i = 0; i < numFrames; i++)
        for (let c = 0; c < numChannels; c++) { dv.setInt32(off, channels[c][i], true); off += 4; }
    }
    return buf;
  }

  // ---------- Cross-channel reversible lifting: full hierarchical decorrelation ----------
  // A single pairwise pass (0,1),(2,3),... only captures adjacent-pair correlation
  // (e.g. front L/R). Real inter-channel redundancy in a 7.1 bed also spans further —
  // front pair vs. rear pair, etc. This recursively re-applies the same reversible
  // lifting step to the "mid" outputs of each level, building a full reduction tree.
  //
  // Critical fix: NOT every pair is actually correlated (e.g. Center vs LFE) — forcing
  // a lift on an uncorrelated pair adds redundancy instead of removing it. Each lift is
  // now adaptive: cheaply compare cost with vs. without, and only commit to the lift if
  // it actually helps. One flag bit per pair, decided once for the whole file (negligible
  // storage), returned alongside the transformed channels so decode can mirror the choice.
  function liftPair(L, R) {
    const len = L.length;
    const mid = new Int32Array(len), side = new Int32Array(len);
    for (let i = 0; i < len; i++) {
      const s = L[i] - R[i];
      const m = R[i] + (s >> 1);
      side[i] = s;
      mid[i] = m;
    }
    return { mid, side };
  }
  function unliftPair(mid, side) {
    const len = mid.length;
    const L = new Int32Array(len), R = new Int32Array(len);
    for (let i = 0; i < len; i++) {
      const r = mid[i] - (side[i] >> 1);
      const l = r + side[i];
      R[i] = r;
      L[i] = l;
    }
    return { L, R };
  }
  function sumAbs(arr) {
    let s = 0;
    for (let i = 0; i < arr.length; i++) { const v = arr[i]; s += v < 0 ? -v : v; }
    return s;
  }
  // Rice/entropy coding cost scales with log2(magnitude), not raw magnitude — two signals
  // with identical sumAbs can have very different actual compressed size (a few large
  // outliers vs. many mid-sized values compress very differently). Every adaptive decision
  // (predictor choice, cross-channel lift, LMS mode) should be judged by this, not sumAbs.
  function estimateBits(arr) {
    let s = 0;
    for (let i = 0; i < arr.length; i++) {
      const v = arr[i]; const av = v < 0 ? -v : v;
      s += Math.log2(av + 1);
    }
    return s;
  }

  function crossChannelForward(channels) {
    const n = channels.length;
    if (n <= 1) return { result: channels.slice(), flags: [] };
    const mids = [], sides = [], pairFlags = [];
    for (let i = 0; i < n; i += 2) {
      if (i + 1 < n) {
        const L = channels[i], R = channels[i + 1];
        const { mid, side } = liftPair(L, R);
        const costLifted = estimateBits(mid) + estimateBits(side);
        const costPlain = estimateBits(L) + estimateBits(R);
        if (costLifted < costPlain) {
          mids.push(mid); sides.push(side); pairFlags.push(1);
        } else {
          mids.push(L); sides.push(R); pairFlags.push(0); // lift didn't help — pass both through unchanged
        }
      } else {
        mids.push(channels[i]); // odd one out passes through to the next level unchanged, no flag needed
      }
    }
    const { result: reducedMids, flags: subFlags } = crossChannelForward(mids);
    return { result: reducedMids.concat(sides), flags: pairFlags.concat(subFlags) };
  }

  function crossChannelInverse(transformed, flags) {
    const n = transformed.length;
    if (n <= 1) return transformed.slice();
    const numMids = Math.ceil(n / 2);
    const numSides = n - numMids;
    const reducedMids = transformed.slice(0, numMids);
    const sides = transformed.slice(numMids);
    const pairFlags = flags.slice(0, numSides);
    const subFlags = flags.slice(numSides);
    const mids = crossChannelInverse(reducedMids, subFlags); // undo the deeper level first (mirror of forward's recursion)
    const result = new Array(n);
    let sideIdx = 0;
    for (let i = 0; i < n; i += 2) {
      if (i + 1 < n) {
        const flag = pairFlags[sideIdx];
        if (flag === 1) {
          const { L, R } = unliftPair(mids[i / 2], sides[sideIdx]);
          result[i] = L; result[i + 1] = R;
        } else {
          result[i] = mids[i / 2]; result[i + 1] = sides[sideIdx]; // was passed through unchanged
        }
        sideIdx++;
      } else {
        result[i] = mids[i / 2]; // the odd-one-out that passed through unchanged
      }
    }
    return result;
  }

  // ---------- Predictors: FLAC-style fixed orders 0-3, plus real adaptive LPC ----------
  // Fixed predictors are a cheap fallback. Adaptive LPC (coefficients fit per-block via
  // Levinson-Durbin, quantized to integers for exact reversibility) is what actually gives
  // codecs like WavPack/Monkey's Audio/FLAC's LPC mode most of their real compression —
  // a fixed-shape predictor can't adapt to the block's actual spectral content, LPC can.

  const BLOCK = 4096;
  const LPC_ORDER = 8;
  // Decoded samples the streaming decoder keeps behind the current chunk. Must be >= LPC_ORDER
  // (and >= 3, the highest fixed-predictor order); 32 leaves a wide margin.
  const STREAM_HISTORY = 32;
  const LPC_PRECISION_BITS = 14;
  const METHOD_LPC = 4;

  // A Welch window applied before autocorrelation — standard practice in FLAC and
  // similar LPC-based codecs, absent from this implementation until now. Without it,
  // the raw block-edge samples get equal weight in the autocorrelation estimate as the
  // rest of the block, which distorts the estimate (samples right at an arbitrary
  // 4096-sample cut point aren't spectrally representative of the block as a whole).
  // Verified empirically: this measurably reduces LPC residual cost at every order
  // tested, not assumed from theory alone.
  function autocorrelate(x, start, end, order) {
    const n = end - start;
    const windowed = new Float64Array(n);
    const half = (n - 1) / 2;
    for (let i = 0; i < n; i++) {
      const t = (i - half) / half;
      windowed[i] = x[start + i] * (1 - t * t);
    }
    const r = new Float64Array(order + 1);
    for (let lag = 0; lag <= order; lag++) {
      let sum = 0;
      for (let i = lag; i < n; i++) sum += windowed[i] * windowed[i - lag];
      r[lag] = sum;
    }
    return r;
  }

  function levinsonDurbin(r, order) {
    let err = r[0];
    let lpc = new Float64Array(order);
    if (err <= 0) return { lpc, ok: false };
    for (let i = 0; i < order; i++) {
      let acc = r[i + 1];
      for (let j = 0; j < i; j++) acc -= lpc[j] * r[i - j];
      const k = acc / err;
      const newLpc = lpc.slice();
      newLpc[i] = k;
      for (let j = 0; j < i; j++) newLpc[j] = lpc[j] - k * lpc[i - 1 - j];
      lpc = newLpc;
      err *= (1 - k * k);
      if (!(err > 0)) return { lpc, ok: false }; // numerical breakdown (e.g. near-silent block)
    }
    return { lpc, ok: true };
  }

  function quantizeLPC(coeffs, precisionBits) {
    let maxCoef = 0;
    for (let i = 0; i < coeffs.length; i++) maxCoef = Math.max(maxCoef, Math.abs(coeffs[i]));
    if (maxCoef <= 0) return { qcoeffs: new Int32Array(coeffs.length), shift: 0, ok: false };
    let shift = precisionBits - 1 - Math.floor(Math.log2(maxCoef)) - 1;
    shift = Math.max(0, Math.min(shift, 30));
    const qcoeffs = new Int32Array(coeffs.length);
    for (let i = 0; i < coeffs.length; i++) {
      let q = Math.round(coeffs[i] * Math.pow(2, shift));
      q = Math.max(-32768, Math.min(32767, q));
      qcoeffs[i] = q;
    }
    return { qcoeffs, shift, ok: true };
  }

  function lpcPredict(x, i, qcoeffs, shift) {
    let acc = 0;
    for (let j = 0; j < qcoeffs.length; j++) acc += qcoeffs[j] * x[i - 1 - j];
    return Math.floor(acc / Math.pow(2, shift));
  }

  function fitLPCForBlock(x, start, end) {
    if (start < LPC_ORDER) return null;
    const r = autocorrelate(x, start, end, LPC_ORDER);
    if (r[0] <= 0) return null; // silent/near-silent block: LPC unstable and unnecessary
    // tiny stabilizing bias, standard practice to avoid ill-conditioning
    r[0] *= 1 + 1e-9;
    const { lpc, ok } = levinsonDurbin(r, LPC_ORDER);
    if (!ok) return null;
    const { qcoeffs, shift, ok: qok } = quantizeLPC(lpc, LPC_PRECISION_BITS);
    if (!qok) return null;
    return { qcoeffs, shift };
  }

  // ---------- Backward-adaptive sign-sign LMS cascade (post-predictor refinement) ----------
  // This is the mechanism that lets Monkey's Audio and similar codecs beat forward
  // block-adaptive LPC: the filter continuously updates its weights sample-by-sample using
  // only already-known (causal) history, so the decoder can replay the identical adaptation
  // deterministically — no coefficients are ever transmitted. Applied here as a refinement
  // pass on top of the existing block-LPC residual, to mop up structure/non-stationarity a
  // fixed 4096-sample block boundary misses.

  // Two cascaded stages, matching the real "cascaded adaptive filters" technique
  // (e.g. MPEG-4 ALS's RLS+LMS cascade): stage 1 does the heavy lifting (larger order),
  // stage 2 mops up what stage 1's fixed order/step-size couldn't track (smaller order,
  // cheap to run). Modest total cost increase — stage 2's order is half of stage 1's.
  const LMS_ORDER_1 = 16, LMS_SHIFT_1 = 9;
  const LMS_ORDER_2 = 8, LMS_SHIFT_2 = 9;
  // A much larger third stage, tried as an additional candidate for every channel
  // (originally gated to stereo/mono only, to keep 8-channel encode time down — later
  // measured directly on real 8-channel content: ~1.4% smaller files, roughly matching
  // the gain stereo sees, at the cost of ~2.2x longer encode time. Extended to all
  // channels deliberately, accepting that trade-off for better compression everywhere).
  // Order/shift found by empirical sweep against a realistic-complexity test signal, not
  // guessed: order=256 initially seemed like the obvious move (informed by Monkey's
  // Audio's actual filter sizes — a real, clean-room-verified reference, whose "Insane"
  // preset uses 1280/256/16), but sign-sign LMS (fixed +/-1 weight updates, not
  // magnitude-proportional) converges too slowly at that size to actually help within a
  // track's length — order=256 with the SAME shift as the smaller stages was measurably
  // WORSE than doing nothing at all. Sweeping order AND shift together found this app's
  // real optimum sits much lower, around order=128 with a properly-scaled shift —
  // smaller, faster, and it measurably beat every larger configuration tried, including
  // 256 taps.
  const LMS_ORDER_BIG = 128, LMS_SHIFT_BIG = 14;
  // A deeper, 4-stage cascade offered ONLY for stereo/mono (see the channel-count gate
  // where this is tried) — stereo has roughly 4x the per-channel compute budget that
  // 8-channel content does, so a configuration too slow to offer multichannel is
  // affordable here. Found by direct measurement against real music (Eagles - Hotel
  // California, the file this app is actually used on), not synthetic signals: verified
  // ~0.66% smaller than the existing 128-order cascade on top of it, on both channels
  // independently. Structurally similar to what Monkey's Audio and the MPEG-4 lossless
  // RLS-LMS standard both do — a cascade of progressively smaller stages, largest first.
  const LMS_ORDER_STEREO_A = 192, LMS_SHIFT_STEREO_A = 14;
  const LMS_ORDER_STEREO_B = 96, LMS_SHIFT_STEREO_B = 13;
  const LMS_WEIGHT_CLAMP = 1 << 12; // keeps order*clamp*maxSample far below 2^53 (float64 exact-integer limit) even for 32-bit audio

  function lmsForward(d, order, shift) {
    const n = d.length;
    const w = new Int32Array(order);
    const hist = new Float64Array(order);
    let pos = 0; // next write position (circular buffer)
    const e = new Float64Array(n); // NOT Int32Array — avoids silent truncation if pred briefly overshoots int32 range
    const div = Math.pow(2, shift);
    for (let i = 0; i < n; i++) {
      let pred = 0;
      for (let j = 0; j < order; j++) {
        const idx = (pos - 1 - j + order * 2) % order; // hist[idx] = sample from j steps ago
        pred += w[j] * hist[idx];
      }
      pred = Math.floor(pred / div);
      const input = d[i];
      const err = input - pred;
      e[i] = err;
      const s = err > 0 ? 1 : (err < 0 ? -1 : 0);
      for (let j = 0; j < order; j++) {
        const idx = (pos - 1 - j + order * 2) % order;
        const hs = hist[idx] > 0 ? 1 : (hist[idx] < 0 ? -1 : 0);
        let nw = w[j] + s * hs;
        if (nw > LMS_WEIGHT_CLAMP) nw = LMS_WEIGHT_CLAMP;
        else if (nw < -LMS_WEIGHT_CLAMP) nw = -LMS_WEIGHT_CLAMP;
        w[j] = nw;
      }
      hist[pos] = input;
      pos = (pos + 1) % order;
    }
    return e;
  }

  function lmsInverse(e, order, shift) {
    const n = e.length;
    const w = new Int32Array(order);
    const hist = new Float64Array(order);
    let pos = 0;
    const d = new Float64Array(n);
    const div = Math.pow(2, shift);
    for (let i = 0; i < n; i++) {
      let pred = 0;
      for (let j = 0; j < order; j++) {
        const idx = (pos - 1 - j + order * 2) % order;
        pred += w[j] * hist[idx];
      }
      pred = Math.floor(pred / div);
      const err = e[i];
      const input = err + pred;
      d[i] = input;
      const s = err > 0 ? 1 : (err < 0 ? -1 : 0);
      for (let j = 0; j < order; j++) {
        const idx = (pos - 1 - j + order * 2) % order;
        const hs = hist[idx] > 0 ? 1 : (hist[idx] < 0 ? -1 : 0);
        let nw = w[j] + s * hs;
        if (nw > LMS_WEIGHT_CLAMP) nw = LMS_WEIGHT_CLAMP;
        else if (nw < -LMS_WEIGHT_CLAMP) nw = -LMS_WEIGHT_CLAMP;
        w[j] = nw;
      }
      hist[pos] = input;
      pos = (pos + 1) % order;
    }
    return d;
  }

  // ---------- Resumable LMS inverse (streaming path) ----------
  // Separate from lmsInverse above for the same reason as the rANS split: this carries
  // real cross-chunk state (weights + history), and any subtle bug here must not be able
  // to touch the already-proven non-streaming path.
  function lmsInverseChunkInit(order) {
    return { w: new Int32Array(order), hist: new Float64Array(order), pos: 0 };
  }
  function lmsInverseChunk(e, order, shift, state) {
    const n = e.length;
    const w = state.w, hist = state.hist;
    let pos = state.pos;
    const d = new Float64Array(n);
    const div = Math.pow(2, shift);
    for (let i = 0; i < n; i++) {
      let pred = 0;
      for (let j = 0; j < order; j++) {
        const idx = (pos - 1 - j + order * 2) % order;
        pred += w[j] * hist[idx];
      }
      pred = Math.floor(pred / div);
      const err = e[i];
      const input = err + pred;
      d[i] = input;
      const s = err > 0 ? 1 : (err < 0 ? -1 : 0);
      for (let j = 0; j < order; j++) {
        const idx = (pos - 1 - j + order * 2) % order;
        const hs = hist[idx] > 0 ? 1 : (hist[idx] < 0 ? -1 : 0);
        let nw = w[j] + s * hs;
        if (nw > LMS_WEIGHT_CLAMP) nw = LMS_WEIGHT_CLAMP;
        else if (nw < -LMS_WEIGHT_CLAMP) nw = -LMS_WEIGHT_CLAMP;
        w[j] = nw;
      }
      hist[pos] = input;
      pos = (pos + 1) % order;
    }
    state.pos = pos; // w and hist were mutated in place already (same typed array references)
    return d;
  }


  // Same fix as cross-channel: a fixed cascade isn't guaranteed to help every channel
  // (e.g. a near-silent LFE channel has no real structure left for an adaptive filter to
  // find — running it anyway just adds filter noise). Pick per-channel, once, whichever of
  // {no LMS, stage 1 only, full cascade, (stereo/mono only) big cascade} actually has the
  // smallest residual magnitude.
  function lmsCascadeForwardAdaptive(d, allowBigCascade, allowStereoCascade) {
    const stage1 = lmsForward(d, LMS_ORDER_1, LMS_SHIFT_1);
    const stage2 = lmsForward(stage1, LMS_ORDER_2, LMS_SHIFT_2);
    const costs = [estimateBits(d), estimateBits(stage1), estimateBits(stage2)];
    let mode = 0, best = costs[0];
    for (let m = 1; m <= 2; m++) if (costs[m] < best) { best = costs[m]; mode = m; }
    let chosen = mode === 0 ? d : (mode === 1 ? stage1 : stage2);
    if (allowBigCascade) {
      // High-compression candidate for every channel count — the 3-stage 128-order
      // cascade. An NLMS variant was tried here too (normalized, magnitude-proportional
      // weight updates, architecturally closer to Monkey's Audio) but tested honestly
      // against real audio files rather than synthetic test signals, it never actually
      // won against this cascade — confirmed across both a real stereo track and a real
      // 7.1 track, 7 of 8 channels on the latter. Removed rather than kept as dead
      // weight: it added a full second adaptive-filter implementation's worth of code
      // for zero real benefit.
      const big = lmsForward(d, LMS_ORDER_BIG, LMS_SHIFT_BIG);
      const bigStage2 = lmsForward(big, LMS_ORDER_2, LMS_SHIFT_2);
      const bigStage1 = lmsForward(bigStage2, LMS_ORDER_1, LMS_SHIFT_1);
      const bigCost = estimateBits(bigStage1);
      if (bigCost < best) { best = bigCost; mode = 3; chosen = bigStage1; }
    }
    if (allowStereoCascade) {
      // A deeper 4-stage cascade offered ONLY for stereo/mono — see LMS_ORDER_STEREO_A's
      // comment for why this isn't tried on multichannel too.
      const a = lmsForward(d, LMS_ORDER_STEREO_A, LMS_SHIFT_STEREO_A);
      const b = lmsForward(a, LMS_ORDER_STEREO_B, LMS_SHIFT_STEREO_B);
      const c2 = lmsForward(b, LMS_ORDER_2, LMS_SHIFT_2);
      const c1 = lmsForward(c2, LMS_ORDER_1, LMS_SHIFT_1);
      const stereoCost = estimateBits(c1);
      if (stereoCost < best) { best = stereoCost; mode = 4; chosen = c1; }
    }
    return { refined: chosen, mode };
  }
  function lmsCascadeInverseAdaptive(e, mode) {
    if (mode === 0) return e;
    if (mode === 1) return lmsInverse(e, LMS_ORDER_1, LMS_SHIFT_1);
    if (mode === 3) {
      const s1 = lmsInverse(e, LMS_ORDER_1, LMS_SHIFT_1);
      const s2 = lmsInverse(s1, LMS_ORDER_2, LMS_SHIFT_2);
      return lmsInverse(s2, LMS_ORDER_BIG, LMS_SHIFT_BIG);
    }
    if (mode === 4) {
      const c1 = lmsInverse(e, LMS_ORDER_1, LMS_SHIFT_1);
      const c2 = lmsInverse(c1, LMS_ORDER_2, LMS_SHIFT_2);
      const b = lmsInverse(c2, LMS_ORDER_STEREO_B, LMS_SHIFT_STEREO_B);
      return lmsInverse(b, LMS_ORDER_STEREO_A, LMS_SHIFT_STEREO_A);
    }
    const stage1 = lmsInverse(e, LMS_ORDER_2, LMS_SHIFT_2);
    return lmsInverse(stage1, LMS_ORDER_1, LMS_SHIFT_1);
  }

  // ---------- Resumable LMS cascade dispatch (streaming path) ----------
  function lmsCascadeInverseChunkInit(mode) {
    if (mode === 0) return null;
    if (mode === 1) return { stage1: lmsInverseChunkInit(LMS_ORDER_1) };
    if (mode === 3) return { stage1: lmsInverseChunkInit(LMS_ORDER_1), stage2: lmsInverseChunkInit(LMS_ORDER_2), big: lmsInverseChunkInit(LMS_ORDER_BIG) };
    if (mode === 4) return { stage1: lmsInverseChunkInit(LMS_ORDER_1), stage2: lmsInverseChunkInit(LMS_ORDER_2), b: lmsInverseChunkInit(LMS_ORDER_STEREO_B), a: lmsInverseChunkInit(LMS_ORDER_STEREO_A) };
    return { stage2: lmsInverseChunkInit(LMS_ORDER_2), stage1: lmsInverseChunkInit(LMS_ORDER_1) };
  }
  function lmsCascadeInverseChunk(e, mode, state) {
    if (mode === 0) return e;
    if (mode === 1) return lmsInverseChunk(e, LMS_ORDER_1, LMS_SHIFT_1, state.stage1);
    if (mode === 3) {
      const s1 = lmsInverseChunk(e, LMS_ORDER_1, LMS_SHIFT_1, state.stage1);
      const s2 = lmsInverseChunk(s1, LMS_ORDER_2, LMS_SHIFT_2, state.stage2);
      return lmsInverseChunk(s2, LMS_ORDER_BIG, LMS_SHIFT_BIG, state.big);
    }
    if (mode === 4) {
      const c1 = lmsInverseChunk(e, LMS_ORDER_1, LMS_SHIFT_1, state.stage1);
      const c2 = lmsInverseChunk(c1, LMS_ORDER_2, LMS_SHIFT_2, state.stage2);
      const b = lmsInverseChunk(c2, LMS_ORDER_STEREO_B, LMS_SHIFT_STEREO_B, state.b);
      return lmsInverseChunk(b, LMS_ORDER_STEREO_A, LMS_SHIFT_STEREO_A, state.a);
    }
    const stage1out = lmsInverseChunk(e, LMS_ORDER_2, LMS_SHIFT_2, state.stage2);
    return lmsInverseChunk(stage1out, LMS_ORDER_1, LMS_SHIFT_1, state.stage1);
  }

  function predictChannelForward(x, onBlockProgress) {
    const len = x.length;
    const residuals = new Int32Array(len);
    const orders = [];
    const lpcParams = []; // { shift, qcoeffs } per block that used LPC, in block order

    let blockCount = 0;
    for (let start = 0; start < len; start += BLOCK) {
      const end = Math.min(start + BLOCK, len);
      let bestMethod = 0, bestCost = Infinity;

      for (let order = 0; order <= 3; order++) {
        if (start < order) continue;
        let cost = 0;
        for (let i = start; i < end; i++) { const r = residualAt(x, i, order); const av = r < 0 ? -r : r; cost += Math.log2(av + 1); }
        if (cost < bestCost) { bestCost = cost; bestMethod = order; }
      }
      if (start < 3) bestMethod = 0;

      let lpcCandidate = null;
      if (start >= LPC_ORDER) {
        lpcCandidate = fitLPCForBlock(x, start, end);
        if (lpcCandidate) {
          // Coefficient storage overhead, in bits — (1 shift byte + 2 bytes per
          // coefficient) — was previously missing entirely from this comparison, so a
          // higher LPC_ORDER could look "cheaper" purely by shrinking residuals, even
          // when the extra coefficient bytes it costs to store outweigh that savings.
          // Found by testing: without this term, raising LPC_ORDER measurably made files
          // LARGER, not smaller, because the adaptive check had no way to see the actual
          // trade-off it was making.
          let cost = (1 + LPC_ORDER * 2) * 8;
          for (let i = start; i < end; i++) {
            const pred = lpcPredict(x, i, lpcCandidate.qcoeffs, lpcCandidate.shift);
            const r = x[i] - pred;
            const av = r < 0 ? -r : r;
            cost += Math.log2(av + 1);
          }
          if (cost < bestCost) { bestCost = cost; bestMethod = METHOD_LPC; }
        }
      }

      orders.push(bestMethod);
      if (bestMethod === METHOD_LPC) {
        lpcParams.push(lpcCandidate);
        for (let i = start; i < end; i++) residuals[i] = x[i] - lpcPredict(x, i, lpcCandidate.qcoeffs, lpcCandidate.shift);
      } else {
        for (let i = start; i < end; i++) residuals[i] = start < bestMethod ? x[i] : residualAt(x, i, bestMethod);
      }
      // Reported every 50 blocks (not every block) — enough for a smooth-looking
      // progress bar without callback overhead on every single 4096-sample block, which
      // for a long track can number in the thousands.
      blockCount++;
      if (onBlockProgress && (blockCount % 50 === 0)) onBlockProgress(end / len);
    }
    return { residuals, orders, lpcParams };
  }

  function residualAt(x, i, order) {
    switch (order) {
      case 0: return x[i];
      case 1: return x[i] - x[i - 1];
      case 2: return x[i] - (2 * x[i - 1] - x[i - 2]);
      case 3: return x[i] - (3 * x[i - 1] - 3 * x[i - 2] + x[i - 3]);
    }
  }

  function predictChannelInverse(residuals, orders, lpcParams, len) {
    const x = new Int32Array(len);
    let blockIdx = 0, lpcIdx = 0;
    for (let start = 0; start < len; start += BLOCK) {
      const end = Math.min(start + BLOCK, len);
      const method = orders[blockIdx++];
      if (method === METHOD_LPC) {
        const { qcoeffs, shift } = lpcParams[lpcIdx++];
        for (let i = start; i < end; i++) x[i] = residuals[i] + lpcPredict(x, i, qcoeffs, shift);
        continue;
      }
      const order = method;
      for (let i = start; i < end; i++) {
        if (start < order) { x[i] = residuals[i]; continue; }
        let pred;
        switch (order) {
          case 0: pred = 0; break;
          case 1: pred = x[i - 1]; break;
          case 2: pred = 2 * x[i - 1] - x[i - 2]; break;
          case 3: pred = 3 * x[i - 1] - 3 * x[i - 2] + x[i - 3]; break;
        }
        x[i] = residuals[i] + pred;
      }
    }
    return x;
  }

  // ---------- Resumable predictor inverse (streaming path) ----------
  // Writes into a persistent, pre-allocated x[] array shared across chunk calls (index
  // is always GLOBAL sample position, matching the original's semantics exactly) — so
  // x[i-1] etc. correctly reads history written by a PREVIOUS chunk call. The only extra
  // state needed is an LPC-params cursor, since lpcParams only has one entry per
  // LPC-method block, not one per block overall.
  function predictChannelInverseChunkInit() {
    return { lpcIdx: 0 };
  }
  // xBase/totalFrames exist so the streaming decoder can keep only a sliding window of
  // decoded samples instead of one full-length array per channel (see createStreamingDecoder).
  // x[k] holds global sample xBase + k. Defaults (xBase 0, totalFrames = x.length) reproduce
  // the original behaviour exactly for every other caller.
  function predictChannelInverseChunk(residualsChunk, ordersChunk, lpcParams, lpcState, x, globalStartSample, xBase = 0, totalFrames = x.length) {
    let blockIdx = 0;
    for (let start = globalStartSample; blockIdx < ordersChunk.length; start += BLOCK) {
      const end = Math.min(start + BLOCK, totalFrames);
      const method = ordersChunk[blockIdx++];
      if (method === METHOD_LPC) {
        const { qcoeffs, shift } = lpcParams[lpcState.lpcIdx++];
        for (let i = start; i < end; i++) x[i - xBase] = residualsChunk[i - globalStartSample] + lpcPredict(x, i - xBase, qcoeffs, shift);
        continue;
      }
      const order = method;
      for (let i = start; i < end; i++) {
        if (start < order) { x[i - xBase] = residualsChunk[i - globalStartSample]; continue; }
        let pred;
        const xi = i - xBase;
        switch (order) {
          case 0: pred = 0; break;
          case 1: pred = x[xi - 1]; break;
          case 2: pred = 2 * x[xi - 1] - x[xi - 2]; break;
          case 3: pred = 3 * x[xi - 1] - 3 * x[xi - 2] + x[xi - 3]; break;
        }
        x[xi] = residualsChunk[i - globalStartSample] + pred;
      }
    }
  }


  // ---------- Bit writer / reader ----------

  function BitWriter() {
    this.bytes = [];
    this.cur = 0;
    this.nbits = 0;
  }
  BitWriter.prototype.writeBits = function (value, n) {
    // writes n bits (0<=n<=24 per call is safe), MSB-first within the stream
    for (let i = n - 1; i >= 0; i--) {
      this.cur = (this.cur << 1) | ((value >>> i) & 1);
      this.nbits++;
      if (this.nbits === 8) { this.bytes.push(this.cur & 0xFF); this.cur = 0; this.nbits = 0; }
    }
  };
  BitWriter.prototype.finish = function () {
    if (this.nbits > 0) { this.cur = this.cur << (8 - this.nbits); this.bytes.push(this.cur & 0xFF); this.cur = 0; this.nbits = 0; }
    return new Uint8Array(this.bytes);
  };

  function BitReader(bytes) {
    this.bytes = bytes;
    this.pos = 0;
    this.bitpos = 0;
  }
  BitReader.prototype.readBits = function (n) {
    let v = 0;
    for (let i = 0; i < n; i++) {
      const byte = this.bytes[this.pos];
      const bit = (byte >> (7 - this.bitpos)) & 1;
      v = (v << 1) | bit;
      this.bitpos++;
      if (this.bitpos === 8) { this.bitpos = 0; this.pos++; }
    }
    return v >>> 0;
  };

  // ---------- Rice-parameter residual splitting + rANS on the quotient ----------
  // Previous approach (bit-length bucket + raw remainder) wasted most of its size on
  // "raw" bits that weren't actually uniformly distributed. This instead picks a
  // per-block Rice parameter k (same idea FLAC uses) so the k low bits genuinely are
  // close to uniform, and only THOSE are stored raw — while the quotient (which FLAC
  // would unary-code) is entropy-coded with rANS instead, using its real measured
  // distribution rather than assuming a fixed geometric shape.

  const QUOT_MAX = 40; // quotient values >= this become an escape (rare outliers)
  const ALPHABET_SIZE = QUOT_MAX + 2; // 0..QUOT_MAX-1 normal, QUOT_MAX = escape symbol

  function zigzagArray(residuals) {
    const n = residuals.length;
    const u = new Float64Array(n); // residual can exceed 32-bit after zigzag in pathological cases; keep headroom
    for (let i = 0; i < n; i++) { const r = residuals[i]; u[i] = r >= 0 ? r * 2 : (-r * 2 - 1); }
    return u;
  }

  function costForK(uSlice, k) {
    let cost = 0;
    const div = Math.pow(2, k);
    for (let i = 0; i < uSlice.length; i++) {
      const q = Math.floor(uSlice[i] / div);
      cost += Math.min(q, QUOT_MAX) + 1 + k;
    }
    return cost;
  }

  function chooseRiceK(uSlice) {
    if (uSlice.length === 0) return 0;
    let sum = 0;
    for (let i = 0; i < uSlice.length; i++) sum += uSlice[i];
    const mean = sum / uSlice.length;
    if (mean < 1) return 0;
    let k0 = Math.max(0, Math.round(Math.log2(mean)));
    let bestK = k0, bestCost = costForK(uSlice, k0);
    for (const kk of [k0 - 1, k0 + 1, k0 - 2, k0 + 2]) {
      if (kk < 0) continue;
      const c = costForK(uSlice, kk);
      if (c < bestCost) { bestCost = c; bestK = kk; }
    }
    return bestK;
  }

  function bitLengthOf(u) {
    if (u <= 0) return 0;
    let b = 0, t = u;
    while (t >= 1) { t = Math.floor(t / 2); b++; }
    return b;
  }
  function writeEscape(bw, u) {
    const bitLen = bitLengthOf(u);
    bw.writeBits(bitLen, 6); // up to 63 bits representable — plenty of headroom
    if (bitLen > 16) { bw.writeBits(Math.floor(u / 65536), bitLen - 16); bw.writeBits(u & 0xFFFF, 16); }
    else if (bitLen > 0) bw.writeBits(u, bitLen);
  }
  function readEscape(br) {
    const bitLen = br.readBits(6);
    if (bitLen === 0) return 0;
    if (bitLen > 16) { const hi = br.readBits(bitLen - 16), lo = br.readBits(16); return hi * 65536 + lo; }
    return br.readBits(bitLen);
  }

  function riceSplitChannel(residuals, blockStarts) {
    const n = residuals.length;
    const u = zigzagArray(residuals);
    const numBlocks = blockStarts.length;
    const riceKs = new Uint8Array(numBlocks);
    const symbols = new Uint8Array(n);
    const bw = new BitWriter();

    for (let b = 0; b < numBlocks; b++) {
      const start = blockStarts[b];
      const end = b + 1 < numBlocks ? blockStarts[b + 1] : n;
      const k = chooseRiceK(u.subarray(start, end));
      riceKs[b] = k;
      const div = Math.pow(2, k);
      for (let i = start; i < end; i++) {
        const q = Math.floor(u[i] / div);
        if (q >= QUOT_MAX) {
          symbols[i] = QUOT_MAX;
          writeEscape(bw, u[i]);
        } else {
          symbols[i] = q;
          if (k > 0) {
            const rem = u[i] - q * div;
            if (k > 24) { bw.writeBits(Math.floor(rem / 65536), k - 16); bw.writeBits(rem & 0xFFFF, 16); }
            else bw.writeBits(rem, k);
          }
        }
      }
    }
    return { symbols, riceKs, extraBytes: bw.finish() };
  }

  function riceJoinChannel(symbols, riceKs, blockStarts, extraBytes, n) {
    const br = new BitReader(extraBytes);
    const residuals = new Float64Array(n); // not Int32Array — LMS-domain residuals can exceed 32-bit range in extreme cases
    const numBlocks = blockStarts.length;
    for (let b = 0; b < numBlocks; b++) {
      const start = blockStarts[b];
      const end = b + 1 < numBlocks ? blockStarts[b + 1] : n;
      const k = riceKs[b];
      const div = Math.pow(2, k);
      for (let i = start; i < end; i++) {
        const sym = symbols[i];
        let u;
        if (sym === QUOT_MAX) {
          u = readEscape(br);
        } else {
          let rem = 0;
          if (k > 0) {
            if (k > 24) { const hi = br.readBits(k - 16), lo = br.readBits(16); rem = hi * 65536 + lo; }
            else rem = br.readBits(k);
          }
          u = sym * div + rem;
        }
        residuals[i] = (u % 2 === 1) ? -((u + 1) / 2) : (u / 2);
      }
    }
    return residuals;
  }

  // ---------- Resumable rice-join (streaming path) ----------
  // Ties together a resumable rANS state and a persistent BitReader (the latter is
  // already naturally resumable — it's a stateful object with its own pos/bitpos — so
  // this just needs to not recreate it each call) to reconstruct one chunk's worth of
  // residuals at a time.
  function riceJoinChannelChunk(ransState, riceKsChunk, blockStarts, startBlockIdx, endBlockIdx, extraBitReader, n) {
    const rangeStart = blockStarts[startBlockIdx];
    const rangeEnd = endBlockIdx < blockStarts.length ? blockStarts[endBlockIdx] : n;
    const rangeLen = rangeEnd - rangeStart;
    const symbols = ransDecodeSymbols(ransState, rangeLen);
    const residuals = new Float64Array(rangeLen);
    let blockIdx = 0;
    for (let b = startBlockIdx; b < endBlockIdx; b++) {
      const start = blockStarts[b];
      const end = b + 1 < blockStarts.length ? blockStarts[b + 1] : n;
      const k = riceKsChunk[blockIdx++];
      const div = Math.pow(2, k);
      for (let i = start; i < end; i++) {
        const localIdx = i - rangeStart;
        const sym = symbols[localIdx];
        let u;
        if (sym === QUOT_MAX) {
          u = readEscape(extraBitReader);
        } else {
          let rem = 0;
          if (k > 0) {
            if (k > 24) { const hi = extraBitReader.readBits(k - 16), lo = extraBitReader.readBits(16); rem = hi * 65536 + lo; }
            else rem = extraBitReader.readBits(k);
          }
          u = sym * div + rem;
        }
        residuals[localIdx] = (u % 2 === 1) ? -((u + 1) / 2) : (u / 2);
      }
    }
    return residuals;
  }

  function blockStartsFor(n) {
    const starts = [];
    for (let s = 0; s < n; s += BLOCK) starts.push(s);
    if (starts.length === 0) starts.push(0);
    return starts;
  }

  // ---------- Static rANS (byte-alphabet, 32-bit state) ----------
  // Encodes a stream of small-alphabet symbols (bucket indices, 0..~32) using
  // their measured frequencies instead of assuming a fixed geometric shape (Rice).

  const RANS_L = 1 << 16; // lower bound of normalization interval
  const PROB_BITS = 14;
  const PROB_SCALE = 1 << PROB_BITS;

  function buildFreqTable(symbols, alphabetSize) {
    const freq = new Uint32Array(alphabetSize);
    for (let i = 0; i < symbols.length; i++) freq[symbols[i]]++;
    // normalize to sum exactly PROB_SCALE, every used symbol gets >=1
    const total = symbols.length || 1;
    const norm = new Uint32Array(alphabetSize);
    let sum = 0;
    for (let s = 0; s < alphabetSize; s++) {
      if (freq[s] === 0) { norm[s] = 0; continue; }
      let f = Math.round(freq[s] * PROB_SCALE / total);
      if (f === 0) f = 1;
      norm[s] = f;
      sum += f;
    }
    // fix rounding so sum === PROB_SCALE exactly
    let diff = PROB_SCALE - sum;
    // adjust the largest-frequency symbol(s) to absorb the difference
    while (diff !== 0) {
      let idx = -1, best = -1;
      for (let s = 0; s < alphabetSize; s++) if (norm[s] > best) { best = norm[s]; idx = s; }
      if (diff > 0) { norm[idx]++; diff--; }
      else { if (norm[idx] > 1) { norm[idx]--; diff++; } else break; }
    }
    const cum = new Uint32Array(alphabetSize + 1);
    for (let s = 0; s < alphabetSize; s++) cum[s + 1] = cum[s] + norm[s];
    return { freq: norm, cum };
  }

  function ransEncode(symbols, table) {
    const { freq, cum } = table;
    let x = RANS_L;
    const outBytes = [];
    // encode in reverse; rANS is a stack machine
    for (let i = symbols.length - 1; i >= 0; i--) {
      const s = symbols[i];
      const f = freq[s], c = cum[s];
      const xMax = ((RANS_L >>> PROB_BITS) << 8) * f; // renorm threshold (byte-wise renorm)
      while (x >= xMax) { outBytes.push(x & 0xFF); x = Math.floor(x / 256); }
      x = Math.floor(x / f) * PROB_SCALE + (x % f) + c;
    }
    outBytes.push(x & 0xFF, (x >>> 8) & 0xFF, (x >>> 16) & 0xFF, (x >>> 24) & 0xFF);
    outBytes.reverse();
    return new Uint8Array(outBytes);
  }

  function ransDecode(bytes, table, count) {
    const { freq, cum } = table;
    let pos = 0;
    function nextByte() { return bytes[pos++]; }
    let x = nextByte() << 24 | nextByte() << 16 | nextByte() << 8 | nextByte();
    x = x >>> 0;
    // build symbol lookup by cumulative freq
    const alphabetSize = freq.length;
    const slot2sym = new Uint8Array(PROB_SCALE);
    for (let s = 0; s < alphabetSize; s++) for (let j = cum[s]; j < cum[s] + freq[s]; j++) slot2sym[j] = s;

    const out = new Uint8Array(count);
    for (let i = 0; i < count; i++) {
      const slot = x & (PROB_SCALE - 1);
      const s = slot2sym[slot];
      const f = freq[s], c = cum[s];
      x = f * (x >>> PROB_BITS) + slot - c;
      while (x < RANS_L) { x = (x * 256) + nextByte(); }
      out[i] = s;
    }
    return out;
  }

  // ---------- Resumable rANS decoding (streaming path) ----------
  // Deliberately separate from ransDecode above rather than refactored from it — this
  // touches core, already-proven decode state machinery, so any bug here is isolated
  // from the existing decode() path rather than risking a regression in it.
  function ransDecoderInit(bytes, table) {
    const { freq, cum } = table;
    let pos = 0;
    let x = bytes[pos++] << 24 | bytes[pos++] << 16 | bytes[pos++] << 8 | bytes[pos++];
    x = x >>> 0;
    const alphabetSize = freq.length;
    const slot2sym = new Uint8Array(PROB_SCALE);
    for (let s = 0; s < alphabetSize; s++) for (let j = cum[s]; j < cum[s] + freq[s]; j++) slot2sym[j] = s;
    return { bytes, pos, x, freq, cum, slot2sym };
  }
  function ransDecodeSymbols(state, count) {
    const out = new Uint8Array(count);
    const bytes = state.bytes, slot2sym = state.slot2sym, freq = state.freq, cum = state.cum;
    let pos = state.pos, x = state.x;
    for (let i = 0; i < count; i++) {
      const slot = x & (PROB_SCALE - 1);
      const s = slot2sym[slot];
      const f = freq[s], c = cum[s];
      x = f * (x >>> PROB_BITS) + slot - c;
      while (x < RANS_L) { x = (x * 256) + bytes[pos++]; }
      out[i] = s;
    }
    state.pos = pos; state.x = x;
    return out;
  }

  // ---------- Container format ----------
  // MAGIC(4) VER(1) sampleRate(4) numChannels(1) bitsPerSample(1) numFrames(4)
  // metaLen(4) metaBytes(metaLen, UTF-8 JSON)
  // per output-channel: numBlocks(4) orders(numBlocks bytes)
  //                      alphabetSize(1) freqTable(alphabetSize * 2 bytes, uint16)
  //                      ransLen(4) ransBytes(ransLen)
  //                      extraBitsLen(4) extraBitsBytes(extraBitsLen)

  const MAGIC = 0x4E4F5641; // 'NOVA'

  function packBits(bits) {
    const nBytes = Math.ceil(bits.length / 8);
    const out = new Uint8Array(nBytes);
    for (let i = 0; i < bits.length; i++) if (bits[i]) out[i >> 3] |= (1 << (i & 7));
    return out;
  }
  function unpackBits(bytes, count) {
    const out = new Array(count);
    for (let i = 0; i < count; i++) out[i] = (bytes[i >> 3] >> (i & 7)) & 1;
    return out;
  }

  // metadata: { tags: {...}, picture: {mime, data:Uint8Array} | null }
  // If omitted, falls back to wav.metadata (whatever was auto-extracted from the source WAV).
  function encode(wav, metadata, onProgress, options) {
    const highCompression = !!(options && options.highCompression);
    metadata = metadata || wav.metadata || { tags: {}, picture: null };
    const tags = metadata.tags || {};
    const picture = metadata.picture || null;
    const { result: crossed, flags: crossFlags } = crossChannelForward(wav.channels);
    const crossFlagBytes = packBits(crossFlags);
    const metaJson = JSON.stringify(tags);
    const metaBytes = new TextEncoder().encode(metaJson);
    const mimeBytes = picture ? new TextEncoder().encode(picture.mime || 'image/jpeg') : new Uint8Array(0);
    const picBytes = picture ? picture.data : new Uint8Array(0);

    // Phase 1: process every channel, collecting per-channel byte blocks + the LMS mode
    // each one settled on. The main header (written next) needs to include the mode
    // bytes, so we can't stream channel bodies out until this pass is done.
    let totalPredicted = 0, totalRans = 0, totalExtra = 0;
    const lmsModes = [];
    const channelBlocks = [];
    const channelByteLengths = []; // total bytes each channel's [header+lpc+rans+extra] occupies — needed to compute the index table below

    for (let c = 0; c < crossed.length; c++) {
      const { residuals, orders, lpcParams } = predictChannelForward(crossed[c], onProgress ? (frac) => {
        // LPC/prediction phase gets roughly the first 70% of this channel's share of
        // the progress bar; the remaining 30% covers the LMS cascade + entropy coding
        // phase that follows, reported (coarsely, but only once, at the end) below.
        onProgress(((c + frac * 0.7) / crossed.length) * 0.95);
      } : null);
      // High-compression candidates are now cleanly split by channel count, not both
      // tried for everything: mode 3 (the 128-order cascade) is multichannel's
      // candidate, mode 4 (the deeper 192/96/8/16 cascade) is stereo/mono's. Previously
      // both were tried for stereo, which cost real encode time for a comparison that
      // mode 4 won every time it was tested (its first two stages alone are already
      // larger than mode 3's single stage) — removing the redundant try speeds up
      // stereo high-compression encoding without giving up any compression in practice.
      const { refined, mode } = lmsCascadeForwardAdaptive(residuals, highCompression && crossed.length > 2, highCompression && crossed.length <= 2);
      lmsModes.push(mode);
      const blockStarts = blockStartsFor(refined.length);
      const { symbols, riceKs, extraBytes } = riceSplitChannel(refined, blockStarts);
      const table = buildFreqTable(symbols, ALPHABET_SIZE);
      const ransBytes = ransEncode(symbols, table);

      const lpcBuf = new ArrayBuffer(lpcParams.length * (1 + LPC_ORDER * 2));
      const lpcDv = new DataView(lpcBuf);
      let lp = 0;
      for (const params of lpcParams) {
        lpcDv.setUint8(lp, params.shift); lp += 1;
        for (let j = 0; j < LPC_ORDER; j++) { lpcDv.setInt16(lp, params.qcoeffs[j], true); lp += 2; }
      }
      const lpcBytes = new Uint8Array(lpcBuf);

      const chHeader = new ArrayBuffer(4 + orders.length + riceKs.length + 4 + 1 + ALPHABET_SIZE * 2 + 4 + 4);
      const cdv = new DataView(chHeader);
      let cp = 0;
      cdv.setUint32(cp, orders.length, true); cp += 4;
      for (let i = 0; i < orders.length; i++) { cdv.setUint8(cp, orders[i]); cp += 1; }
      for (let i = 0; i < riceKs.length; i++) { cdv.setUint8(cp, riceKs[i]); cp += 1; }
      cdv.setUint32(cp, lpcBytes.length, true); cp += 4;
      cdv.setUint8(cp, ALPHABET_SIZE); cp += 1;
      for (let s = 0; s < ALPHABET_SIZE; s++) { cdv.setUint16(cp, table.freq[s], true); cp += 2; }
      cdv.setUint32(cp, ransBytes.length, true); cp += 4;
      cdv.setUint32(cp, extraBytes.length, true); cp += 4;

      channelBlocks.push(new Uint8Array(chHeader), lpcBytes, ransBytes, extraBytes);
      channelByteLengths.push(chHeader.byteLength + lpcBytes.length + ransBytes.length + extraBytes.length);
      totalPredicted += residuals.length;
      totalRans += ransBytes.length;
      totalExtra += extraBytes.length;
      // Per-channel processing (LPC + LMS cascade + entropy coding) is by far the
      // dominant cost — reserve the last 5% for final assembly/header writing below,
      // which is comparatively instant.
      if (onProgress) onProgress((c + 1) / crossed.length * 0.95);
    }

    // Phase 2: now write the main header (mode bytes + cross-channel flags are known) and assemble.
    const parts = [];
    const indexTableSize = wav.numChannels * 4; // 4 bytes per channel: absolute file offset of that channel's header
    const header = new ArrayBuffer(4 + 1 + 4 + 1 + 1 + 4 + 4 + 1 + 4 + 1 + crossFlagBytes.length + wav.numChannels + indexTableSize);
    const hdv = new DataView(header);
    let p = 0;
    hdv.setUint32(p, MAGIC, false); p += 4;
    hdv.setUint8(p, 8); p += 1; // version 8: adds a per-channel byte-offset index table right after the
    // main header, so a network-aware decoder can locate ANY channel's header with one
    // targeted fetch instead of having to download everything before it (channels are
    // stored fully sequentially in the file, so without this index, reaching channel 7's
    // header requires having already fetched channels 0-6's ENTIRE content — discovered
    // via testing, not assumed; see the network streaming decoder for how this gets used).
    hdv.setUint32(p, wav.sampleRate, true); p += 4;
    hdv.setUint8(p, wav.numChannels); p += 1;
    hdv.setUint8(p, wav.bitsPerSample); p += 1;
    hdv.setUint32(p, wav.numFrames, true); p += 4;
    hdv.setUint32(p, metaBytes.length, true); p += 4;
    hdv.setUint8(p, mimeBytes.length); p += 1;
    hdv.setUint32(p, picBytes.length, true); p += 4;
    hdv.setUint8(p, crossFlagBytes.length); p += 1;
    for (let i = 0; i < crossFlagBytes.length; i++) { hdv.setUint8(p, crossFlagBytes[i]); p += 1; }
    for (let i = 0; i < lmsModes.length; i++) { hdv.setUint8(p, lmsModes[i]); p += 1; }
    // Index table: now that the full header size (including this table itself) and
    // metadata/artwork sizes are known, compute each channel's absolute file offset.
    const channelDataStart = header.byteLength + metaBytes.length + mimeBytes.length + picBytes.length;
    let channelCursor = channelDataStart;
    for (let c = 0; c < wav.numChannels; c++) {
      hdv.setUint32(p, channelCursor, true); p += 4;
      channelCursor += channelByteLengths[c];
    }
    parts.push(new Uint8Array(header), metaBytes, mimeBytes, picBytes);
    for (const block of channelBlocks) parts.push(block);

    // concat
    let total = 0;
    for (const p2 of parts) total += p2.length;
    const out = new Uint8Array(total);
    let off = 0;
    for (const p2 of parts) { out.set(p2, off); off += p2.length; }

    if (onProgress) onProgress(1);
    return { buffer: out, stats: { totalPredicted, totalRans, totalExtra } };
  }

  // Lightweight header-only reader: stops right after tags/artwork, never touches the
  // per-channel audio blocks (which are what actually costs the 10s-30s+ full decode()
  // takes). Essential for a library view — listing N tracks can't afford to fully decode
  // each one just to show a title and thumbnail.
  function readMetadata(bytes) {
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let p = 0;
    const magic = dv.getUint32(p, false); p += 4;
    if (magic !== MAGIC) throw new Error('Bad magic / not a NOVA file');
    const version = dv.getUint8(p); p += 1;
    const sampleRate = dv.getUint32(p, true); p += 4;
    const numChannels = dv.getUint8(p); p += 1;
    const bitsPerSample = dv.getUint8(p); p += 1;
    const numFrames = dv.getUint32(p, true); p += 4;
    const metaLen = dv.getUint32(p, true); p += 4;
    let mimeLen = 0, picLen = 0;
    if (version >= 2) {
      mimeLen = dv.getUint8(p); p += 1;
      picLen = dv.getUint32(p, true); p += 4;
    }
    let lmsModes = new Array(numChannels).fill(0);
    if (version >= 7) {
      const crossFlagByteLen = dv.getUint8(p); p += 1;
      p += crossFlagByteLen;
      for (let c = 0; c < numChannels; c++) { lmsModes[c] = dv.getUint8(p); p += 1; } // mode 3 = the larger, slower-decoding filter stage
    }
    if (version >= 8) { p += numChannels * 4; } // per-channel byte-offset index table — not needed here, just skip past it
    const metaBytes = bytes.subarray(p, p + metaLen); p += metaLen;
    const tags = metaLen > 0 ? JSON.parse(new TextDecoder().decode(metaBytes)) : {};
    let picture = null;
    if (mimeLen > 0) {
      const mime = new TextDecoder('latin1').decode(bytes.subarray(p, p + mimeLen)); p += mimeLen;
      const data = bytes.subarray(p, p + picLen).slice();
      picture = { mime, data };
    }
    return {
      sampleRate, numChannels, bitsPerSample, numFrames,
      durationSeconds: numFrames / sampleRate,
      tags, picture,
      // Whether any channel used the larger, slower-decoding adaptive filter stage
      // (roughly 1-1.5% smaller files, but measured at ~3.5x slower decode) — lets a
      // player warn about slower decode, or a library view show which files were
      // encoded which way, without needing a full decode to find out.
      usesHighCompression: lmsModes.some(m => m === 3 || m === 4),
    };
  }

  function decode(bytes) {
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let p = 0;
    const magic = dv.getUint32(p, false); p += 4;
    if (magic !== MAGIC) throw new Error('Bad magic / not a NOVA file');
    const version = dv.getUint8(p); p += 1;
    const sampleRate = dv.getUint32(p, true); p += 4;
    const numChannels = dv.getUint8(p); p += 1;
    const bitsPerSample = dv.getUint8(p); p += 1;
    const numFrames = dv.getUint32(p, true); p += 4;
    const metaLen = dv.getUint32(p, true); p += 4;
    let mimeLen = 0, picLen = 0;
    if (version >= 2) {
      mimeLen = dv.getUint8(p); p += 1;
      picLen = dv.getUint32(p, true); p += 4;
    }
    let crossFlags = [];
    let lmsModes = new Array(numChannels).fill(0);
    if (version >= 7) {
      const crossFlagByteLen = dv.getUint8(p); p += 1;
      const crossFlagBytes = bytes.subarray(p, p + crossFlagByteLen); p += crossFlagByteLen;
      crossFlags = unpackBits(crossFlagBytes, Math.max(0, numChannels - 1));
      lmsModes = [];
      for (let i = 0; i < numChannels; i++) { lmsModes.push(dv.getUint8(p)); p += 1; }
    }
    if (version >= 8) { p += numChannels * 4; } // per-channel byte-offset index table — not used on this read path, just skip past it
    // Header (including the embedded cross-channel flags / LMS modes) is now fully consumed —
    // only now do we pull the actual meta/artwork content, matching the order encode wrote it in.
    const metaBytes = bytes.subarray(p, p + metaLen); p += metaLen;
    const tags = metaLen > 0 ? JSON.parse(new TextDecoder().decode(metaBytes)) : {};
    let picture = null;
    if (mimeLen > 0) {
      const mime = new TextDecoder('latin1').decode(bytes.subarray(p, p + mimeLen)); p += mimeLen;
      const data = bytes.subarray(p, p + picLen).slice(); p += picLen;
      picture = { mime, data };
    }
    const metadata = { tags, picture };

    const crossed = [];
    for (let c = 0; c < numChannels; c++) {
      const numBlocks = dv.getUint32(p, true); p += 4;
      const orders = new Uint8Array(numBlocks);
      for (let i = 0; i < numBlocks; i++) { orders[i] = dv.getUint8(p); p += 1; }
      const riceKs = new Uint8Array(numBlocks);
      for (let i = 0; i < numBlocks; i++) { riceKs[i] = dv.getUint8(p); p += 1; }
      const lpcBytesLen = dv.getUint32(p, true); p += 4;
      const alphabetSize = dv.getUint8(p); p += 1;
      const freq = new Uint32Array(alphabetSize);
      for (let s = 0; s < alphabetSize; s++) { freq[s] = dv.getUint16(p, true); p += 2; }
      const cum = new Uint32Array(alphabetSize + 1);
      for (let s = 0; s < alphabetSize; s++) cum[s + 1] = cum[s] + freq[s];
      const ransLen = dv.getUint32(p, true); p += 4;
      const extraLen = dv.getUint32(p, true); p += 4;
      // header finished — now pull the actual content chunks, in the order they were written
      const lpcBytes = bytes.subarray(p, p + lpcBytesLen); p += lpcBytesLen;
      const ransBytes = bytes.subarray(p, p + ransLen); p += ransLen;
      const extraBytes = bytes.subarray(p, p + extraLen); p += extraLen;

      const lpcDv = new DataView(lpcBytes.buffer, lpcBytes.byteOffset, lpcBytes.byteLength);
      const lpcParams = [];
      let lp = 0;
      while (lp < lpcBytes.length) {
        const shift = lpcDv.getUint8(lp); lp += 1;
        const qcoeffs = new Int32Array(LPC_ORDER);
        for (let j = 0; j < LPC_ORDER; j++) { qcoeffs[j] = lpcDv.getInt16(lp, true); lp += 2; }
        lpcParams.push({ shift, qcoeffs });
      }

      const symbols = ransDecode(ransBytes, { freq, cum }, numFrames);
      const blockStarts = blockStartsFor(numFrames);
      const residualsRefined = riceJoinChannel(symbols, riceKs, blockStarts, extraBytes, numFrames);
      const residuals = lmsCascadeInverseAdaptive(residualsRefined, lmsModes[c]);
      const ch = predictChannelInverse(residuals, orders, lpcParams, numFrames);
      crossed.push(ch);
    }

    const channels = crossChannelInverse(crossed, crossFlags);
    return { sampleRate, numChannels, bitsPerSample, numFrames, channels, metadata };
  }

  // ---------- Streaming decoder (progressive decode-and-play) ----------
  // Parses the header once (duplicated from decode() rather than shared with it, so a
  // bug here can't touch the already-proven one-shot path), then exposes
  // decodeNextChunk(numBlocks) which can be called repeatedly to get successive PCM
  // chunks — each call advances every channel's rANS/BitReader/LMS/predictor state by
  // exactly that many blocks, using only the resumable primitives verified above.
  function createStreamingDecoder(bytes, opts) {
    opts = opts || {};
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let p = 0;
    const magic = dv.getUint32(p, false); p += 4;
    if (magic !== MAGIC) throw new Error('Bad magic / not a NOVA file');
    const version = dv.getUint8(p); p += 1;
    const sampleRate = dv.getUint32(p, true); p += 4;
    const numChannels = dv.getUint8(p); p += 1;
    const bitsPerSample = dv.getUint8(p); p += 1;
    const numFrames = dv.getUint32(p, true); p += 4;
    const metaLen = dv.getUint32(p, true); p += 4;
    let mimeLen = 0, picLen = 0;
    if (version >= 2) {
      mimeLen = dv.getUint8(p); p += 1;
      picLen = dv.getUint32(p, true); p += 4;
    }
    let crossFlags = [];
    let lmsModes = new Array(numChannels).fill(0);
    if (version >= 7) {
      const crossFlagByteLen = dv.getUint8(p); p += 1;
      const crossFlagBytes = bytes.subarray(p, p + crossFlagByteLen); p += crossFlagByteLen;
      crossFlags = unpackBits(crossFlagBytes, Math.max(0, numChannels - 1));
      lmsModes = [];
      for (let i = 0; i < numChannels; i++) { lmsModes.push(dv.getUint8(p)); p += 1; }
    }
    if (version >= 8) { p += numChannels * 4; } // per-channel byte-offset index table — not used on this read path, just skip past it
    const metaBytes = bytes.subarray(p, p + metaLen); p += metaLen;
    const tags = metaLen > 0 ? JSON.parse(new TextDecoder().decode(metaBytes)) : {};
    let picture = null;
    if (mimeLen > 0) {
      const mime = new TextDecoder('latin1').decode(bytes.subarray(p, p + mimeLen)); p += mimeLen;
      const data = bytes.subarray(p, p + picLen).slice(); p += picLen;
      picture = { mime, data };
    }
    const metadata = { tags, picture };

    const blockStarts = blockStartsFor(numFrames);
    const numBlocksTotal = blockStarts.length;

    // Per-channel setup: parse each channel's header/content exactly like decode() does,
    // but instead of fully decoding, set up resumable state for each stage.
    const channelState = [];
    for (let c = 0; c < numChannels; c++) {
      const numBlocks = dv.getUint32(p, true); p += 4;
      const orders = new Uint8Array(numBlocks);
      for (let i = 0; i < numBlocks; i++) { orders[i] = dv.getUint8(p); p += 1; }
      const riceKs = new Uint8Array(numBlocks);
      for (let i = 0; i < numBlocks; i++) { riceKs[i] = dv.getUint8(p); p += 1; }
      const lpcBytesLen = dv.getUint32(p, true); p += 4;
      const alphabetSize = dv.getUint8(p); p += 1;
      const freq = new Uint32Array(alphabetSize);
      for (let s = 0; s < alphabetSize; s++) { freq[s] = dv.getUint16(p, true); p += 2; }
      const cum = new Uint32Array(alphabetSize + 1);
      for (let s = 0; s < alphabetSize; s++) cum[s + 1] = cum[s] + freq[s];
      const ransLen = dv.getUint32(p, true); p += 4;
      const extraLen = dv.getUint32(p, true); p += 4;
      const lpcBytes = bytes.subarray(p, p + lpcBytesLen); p += lpcBytesLen;
      const ransBytes = bytes.subarray(p, p + ransLen); p += ransLen;
      const extraBytes = bytes.subarray(p, p + extraLen); p += extraLen;

      const lpcDv = new DataView(lpcBytes.buffer, lpcBytes.byteOffset, lpcBytes.byteLength);
      const lpcParams = [];
      let lp = 0;
      while (lp < lpcBytes.length) {
        const shift = lpcDv.getUint8(lp); lp += 1;
        const qcoeffs = new Int32Array(LPC_ORDER);
        for (let j = 0; j < LPC_ORDER; j++) { qcoeffs[j] = lpcDv.getInt16(lp, true); lp += 2; }
        lpcParams.push({ shift, qcoeffs });
      }

      channelState.push({
        orders, riceKs, lpcParams,
        ransState: ransDecoderInit(ransBytes, { freq, cum }),
        extraBitReader: new BitReader(extraBytes),
        lmsMode: lmsModes[c],
        lmsState: lmsCascadeInverseChunkInit(lmsModes[c]),
        lpcState: predictChannelInverseChunkInit(),
        // Real, direct fix: this was `new Int32Array(numFrames)` — one FULL-LENGTH array per
        // channel, kept for the whole decode. For an 8-channel, 6-minute track that is ~527 MB
        // of decoded samples per live decode request, before anything else; measured against
        // a realistic 7.1 track, one deep-skip request cost +517 MB and three overlapping ones
        // +1.2 GB — and first play of a track always overlaps several. The predictors only ever
        // look back a few samples (LPC_ORDER is 8), so only a short window is kept: x[k] holds
        // global sample xBase + k, and decodeNextChunk slides it forward. Output is verified
        // bit-identical to the full-length version.
        x: new Int32Array(Math.min(numFrames, 30 * BLOCK + STREAM_HISTORY)), xBase: 0,
        nextBlockIdx: 0,
      });
    }

    let nextBlockIdx = 0; // shared across channels — every channel advances in lockstep

    // ---- Checkpoints: decode from the middle without decoding what comes before ----
    // The decoder is a state machine whose whole state is small and sits at a block boundary between chunks:
    // per channel the rANS position and state, the extra-bits reader position, the LPC parameter index, every
    // LMS stage's weights/history/position, and the last few decoded samples the predictors look back into.
    // snapshot() copies it; opts.resume puts it back. A resumed decode produces exactly the samples a full decode
    // would from that point (verified bit-for-bit in test/codec-checkpoints.test.js), so the file format is
    // unchanged and every existing .nova file keeps working.
    function snapshotLms(state) {
      if (!state) return null;
      const out = {};
      for (const k of Object.keys(state)) out[k] = { w: state[k].w.slice(), hist: state[k].hist.slice(), pos: state[k].pos };
      return out;
    }
    function snapshot() {
      const rangeStart = nextBlockIdx < numBlocksTotal ? blockStarts[nextBlockIdx] : numFrames;
      return {
        blockIdx: nextBlockIdx, startSample: rangeStart,
        channels: channelState.map((cs) => {
          const tailLen = Math.min(STREAM_HISTORY, rangeStart);
          const from = rangeStart - tailLen - cs.xBase;
          return {
            ransPos: cs.ransState.pos, ransX: cs.ransState.x, extraPos: cs.extraBitReader.pos, extraBit: cs.extraBitReader.bitpos,
            lpcIdx: cs.lpcState.lpcIdx, lms: snapshotLms(cs.lmsState),
            xTailStart: rangeStart - tailLen, xTail: cs.x.slice(from, from + tailLen),
          };
        }),
      };
    }
    if (opts.resume) {
      const snap = opts.resume;
      if (!snap.channels || snap.channels.length !== numChannels) throw new Error('checkpoint does not match this file');
      nextBlockIdx = snap.blockIdx;
      for (let c = 0; c < numChannels; c++) {
        const cs = channelState[c], sc = snap.channels[c];
        cs.ransState.pos = sc.ransPos; cs.ransState.x = sc.ransX;
        cs.extraBitReader.pos = sc.extraPos; cs.extraBitReader.bitpos = sc.extraBit;
        cs.lpcState.lpcIdx = sc.lpcIdx;
        if (sc.lms) for (const k of Object.keys(sc.lms)) { cs.lmsState[k].w.set(sc.lms[k].w); cs.lmsState[k].hist.set(sc.lms[k].hist); cs.lmsState[k].pos = sc.lms[k].pos; }
        cs.xBase = sc.xTailStart;
        cs.x.set(sc.xTail, 0);
      }
    }

    function decodeNextChunk(numBlocksPerChunk) {
      if (nextBlockIdx >= numBlocksTotal) return null; // already fully decoded
      const startBlockIdx = nextBlockIdx;
      const endBlockIdx = Math.min(startBlockIdx + numBlocksPerChunk, numBlocksTotal);
      const rangeStart = blockStarts[startBlockIdx];
      const rangeEnd = endBlockIdx < numBlocksTotal ? blockStarts[endBlockIdx] : numFrames;

      const crossedChunks = [];
      for (let c = 0; c < numChannels; c++) {
        const cs = channelState[c];
        const riceKsChunk = cs.riceKs.slice(startBlockIdx, endBlockIdx);
        const ordersChunk = cs.orders.slice(startBlockIdx, endBlockIdx);
        const refinedChunk = riceJoinChannelChunk(cs.ransState, riceKsChunk, blockStarts, startBlockIdx, endBlockIdx, cs.extraBitReader, numFrames);
        const residualsChunk = lmsCascadeInverseChunk(refinedChunk, cs.lmsMode, cs.lmsState);
        // Slide the window so it starts STREAM_HISTORY samples before this chunk (the
        // history the predictors read back into), and grow it if this chunk is larger
        // than anything seen so far.
        const windowStart = Math.max(0, rangeStart - STREAM_HISTORY);
        if (windowStart > cs.xBase) {
          cs.x.copyWithin(0, windowStart - cs.xBase, rangeStart - cs.xBase);
          cs.xBase = windowStart;
        }
        const neededLen = rangeEnd - cs.xBase;
        if (cs.x.length < neededLen) {
          const bigger = new Int32Array(neededLen);
          bigger.set(cs.x.subarray(0, rangeStart - cs.xBase));
          cs.x = bigger;
        }
        predictChannelInverseChunk(residualsChunk, ordersChunk, cs.lpcParams, cs.lpcState, cs.x, rangeStart, cs.xBase, numFrames);
        crossedChunks.push(cs.x.subarray(rangeStart - cs.xBase, rangeEnd - cs.xBase));
      }

      const decodedChunk = crossChannelInverse(crossedChunks, crossFlags);
      nextBlockIdx = endBlockIdx;
      return { channels: decodedChunk, startSample: rangeStart, endSample: rangeEnd, done: nextBlockIdx >= numBlocksTotal };
    }

    return {
      sampleRate, numChannels, bitsPerSample, numFrames, metadata,
      usesHighCompression: lmsModes.some(m => m === 3 || m === 4),
      decodeNextChunk, snapshot,
      nextBlockIndex: () => nextBlockIdx,
      isDone: () => nextBlockIdx >= numBlocksTotal,
    };
  }

  // ---------- Header-only structure parse (for progressive network fetch) ----------
  // Reads the main header, metadata/artwork, and every channel's SMALL per-block header
  // arrays (orders, riceKs, LPC params) and length fields — WITHOUT requiring the large
  // rANS/extra CONTENT bytes to be present. Computes each channel's exact byte offset
  // within the full file, so the caller can fetch just the portion of just the channels
  // actually needed for the next chunk, rather than the whole file upfront.
  //
  // If `bytes` doesn't extend far enough to complete this parse (e.g. artwork pushed the
  // channel headers further into the file than what's been fetched so far), returns
  // { needMoreBytes: true } instead of throwing, so the caller can fetch more and retry —
  // parsing this header structure is cheap, re-running it from scratch on a larger buffer
  // is not a meaningful cost.
  function parseFileStructure(bytes) {
    try {
      const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
      let p = 0;
      function need(n) { if (p + n > bytes.length) throw { needMoreBytes: true }; }
      need(4); const magic = dv.getUint32(p, false); p += 4;
      if (magic !== MAGIC) throw new Error('Bad magic / not a NOVA file');
      need(1); const version = dv.getUint8(p); p += 1;
      need(4); const sampleRate = dv.getUint32(p, true); p += 4;
      need(1); const numChannels = dv.getUint8(p); p += 1;
      need(1); const bitsPerSample = dv.getUint8(p); p += 1;
      need(4); const numFrames = dv.getUint32(p, true); p += 4;
      need(4); const metaLen = dv.getUint32(p, true); p += 4;
      let mimeLen = 0, picLen = 0;
      if (version >= 2) {
        need(1); mimeLen = dv.getUint8(p); p += 1;
        need(4); picLen = dv.getUint32(p, true); p += 4;
      }
      let crossFlags = [];
      let lmsModes = new Array(numChannels).fill(0);
      if (version >= 7) {
        need(1); const crossFlagByteLen = dv.getUint8(p); p += 1;
        need(crossFlagByteLen); const crossFlagBytes = bytes.subarray(p, p + crossFlagByteLen); p += crossFlagByteLen;
        crossFlags = unpackBits(crossFlagBytes, Math.max(0, numChannels - 1));
        lmsModes = [];
        need(numChannels);
        for (let i = 0; i < numChannels; i++) { lmsModes.push(dv.getUint8(p)); p += 1; }
      }
      let channelHeaderOffsets = null;
      if (version >= 8) {
        need(numChannels * 4);
        channelHeaderOffsets = [];
        for (let i = 0; i < numChannels; i++) { channelHeaderOffsets.push(dv.getUint32(p, true)); p += 4; }
      }
      need(metaLen); const metaBytes = bytes.subarray(p, p + metaLen); p += metaLen;
      const tags = metaLen > 0 ? JSON.parse(new TextDecoder().decode(metaBytes)) : {};
      let picture = null;
      if (mimeLen > 0) {
        need(mimeLen); const mime = new TextDecoder('latin1').decode(bytes.subarray(p, p + mimeLen)); p += mimeLen;
        need(picLen); const data = bytes.subarray(p, p + picLen).slice(); p += picLen;
        picture = { mime, data };
      }
      const metadata = { tags, picture };
      const blockStarts = blockStartsFor(numFrames);

      const channels = [];
      for (let c = 0; c < numChannels; c++) {
        need(4); const numBlocks = dv.getUint32(p, true); p += 4;
        need(numBlocks); const orders = bytes.subarray(p, p + numBlocks).slice(); p += numBlocks;
        need(numBlocks); const riceKs = bytes.subarray(p, p + numBlocks).slice(); p += numBlocks;
        need(4); const lpcBytesLen = dv.getUint32(p, true); p += 4;
        need(1); const alphabetSize = dv.getUint8(p); p += 1;
        need(alphabetSize * 2);
        const freq = new Uint32Array(alphabetSize);
        for (let s = 0; s < alphabetSize; s++) { freq[s] = dv.getUint16(p, true); p += 2; }
        const cum = new Uint32Array(alphabetSize + 1);
        for (let s = 0; s < alphabetSize; s++) cum[s + 1] = cum[s] + freq[s];
        need(4); const ransLen = dv.getUint32(p, true); p += 4;
        need(4); const extraLen = dv.getUint32(p, true); p += 4;
        // Content offsets computed here — content itself is NOT required to be present
        // in `bytes` for this parse to succeed; only the header fields above are.
        const lpcBytesOffset = p; p += lpcBytesLen;
        const ransBytesOffset = p; p += ransLen;
        const extraBytesOffset = p; p += extraLen;
        channels.push({
          numBlocks, orders, riceKs, alphabetSize, freq, cum,
          lpcBytesOffset, lpcBytesLen, ransBytesOffset, ransLen, extraBytesOffset, extraLen,
        });
      }

      return {
        sampleRate, numChannels, bitsPerSample, numFrames, metadata,
        crossFlags, lmsModes, blockStarts, channels,
        channelHeaderOffsets, hasIndex: channelHeaderOffsets !== null,
        headerEndOffset: p, // NOT "where channel 0's content starts" despite what an earlier
        // version of this comment claimed — by this point p has walked through EVERY
        // channel's header AND content, so this is actually close to end-of-file. Use
        // channelHeaderOffsets (when hasIndex is true) for the useful per-channel offsets.
      };
    } catch (e) {
      if (e && e.needMoreBytes) return { needMoreBytes: true };
      throw e;
    }
  }

  // ---------- Header-only structure parse (for progressive network fetch) ----------
  // parseFileStructure (above, in the OLDER v7-oriented design) walks every channel
  // sequentially, which — as testing revealed — requires having fetched nearly the whole
  // file to reach the LAST channel's header, since channels are stored fully sequentially.
  // For v8+ files (which carry a channel offset index), this lighter function reads ONLY
  // the main header/metadata/index — never attempting the sequential per-channel walk —
  // so it stays small and fast regardless of file size.
  function parseMainHeaderAndIndex(bytes) {
    try {
      const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
      let p = 0;
      function need(n) { if (p + n > bytes.length) throw { needMoreBytes: true }; }
      need(4); const magic = dv.getUint32(p, false); p += 4;
      if (magic !== MAGIC) throw new Error('Bad magic / not a NOVA file');
      need(1); const version = dv.getUint8(p); p += 1;
      need(4); const sampleRate = dv.getUint32(p, true); p += 4;
      need(1); const numChannels = dv.getUint8(p); p += 1;
      need(1); const bitsPerSample = dv.getUint8(p); p += 1;
      need(4); const numFrames = dv.getUint32(p, true); p += 4;
      need(4); const metaLen = dv.getUint32(p, true); p += 4;
      let mimeLen = 0, picLen = 0;
      if (version >= 2) {
        need(1); mimeLen = dv.getUint8(p); p += 1;
        need(4); picLen = dv.getUint32(p, true); p += 4;
      }
      let crossFlags = [];
      let lmsModes = new Array(numChannels).fill(0);
      if (version >= 7) {
        need(1); const crossFlagByteLen = dv.getUint8(p); p += 1;
        need(crossFlagByteLen); const crossFlagBytes = bytes.subarray(p, p + crossFlagByteLen); p += crossFlagByteLen;
        crossFlags = unpackBits(crossFlagBytes, Math.max(0, numChannels - 1));
        lmsModes = [];
        need(numChannels);
        for (let i = 0; i < numChannels; i++) { lmsModes.push(dv.getUint8(p)); p += 1; }
      }
      let channelHeaderOffsets = null;
      if (version >= 8) {
        need(numChannels * 4);
        channelHeaderOffsets = [];
        for (let i = 0; i < numChannels; i++) { channelHeaderOffsets.push(dv.getUint32(p, true)); p += 4; }
      }
      need(metaLen); const metaBytes = bytes.subarray(p, p + metaLen); p += metaLen;
      const tags = metaLen > 0 ? JSON.parse(new TextDecoder().decode(metaBytes)) : {};
      let picture = null;
      if (mimeLen > 0) {
        need(mimeLen); const mime = new TextDecoder('latin1').decode(bytes.subarray(p, p + mimeLen)); p += mimeLen;
        need(picLen); const data = bytes.subarray(p, p + picLen).slice(); p += picLen;
        picture = { mime, data };
      }
      const metadata = { tags, picture };
      return {
        version, sampleRate, numChannels, bitsPerSample, numFrames, metadata,
        crossFlags, lmsModes, blockStarts: blockStartsFor(numFrames),
        channelHeaderOffsets, hasIndex: channelHeaderOffsets !== null,
        channel0HeaderOffsetIfNoIndex: p, // only meaningful when hasIndex is false
      };
    } catch (e) {
      if (e && e.needMoreBytes) return { needMoreBytes: true };
      throw e;
    }
  }

  // Parses ONE channel's header fields starting at `localOffset` within `bytes` —
  // independently of any other channel. Offsets in the returned object are LOCAL to
  // `bytes` (relative to its start); the caller adds the channel's own absolute file
  // offset to get real file positions.
  function parseChannelHeaderAt(bytes, localOffset) {
    try {
      const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
      let p = localOffset;
      function need(n) { if (p + n > bytes.length) throw { needMoreBytes: true }; }
      need(4); const numBlocks = dv.getUint32(p, true); p += 4;
      need(numBlocks); const orders = bytes.subarray(p, p + numBlocks).slice(); p += numBlocks;
      need(numBlocks); const riceKs = bytes.subarray(p, p + numBlocks).slice(); p += numBlocks;
      need(4); const lpcBytesLen = dv.getUint32(p, true); p += 4;
      need(1); const alphabetSize = dv.getUint8(p); p += 1;
      need(alphabetSize * 2);
      const freq = new Uint32Array(alphabetSize);
      for (let s = 0; s < alphabetSize; s++) { freq[s] = dv.getUint16(p, true); p += 2; }
      const cum = new Uint32Array(alphabetSize + 1);
      for (let s = 0; s < alphabetSize; s++) cum[s + 1] = cum[s] + freq[s];
      need(4); const ransLen = dv.getUint32(p, true); p += 4;
      need(4); const extraLen = dv.getUint32(p, true); p += 4;
      const lpcBytesOffset = p;
      const ransBytesOffset = p + lpcBytesLen;
      const extraBytesOffset = ransBytesOffset + ransLen;
      return { numBlocks, orders, riceKs, alphabetSize, freq, cum, lpcBytesOffset, lpcBytesLen, ransBytesOffset, ransLen, extraBytesOffset, extraLen };
    } catch (e) {
      if (e && e.needMoreBytes) return { needMoreBytes: true };
      throw e;
    }
  }

  // ---------- Network-aware streaming decoder ----------
  // v8+ files (with the index table): fetch each channel's header independently and IN
  // PARALLEL using its known absolute offset, then fetch a generous per-channel head
  // start (also in parallel) — no channel depends on any other channel's data at all.
  // Pre-v8 files (no index): falls back to fetching the whole file and using the older
  // sequential parser — matches original, already-working behavior, just without the
  // speed win, since there's genuinely no way to locate later channels without it.
  async function createNetworkStreamingDecoder(fetchRangeAsync, opts) {
    opts = opts || {};
    const PROBE_SIZE = opts.probeSize || 512 * 1024;
    const CHANNEL_HEADER_PROBE = opts.channelHeaderProbe || 16 * 1024;
    // Asymmetric, not one shared size: real data (both actual tracks and synthetic
    // testing) shows the "extra bits" stream running several times larger than the
    // rANS-coded stream, so a single shared head-start size either starves rANS or wastes
    // bandwidth over-fetching it. Sized to comfortably clear the FIRST chunk's threshold
    // (defined below) with margin for a few more chunks — not the whole track; refills
    // that happen once playback has already started aren't a problem to avoid.
    const RANS_HEAD_START = opts.ransHeadStart || 250 * 1024;
    const EXTRA_HEAD_START = opts.extraHeadStart || 1000 * 1024;
    const REFILL_SIZE = opts.refillSize || 800 * 1024;

    let probeBytes = await fetchRangeAsync(0, PROBE_SIZE - 1);
    let main = parseMainHeaderAndIndex(probeBytes);
    while (main.needMoreBytes) {
      const more = await fetchRangeAsync(probeBytes.length, probeBytes.length + PROBE_SIZE - 1);
      if (more.length === 0) throw new Error('Could not parse NOVA header — file may be corrupt or truncated');
      const combined = new Uint8Array(probeBytes.length + more.length);
      combined.set(probeBytes, 0); combined.set(more, probeBytes.length);
      probeBytes = combined;
      main = parseMainHeaderAndIndex(probeBytes);
    }

    let channelHeaders;

    if (main.hasIndex) {
      const headerFetches = main.channelHeaderOffsets.map(async (absOffset) => {
        if (probeBytes.length > absOffset) {
          const already = parseChannelHeaderAt(probeBytes, absOffset);
          if (!already.needMoreBytes) return already;
        }
        let extended = await fetchRangeAsync(absOffset, absOffset + CHANNEL_HEADER_PROBE - 1);
        let parsed = parseChannelHeaderAt(extended, 0);
        while (parsed.needMoreBytes) {
          const more = await fetchRangeAsync(absOffset + extended.length, absOffset + extended.length + CHANNEL_HEADER_PROBE - 1);
          if (more.length === 0) throw new Error('Could not parse channel header — file may be corrupt or truncated');
          const combined = new Uint8Array(extended.length + more.length);
          combined.set(extended, 0); combined.set(more, extended.length);
          extended = combined;
          parsed = parseChannelHeaderAt(extended, 0);
        }
        // Convert offsets from "local to this channel's own probe" to absolute file offsets.
        return {
          ...parsed,
          lpcBytesOffset: absOffset + parsed.lpcBytesOffset,
          ransBytesOffset: absOffset + parsed.ransBytesOffset,
          extraBytesOffset: absOffset + parsed.extraBytesOffset,
        };
      });
      channelHeaders = await Promise.all(headerFetches);
    } else {
      let fullBytes = probeBytes;
      let structure = parseFileStructure(fullBytes);
      while (structure.needMoreBytes) {
        const more = await fetchRangeAsync(fullBytes.length, fullBytes.length + PROBE_SIZE * 4 - 1);
        if (more.length === 0) throw new Error('Could not parse NOVA file structure');
        const combined = new Uint8Array(fullBytes.length + more.length);
        combined.set(fullBytes, 0); combined.set(more, fullBytes.length);
        fullBytes = combined;
        structure = parseFileStructure(fullBytes);
      }
      channelHeaders = structure.channels;
      probeBytes = fullBytes; // pre-v8 fallback effectively already has (most of) the file
    }

    // Per-channel buffer state, seeded with whatever the probe/header-fetch already covered.
    const chanBuf = channelHeaders.map((ch) => {
      function seed(offset, len) {
        const availableFromProbe = Math.max(0, Math.min(len, probeBytes.length - offset));
        return {
          buf: availableFromProbe > 0 ? probeBytes.slice(offset, offset + availableFromProbe) : new Uint8Array(0),
          fetchedUpTo: offset + availableFromProbe,
        };
      }
      return { rans: seed(ch.ransBytesOffset, ch.ransLen), extra: seed(ch.extraBytesOffset, ch.extraLen) };
    });

    const headStartFetches = [];
    for (let c = 0; c < main.numChannels; c++) {
      const ch = channelHeaders[c], cb = chanBuf[c];
      const ransTarget = Math.min(ch.ransBytesOffset + ch.ransLen, ch.ransBytesOffset + RANS_HEAD_START);
      if (cb.rans.fetchedUpTo < ransTarget) {
        headStartFetches.push(fetchRangeAsync(cb.rans.fetchedUpTo, ransTarget - 1).then(bytes => {
          const merged = new Uint8Array(cb.rans.buf.length + bytes.length);
          merged.set(cb.rans.buf, 0); merged.set(bytes, cb.rans.buf.length);
          cb.rans.buf = merged; cb.rans.fetchedUpTo = ransTarget;
        }));
      }
      const extraTarget = Math.min(ch.extraBytesOffset + ch.extraLen, ch.extraBytesOffset + EXTRA_HEAD_START);
      if (cb.extra.fetchedUpTo < extraTarget) {
        headStartFetches.push(fetchRangeAsync(cb.extra.fetchedUpTo, extraTarget - 1).then(bytes => {
          const merged = new Uint8Array(cb.extra.buf.length + bytes.length);
          merged.set(cb.extra.buf, 0); merged.set(bytes, cb.extra.buf.length);
          cb.extra.buf = merged; cb.extra.fetchedUpTo = extraTarget;
        }));
      }
    }
    await Promise.all(headStartFetches);

    async function ensureLpcParsed(c) {
      const ch = channelHeaders[c];
      if (ch.lpcBytesLen === 0) return []; // nothing to fetch — this channel used only fixed predictors, no LPC blocks at all
      let lpcBytes = probeBytes.length >= ch.lpcBytesOffset + ch.lpcBytesLen
        ? probeBytes.slice(ch.lpcBytesOffset, ch.lpcBytesOffset + ch.lpcBytesLen)
        : await fetchRangeAsync(ch.lpcBytesOffset, ch.lpcBytesOffset + ch.lpcBytesLen - 1);
      const lpcDv = new DataView(lpcBytes.buffer, lpcBytes.byteOffset, lpcBytes.byteLength);
      const lpcParams = [];
      let lp = 0;
      while (lp < lpcBytes.length) {
        const shift = lpcDv.getUint8(lp); lp += 1;
        const qcoeffs = new Int32Array(LPC_ORDER);
        for (let j = 0; j < LPC_ORDER; j++) { qcoeffs[j] = lpcDv.getInt16(lp, true); lp += 2; }
        lpcParams.push({ shift, qcoeffs });
      }
      return lpcParams;
    }

    const channelState = new Array(main.numChannels);
    for (let c = 0; c < main.numChannels; c++) {
      const ch = channelHeaders[c];
      channelState[c] = {
        orders: ch.orders, riceKs: ch.riceKs,
        lpcParams: await ensureLpcParsed(c),
        ransState: ransDecoderInit(chanBuf[c].rans.buf, { freq: ch.freq, cum: ch.cum }),
        extraBitReader: new BitReader(chanBuf[c].extra.buf),
        lmsMode: main.lmsModes[c],
        lmsState: lmsCascadeInverseChunkInit(main.lmsModes[c]),
        lpcState: predictChannelInverseChunkInit(),
        x: new Int32Array(main.numFrames),
      };
    }

    async function ensureBuffered(c, ransAheadBytes, extraAheadBytes) {
      const ch = channelHeaders[c], cb = chanBuf[c], cs = channelState[c];
      if (cb.rans.fetchedUpTo < ch.ransBytesOffset + ch.ransLen && cb.rans.buf.length - cs.ransState.pos < ransAheadBytes) {
        const target = Math.min(ch.ransBytesOffset + ch.ransLen, cb.rans.fetchedUpTo + REFILL_SIZE);
        const more = await fetchRangeAsync(cb.rans.fetchedUpTo, target - 1);
        const merged = new Uint8Array(cb.rans.buf.length + more.length);
        merged.set(cb.rans.buf, 0); merged.set(more, cb.rans.buf.length);
        cs.ransState.bytes = merged; cb.rans.buf = merged; cb.rans.fetchedUpTo = target;
      }
      if (cb.extra.fetchedUpTo < ch.extraBytesOffset + ch.extraLen && cb.extra.buf.length - cs.extraBitReader.pos < extraAheadBytes) {
        const target = Math.min(ch.extraBytesOffset + ch.extraLen, cb.extra.fetchedUpTo + REFILL_SIZE);
        const more = await fetchRangeAsync(cb.extra.fetchedUpTo, target - 1);
        const merged = new Uint8Array(cb.extra.buf.length + more.length);
        merged.set(cb.extra.buf, 0); merged.set(more, cb.extra.buf.length);
        cs.extraBitReader.bytes = merged; cb.extra.buf = merged; cb.extra.fetchedUpTo = target;
      }
    }

    let nextBlockIdx = 0;
    const numBlocksTotal = main.blockStarts.length;

    async function decodeNextChunk(numBlocksPerChunk) {
      if (nextBlockIdx >= numBlocksTotal) return null;
      const startBlockIdx = nextBlockIdx;
      const endBlockIdx = Math.min(startBlockIdx + numBlocksPerChunk, numBlocksTotal);
      const rangeStart = main.blockStarts[startBlockIdx];
      const rangeEnd = endBlockIdx < numBlocksTotal ? main.blockStarts[endBlockIdx] : main.numFrames;
      const chunkSamples = rangeEnd - rangeStart;
      // Separate, realistically-sized thresholds per stream — measured real data (both
      // real tracks and synthetic testing) shows the "extra bits" stream running several
      // times larger than the rANS-coded stream, so one shared threshold badly over-
      // triggers refills on the smaller stream. Still deliberately conservative (worst
      // case, not typical case) — an oversized estimate only costs a bit of extra latency
      // via ensureBuffered, never correctness.
      const ransAheadBytes = chunkSamples * 2;   // ~4x realistic worst-case rANS rate
      const extraAheadBytes = chunkSamples * 8;  // ~4x realistic worst-case extra-bits rate

      const crossedChunks = [];
      for (let c = 0; c < main.numChannels; c++) {
        await ensureBuffered(c, ransAheadBytes, extraAheadBytes);
        const cs = channelState[c];
        const riceKsChunk = cs.riceKs.slice(startBlockIdx, endBlockIdx);
        const ordersChunk = cs.orders.slice(startBlockIdx, endBlockIdx);
        const refinedChunk = riceJoinChannelChunk(cs.ransState, riceKsChunk, main.blockStarts, startBlockIdx, endBlockIdx, cs.extraBitReader, main.numFrames);
        const residualsChunk = lmsCascadeInverseChunk(refinedChunk, cs.lmsMode, cs.lmsState);
        predictChannelInverseChunk(residualsChunk, ordersChunk, cs.lpcParams, cs.lpcState, cs.x, rangeStart);
        crossedChunks.push(cs.x.subarray(rangeStart, rangeEnd));
      }

      const decodedChunk = crossChannelInverse(crossedChunks, main.crossFlags);
      nextBlockIdx = endBlockIdx;
      return { channels: decodedChunk, startSample: rangeStart, endSample: rangeEnd, done: nextBlockIdx >= numBlocksTotal };
    }

    return {
      sampleRate: main.sampleRate, numChannels: main.numChannels,
      bitsPerSample: main.bitsPerSample, numFrames: main.numFrames, metadata: main.metadata,
      usedIndexedFastPath: main.hasIndex,
      usesHighCompression: main.lmsModes.some(m => m === 3 || m === 4),
      decodeNextChunk,
      isDone: () => nextBlockIdx >= numBlocksTotal,
    };
  }

  const NovaCodec = { parseWav, writeWav, encode, decode, readMetadata, createStreamingDecoder, parseFileStructure, createNetworkStreamingDecoder };
  if (typeof module !== 'undefined' && module.exports) module.exports = NovaCodec;
  else root.NovaCodec = NovaCodec;

})(typeof window !== 'undefined' ? window : globalThis);
