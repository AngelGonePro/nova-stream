'use strict';
// Reads the server's compressed audio stream (/api/stream/pcm?enc=z): [u32 big-endian length][NOVA file] blocks, each a few
// seconds of lossless-compressed audio. novaZBody() turns such a response into an async iterable of plain PCM chunks, so
// the rest of the download code does not care how the bytes travelled. Decoding runs on a worker thread.
const path = require('path');
const { Worker } = require('worker_threads');

let worker = null, nextId = 1; const waiting = new Map();
function getWorker() {
  if (worker) return worker;
  worker = new Worker(path.join(__dirname, 'novaZDecodeWorker.js'));
  worker.unref();
  worker.on('message', (m) => { const w = waiting.get(m.id); if (!w) return; waiting.delete(m.id); if (m.error) w.reject(new Error('nova-z: ' + m.error)); else w.resolve(Buffer.from(m.pcm.buffer, m.pcm.byteOffset, m.pcm.byteLength)); });
  const fail = (e) => { for (const w of waiting.values()) w.reject(e); waiting.clear(); worker = null; };
  worker.on('error', fail); worker.on('exit', () => fail(new Error('nova-z decoder exited')));
  return worker;
}
function decodeBlock(bytes) {
  return new Promise((resolve, reject) => { const id = nextId++; waiting.set(id, { resolve, reject }); getWorker().postMessage({ id, bytes }); });
}

class NovaZDecodeError extends Error {}

/** res: an http response whose body is nova-z. Yields Buffers of plain s16le PCM. */
async function* novaZBody(res, stats) {
  let acc = Buffer.alloc(0);
  for await (const chunk of res) {
    if (stats) stats.wireBytes += chunk.length;
    acc = acc.length ? Buffer.concat([acc, chunk]) : chunk;
    while (acc.length >= 4) {
      const len = acc.readUInt32BE(0);
      if (len <= 0 || len > 64 * 1024 * 1024) throw new Error('nova-z: bad block length ' + len);
      if (acc.length < 4 + len) break;
      const blob = Buffer.from(acc.subarray(4, 4 + len)); acc = acc.subarray(4 + len);
      let pcm; try { pcm = await decodeBlock(blob); } catch (e) { throw new NovaZDecodeError(e.message); }
      yield pcm;
    }
  }
  if (acc.length) throw new Error('nova-z stream ended inside a block');
}
function shutdown() { if (worker) { const w = worker; worker = null; w.terminate(); } }
module.exports = { novaZBody, NovaZDecodeError, decodeBlock, shutdown };
