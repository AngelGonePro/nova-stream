'use strict';
// Decodes one block of the server's compressed (nova-z) stream off the main process: NOVA file bytes in, 16-bit little-endian
// interleaved PCM out.
const { parentPort } = require('worker_threads');
const NovaCodec = require('./novaCodec');
parentPort.on('message', ({ id, bytes }) => {
  try {
    const d = NovaCodec.decode(new Uint8Array(bytes.buffer, bytes.byteOffset, bytes.byteLength));
    const ch = d.numChannels, frames = d.numFrames;
    const out = Buffer.alloc(frames * ch * 2);
    let o = 0;
    for (let i = 0; i < frames; i++) for (let c = 0; c < ch; c++, o += 2) out.writeInt16LE(d.channels[c][i], o);
    const u8 = new Uint8Array(out.buffer, out.byteOffset, out.length);
    parentPort.postMessage({ id, pcm: u8, channels: ch }, [out.buffer]);
  } catch (e) { parentPort.postMessage({ id, error: String(e && e.message || e) }); }
});
