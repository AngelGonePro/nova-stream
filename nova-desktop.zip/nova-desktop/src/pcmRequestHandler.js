'use strict';
// Handles the player's /api/stream/pcm requests for the desktop app: decides which
// background download a request belongs to, and answers it from that download's cache
// when it can. Lives in its own module (it used to be inline in main.js's Electron
// protocol handler) so the real logic can be exercised end to end in a plain Node test
// against the real download manager and the real server.
//
// What this fixes, in one place, from a reported "skipping a track takes forever to
// start the next one, then the audio cuts out" with the real log in hand:
//
//  1. SKIP vs PREFETCH was guessed. Any request for a different track used to be treated
//     as a background prefetch if the previous track's download hadn't finished yet. So
//     after a skip, the old track kept downloading — competing for the same server — while
//     the new one started. The player knows whether a request is a prefetch (isPrefetch),
//     and now says so explicitly (&prefetch=1; the server ignores unknown parameters), so
//     nothing is guessed: a prefetch becomes the "next" download, any other request for a
//     different track is a real track change and replaces the current download.
//
//  2. THE CACHE ANSWERED WITH SHORT SNAPSHOTS. It returned whatever bytes happened to be
//     downloaded so far and ended the response, so the player re-asked again and again to
//     follow the download (a flood of requests and log lines); when the download hadn't
//     reached the requested position it waited a fixed 8 seconds, then fired a SECOND,
//     duplicate network request for the same audio — doubling the decode load on the
//     server exactly when it was already slow (the first request for every new track
//     duplicated too, because no buffer exists until the first response arrives). Now the
//     cache streams exactly like the real server does: one request per segment, delivered
//     as the download produces the bytes, no duplicate.
//
//  3. A SEEK FAR AHEAD of the download waited those 8 seconds before going to the server.
//     It now goes straight to the server, since a direct decode at that position is
//     faster than waiting for a sequential download to get there.

const FOLLOW_AHEAD_SECONDS = 60;   // a request this far (or less) beyond the download's progress waits for it; farther goes straight to the server
// Both are deliberately at least as patient as the download manager's own 120s read timeout (see
// downloadManager.js): a never-played track's first bytes, or a deep segment of a long multichannel track, can
// legitimately take a good while on a modest server, and the cache must not give up on a download the manager
// is still (correctly) waiting on. If the manager does give up, the stream notices at once (isDownloadActive).
const BUFFER_WAIT_MS = 120000;     // how long to wait for a just-started download to produce its first byte
const STALL_TIMEOUT_MS = 150000;   // a stream with no new bytes for this long gives up, so the player retries instead of hanging
const POLL_MS = 40;
const CHUNK_BYTES = 256 * 1024;
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Which download does this request belong to? Pure function of its inputs.
 * 'none'          — nothing to start; answer from whatever buffer exists
 * 'promote-next'  — the player moved on to the track that was being prefetched
 * 'start-current' — a real track change, or a seek backward before this download's start
 * 'start-next'    — a prefetch request for a track that isn't current or already prefetching
 */
function decideTrackAction({ sourcePath, skipToSeconds, isPrefetch, trackedPath, trackedStartAtSeconds, nextTrackId }) {
    if (isPrefetch) {
        if (sourcePath === trackedPath || sourcePath === nextTrackId) return { type: 'none' };
        return { type: 'start-next' };
    }
    if (sourcePath === trackedPath && skipToSeconds < trackedStartAtSeconds) {
        return { type: 'start-current', startAtSeconds: Math.floor(skipToSeconds), reason: 'deep seek backward' };
    }
    if (sourcePath === trackedPath) return { type: 'none' };
    if (sourcePath === nextTrackId) return { type: 'promote-next' };
    return { type: 'start-current', startAtSeconds: Math.floor(skipToSeconds), reason: 'track change' };
}

/**
 * A streaming 200 response that follows a TrackBuffer as the download fills it. Positions in the
 * headers are ABSOLUTE in the track — the player works in absolute positions — so they are offset
 * by where this buffer starts (originSamples); see TrackBuffer.originSamples.
 */
function createCacheResponse({ buf, startByte, maxDurationSeconds, originSamples, isDownloadActive, stallTimeoutMs = STALL_TIMEOUT_MS, pollMs = POLL_MS }) {
    const bytesPerFrame = buf.channels * 2;
    const bytesPerSecond = buf.sampleRate * bytesPerFrame;
    const segmentLimit = startByte + Math.ceil(maxDurationSeconds * bytesPerSecond);
    const headers = {
        'X-PCM-Sample-Rate': String(buf.sampleRate),
        'X-PCM-Channels': String(buf.channels),
        'X-PCM-Skip-Samples': String(originSamples + Math.floor(startByte / bytesPerFrame)),
    };
    if (buf.totalBytes != null) headers['X-PCM-Total-Frames'] = String(originSamples + Math.floor(buf.totalBytes / bytesPerFrame));
    let cursor = startByte, cancelled = false, lastProgress = Date.now();
    const stream = new ReadableStream({
        async pull(controller) {
            for (;;) {
                if (cancelled) return;
                const total = buf.totalBytes;
                const limit = total != null ? Math.min(segmentLimit, total) : segmentLimit;
                const available = Math.min(buf.downloadedBytes, limit) - cursor;
                if (available > 0) {
                    const n = Math.min(available, CHUNK_BYTES);
                    try { controller.enqueue(new Uint8Array(buf.readAt(cursor, n))); } catch (e) { controller.error(e); return; }
                    cursor += n; lastProgress = Date.now();
                    return;
                }
                if (cursor >= limit) { controller.close(); return; }                           // this segment (or the track) is complete
                if (total != null && buf.downloadedBytes >= total) { controller.close(); return; }
                if (!isDownloadActive()) {                                                      // the download ended (or gave up) short of this point
                    if (total == null) { controller.close(); return; }
                    controller.error(new Error('cache download stopped before this segment was complete'));
                    return;
                }
                if (Date.now() - lastProgress > stallTimeoutMs) { controller.error(new Error('cache download stalled')); return; }
                await sleep(pollMs);
            }
        },
        cancel() { cancelled = true; },
    });
    return new Response(stream, { status: 200, headers });
}

function createPcmRequestHandler({ getDownloadManager, proxyThrough, logLine }) {
    let trackedPath = null;
    let trackedStartAtSeconds = 0;

    async function handle(request, { sourcePath, quality, skipToSeconds, maxDurationSeconds, isPrefetch }) {
        const dm = getDownloadManager();
        logLine('fetchPatch', `PCM request: path=${sourcePath} quality=${quality} skipToSeconds=${skipToSeconds} maxDurationSeconds=${maxDurationSeconds}${isPrefetch ? ' (prefetch)' : ''}`);
        try {
            const action = decideTrackAction({ sourcePath, skipToSeconds, isPrefetch, trackedPath, trackedStartAtSeconds, nextTrackId: dm.getNextTrackId() });
            if (action.type === 'promote-next') {
                if (dm.promoteIfMatches(sourcePath)) {
                    trackedPath = sourcePath; trackedStartAtSeconds = 0;
                    logLine('fetchPatch', `Promoted existing prefetch to current: path=${sourcePath}`);
                }
            } else if (action.type === 'start-current') {
                trackedPath = sourcePath; trackedStartAtSeconds = action.startAtSeconds;
                logLine('fetchPatch', `Starting new background download: path=${sourcePath} quality=${quality} startAtSeconds=${trackedStartAtSeconds} (${action.reason}; any previous download for the current track is stopped)`);
                dm.startCurrent(sourcePath, sourcePath, quality, trackedStartAtSeconds);
            } else if (action.type === 'start-next') {
                logLine('fetchPatch', `Starting gapless prefetch download: path=${sourcePath} quality=${quality}`);
                dm.startNext(sourcePath, sourcePath, quality);
            }

            // The current track's download starts at trackedStartAtSeconds; a prefetch always starts at 0.
            const lookupStartAt = sourcePath === trackedPath ? trackedStartAtSeconds : 0;
            // A request is only still worth answering while its track is the current one or the one being
            // prefetched. If the user has moved on to another track since this request arrived (e.g. skipped again
            // before this track's first byte), the player has already abandoned it — see the check below.
            const stillWanted = () => sourcePath === trackedPath || sourcePath === dm.getNextTrackId();
            let buf = dm.findBuffer(sourcePath, lookupStartAt);
            if (!buf && dm.isActiveFor(sourcePath)) {
                // A download for this track was just started and hasn't produced its first byte yet, so no buffer
                // exists. This used to fall straight through to a SECOND network request for the same audio.
                // Wait for the one already running instead.
                const waitStart = Date.now();
                while (Date.now() - waitStart < BUFFER_WAIT_MS) {
                    await sleep(POLL_MS);
                    buf = dm.findBuffer(sourcePath, lookupStartAt);
                    if (buf || !dm.isActiveFor(sourcePath) || !stillWanted()) break;
                }
                if (buf) logLine('fetchPatch', `Download started producing data after ${Date.now() - waitStart}ms: path=${sourcePath} — serving from it instead of a duplicate network request`);
            }
            if (!buf && !stillWanted()) {
                // This request was waiting for a download that was cancelled because the user skipped to another
                // track. Falling through to a network request would make the server decode audio for a track nobody
                // is listening to, at the moment it is busiest with the new one. The player has already given up on it.
                logLine('fetchPatch', `Dropping request for a track the user has already left: path=${sourcePath}`);
                return new Response(null, { status: 499 });
            }
            if (!buf) {
                logLine('fetchPatch', `Cache miss (no buffer), falling back to real network request: path=${sourcePath} skipToSeconds=${skipToSeconds}`);
                return proxyThrough(request);
            }

            const bytesPerFrame = buf.channels * 2;
            const bytesPerSecond = buf.sampleRate * bytesPerFrame;
            const relativeSeconds = skipToSeconds - lookupStartAt;
            if (relativeSeconds < 0) return proxyThrough(request);
            let startByte = Math.floor(relativeSeconds * bytesPerSecond);
            startByte = Math.floor(startByte / bytesPerFrame) * bytesPerFrame;

            const fullyDownloaded = buf.totalBytes != null && buf.downloadedBytes >= buf.totalBytes;
            const active = !!dm.isActiveFor(sourcePath);
            if (startByte >= buf.downloadedBytes && !fullyDownloaded) {
                if (!active) {
                    logLine('fetchPatch', `Cache miss (not downloaded, and nothing is downloading it), falling back to real network request: path=${sourcePath} skipToSeconds=${skipToSeconds}`);
                    return proxyThrough(request);
                }
                const aheadSeconds = (startByte - buf.downloadedBytes) / bytesPerSecond;
                if (aheadSeconds > FOLLOW_AHEAD_SECONDS) {
                    logLine('fetchPatch', `Seek is ${aheadSeconds.toFixed(0)}s beyond what has downloaded; asking the server directly instead of waiting: path=${sourcePath} skipToSeconds=${skipToSeconds}`);
                    return proxyThrough(request);
                }
            }
            const originSamples = (typeof buf.originSamples === 'number') ? buf.originSamples : Math.round(lookupStartAt * buf.sampleRate);
            logLine('fetchPatch', `Serving from local cache (streaming): path=${sourcePath} from=${skipToSeconds.toFixed(2)}s sampleRate=${buf.sampleRate} channels=${buf.channels} downloaded=${buf.downloadedBytes}/${buf.totalBytes == null ? '?' : buf.totalBytes}`);
            return createCacheResponse({ buf, startByte, maxDurationSeconds, originSamples, isDownloadActive: () => !!dm.isActiveFor(sourcePath) });
        } catch (e) {
            logLine('fetchPatch', `Cache layer error, falling back to network: ${e.message}`);
            return proxyThrough(request);
        }
    }

    return { handle, getState: () => ({ trackedPath, trackedStartAtSeconds }) };
}

module.exports = { createPcmRequestHandler, decideTrackAction, createCacheResponse, FOLLOW_AHEAD_SECONDS };
