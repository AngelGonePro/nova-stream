'use strict';
const { contextBridge, ipcRenderer } = require('electron');

// ==================== Local helpers the PRELOAD SCRIPT ITSELF can use ====================
// Real, direct fix for a confirmed, repeated bug in this file: Electron's
// own docs state plainly that a preload script cannot attach anything to
// window and then read it back via window.X from within its OWN code —
// contextBridge.exposeInMainWorld only pushes things OUT to the page;
// it does not make them available back here. Every prior version of this
// file called window.novaDesktop.log(...) / window.novaAudioDevice.X(...)
// from its OWN top-level code, which is exactly the broken pattern —
// confirmed directly by a real "Cannot read properties of undefined
// (reading 'log')" error. Local functions here are what the preload
// script's own code actually calls; contextBridge exposure below is
// SEPARATELY what the page calls — two different consumers, never mixed.
function logToMain(tag, message) {
    try { ipcRenderer.send('nova:rendererLog', { tag, message }); } catch (e) { /* nothing further to do if even this fails */ }
}
async function listOutputDevicesLocal() {
    // Enumerating real device labels requires a permission grant first (a
    // getUserMedia prompt) — attempted here, but a rejection is treated as
    // "device list will just have generic labels," not fatal.
    try { await navigator.mediaDevices.getUserMedia({ audio: true }).then(s => s.getTracks().forEach(t => t.stop())); } catch (e) { /* permission denied or no input device — output device listing can still proceed */ }
    const devices = await navigator.mediaDevices.enumerateDevices();
    return devices.filter(d => d.kind === 'audiooutput').map(d => ({ deviceId: d.deviceId, label: d.label || `Output device (${d.deviceId.slice(0, 8)})` }));
}

// ==================== Safe, limited API exposed to the page ====================
contextBridge.exposeInMainWorld('novaDesktop', {
    openLogsWindow: () => ipcRenderer.invoke('nova:openLogsWindow'),
    log: (tag, message) => ipcRenderer.send('nova:rendererLog', { tag, message }),
});
contextBridge.exposeInMainWorld('novaAudioDevice', {
    listOutputDevices: () => listOutputDevicesLocal(),
});

// ==================== Global renderer crash reporting ====================
// Real, direct port of NovaApplication.kt's design — catches anything
// uncaught in this window and gets it to the main process (which writes
// it to a durable file) rather than letting it vanish with the window.
window.addEventListener('error', (event) => {
    try {
        ipcRenderer.send('nova:rendererCrash', {
            message: event.message,
            stack: event.error && event.error.stack ? event.error.stack : `${event.message} at ${event.filename}:${event.lineno}:${event.colno}`,
        });
    } catch (e) { /* nothing further to do if even reporting the crash fails */ }
});
window.addEventListener('unhandledrejection', (event) => {
    try {
        const reason = event.reason;
        ipcRenderer.send('nova:rendererCrash', {
            message: `Unhandled promise rejection: ${reason && reason.message ? reason.message : reason}`,
            stack: reason && reason.stack ? reason.stack : String(reason),
        });
    } catch (e) { /* nothing further to do */ }
});

// ==================== Native cache operations exposed to the page ====================
// Deliberately scoped to ONLY /api/stream/pcm requests — every other
// fetch call on the page (metadata, images, everything else) goes
// straight through to the real, original fetch, completely untouched.
// The actual fetch() override that USES these lives in main.js, injected
// directly into the main world — see that file's own comment for why:
// contextBridge can only expose new, custom properties, never override
// an existing global like fetch, so the override itself cannot live here.
contextBridge.exposeInMainWorld('novaCache', {
    getNextTrackId: () => ipcRenderer.invoke('nova:getNextTrackId'),
    promoteNextTrackDownload: (trackId) => ipcRenderer.invoke('nova:promoteNextTrackDownload', { trackId }),
    isCurrentTrackFinished: () => ipcRenderer.invoke('nova:isCurrentTrackFinished'),
    startTrackDownload: (trackId, path, quality, startAtSeconds) => ipcRenderer.invoke('nova:startTrackDownload', { trackId, path, quality, startAtSeconds }),
    prepareNextTrackDownload: (trackId, path, quality) => ipcRenderer.invoke('nova:prepareNextTrackDownload', { trackId, path, quality }),
    readCachedRange: (trackId, bufferStartAtSeconds, skipToSeconds, maxDurationSeconds) => ipcRenderer.invoke('nova:readCachedRange', { trackId, bufferStartAtSeconds, skipToSeconds, maxDurationSeconds }),
    log: (tag, message) => ipcRenderer.send('nova:rendererLog', { tag, message }),
});

// ==================== Native menu integration: logs + output device list ====================
// Real, direct redesign after several confirmed reports across this
// file: the previous version called the page-facing, contextBridge-
// exposed functions (window.novaDesktop.log, window.novaAudioDevice.X)
// from the preload script's OWN code — exactly the broken pattern
// described above. Fixed by using the LOCAL functions defined at the top
// of this file instead. Note there is no more ipcRenderer.on for
// applying a chosen device here at all — that used to round-trip through
// this preload script, but the AudioContext instance itself cannot be
// sent across the isolation boundary in either direction (it isn't a
// serializable value), so applying a device selection has to happen
// entirely within the main world — see main.js, which now calls
// window.__novaApplyOutputDevice(...) there directly via
// executeJavaScript rather than going through this file at all.
try {
    logToMain('devicePicker', 'Device-list reporting: starting setup');

    async function reportDeviceListToMain() {
        try {
            const devices = await listOutputDevicesLocal();
            ipcRenderer.send('nova:deviceListUpdated', devices);
            logToMain('devicePicker', `Reported ${devices.length} output device(s) to the native menu`);
        } catch (e) {
            logToMain('devicePicker', `Failed to list/report output devices: ${e && e.stack ? e.stack : e}`);
        }
    }

    function wireUpDeviceReporting() {
        reportDeviceListToMain();
        try {
            navigator.mediaDevices.addEventListener('devicechange', reportDeviceListToMain);
        } catch (e) {
            logToMain('devicePicker', `Could not attach devicechange listener: ${e && e.stack ? e.stack : e}`);
        }
    }
    // document.readyState covers the real, confirmed case where
    // DOMContentLoaded has ALREADY fired by the time this code runs.
    if (document.readyState === 'loading') {
        window.addEventListener('DOMContentLoaded', wireUpDeviceReporting);
    } else {
        wireUpDeviceReporting();
    }
    logToMain('devicePicker', 'Device-list reporting: setup complete, listener attached');
} catch (e) {
    logToMain('devicePicker', `Top-level setup threw: ${e && e.stack ? e.stack : e}`);
}
