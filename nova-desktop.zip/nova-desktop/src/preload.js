'use strict';
const { contextBridge, ipcRenderer } = require('electron');

// ==================== Safe, limited API exposed to the page ====================
contextBridge.exposeInMainWorld('novaDesktop', {
    openLogsWindow: () => ipcRenderer.invoke('nova:openLogsWindow'),
    log: (tag, message) => ipcRenderer.send('nova:rendererLog', { tag, message }),
});

// ==================== Global renderer crash reporting ====================
// Real, direct port of NovaApplication.kt's design — catches anything
// uncaught in this window and gets it to the main process (which writes
// it to a durable file) rather than letting it vanish with the window.
window.addEventListener('error', (event) => {
    try {
        ipcRenderer.send('nova:rendererCrash', {
            message: event.message,
            stack: event.error && event.error.stack ? event.error.stack : `${event.message} at ${event.filename}:${event.lineno}:${event.colno}`,
        });
    } catch (e) { /* nothing further to do if even reporting the crash fails */ }
});
window.addEventListener('unhandledrejection', (event) => {
    try {
        const reason = event.reason;
        ipcRenderer.send('nova:rendererCrash', {
            message: `Unhandled promise rejection: ${reason && reason.message ? reason.message : reason}`,
            stack: reason && reason.stack ? reason.stack : String(reason),
        });
    } catch (e) { /* nothing further to do */ }
});

// ==================== "Bit perfect" audio output device selection ====================
// Captures whichever AudioContext instance app.js itself creates, by
// wrapping the constructor before app.js's own script runs. This works
// even with contextIsolation enabled because isolation separates
// JavaScript execution contexts/prototypes, not the underlying window/DOM
// object itself — a preload script's `window` reference is the same
// window the page sees, the same reason the fetch() patch above works.
let capturedAudioContext = null;
(function captureAudioContext() {
    const NativeAudioContext = window.AudioContext || window.webkitAudioContext;
    if (!NativeAudioContext) return; // no Web Audio API at all in this environment — nothing to hook
    function WrappedAudioContext(...args) {
        const instance = new NativeAudioContext(...args);
        capturedAudioContext = instance;
        try { ipcRenderer.send('nova:rendererLog', { tag: 'audioDevice', message: 'AudioContext created and captured for output device selection' }); } catch (e) {}
        return instance;
    }
    WrappedAudioContext.prototype = NativeAudioContext.prototype;
    window.AudioContext = WrappedAudioContext;
    if (window.webkitAudioContext) window.webkitAudioContext = WrappedAudioContext;
})();

contextBridge.exposeInMainWorld('novaAudioDevice', {
    listOutputDevices: async () => {
        // Enumerating real device labels requires a permission grant first
        // (a getUserMedia prompt) — attempted here, but a rejection is
        // treated as "device list will just have generic labels," not a
        // fatal error; device selection can still work by ID even without
        // human-readable names.
        try { await navigator.mediaDevices.getUserMedia({ audio: true }).then(s => s.getTracks().forEach(t => t.stop())); } catch (e) { /* permission denied or no input device — output device listing can still proceed */ }
        const devices = await navigator.mediaDevices.enumerateDevices();
        return devices.filter(d => d.kind === 'audiooutput').map(d => ({ deviceId: d.deviceId, label: d.label || `Output device (${d.deviceId.slice(0, 8)})` }));
    },
    setOutputDevice: async (deviceId) => {
        if (!capturedAudioContext) return { ok: false, error: 'No AudioContext has been created by the page yet — try again after playback has started at least once.' };
        if (typeof capturedAudioContext.setSinkId !== 'function') return { ok: false, error: 'AudioContext.setSinkId is not available in this build of Electron/Chromium.' };
        try {
            await capturedAudioContext.setSinkId(deviceId);
            return { ok: true };
        } catch (e) {
            return { ok: false, error: e.message };
        }
    },
    hasAudioContext: () => !!capturedAudioContext,
});

// ==================== Injected UI: logs button + output device picker ====================
// A small floating panel injected into the page — the loaded web UI
// itself (app.js/index.html) is used completely unmodified; this is
// added alongside it, not a change to it.
window.addEventListener('DOMContentLoaded', () => {
    const panel = document.createElement('div');
    panel.id = 'nova-desktop-panel';
    panel.style.cssText = 'position:fixed;bottom:8px;right:8px;z-index:999999;display:flex;gap:6px;align-items:center;font-family:sans-serif;font-size:12px;background:rgba(20,20,20,0.85);padding:6px 8px;border-radius:8px;color:#eee;';
    panel.innerHTML = `
      <select id="nova-desktop-device-select" style="max-width:180px;background:#222;color:#eee;border:1px solid #444;border-radius:4px;padding:2px;">
        <option value="">Output: default</option>
      </select>
      <button id="nova-desktop-logs-btn" style="background:#222;color:#eee;border:1px solid #444;border-radius:4px;padding:3px 8px;cursor:pointer;">Logs</button>
    `;
    document.body.appendChild(panel);

    const select = panel.querySelector('#nova-desktop-device-select');
    const logsBtn = panel.querySelector('#nova-desktop-logs-btn');

    logsBtn.addEventListener('click', () => { window.novaDesktop.openLogsWindow(); });

    async function refreshDeviceList() {
        try {
            const devices = await window.novaAudioDevice.listOutputDevices();
            const currentValue = select.value;
            select.innerHTML = '<option value="">Output: default</option>' + devices.map(d => `<option value="${d.deviceId}">${escapeHtml(d.label)}</option>`).join('');
            if (devices.some(d => d.deviceId === currentValue)) select.value = currentValue;
        } catch (e) {
            window.novaDesktop.log('panel', `Failed to list output devices: ${e.message}`);
        }
    }
    function escapeHtml(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

    select.addEventListener('change', async () => {
        const deviceId = select.value;
        const result = await window.novaAudioDevice.setOutputDevice(deviceId || 'default');
        if (!result.ok) {
            window.novaDesktop.log('panel', `Failed to set output device: ${result.error}`);
            alert(`Could not switch output device: ${result.error}`);
        }
    });

    refreshDeviceList();
    navigator.mediaDevices.addEventListener('devicechange', refreshDeviceList);
});
// Deliberately scoped to ONLY /api/stream/pcm requests — every other
// fetch call on the page (metadata, images, everything else) goes
// straight through to the real, original fetch, completely untouched.
// See main.js's installCacheInterceptor comment for why this approach
// was chosen over a protocol/webRequest-level interceptor.
//
// Scoped in this first version to CURRENT-track caching only, not a
// separate gapless next-track prefetch — the background download for the
// current track already covers the whole thing regardless of how the
// existing player fetches it in small pieces, so this still gets the
// core benefit (instant re-seeks within a track already played, reduced
// network use) with less new surface area to get wrong.
(function installFetchPatch() {
    const originalFetch = window.fetch.bind(window);
    let trackedPath = null;
    let trackedStartAtSeconds = 0;

    window.fetch = async function (input, init) {
        try {
            const url = typeof input === 'string' ? new URL(input, window.location.href) : new URL(input.url, window.location.href);
            if (url.pathname !== '/api/stream/pcm') return originalFetch(input, init);

            const sourcePath = url.searchParams.get('path');
            const quality = url.searchParams.get('quality') || 'reduced';
            const skipToSeconds = parseFloat(url.searchParams.get('skipToSeconds') || '0');
            const maxDurationSeconds = parseFloat(url.searchParams.get('maxDurationSeconds') || '60');
            if (!sourcePath) return originalFetch(input, init);

            // Real, direct rewrite for gapless prefetch support. app.js's
            // own existing web-audio path already has to fetch the NEXT
            // track's data ahead of time, before the current one finishes,
            // to have any chance of a gapless transition at all — so a
            // request for a different path doesn't necessarily mean
            // playback has actually moved on yet. Naively treating every
            // new path as "the new current track" would kill the still-
            // relevant current download the moment app.js starts
            // prefetching, discarding a download that's still needed.
            const isDeepSeekBackWithinSameTrack = sourcePath === trackedPath && skipToSeconds < trackedStartAtSeconds;
            if (sourcePath !== trackedPath || isDeepSeekBackWithinSameTrack) {
                const alreadyMatchesPrefetch = !isDeepSeekBackWithinSameTrack && await ipcRenderer.invoke('nova:getNextTrackId').catch(() => null);
                if (alreadyMatchesPrefetch === sourcePath) {
                    // app.js is now actually requesting data for a track
                    // that was already being prefetched — this IS the real
                    // transition. Hand off the already-running download
                    // instead of restarting it from scratch.
                    const result = await ipcRenderer.invoke('nova:promoteNextTrackDownload', { trackId: sourcePath }).catch(() => ({ promoted: false }));
                    if (result && result.promoted) {
                        trackedPath = sourcePath;
                        trackedStartAtSeconds = 0;
                    }
                } else {
                    const currentFinished = isDeepSeekBackWithinSameTrack ? false : await ipcRenderer.invoke('nova:isCurrentTrackFinished').catch(() => true);
                    if (isDeepSeekBackWithinSameTrack || currentFinished) {
                        // Either a deep seek backward past what a from-0
                        // download would ever roll back to (same track), or
                        // the current track is genuinely done and this is a
                        // fresh starting point worth downloading the rest
                        // of the track from — matches the Android app's own
                        // "restart the buffered system at the new position"
                        // behavior for a deep seek.
                        trackedPath = sourcePath;
                        trackedStartAtSeconds = Math.floor(skipToSeconds);
                        ipcRenderer.invoke('nova:startTrackDownload', {
                            trackId: sourcePath, path: sourcePath, quality, startAtSeconds: trackedStartAtSeconds,
                        }).catch(() => {}); // best-effort — a failure here just means this fetch falls through to the network below, same as a cache miss
                    } else {
                        // The current track is still actively playing/
                        // downloading — this is app.js prefetching ahead of
                        // time for a gapless transition. Start a SEPARATE
                        // background download for it without touching the
                        // still-relevant current one. This specific fetch
                        // call falls through to a real network request
                        // below (the prefetch has no data yet) — that's
                        // expected and correct; future requests for this
                        // same track, once app.js actually transitions to
                        // it, will hit the branch above and benefit from
                        // whatever this prefetch has managed to download by
                        // then.
                        ipcRenderer.invoke('nova:prepareNextTrackDownload', {
                            trackId: sourcePath, path: sourcePath, quality,
                        }).catch(() => {});
                    }
                }
            }

            const cached = await ipcRenderer.invoke('nova:readCachedRange', {
                trackId: sourcePath,
                bufferStartAtSeconds: trackedStartAtSeconds,
                skipToSeconds,
                maxDurationSeconds,
            });
            if (!cached || !cached.available) return originalFetch(input, init);

            const headers = new Headers({
                'X-PCM-Sample-Rate': String(cached.sampleRate),
                'X-PCM-Channels': String(cached.channels),
                'X-PCM-Skip-Samples': String(cached.skipSamples),
            });
            if (cached.totalBytes != null) {
                const bytesPerFrame = cached.channels * 2;
                const totalFrames = Math.floor(cached.totalBytes / bytesPerFrame) + Math.floor(cached.skipSamples);
                headers.set('X-PCM-Total-Frames', String(totalFrames));
            }
            const bodyArray = cached.bytes instanceof Uint8Array ? cached.bytes : new Uint8Array(cached.bytes);
            // Real, direct addition alongside a matching fix in app.js's
            // own throughput-measurement code — see its comment there for
            // the full reasoning. Set immediately before returning a
            // cached response so app.js can tell "this segment arrived
            // basically instantly because it was already on disk" apart
            // from "this segment arrived fast because the network is
            // genuinely fast" — the same window/DOM object is shared
            // across the context-isolation boundary, the same reason the
            // fetch() reassignment above works at all.
            window.__novaCacheServedRecently = true;
            return new Response(bodyArray, { status: 200, headers });
        } catch (e) {
            // Any failure in the caching layer itself must never break
            // actual playback — always fall through to a real, normal
            // fetch rather than let an error here propagate up as a
            // failed audio request.
            try { ipcRenderer.send('nova:rendererLog', { tag: 'fetchPatch', message: `Cache layer error, falling back to network: ${e.message}` }); } catch (e2) {}
            return originalFetch(input, init);
        }
    };
})();
