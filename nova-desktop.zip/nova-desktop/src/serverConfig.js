'use strict';
// Which NOVA server the desktop app talks to: chosen on first start (or from the menu / settings), stored in the
// app's user-data folder. NOVA_SERVER_ORIGIN in the environment still wins, for people who launch it from a script.
const fs = require('fs');
const path = require('path');

/** "music.example.com", "https://music.example.com/", "https://host:8443/x" -> "https://host[:port]", or null. */
function normalize(input) {
  let text = String(input == null ? '' : input).trim();
  if (!text) return null;
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) text = 'https://' + text;
  let u;
  try { u = new URL(text); } catch (e) { return null; }
  if (u.protocol !== 'https:' || !u.hostname || u.username || u.password) return null;
  if (!u.hostname.includes('.') && u.hostname !== 'localhost') return null;
  return 'https://' + u.hostname + (u.port && u.port !== '443' ? ':' + u.port : '');
}

const fileFor = (dir) => path.join(dir, 'server.json');
const read = (dir) => { try { return JSON.parse(fs.readFileSync(fileFor(dir), 'utf8')) || {}; } catch (e) { return {}; } };
const write = (dir, obj) => {
  fs.mkdirSync(dir, { recursive: true });
  const tmp = fileFor(dir) + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(obj));
  fs.renameSync(tmp, fileFor(dir));
};
/** The last server address that was chosen (kept even while the app is set to the local library, so switching back is one click). */
function load(dir) { return normalize(read(dir).origin); }
/** What the app should use now: { kind: 'local' }, { kind: 'server', origin }, or null when nothing was chosen yet. */
function loadChoice(dir) {
  const c = read(dir);
  if (c.mode === 'local') return { kind: 'local' };
  const origin = normalize(c.origin);
  return origin ? { kind: 'server', origin } : null;
}
function save(dir, origin) {
  const n = normalize(origin);
  if (!n) throw new Error('not a valid server address');
  write(dir, { origin: n });
  return n;
}
/** Use the files on this computer. The previous server address is remembered. */
function saveLocal(dir) {
  const prev = load(dir);
  write(dir, prev ? { mode: 'local', origin: prev } : { mode: 'local' });
}
module.exports = { normalize, load, loadChoice, save, saveLocal };
