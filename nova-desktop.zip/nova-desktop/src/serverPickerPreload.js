'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('novaServerPicker', {
  getInfo: () => ipcRenderer.invoke('nova:serverPicker:info'),
  submit: (text) => ipcRenderer.invoke('nova:serverPicker:submit', text),
  cancel: () => ipcRenderer.invoke('nova:serverPicker:cancel'),
  useLocal: () => ipcRenderer.invoke('nova:serverPicker:useLocal'),
});
