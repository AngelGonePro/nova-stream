'use strict';
// Local encode / decode for the NOVA desktop app. Runs in a worker thread (see toolsWorker.js), one file per
// worker, so a whole library is converted on all CPU cores at once.
//
// Anything that is not already a WAV is first turned into a WAV by ffmpeg (FLAC, ALAC, MP3, ...), keeping the
// source's sample rate, channel layout and bit depth (16 or 24 bit; anything deeper is stored as 24 bit). Tags and
// embedded cover art are carried across.
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const NovaCodec = require('./novaCodec');

const toAB = (b) => b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);

const q = (a) => /[\s"']/.test(a) ? '"' + String(a).replace(/"/g, '\\"') + '"' : String(a);
const noop = () => {};

/** Runs a program. Every launch is logged with its full command line, and its pid is reported so a Stop can kill it. */
function run(cmd, args, ctx, { capture } = {}) {
  const log = (ctx && ctx.log) || noop, onChild = (ctx && ctx.onChild) || noop;
  return new Promise((resolve, reject) => {
    const started = Date.now();
    log(`exec: ${q(cmd)} ${args.map(q).join(' ')}`);
    const p = spawn(cmd, args, { stdio: ['ignore', capture ? 'pipe' : 'ignore', 'pipe'], windowsHide: true });
    if (p.pid) onChild(p.pid, 'start');
    let out = '', err = '';
    if (capture) p.stdout.on('data', (d) => { out += d; });
    p.stderr.on('data', (d) => { err += d; if (err.length > 8000) err = err.slice(-8000); });
    p.on('error', (e) => { log(`exec failed to start: ${q(cmd)}: ${e.message}`); reject(new Error(`could not start ${cmd}: ${e.message}`)); });
    p.on('close', (code, signal) => {
      if (p.pid) onChild(p.pid, 'exit');
      log(`exit: ${path.basename(cmd)} code=${code}${signal ? ' signal=' + signal : ''} after ${Date.now() - started} ms`);
      if (code === 0) return resolve(out);
      const tail = err.trim().split('\n').slice(-3).join(' | ');
      log(`stderr: ${err.trim().split('\n').slice(-6).join(' | ')}`);
      reject(new Error(`${path.basename(cmd)} failed (${code}): ${tail}`));
    });
  });
}

const TAG_KEYS = ['title', 'artist', 'album', 'date', 'genre', 'comment', 'track', 'albumartist', 'album_artist', 'composer', 'disc'];

async function probe(input, ctx) {
  const json = JSON.parse(await run(ctx.ffprobe, ['-v', 'error', '-show_streams', '-show_format', '-of', 'json', input], ctx, { capture: true }));
  const audio = (json.streams || []).find((s) => s.codec_type === 'audio');
  if (!audio) throw new Error('no audio stream in this file');
  const picture = (json.streams || []).find((s) => s.codec_type === 'video' && (s.codec_name === 'mjpeg' || s.codec_name === 'png'));
  const rawTags = Object.assign({}, (json.format && json.format.tags) || {}, audio.tags || {});
  const tags = {};
  for (const [k, v] of Object.entries(rawTags)) { const key = k.toLowerCase(); if (TAG_KEYS.includes(key) && String(v).trim()) tags[key === 'album_artist' ? 'albumartist' : key] = String(v); }
  const bits = parseInt(audio.bits_per_raw_sample, 10) || parseInt(audio.bits_per_sample, 10) || (/^s16/.test(audio.sample_fmt || '') ? 16 : 24);
  return { bits: bits <= 16 ? 16 : 24, tags, picture: picture ? picture.codec_name : null };
}

function tmpName(ext) { return path.join(os.tmpdir(), `nova-tools-${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2)}${ext}`); }

/** Temp-file bookkeeping: every file this module creates is reported (so a hard Stop can remove leftovers) and logged. */
function tracker(ctx) {
  const log = ctx.log || noop, onTemp = ctx.onTemp || noop;
  return {
    made(f, why) { onTemp(f, 'add'); log(`temp file: ${f} (${why})`); },
    drop(f) { try { fs.unlinkSync(f); log(`delete: ${f}`); } catch (e) { if (e.code !== 'ENOENT') log(`delete failed: ${f}: ${e.message}`); } onTemp(f, 'remove'); },
  };
}

/** Reads any audio file as { wav (parsed), metadata: { tags, picture } }. */
async function loadAsWav(input, ctx) {
  const log = ctx.log || noop, t = tracker(ctx);
  const ext = path.extname(input).toLowerCase();
  if (ext === '.wav') {
    log(`read: ${input} (${fs.statSync(input).size} bytes, parsed directly as WAV)`);
    const wav = NovaCodec.parseWav(toAB(fs.readFileSync(input)));
    return { wav, metadata: wav.metadata || { tags: {}, picture: null } };
  }
  const info = await probe(input, ctx);
  log(`probed: ${input}: ${info.bits}-bit, tags=${Object.keys(info.tags).join(',') || 'none'}, cover=${info.picture || 'none'}`);
  const tmpWav = tmpName('.wav');
  let tmpPic = null;
  t.made(tmpWav, 'ffmpeg writes the decoded WAV here');
  try {
    await run(ctx.ffmpeg, ['-v', 'error', '-y', '-i', input, '-map', '0:a:0', '-vn', '-map_metadata', '-1', '-c:a', info.bits === 16 ? 'pcm_s16le' : 'pcm_s24le', '-f', 'wav', tmpWav], ctx);
    log(`read: ${tmpWav} (${fs.statSync(tmpWav).size} bytes)`);
    const wav = NovaCodec.parseWav(toAB(fs.readFileSync(tmpWav)));
    let picture = null;
    if (info.picture) {
      tmpPic = tmpName(info.picture === 'png' ? '.png' : '.jpg');
      t.made(tmpPic, 'embedded cover');
      try {
        await run(ctx.ffmpeg, ['-v', 'error', '-y', '-i', input, '-map', '0:v:0', '-c', 'copy', '-frames:v', '1', tmpPic], ctx);
        picture = { mime: info.picture === 'png' ? 'image/png' : 'image/jpeg', data: new Uint8Array(fs.readFileSync(tmpPic)) };
      } catch (e) { picture = null; log('cover could not be extracted; continuing without it'); } // a cover that cannot be extracted is not worth failing the conversion for
    }
    return { wav, metadata: { tags: info.tags, picture } };
  } finally { t.drop(tmpWav); if (tmpPic) t.drop(tmpPic); }
}

function sameAudio(a, b) {
  if (a.numChannels !== b.numChannels || a.numFrames !== b.numFrames || a.sampleRate !== b.sampleRate) return false;
  for (let c = 0; c < a.numChannels; c++) {
    const x = a.channels[c], y = b.channels[c];
    for (let i = 0; i < a.numFrames; i++) if (x[i] !== y[i]) return false;
  }
  return true;
}

/** Tags the person edited in the queue replace the file's own; an empty value removes that tag. */
function applyTagEdits(metadata, edits, log) {
  if (!edits || typeof edits !== 'object') return;
  const tags = Object.assign({}, metadata.tags || {});
  for (const [k, v] of Object.entries(edits)) {
    const key = k === 'album_artist' ? 'albumartist' : String(k).toLowerCase();
    if (!TAG_KEYS.includes(key)) continue;
    const val = String(v == null ? '' : v).trim();
    if (val) tags[key] = val; else delete tags[key];
  }
  metadata.tags = tags;
  if (log) log(`tags edited in the queue: ${Object.keys(edits).join(', ')}`);
}

/** The tags a file carries, for the tag editor. */
async function readTags(input, ctx) {
  if (path.extname(input).toLowerCase() === '.wav') {
    const wav = NovaCodec.parseWav(toAB(fs.readFileSync(input)));
    return Object.assign({}, (wav.metadata && wav.metadata.tags) || {});
  }
  return (await probe(input, ctx)).tags;
}

/** input (wav/flac/...) -> .nova.  ctx: { ffmpeg, ffprobe, log, onChild, onTemp, onProgress } */
async function encodeFile({ input, output, highCompression, verify, tags: tagEdits, ...ctx }) {
  const progress = ctx.onProgress || noop, log = ctx.log || noop, t = tracker(ctx);
  log(`encode start: ${input} -> ${output} (highCompression=${!!highCompression}, verify=${!!verify})`);
  progress(0.02, 'reading');
  const { wav, metadata } = await loadAsWav(input, ctx);
  applyTagEdits(metadata, tagEdits, log);
  progress(0.1, 'encoding');
  const encoded = NovaCodec.encode(wav, metadata, (f) => progress(0.1 + f * 0.75, 'encoding'), { highCompression: !!highCompression });
  const bytes = encoded.buffer ? Buffer.from(encoded.buffer, encoded.byteOffset || 0, encoded.byteLength) : Buffer.from(encoded);
  log(`encoded: ${wav.numChannels} ch, ${wav.sampleRate} Hz, ${wav.numFrames} frames -> ${bytes.length} bytes`);
  if (verify) {
    progress(0.88, 'verifying');
    if (!sameAudio(wav, NovaCodec.decode(new Uint8Array(bytes)))) throw new Error('verification failed: decoded audio differs from the source (nothing was written)');
    log('verify: decoded audio is identical to the source');
  }
  fs.mkdirSync(path.dirname(output), { recursive: true });
  const tmpOut = output + '.part';
  t.made(tmpOut, 'output is written here first');
  try {
    fs.writeFileSync(tmpOut, bytes);
    fs.renameSync(tmpOut, output);
    log(`rename: ${tmpOut} -> ${output}`);
  } catch (e) { t.drop(tmpOut); throw e; }
  ctx.onTemp && ctx.onTemp(tmpOut, 'remove');
  progress(1, 'done');
  return { bytesIn: fs.statSync(input).size, bytesOut: bytes.length };
}

/** .nova -> .wav | .flac */
async function decodeFile({ input, output, format, ...ctx }) {
  const progress = ctx.onProgress || noop, log = ctx.log || noop, t = tracker(ctx);
  log(`decode start: ${input} -> ${output} (${format})`);
  progress(0.02, 'reading');
  const decoded = NovaCodec.decode(new Uint8Array(fs.readFileSync(input)));
  log(`decoded: ${decoded.numChannels} ch, ${decoded.sampleRate} Hz, ${decoded.numFrames} frames`);
  progress(0.7, 'writing');
  const wavBuf = Buffer.from(NovaCodec.writeWav(decoded));
  fs.mkdirSync(path.dirname(output), { recursive: true });
  const tmpOut = output + '.part';
  t.made(tmpOut, 'output is written here first');
  try {
    if (format === 'flac') {
      const tmpWav = tmpName('.wav');
      let tmpPic = null;
      t.made(tmpWav, 'intermediate WAV for ffmpeg');
      try {
        fs.writeFileSync(tmpWav, wavBuf);
        const md = decoded.metadata || { tags: {}, picture: null };
        const args = ['-v', 'error', '-y', '-i', tmpWav];
        if (md.picture && md.picture.data && md.picture.data.length) {
          tmpPic = tmpName(md.picture.mime === 'image/png' ? '.png' : '.jpg');
          t.made(tmpPic, 'cover to embed');
          fs.writeFileSync(tmpPic, Buffer.from(md.picture.data));
          args.push('-i', tmpPic, '-map', '0:a', '-map', '1:v', '-c:v', 'copy', '-disposition:v', 'attached_pic');
        }
        args.push('-c:a', 'flac', '-compression_level', '8');
        for (const [k, v] of Object.entries(md.tags || {})) args.push('-metadata', `${k}=${v}`);
        args.push('-f', 'flac', tmpOut);
        await run(ctx.ffmpeg, args, ctx);
      } finally { t.drop(tmpWav); if (tmpPic) t.drop(tmpPic); }
    } else {
      fs.writeFileSync(tmpOut, wavBuf);
    }
    fs.renameSync(tmpOut, output);
    log(`rename: ${tmpOut} -> ${output}`);
    ctx.onTemp && ctx.onTemp(tmpOut, 'remove');
  } catch (e) { t.drop(tmpOut); throw e; }
  progress(1, 'done');
  return { bytesIn: fs.statSync(input).size, bytesOut: fs.statSync(output).size };
}

module.exports = { encodeFile, decodeFile, sameAudio, readTags, applyTagEdits, TAG_KEYS };
