'use strict';
// Main-process side of the Library Tools window (encode / decode / play local files).
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const { ToolsQueue } = require('./toolsQueue');
const { scanFolder, AUDIO_EXTS } = require('./toolsPlan');

function resolveBinary(pkg, fallback) {
  try { const p = require(pkg); const bin = typeof p === 'string' ? p : p && p.path; if (bin && fs.existsSync(bin)) return bin; } catch (e) {}
  return fallback;
}
const works = (bin) => { try { return spawnSync(bin, ['-version'], { timeout: 8000 }).status === 0; } catch (e) { return false; } };

function createToolsController({ ipcMain, dialog, BrowserWindow, logLine, workerDir, userDataDir }) {
  const dir = workerDir || __dirname;
  const ffmpeg = resolveBinary('ffmpeg-static', 'ffmpeg');
  const ffprobe = resolveBinary('ffprobe-static', 'ffprobe');
  let win = null, queue = null;
  const send = (channel, data) => { if (win && !win.isDestroyed()) { try { win.webContents.send(channel, data); } catch (e) {} } };

  function createWindow(parent) {
    if (win && !win.isDestroyed()) { win.focus(); return; }
    win = new BrowserWindow({
      width: 980, height: 700, title: 'NOVA — Library Tools',
      webPreferences: { preload: path.join(dir, 'toolsPreload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true },
    });
    win.setMenuBarVisibility(false);
    win.loadFile(path.join(dir, 'tools.html'));
    win.on('closed', () => { win = null; }); // the queue keeps running without the window; closing the app stops it
  }

  const audioFilter = [{ name: 'Audio', extensions: [...AUDIO_EXTS].map((e) => e.slice(1)) }];
  ipcMain.handle('tools:defaults', () => ({ cores: os.cpus().length, threads: Math.max(1, os.cpus().length - 1), ffmpegOk: works(ffmpeg) && works(ffprobe) }));
  ipcMain.handle('tools:pickFiles', async (e, kind) => {
    const r = await dialog.showOpenDialog(win, { properties: ['openFile', 'multiSelections'], filters: kind === 'nova' ? [{ name: 'NOVA', extensions: ['nova'] }] : audioFilter });
    return r.canceled ? [] : r.filePaths.map((p) => ({ path: p, rel: path.basename(p) }));
  });
  ipcMain.handle('tools:pickFolder', async (e, kind) => {
    const r = await dialog.showOpenDialog(win, { properties: ['openDirectory'] });
    if (r.canceled || !r.filePaths[0]) return null;
    return { dir: r.filePaths[0], items: scanFolder(r.filePaths[0], kind) };
  });
  ipcMain.handle('tools:pickOutputDir', async () => {
    const r = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'] });
    return r.canceled ? null : r.filePaths[0];
  });

  // ---------- the conversion queue ----------
  const getQueue = () => {
    if (queue) return queue;
    queue = new ToolsQueue({
      ffmpeg, ffprobe, workerFile: path.join(dir, 'toolsWorker.js'), threads: Math.max(1, os.cpus().length - 1),
      persistFile: userDataDir ? path.join(userDataDir, 'tools-queue.json') : null,
      log: (line) => logLine('TOOLS', line),
    });
    queue.on('state', (s) => send('tools:state', s));
    return queue;
  };
  ipcMain.handle('tools:readTags', async (e, file) => {
    try { return { ok: true, tags: await require('./toolsCore').readTags(String(file), { ffprobe, ffmpeg, log: (l) => logLine('TOOLS', l) }) }; }
    catch (err) { return { ok: false, error: String(err && err.message || err), tags: {} }; }
  });
  ipcMain.handle('tools:readCover', async (e, file) => {
    try { return { ok: true, url: await require('./toolsCore').readCover(String(file), { ffprobe, ffmpeg, log: (l) => logLine('TOOLS', l) }) }; }
    catch (err) { return { ok: false, error: String(err && err.message || err), url: null }; }
  });
  ipcMain.handle('tools:readImage', (e, p) => { try { return { url: `data:${/\.png$/i.test(p) ? 'image/png' : 'image/jpeg'};base64,${fs.readFileSync(String(p)).toString('base64')}` }; } catch (err) { return { url: null }; } });
  ipcMain.handle('tools:pickImage', async () => {
    const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'Image', extensions: ['jpg', 'jpeg', 'png'] }] });
    if (r.canceled || !r.filePaths[0]) return null;
    const p = r.filePaths[0], png = /\.png$/i.test(p);
    return { path: p, url: `data:${png ? 'image/png' : 'image/jpeg'};base64,${fs.readFileSync(p).toString('base64')}` };
  });
  ipcMain.handle('tools:queue:get', () => getQueue().snapshot());
  ipcMain.handle('tools:queue:add', (e, req) => {
    const r = getQueue().add(req.kind === 'decode' ? 'decode' : 'encode', req.items || [], req.settings || {});
    return { ok: true, ...r };
  });
  ipcMain.handle('tools:queue:do', (e, req) => {
    const q = getQueue();
    switch (req && req.action) {
      case 'start': q.start(); break;
      case 'pause': q.pause(); break;
      case 'stop': q.stop(); break;
      case 'threads': q.setThreads(req.n); break;
      case 'remove': q.remove(req.id); break;
      case 'move': q.move(req.id, req.to); break;
      case 'retry': q.retry(req.id); break;
      case 'setCover': q.setCover(req.id, req.cover); break;
      case 'setTags': q.setTags(req.id, req.tags); break;
      case 'retryFailed': q.retryFailed(); break;
      case 'clearFinished': q.clearFinished(); break;
      default: return { ok: false, error: 'unknown action' };
    }
    return { ok: true };
  });


  return { open: createWindow, close: () => { if (win && !win.isDestroyed()) win.close(); }, shutdown: async () => { if (queue) await queue.close(); } };
}
module.exports = { createToolsController };
