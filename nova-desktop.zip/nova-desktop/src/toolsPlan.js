'use strict';
// Turns what the user picked into a list of conversion jobs, and finds audio files in a folder.
const fs = require('fs');
const path = require('path');

const AUDIO_EXTS = new Set(['.wav', '.flac', '.alac', '.m4a', '.mp3', '.ogg', '.opus', '.aiff', '.aif', '.wv', '.ape', '.wma']);
const NOVA_EXTS = new Set(['.nova']);

/** Recursively lists files with a wanted extension: [{ path, rel }] where rel keeps the sub-folders under `dir`. */
function scanFolder(dir, kind) {
  const wanted = kind === 'nova' ? NOVA_EXTS : AUDIO_EXTS;
  const out = [];
  const walk = (d) => {
    let entries; try { entries = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    entries.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
    for (const e of entries) {
      const full = path.join(d, e.name);
      if (e.isDirectory()) walk(full);
      else if (wanted.has(path.extname(e.name).toLowerCase())) out.push({ path: full, rel: path.relative(dir, full) });
    }
  };
  walk(dir);
  return out;
}

/** Where a converted file goes. outputDir null = next to the source. Never the source itself. */
function outputFor({ kind, item, outputDir, format }) {
  const ext = kind === 'decode' ? (format === 'flac' ? '.flac' : '.wav') : '.nova';
  const rel = item.rel || path.basename(item.path);
  const base = rel.slice(0, rel.length - path.extname(rel).length);
  let output = outputDir ? path.join(outputDir, base + ext) : path.join(path.dirname(item.path), path.basename(base) + ext);
  if (path.resolve(output) === path.resolve(item.path)) output = output.slice(0, -ext.length) + ' (converted)' + ext;
  return { output, ext };
}

/** Makes `output` unique against `used` (a Set of lower-cased paths): two different sources that would write the same file keep both. */
function uniqueOutput(output, ext, used) {
  let candidate = output, n = 2;
  while (used.has(candidate.toLowerCase())) candidate = output.slice(0, -ext.length) + ` (${n++})` + ext;
  used.add(candidate.toLowerCase());
  return candidate;
}

module.exports = { scanFolder, outputFor, uniqueOutput, AUDIO_EXTS };
