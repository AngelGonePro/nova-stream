'use strict';
const { contextBridge, ipcRenderer } = require('electron');
const sub = (channel) => (cb) => { const l = (e, d) => cb(d); ipcRenderer.on(channel, l); return () => ipcRenderer.removeListener(channel, l); };
contextBridge.exposeInMainWorld('novaTools', {
  defaults: () => ipcRenderer.invoke('tools:defaults'),
  pickFiles: (kind) => ipcRenderer.invoke('tools:pickFiles', kind),
  pickFolder: (kind) => ipcRenderer.invoke('tools:pickFolder', kind),
  pickOutputDir: () => ipcRenderer.invoke('tools:pickOutputDir'),
  readCover: (file) => ipcRenderer.invoke('tools:readCover', file),
  readImage: (p) => ipcRenderer.invoke('tools:readImage', p),
  pickImage: () => ipcRenderer.invoke('tools:pickImage'),
  readTags: (file) => ipcRenderer.invoke('tools:readTags', file),
  queueGet: () => ipcRenderer.invoke('tools:queue:get'),
  queueAdd: (req) => ipcRenderer.invoke('tools:queue:add', req),
  queueDo: (req) => ipcRenderer.invoke('tools:queue:do', req),
  onState: sub('tools:state'),
});
