'use strict';
// The conversion queue behind Library Tools.
//
//  - Jobs can be added at any time, also while the queue is running; each job keeps the settings it was added with
//    (high compression, verify, output folder/format, skip-existing), so changing the form later never touches it.
//  - Start / Pause / Stop: Pause lets running jobs finish and starts no new ones; Stop kills the running jobs (the worker
//    thread AND the ffmpeg/ffprobe processes it started), deletes their half-written files and puts them back in the
//    queue.
//  - Queued jobs can be moved, removed and re-run; failed ones can be retried.
//  - Every job runs on its own worker thread (up to `threads` at once; changeable while running).
//  - Everything that happens is reported through `log` (the app's log): each program launch with its full command line,
//    every file read / written / renamed / deleted, and each job's start and end.
const { Worker } = require('worker_threads');
const { EventEmitter } = require('events');
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const { outputFor, uniqueOutput } = require('./toolsPlan');
const TAG_KEYS = ['title', 'artist', 'album', 'date', 'genre', 'comment', 'track', 'albumartist', 'composer', 'disc']; // same set toolsCore writes

const RUN_STATES = ['idle', 'running', 'paused'];

function killTree(pid, log) {
  try {
    if (process.platform === 'win32') {
      const r = spawnSync('taskkill', ['/pid', String(pid), '/T', '/F'], { windowsHide: true });
      log(`kill: taskkill /pid ${pid} /T /F -> ${r.status}`);
    } else {
      process.kill(pid, 'SIGKILL');
      log(`kill: SIGKILL ${pid}`);
    }
  } catch (e) { log(`kill: ${pid} already gone (${e.code || e.message})`); }
}

class ToolsQueue extends EventEmitter {
  constructor({ ffmpeg, ffprobe, workerFile, threads, persistFile, log, now } = {}) {
    super();
    this.ffmpeg = ffmpeg || 'ffmpeg';
    this.ffprobe = ffprobe || 'ffprobe';
    this.workerFile = workerFile || path.join(__dirname, 'toolsWorker.js');
    this.threads = Math.max(1, Math.min(64, parseInt(threads, 10) || 1));
    this.persistFile = persistFile || null;
    this.log = log || (() => {});
    this.now = now || Date.now;
    this.jobs = [];            // in run order
    this.nextId = 1;
    this.state = 'idle';
    this.running = new Map();  // id -> { worker, pids:Set, temps:Set, killed:boolean }
    // totals for the overall bar / ETA, for the stretch since the queue was last started from idle
    this.session = { startedAt: 0, activeMs: 0, activeSince: 0, baseBytes: 0 };
    this._emitTimer = null;
    this._load();
  }

  // ---------- state out ----------
  weight(j) { return Math.max(1, j.sizeBytes || 1); }
  processedBytes() { let b = 0; for (const j of this.jobs) b += this.weight(j) * (j.status === 'done' || j.status === 'skipped' ? 1 : j.status === 'running' ? j.frac || 0 : 0); return b; }
  totalBytes() { let b = 0; for (const j of this.jobs) b += this.weight(j); return b; }
  activeMs() { return this.session.activeMs + (this.state === 'running' ? this.now() - this.session.activeSince : 0); }
  snapshot() {
    const total = this.totalBytes(), processed = this.processedBytes();
    const counts = { queued: 0, running: 0, done: 0, failed: 0, skipped: 0 };
    for (const j of this.jobs) counts[j.status]++;
    const activeMs = this.activeMs();
    const sessionBytes = processed - this.session.baseBytes;
    let etaMs = null;
    if (this.state === 'running' && sessionBytes > 0 && activeMs > 1500 && counts.queued + counts.running > 0) etaMs = Math.round((total - processed) / (sessionBytes / activeMs));
    return {
      state: this.state, threads: this.threads, counts,
      overall: { frac: total ? processed / total : 0, elapsedMs: Math.round(activeMs), etaMs },
      jobs: this.jobs.map((j) => ({ id: j.id, tags: j.tags || null, kind: j.kind, input: j.input, output: j.output, settings: j.settings, sizeBytes: j.sizeBytes, status: j.status, frac: j.frac, stage: j.stage, error: j.error, result: j.result })),
    };
  }
  _changed(immediate) {
    if (immediate) { clearTimeout(this._emitTimer); this._emitTimer = null; this.emit('state', this.snapshot()); return; }
    if (this._emitTimer) return;
    this._emitTimer = setTimeout(() => { this._emitTimer = null; this.emit('state', this.snapshot()); }, 100);
  }

  // ---------- adding ----------
  /**
   * items: [{ path, rel? }] in the order they should run. settings: { format, highCompression, verify, skipExisting, outputDir }.
   * Returns { added, duplicates, skipped }.
   */
  add(kind, items, settings) {
    const st = { format: settings && settings.format, highCompression: !!(settings && settings.highCompression), verify: !!(settings && settings.verify), skipExisting: !!(settings && settings.skipExisting), outputDir: (settings && settings.outputDir) || null };
    if (kind === 'decode') { st.format = st.format === 'flac' ? 'flac' : 'wav'; st.highCompression = false; st.verify = false; } else { st.format = undefined; }
    const used = new Set(this.jobs.map((j) => j.output.toLowerCase()));
    let added = 0, duplicates = 0, skipped = 0;
    for (const it of items || []) {
      const { output: planned, ext } = outputFor({ kind, item: it, outputDir: st.outputDir, format: st.format });
      // the same source going to the same place as a job already in the list is that job, not a new one
      const same = this.jobs.find((j) => j.kind === kind && j.input === it.path && j.output.toLowerCase() === planned.toLowerCase());
      if (same && (same.status === 'queued' || same.status === 'running')) { duplicates++; continue; }
      const output = same ? planned : uniqueOutput(planned, ext, used);
      if (same) this.jobs = this.jobs.filter((j) => j !== same); // a finished/failed entry is replaced by the new request
      let sizeBytes = 0; try { sizeBytes = fs.statSync(it.path).size; } catch (e) {}
      const job = { id: this.nextId++, kind, input: it.path, output, settings: st, sizeBytes, status: 'queued', frac: 0, stage: '', error: null, result: null };
      if (st.skipExisting && fs.existsSync(output)) { job.status = 'skipped'; job.stage = 'already done'; job.frac = 1; skipped++; }
      this.jobs.push(job); added++;
      this.log(`queue: added #${job.id} ${kind} ${job.input} -> ${job.output} ${JSON.stringify(st)}${job.status === 'skipped' ? ' (output exists, skipped)' : ''}`);
    }
    if (added) { this._save(); this._pump(); }
    this._changed(true);
    return { added, duplicates, skipped };
  }

  // ---------- run control ----------
  start() {
    if (this.state === 'running') return;
    if (this.state === 'idle') { // a fresh stretch: the overall bar and ETA count from here
      this.session = { startedAt: this.now(), activeMs: 0, activeSince: 0, baseBytes: this.processedBytes() };
    }
    this.state = 'running'; this.session.activeSince = this.now();
    this.log(`queue: start (${this.jobs.filter((j) => j.status === 'queued').length} waiting, ${this.threads} thread(s))`);
    this._pump(); this._changed(true);
  }
  pause() {
    if (this.state !== 'running') return;
    this.session.activeMs += this.now() - this.session.activeSince; this.state = 'paused';
    this.log('queue: paused (running jobs finish, no new ones start)');
    this._changed(true);
  }
  /** Kills every running job (processes, worker, half-written files) and puts them back in the queue. */
  stop() {
    if (this.state === 'running') this.session.activeMs += this.now() - this.session.activeSince;
    this.state = 'idle';
    this.log('queue: stop');
    for (const id of [...this.running.keys()]) this._kill(id, 'queued', 'stopped');
    this._save(); this._changed(true);
  }
  setThreads(n) {
    this.threads = Math.max(1, Math.min(64, parseInt(n, 10) || 1));
    this.log(`queue: threads = ${this.threads}`);
    this._pump(); this._changed(true);
  }

  // ---------- editing ----------
  remove(id) {
    const j = this._job(id); if (!j) return false;
    if (this.running.has(id)) this._kill(id, null, 'removed');
    this.jobs = this.jobs.filter((x) => x !== j);
    this.log(`queue: removed #${id}`);
    this._save(); this._pump(); this._changed(true);
    return true;
  }
  /** Moves a waiting job to position `to` among all jobs (0 = front). Jobs that are running or finished keep their place. */
  move(id, to) {
    const j = this._job(id); if (!j || j.status !== 'queued') return false;
    const from = this.jobs.indexOf(j);
    // queued jobs are only ever reordered among the queued ones
    const queued = this.jobs.filter((x) => x.status === 'queued');
    const qi = queued.indexOf(j), qt = Math.max(0, Math.min(queued.length - 1, to));
    if (qi === qt) return true;
    queued.splice(qi, 1); queued.splice(qt, 0, j);
    let k = 0; this.jobs = this.jobs.map((x) => (x.status === 'queued' ? queued[k++] : x));
    this.log(`queue: moved #${id} from ${from} to queued position ${qt}`);
    this._save(); this._changed(true);
    return true;
  }
  /** Sets the tags a waiting (or failed) encode job writes into its .nova, over the file's own. {} clears the edits. */
  setTags(id, tags) {
    const j = this._job(id); if (!j || j.kind !== 'encode' || j.status === 'running') return false;
    const clean = {};
    for (const [k, v] of Object.entries(tags || {})) { if (TAG_KEYS.includes(k)) clean[k] = String(v == null ? '' : v); }
    j.tags = Object.keys(clean).length ? clean : null;
    this.log(`queue: #${id} tags ${j.tags ? JSON.stringify(j.tags) : 'reset to the file\'s own'}`);
    this._save(); this._changed(true);
    return true;
  }
  retry(id) {
    const j = this._job(id); if (!j || (j.status !== 'failed' && j.status !== 'skipped')) return false;
    j.status = 'queued'; j.frac = 0; j.stage = ''; j.error = null; j.result = null;
    this.log(`queue: retry #${id}`);
    this._save();
    if (this.state === 'idle') this.start(); else { this._pump(); this._changed(true); } // retrying is a request to run it now
    return true;
  }
  retryFailed() { let n = 0; for (const j of this.jobs) if (j.status === 'failed' && this.retry(j.id)) n++; return n; }
  clearFinished() {
    const before = this.jobs.length;
    this.jobs = this.jobs.filter((j) => j.status === 'queued' || j.status === 'running');
    this.log(`queue: cleared ${before - this.jobs.length} finished job(s)`);
    this._save(); this._changed(true); this._maybeFinish();
  }

  // ---------- internals ----------
  _job(id) { return this.jobs.find((j) => j.id === id); }
  _pump() {
    if (this.state !== 'running') return;
    for (;;) {
      if (this.running.size >= this.threads) break;
      const j = this.jobs.find((x) => x.status === 'queued');
      if (!j) break;
      if (j.settings.skipExisting && fs.existsSync(j.output)) { j.status = 'skipped'; j.stage = 'already done'; j.frac = 1; this.log(`queue: #${j.id} skipped, ${j.output} exists`); continue; }
      this._startJob(j);
    }
    this._maybeFinish(); this._changed();
  }
  _maybeFinish() {
    if (this.state === 'running' && !this.running.size && !this.jobs.some((j) => j.status === 'queued')) {
      this.session.activeMs += this.now() - this.session.activeSince; this.state = 'idle';
      const c = this.snapshot().counts;
      this.log(`queue: finished, ${c.done} done, ${c.failed} failed, ${c.skipped} skipped`);
      this._save(); this._changed(true);
      this.emit('finished', c);
    }
  }
  _startJob(j) {
    j.status = 'running'; j.frac = 0; j.stage = 'starting'; j.error = null; j.startedAt = this.now();
    const tag = `#${j.id}`;
    const jl = (line) => this.log(`${tag} ${line}`);
    jl(`start ${j.kind}: ${j.input} -> ${j.output}`);
    const rec = { worker: null, pids: new Set(), temps: new Set(), killed: false };
    this.running.set(j.id, rec);
    let settled = false;
    const settle = (fn) => { if (settled) return; settled = true; this.running.delete(j.id); fn(); this._save(); this._pump(); this._changed(true); };
    let w;
    try {
      w = new Worker(this.workerFile, { workerData: { ffmpeg: this.ffmpeg, ffprobe: this.ffprobe, job: { id: j.id, kind: j.kind, input: j.input, output: j.output, format: j.settings.format, highCompression: j.settings.highCompression, verify: j.settings.verify, tags: j.tags || undefined } } });
    } catch (e) { settle(() => { j.status = 'failed'; j.error = 'could not start a worker: ' + e.message; jl('failed: ' + j.error); }); return; }
    rec.worker = w;
    w.on('message', (m) => {
      if (rec.killed) return;
      if (m.type === 'progress') { j.frac = m.frac; j.stage = m.stage || ''; this._changed(); }
      else if (m.type === 'log') jl(m.line);
      else if (m.type === 'child') { if (m.state === 'start') rec.pids.add(m.pid); else rec.pids.delete(m.pid); }
      else if (m.type === 'temp') { if (m.op === 'add') rec.temps.add(m.file); else rec.temps.delete(m.file); }
      else if (m.type === 'done') settle(() => { j.status = 'done'; j.frac = 1; j.stage = 'done'; j.result = m.result; j.finishedAt = this.now(); jl(`done in ${j.finishedAt - j.startedAt} ms: ${m.result.bytesIn} -> ${m.result.bytesOut} bytes`); });
      else if (m.type === 'error') settle(() => { j.status = 'failed'; j.error = m.message; j.stage = 'failed'; j.finishedAt = this.now(); jl('failed: ' + m.message); this._cleanTemps(rec, jl); });
    });
    w.on('error', (e) => { if (rec.killed) return; settle(() => { j.status = 'failed'; j.error = 'worker crashed: ' + e.message; j.stage = 'failed'; jl('failed: ' + j.error); this._cleanTemps(rec, jl); }); });
    w.on('exit', (code) => { if (rec.killed || settled) return; settle(() => { j.status = 'failed'; j.error = 'worker exited unexpectedly (code ' + code + ')'; j.stage = 'failed'; jl('failed: ' + j.error); this._cleanTemps(rec, jl); }); });
  }
  _cleanTemps(rec, jl) {
    for (const f of rec.temps) { try { fs.unlinkSync(f); jl(`delete leftover: ${f}`); } catch (e) { if (e.code !== 'ENOENT') jl(`could not delete ${f}: ${e.message}`); } }
    rec.temps.clear();
  }
  /** Hard-stops one running job: its ffmpeg/ffprobe processes first, then the worker, then its half-written files. */
  _kill(id, newStatus, why) {
    const rec = this.running.get(id), j = this._job(id);
    if (!rec) return;
    rec.killed = true;
    const jl = (line) => this.log(`#${id} ${line}`);
    jl(`${why}: killing ${rec.pids.size} process(es) and the worker`);
    for (const pid of rec.pids) killTree(pid, jl);
    rec.pids.clear();
    this.running.delete(id);
    const finish = () => { this._cleanTemps(rec, jl); };
    // the worker's event loop reaps the killed process; give it a moment before taking the worker down (no zombie left behind)
    setTimeout(() => { Promise.resolve(rec.worker.terminate()).then(finish, finish); }, 120);
    // on Windows a just-killed ffmpeg can still hold its output file for a moment
    if (process.platform === 'win32') setTimeout(finish, 500);
    if (j && newStatus) { j.status = newStatus; j.frac = 0; j.stage = why; }
  }

  // ---------- persistence: waiting and failed jobs survive a restart ----------
  _save() {
    if (!this.persistFile) return;
    try {
      const keep = this.jobs.filter((j) => j.status !== 'done' && j.status !== 'skipped').map((j) => ({ id: j.id, kind: j.kind, input: j.input, output: j.output, settings: j.settings, tags: j.tags || null, sizeBytes: j.sizeBytes, status: j.status === 'running' ? 'queued' : j.status, error: j.error }));
      fs.mkdirSync(path.dirname(this.persistFile), { recursive: true });
      const tmp = this.persistFile + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify({ nextId: this.nextId, jobs: keep }));
      fs.renameSync(tmp, this.persistFile);
    } catch (e) { this.log('queue: could not save the queue: ' + e.message); }
  }
  _load() {
    if (!this.persistFile) return;
    try {
      const data = JSON.parse(fs.readFileSync(this.persistFile, 'utf8'));
      for (const j of data.jobs || []) {
        if (!j || !j.input || !j.output || !j.settings || (j.kind !== 'encode' && j.kind !== 'decode')) continue;
        if (!fs.existsSync(j.input)) continue;
        this.jobs.push({ id: j.id, kind: j.kind, input: j.input, output: j.output, settings: j.settings, tags: j.tags || null, sizeBytes: j.sizeBytes || 0, status: j.status === 'failed' ? 'failed' : 'queued', frac: 0, stage: j.status === 'failed' ? 'failed' : '', error: j.error || null, result: null });
      }
      this.nextId = Math.max(data.nextId || 1, ...this.jobs.map((j) => j.id + 1), 1);
      if (this.jobs.length) this.log(`queue: restored ${this.jobs.length} job(s) from the last session`);
    } catch (e) { /* no saved queue */ }
  }
  async close() {
    clearTimeout(this._emitTimer);
    for (const id of [...this.running.keys()]) this._kill(id, 'queued', 'closing');
  }
}
module.exports = { ToolsQueue, RUN_STATES };
