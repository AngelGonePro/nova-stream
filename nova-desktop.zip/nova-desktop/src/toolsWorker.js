'use strict';
// One conversion per worker thread (see toolsQueue.js). The job comes in through workerData and the result goes back as
// a message. Everything the job does that the app must be able to log or undo is reported: log lines, the pid of every
// ffmpeg/ffprobe it starts, and every temporary file it creates.
const { parentPort, workerData } = require('worker_threads');
const core = require('./toolsCore');

const job = workerData.job;
const ctx = {
  ffmpeg: workerData.ffmpeg, ffprobe: workerData.ffprobe,
  onProgress: (frac, stage) => parentPort.postMessage({ type: 'progress', frac, stage }),
  log: (line) => parentPort.postMessage({ type: 'log', line }),
  onChild: (pid, state) => parentPort.postMessage({ type: 'child', pid, state }),
  onTemp: (file, op) => parentPort.postMessage({ type: 'temp', file, op }),
};
(async () => {
  try {
    const result = job.kind === 'decode'
      ? await core.decodeFile({ ...job, ...ctx })
      : await core.encodeFile({ ...job, ...ctx });
    parentPort.postMessage({ type: 'done', result });
  } catch (e) {
    parentPort.postMessage({ type: 'error', message: String(e && e.message || e) });
  }
})();
