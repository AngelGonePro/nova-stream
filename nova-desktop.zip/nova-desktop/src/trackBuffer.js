'use strict';
// Real, direct port of the Android app's own TrackBuffer (NativeAudioEngine.kt)
// — file-backed, not memory-backed, from the start here (the Android version
// only moved to this design after a real OutOfMemoryError; there's no reason
// to repeat that mistake on a platform where it was already learned).
//
// Design, carried over exactly: separate read and write file descriptors on
// the SAME file. A single shared descriptor would mean the writer's
// sequential appends and the reader's arbitrary-offset seeks could clobber
// each other's file position — Node's fs read/write-with-position variants
// avoid this more directly than Java's RandomAccessFile did (each read/write
// call takes an explicit position, no persistent "current position" state to
// collide over), but two separate open file descriptors are kept anyway, to
// stay consistent with the proven design and make the two roles' lifecycles
// (closing/deleting) trivially independent.

const fs = require('fs');
const path = require('path');

class TrackBuffer {
    constructor(trackId, sampleRate, channels, cacheDir, maxBytes) {
        this.trackId = trackId;
        this.sampleRate = sampleRate;
        this.channels = channels;
        this.downloadedBytes = 0;
        this.totalBytes = null; // set once the server reports the track's real remaining size
        this.maxBytes = maxBytes;
        this.filePath = path.join(cacheDir, `nova_trackbuf_${Date.now()}_${process.hrtime.bigint()}_${hashTrackId(trackId)}.pcm`);
        this.writeFd = fs.openSync(this.filePath, 'w+');
        this.readFd = fs.openSync(this.filePath, 'r');
        this.closed = false;
    }

    /** Appends bytes to the end of the file. Returns false (and logs) if this would exceed the safety cap — caller should treat that as "stop downloading," not retry. */
    append(buffer, logFn) {
        if (this.closed) return false;
        const needed = this.downloadedBytes + buffer.length;
        if (needed > this.maxBytes) {
            if (logFn) logFn('TrackBuffer', `append() for trackId=${this.trackId} would exceed the ${this.maxBytes} byte safety cap (needed=${needed}) — dropping this append rather than risk filling disk. This should not happen in normal operation.`);
            return false;
        }
        fs.writeSync(this.writeFd, buffer, 0, buffer.length, this.downloadedBytes);
        this.downloadedBytes += buffer.length;
        return true;
    }

    /**
     * Real, direct port of the exact fix that resolved a confirmed
     * "audio skipped back, sounded worse quality" bug on the Android side —
     * a download attempt that fails partway through must not leave its
     * partial bytes permanently in the file, or a retry appends its own
     * full copy right after the leftover partial one, duplicating audio.
     * Called from the download retry loop's own catch block, rewinding the
     * file back to exactly where it stood before the failed attempt began.
     */
    truncateTo(bytes) {
        if (this.closed) return;
        if (bytes >= this.downloadedBytes) return; // nothing to roll back
        this.downloadedBytes = bytes;
        fs.ftruncateSync(this.writeFd, bytes);
    }

    /** Reads exactly `length` bytes starting at `offset`. Caller is responsible for never requesting beyond downloadedBytes. */
    readAt(offset, length) {
        const buf = Buffer.alloc(length);
        let totalRead = 0;
        // A short retry here mirrors the same resilience fix added on the
        // Android side after a "audio cut out, timeline froze" report —
        // treating a single transient read failure as immediately fatal
        // took down an entire playback loop for what could be a momentary
        // hiccup rather than a genuine, persistent problem.
        let lastError = null;
        for (let attempt = 0; attempt < 3; attempt++) {
            try {
                totalRead = fs.readSync(this.readFd, buf, 0, length, offset);
                if (totalRead !== length) throw new Error(`short read: expected ${length} bytes, got ${totalRead}`);
                return buf;
            } catch (e) {
                lastError = e;
            }
        }
        throw lastError || new Error('readAt failed with no captured exception');
    }

    /** Explicit close + delete — a real file needs this, unlike a garbage-collected in-memory buffer. Safe to call more than once. */
    close() {
        if (this.closed) return;
        this.closed = true;
        try { fs.closeSync(this.writeFd); } catch (e) {}
        try { fs.closeSync(this.readFd); } catch (e) {}
        try { fs.unlinkSync(this.filePath); } catch (e) {}
    }
}

function hashTrackId(trackId) {
    let h = 0;
    for (let i = 0; i < trackId.length; i++) { h = (Math.imul(31, h) + trackId.charCodeAt(i)) | 0; }
    return Math.abs(h);
}

module.exports = { TrackBuffer };
