// The desktop's background download over the compressed (nova-z) transport must produce exactly the bytes the plain PCM
// stream gives, from the start and from a resume position, and must fall back cleanly when asked for plain PCM.
const test = require('node:test'), assert = require('node:assert'), fs = require('fs'), os = require('os'), path = require('path'), http = require('http');
const { execFileSync } = require('child_process');
const { encodeFile } = require('../src/toolsCore');
const { DownloadManager } = require('../src/downloadManager');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-dlz-'));
const lib = path.join(tmp, 'Music'), data = path.join(tmp, 'data');
let srv, cookie = '', requests = [];
const get = (url, headers = {}) => new Promise((resolve, reject) => { const u = new URL(url); http.get({ hostname: u.hostname, port: u.port, path: u.pathname + u.search, headers }, (res) => { const c = []; res.on('data', d => c.push(d)); res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(c) })); }).on('error', reject); });

test.before(async () => {
  fs.mkdirSync(lib, { recursive: true });
  execFileSync('ffmpeg', ['-v', 'error', '-y', '-f', 'lavfi', '-i', 'aevalsrc=0.3*sin(2*PI*220*t)+0.1*sin(2*PI*1330*t)+0.05*random(0):d=13:s=48000:c=7.1', '-c:a', 'flac', path.join(tmp, 'a.flac')]);
  await encodeFile({ input: path.join(tmp, 'a.flac'), output: path.join(lib, 'a.nova'), ffmpeg: 'ffmpeg', ffprobe: 'ffprobe' });
  const { startLocalServer } = require('../src/local/localServer');
  srv = await startLocalServer({ dataDir: data, roots: [{ name: 'Music', dir: lib }], ffmpeg: 'ffmpeg', ffprobe: 'ffprobe' });
  const r = await get(srv.entryUrl); cookie = r.headers['set-cookie'][0].split(';')[0];
});
test.after(async () => { require('../src/novaZ').shutdown(); http.globalAgent.destroy(); if (srv) await srv.close(); fs.rmSync(tmp, { recursive: true, force: true }); });

async function download(startAt, zOff) {
  const logs = [];
  const dm = new DownloadManager({ serverOrigin: srv.origin, cacheDir: tmp, maxTrackBytes: 1e9, logFn: (t, m) => logs.push(m), getCookieHeader: async () => cookie });
  if (zOff) dm.zBroken = true;
  dm.startCurrent('t', 'Music/a.nova', 'full', startAt);
  for (let i = 0; i < 400 && !(dm.current && dm.current.isFinished); i++) await new Promise(r => setTimeout(r, 100));
  const e = dm.current; assert.ok(e && e.isFinished, 'download finished: ' + logs.slice(-3).join(' | '));
  const bytes = e.buffer.readAt(0, e.buffer.downloadedBytes);
  const out = { bytes: Buffer.from(bytes), total: e.buffer.totalBytes, logs }; dm.stopCurrent(); return out;
}
for (const startAt of [0, 5]) {
  test(`desktop download over nova-z equals the plain download (start ${startAt}s), whole track across segments`, async () => {
    const plain = await download(startAt, true);
    const z = await download(startAt, false);
    assert.ok(plain.bytes.length > 48000 * 8 * 2 * 5, 'plain download has audio: ' + plain.bytes.length);
    assert.strictEqual(z.bytes.length, plain.bytes.length);
    assert.ok(z.bytes.equals(plain.bytes), 'audio differs');
    assert.strictEqual(z.total, plain.total);
  });
}
