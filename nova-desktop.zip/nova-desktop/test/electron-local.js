// The real Electron app in local-library mode (needs a display, e.g. xvfb-run): first-run choice -> local mode, the library
// window opens when nothing is chosen yet, the real NOVA page loads from the in-app server and plays a chosen song, seeking
// asks the server for the right part, the search finds songs, and the loopback server refuses outsiders.
//   Run: xvfb-run -a node test/electron-local.js
const { _electron: electron } = require(require.resolve('playwright', { paths: ['/opt/npm-tools/node_modules', __dirname] }));
const assert = require('assert'), fs = require('fs'), os = require('os'), path = require('path'), http = require('http');
const { execFileSync } = require('child_process');
const { encodeFile } = require('../src/toolsCore');

const findWindow = async (app, pred, ms = 30000) => { for (let t = 0; t < ms; t += 100) { const w = app.windows().find(pred); if (w) return w; await new Promise((r) => setTimeout(r, 100)); } throw new Error('window not found; windows: ' + app.windows().map((w) => w.url())); };
(async () => {
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-ell-'));
  const profile = path.join(work, 'profile'), music = path.join(work, 'Music');
  fs.mkdirSync(path.join(music, 'Album'), { recursive: true }); fs.mkdirSync(profile, { recursive: true });
  const ff = (...a) => execFileSync('ffmpeg', ['-v', 'error', '-y', ...a]);
  ff('-f', 'lavfi', '-i', 'sine=frequency=330:duration=150:sample_rate=48000', '-ac', '2', '-metadata', 'title=Long Tone', '-metadata', 'artist=Sine', path.join(work, 'long.flac'));
  ff('-f', 'lavfi', '-i', 'sine=frequency=550:duration=5:sample_rate=48000', '-ac', '2', '-metadata', 'title=Short Tone', '-metadata', 'artist=Sine', path.join(work, 'short.flac'));
  await encodeFile({ input: path.join(work, 'long.flac'), output: path.join(music, 'Album', 'long.nova'), ffmpeg: 'ffmpeg', ffprobe: 'ffprobe' });
  await encodeFile({ input: path.join(work, 'short.flac'), output: path.join(music, 'Album', 'short.nova'), ffmpeg: 'ffmpeg', ffprobe: 'ffprobe' });

  const launch = () => electron.launch({ executablePath: path.join(__dirname, '..', 'node_modules', 'electron', 'dist', 'electron'), args: [path.join(__dirname, '..'), '--no-sandbox', '--autoplay-policy=no-user-gesture-required', `--user-data-dir=${profile}`], env: { ...process.env, NOVA_SERVER_ORIGIN: '' } });

  // 1. first start: the picker offers the local library; choosing it restarts the app in local mode
  let app = await launch(); let win = await app.firstWindow(); await win.waitForLoadState('domcontentloaded');
  assert.strictEqual(await win.title(), 'NOVA — Server');
  assert.match(await win.textContent('#local'), /Play files on this computer/);
  const closed = new Promise((r) => app.process().once('exit', r));
  await win.click('#local'); await closed;
  assert.deepStrictEqual(JSON.parse(fs.readFileSync(path.join(profile, 'server.json'), 'utf8')), { mode: 'local' });
  console.log('first start: "Play files on this computer" stored');

  // 2. local mode with nothing chosen yet: the library window opens by itself, and adding a folder works
  app = await launch();
  const lib = await findWindow(app, (w) => w.url().endsWith('localLibrary.html'));
  await lib.waitForLoadState('domcontentloaded');
  assert.match(await lib.textContent('#list'), /Nothing here yet/);
  assert.deepStrictEqual(await lib.evaluate(() => window.novaLibrary.list()), []);
  // "Add folder…" for real (the native dialog is replaced by one that answers with our folder), while the main page is open
  const main0 = await findWindow(app, (w) => w.url().startsWith('http://127.0.0.1:'));
  await main0.waitForSelector('#breadcrumbs .crumb', { timeout: 20000 });
  assert.strictEqual(await main0.locator('#dirList .dirRow').count(), 0, 'empty library: nothing to browse yet');
  await app.evaluate(({ dialog }, folder) => { dialog.showOpenDialog = async () => ({ canceled: false, filePaths: [folder] }); }, music);
  await lib.click('#addFolder');
  await lib.waitForFunction(() => /Music/.test(document.getElementById('list').textContent));
  await main0.waitForSelector('#dirList .dirRow', { timeout: 20000 }); // the open page picked it up without a restart
  // and a hand-picked file goes into "Selected files"
  await app.evaluate(({ dialog }, f) => { dialog.showOpenDialog = async () => ({ canceled: false, filePaths: [f] }); }, path.join(work, 'short.flac'));
  await lib.click('#addFiles');
  await lib.waitForFunction(() => /Selected files/.test(document.getElementById('list').textContent));
  assert.deepStrictEqual((await lib.evaluate(() => window.novaLibrary.list())).map((r) => r.name), ['Music', 'Selected files']);
  await lib.locator('button', { hasText: 'Remove' }).nth(1).click(); // remove it again
  await lib.waitForFunction(() => !/Selected files/.test(document.getElementById('list').textContent));
  assert.deepStrictEqual(JSON.parse(fs.readFileSync(path.join(profile, 'local-library.json'), 'utf8')).roots.map((r) => r.name), ['Music']);
  await app.close();

  // 3. with a folder chosen: the real page loads from the in-app server and plays
  app = await launch();
  const page = await (async () => { for (let i = 0; i < 100; i++) { const w = app.windows().find((x) => x.url().startsWith('http://127.0.0.1:')); if (w) return w; await new Promise((r) => setTimeout(r, 100)); } throw new Error('no local window; windows: ' + app.windows().map((w) => w.url())); })();
  await page.waitForSelector('#dirList .dirRow', { timeout: 20000 });
  assert.ok(!app.windows().some((w) => w.url().endsWith('localLibrary.html')), 'no library window once something is chosen');
  const origin = new URL(page.url()).origin;
  assert.deepStrictEqual(await page.$$eval('#dirList .dirRow', (e) => e.map((x) => x.textContent.trim())), ['📁 Music']);
  assert.strictEqual(await page.evaluate(() => window.novaDesktop.isLocalLibrary), true);
  await page.click('#dirList .dirRow'); await page.waitForFunction(() => /Album/.test(document.getElementById('dirList').textContent));
  await page.click('#dirList .dirRow');
  await page.waitForSelector('#trackList .track-row', { timeout: 20000 });
  const names = await page.$$eval('#trackList .track-row', (e) => e.length);
  assert.strictEqual(names, 2);
  // tags come from the files
  await page.waitForFunction(() => /Long Tone/.test(document.getElementById('trackList').textContent), null, { timeout: 20000 });
  // play the first one (double click like the page expects)
  const pcmRequests = []; page.on('request', (r) => { if (r.url().includes('/api/stream/pcm')) pcmRequests.push(r.url()); });
  await page.locator('#trackList .track-row', { hasText: 'Long Tone' }).dblclick();
  await page.waitForFunction(() => document.getElementById('timeTotal').textContent.replace(/\s/g, '') !== '' && document.getElementById('timeTotal').textContent !== '0:00', null, { timeout: 30000 });
  assert.match(await page.textContent('#timeTotal'), /2:30/);
  await page.waitForFunction(() => { const t = document.getElementById('timeCurrent').textContent; return /^0:0[1-9]/.test(t); }, null, { timeout: 30000 });
  console.log('playing:', await page.textContent('#npTextInfo'), await page.textContent('#timeCurrent') + ' / ' + await page.textContent('#timeTotal'));
  assert.ok(pcmRequests.length >= 1);
  // seek to the middle with the seek bar, as a user would (the page's own handlers)
  const before = pcmRequests.length;
  await page.evaluate(() => { const b = document.getElementById('seekBar'); b.value = Math.round((+b.max || 1000) * 0.8); b.dispatchEvent(new Event('pointerdown')); b.dispatchEvent(new Event('input')); b.dispatchEvent(new Event('pointerup')); b.dispatchEvent(new Event('change')); });
  await page.waitForFunction(() => { const [m, s] = document.getElementById('timeCurrent').textContent.split(':').map(Number); return m * 60 + s >= 119; }, null, { timeout: 30000 });
  console.log('after seek:', await page.textContent('#timeCurrent'), '(' + (pcmRequests.length - before) + ' new stream request(s))');
  assert.ok(pcmRequests.slice(before).some((u) => /skipToSeconds=(60|1\d\d)/.test(u)), 'the seek asked the server for the later part (the player fetches 60 s segments): ' + pcmRequests.slice(before).join(' '));
  // the queue, shuffle and repeat controls the server page has are all there
  for (const id of ['queueToggleBtn', 'shuffleBtn', 'repeatBtn', 'prevBtn', 'nextBtn']) assert.ok(await page.$('#' + id), id);
  // search through the whole local library
  await page.fill('#searchBox', 'short'); await page.waitForFunction(() => /Short Tone/.test(document.getElementById('trackList').textContent), null, { timeout: 20000 });
  // settings: shows the local library and the button to choose folders
  await page.fill('#searchBox', ''); await page.click('#settingsToggle');
  assert.match(await page.textContent('#serverCurrent'), /This computer/);
  assert.strictEqual(await page.isVisible('#libraryManageBtn'), true);
  await page.click('#libraryManageBtn');
  await findWindow(app, (w) => w.url().endsWith('localLibrary.html'));
  // outsiders
  const status = (p, headers) => new Promise((res) => http.get(origin + p, { headers }, (r) => { r.resume(); res(r.statusCode); }));
  assert.strictEqual(await status('/api/browse?path='), 403, 'a request without the app\'s key is refused');
  assert.strictEqual(await status('/api/browse?path=', { Host: 'evil.example' }), 403);
  // the log has the story
  const log = fs.readFileSync(path.join(profile, 'nova.log'), 'utf8');
  assert.match(log, /\[LOCAL\] Local library serving http:\/\/127\.0\.0\.1:\d+/);
  console.log('local library in the real app: OK');
  await app.close();
  fs.rmSync(work, { recursive: true, force: true });
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
