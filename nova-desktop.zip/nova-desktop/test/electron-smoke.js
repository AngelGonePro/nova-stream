// Launches the real Electron app (needs a display, e.g. xvfb-run) with a throwaway profile and checks:
// first start asks for a server, a bad address is refused, a good one is stored and the app restarts with it,
// and Library Tools opens.   Run: xvfb-run -a node test/electron-smoke.js
const { _electron: electron } = require(require.resolve('playwright', { paths: ['/opt/npm-tools/node_modules', __dirname] }));
const assert = require('assert'), fs = require('fs'), os = require('os'), path = require('path');
(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-el-'));
  const launch = () => electron.launch({ executablePath: path.join(__dirname, '..', 'node_modules', 'electron', 'dist', 'electron'), args: [path.join(__dirname, '..'), '--no-sandbox', `--user-data-dir=${profile}`], env: { ...process.env, NOVA_SERVER_ORIGIN: '' } });
  let app = await launch();
  let win = await app.firstWindow();
  await win.waitForLoadState('domcontentloaded');
  assert.strictEqual(await win.title(), 'NOVA — Server');
  assert.strictEqual(await win.inputValue('#addr'), '');
  assert.strictEqual(await win.textContent('#cancel'), 'Quit');
  await win.fill('#addr', 'not a server'); await win.click('#ok');
  await win.waitForFunction(() => document.getElementById('err').textContent.length > 0);
  await win.fill('#addr', 'http://plain.example.com'); await win.click('#ok');
  assert.match(await win.textContent('#err'), /https/);
  const closed = new Promise((r) => app.process().once('exit', r));
  await win.fill('#addr', 'music.example.org/'); await win.click('#ok');
  await closed;
  const saved = JSON.parse(fs.readFileSync(path.join(profile, 'server.json'), 'utf8'));
  assert.strictEqual(saved.origin, 'https://music.example.org');
  console.log('first start: picker validated and stored', saved.origin);

  // second start: the stored address is used, no picker (the page itself cannot load - no such host - but the window targets it)
  app = await launch();
  win = await app.firstWindow();
  await win.waitForTimeout(1500);
  const urls = app.windows().map((w) => w.url());
  assert.ok(!urls.some((u) => u.endsWith('serverPicker.html')), 'no picker once a server is stored: ' + urls);
  // Library Tools via the menu
  await app.evaluate(({ Menu }) => { const nova = Menu.getApplicationMenu().items.find((i) => i.label === 'NOVA'); nova.submenu.items.find((i) => i.label === 'Library Tools…').click(); });
  const tools = await app.waitForEvent('window', { predicate: (w) => w.url().endsWith('tools.html') });
  await tools.waitForLoadState('domcontentloaded');
  assert.strictEqual(await tools.evaluate(() => typeof window.novaTools.queueAdd), 'function');
  const d = await tools.evaluate(() => window.novaTools.defaults());
  assert.ok(d.cores >= 1 && d.threads >= 1);
  console.log('library tools opened; ffmpegOk =', d.ffmpegOk);
  // Real conversion through the real IPC and the real queue: FLAC -> NOVA, with one file added while the queue runs
  const { execFileSync } = require('child_process');
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-el-work-'));
  execFileSync('ffmpeg', ['-v', 'error', '-f', 'lavfi', '-i', 'sine=frequency=500:duration=3:sample_rate=48000', '-ac', '2', path.join(work, 'tone.flac')]);
  execFileSync('ffmpeg', ['-v', 'error', '-f', 'lavfi', '-i', 'sine=frequency=700:duration=2:sample_rate=48000', '-ac', '2', path.join(work, 'tone2.flac')]);
  const q = await tools.evaluate(async ({ a, b, out }) => {
    const states = [];
    window.novaTools.onState((s) => states.push({ state: s.state, counts: s.counts, overall: s.overall.frac }));
    const r1 = await window.novaTools.queueAdd({ kind: 'encode', items: [{ path: a, rel: 'tone.flac' }], settings: { outputDir: out, verify: true, highCompression: false } });
    await window.novaTools.queueDo({ action: 'threads', n: 1 });
    await window.novaTools.queueDo({ action: 'start' });
    const r2 = await window.novaTools.queueAdd({ kind: 'encode', items: [{ path: b, rel: 'tone2.flac' }], settings: { outputDir: out, verify: false, highCompression: true } });
    for (let i = 0; i < 300; i++) { const s = await window.novaTools.queueGet(); if (s.state === 'idle' && s.counts.done === 2) return { r1, r2, final: s, seen: states.length }; await new Promise((r) => setTimeout(r, 100)); }
    return { r1, r2, final: await window.novaTools.queueGet(), seen: states.length };
  }, { a: path.join(work, 'tone.flac'), b: path.join(work, 'tone2.flac'), out: path.join(work, 'out') });
  assert.deepStrictEqual([q.r1.added, q.r2.added], [1, 1]);
  assert.strictEqual(q.final.counts.done, 2, JSON.stringify(q.final.counts));
  assert.ok(q.seen > 2, 'state updates were pushed to the window');
  assert.ok(fs.statSync(path.join(work, 'out', 'tone.nova')).size > 1000 && fs.statSync(path.join(work, 'out', 'tone2.nova')).size > 1000);
  const logText = fs.readFileSync(path.join(profile, 'nova.log'), 'utf8');
  assert.match(logText, /\[TOOLS\] #\d+ exec: .*ffprobe.* -show_streams/, 'every program launch is in the app log');
  assert.match(logText, /\[TOOLS\] queue: start/);
  console.log('real queue (2 files, one added while running) through the app: OK');
  // Change Server from the menu opens the picker with the current value
  await app.evaluate(({ Menu }) => { const nova = Menu.getApplicationMenu().items.find((i) => i.label === 'NOVA'); nova.submenu.items.find((i) => i.label === 'Change Server…').click(); });
  const picker = await app.waitForEvent('window', { predicate: (w) => w.url().endsWith('serverPicker.html') });
  await picker.waitForFunction(() => document.getElementById('addr').value.length > 0);
  assert.strictEqual(await picker.inputValue('#addr'), 'https://music.example.org');
  assert.strictEqual(await picker.textContent('#cancel'), 'Cancel');
  console.log('change server: picker pre-filled');
  await app.close();
  console.log('OK');
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
