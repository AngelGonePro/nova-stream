// The Local library: the real NOVA server running inside the app over folders/files on this computer.
const test = require('node:test'), assert = require('node:assert'), fs = require('fs'), os = require('os'), path = require('path'), http = require('http');
const { execFileSync, spawnSync } = require('child_process');
const { encodeFile } = require('../src/toolsCore');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-local-'));
const lib = path.join(tmp, 'Music'), data = path.join(tmp, 'data');
const ff = (...a) => execFileSync('ffmpeg', ['-v', 'error', '-y', ...a]);
let srv = null;

const get = (url, { headers = {}, host } = {}) => new Promise((resolve, reject) => {
  const u = new URL(url);
  http.get({ hostname: u.hostname, port: u.port, path: u.pathname + u.search, headers: { ...(host ? { Host: host } : {}), ...headers } }, (res) => {
    const chunks = []; res.on('data', (d) => chunks.push(d)); res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
  }).on('error', reject);
});
const send = (method, url, body, cookie) => new Promise((resolve, reject) => {
  const u = new URL(url); const data = JSON.stringify(body || {});
  const r = http.request({ method, hostname: u.hostname, port: u.port, path: u.pathname, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data), Cookie: cookie } }, (res) => {
    const chunks = []; res.on('data', (d) => chunks.push(d)); res.on('end', () => resolve({ status: res.statusCode, json: (() => { try { return JSON.parse(Buffer.concat(chunks)); } catch (e) { return null; } })() }));
  }); r.on('error', reject); r.end(data);
});

test.before(async () => {
  fs.mkdirSync(path.join(lib, 'Album One'), { recursive: true }); fs.mkdirSync(path.join(tmp, 'other'), { recursive: true });
  ff('-f', 'lavfi', '-i', 'color=c=blue:s=64x64:d=1', '-frames:v', '1', path.join(tmp, 'cover.jpg'));
  ff('-f', 'lavfi', '-i', 'sine=frequency=330:duration=6:sample_rate=48000', '-f', 'lavfi', '-i', 'anoisesrc=d=6:c=pink:r=48000:a=0.05', '-filter_complex', '[0][1]amix=inputs=2,pan=5.1|c0=c0|c1=c1|c2=c0|c3=c1|c4=c0|c5=c1[a]', '-map', '[a]', '-c:a', 'flac', path.join(tmp, 'six.tmp.flac'));
  ff('-i', path.join(tmp, 'six.tmp.flac'), '-i', path.join(tmp, 'cover.jpg'), '-map', '0:a', '-map', '1:v', '-c:a', 'flac', '-c:v', 'copy', '-disposition:v', 'attached_pic', '-metadata', 'title=Six Channels', '-metadata', 'artist=Tester', '-metadata', 'album=Local Album', path.join(tmp, 'six.flac'));
  ff('-f', 'lavfi', '-i', 'sine=frequency=500:duration=3:sample_rate=44100', '-ac', '2', path.join(tmp, 'tone.flac'));
  const ctx = { ffmpeg: 'ffmpeg', ffprobe: 'ffprobe' };
  await encodeFile({ input: path.join(tmp, 'six.flac'), output: path.join(lib, 'Album One', 'six.nova'), ...ctx });
  await encodeFile({ input: path.join(tmp, 'tone.flac'), output: path.join(tmp, 'other', 'tone.nova'), ...ctx });
  fs.copyFileSync(path.join(tmp, 'tone.flac'), path.join(tmp, 'other', 'plain.flac'));
  const { startLocalServer } = require('../src/local/localServer');
  srv = await startLocalServer({ dataDir: data, roots: [{ name: 'Music', dir: lib }, { name: 'Picked files', files: [path.join(tmp, 'other', 'tone.nova'), path.join(tmp, 'other', 'plain.flac')] }], ffmpeg: 'ffmpeg', ffprobe: 'ffprobe' });
});
test.after(async () => { if (srv) await srv.close(); fs.rmSync(tmp, { recursive: true, force: true }); });

let cookie = '';
test('only the app itself gets in: no key, wrong key and a foreign Host header are refused; the entry URL signs in', async () => {
  assert.strictEqual((await get(srv.origin + '/api/browse')).status, 403);
  assert.strictEqual((await get(srv.origin + '/__nova_local?k=wrong')).status, 403);
  assert.strictEqual((await get(srv.entryUrl, { host: 'evil.example:' + srv.port })).status, 403, 'DNS-rebinding style Host header');
  const r = await get(srv.entryUrl);
  assert.strictEqual(r.status, 302); assert.strictEqual(r.headers.location, '/');
  const set = r.headers['set-cookie'][0]; assert.match(set, /HttpOnly/); assert.match(set, /SameSite=Strict/);
  cookie = set.split(';')[0];
  const page = await get(srv.origin + '/', { headers: { Cookie: cookie } });
  assert.strictEqual(page.status, 200); assert.match(page.body.toString(), /<title>/i);
});
const api = async (p) => { const r = await get(srv.origin + p, { headers: { Cookie: cookie } }); return { status: r.status, headers: r.headers, body: r.body, json: () => JSON.parse(r.body) }; };

test('signed in automatically; library lists the chosen folders and files with the server\'s own API', async () => {
  const me = (await api('/api/auth/me')).json(); assert.strictEqual(me.username, 'This computer');
  const top = (await api('/api/browse?path=')).json();
  assert.deepStrictEqual(top.dirs.map((d) => d.name).sort(), ['Music', 'Picked files']);
  const album = (await api('/api/browse?path=' + encodeURIComponent('Music/Album One'))).json();
  assert.deepStrictEqual(album.files.map((f) => f.path), ['Music/Album One/six.nova']);
  const picked = (await api('/api/browse?path=' + encodeURIComponent('Picked files'))).json();
  assert.deepStrictEqual(picked.files.map((f) => f.name).sort(), ['plain.flac', 'tone.nova']);
  assert.strictEqual((await api('/api/browse?path=' + encodeURIComponent('Music/../Picked files'))).status, 400);
  const tags = (await api('/api/browse/tags?path=' + encodeURIComponent('Music/Album One/six.nova'))).json();
  assert.deepStrictEqual([tags.title, tags.artist, tags.album, tags.numChannels], ['Six Channels', 'Tester', 'Local Album', 6]);
  const art = await api('/api/browse/artwork?path=' + encodeURIComponent('Music/Album One/six.nova'));
  assert.strictEqual(art.status, 200); assert.match(art.headers['content-type'], /image\/jpeg/);
  const flacTags = (await api('/api/browse/tags?path=' + encodeURIComponent('Picked files/plain.flac'))).json();
  assert.strictEqual(flacTags.numChannels, 2, 'non-NOVA files are read through the bundled ffprobe');
});

test('playback: a .nova decodes to 16-bit PCM, and seeking (skipToSeconds) lands on exactly the same samples as playing from the start', { timeout: 120000 }, async () => {
  const p = encodeURIComponent('Music/Album One/six.nova');
  const whole = await api(`/api/stream/pcm?path=${p}&quality=full`);
  assert.strictEqual(whole.status, 200);
  assert.deepStrictEqual([whole.headers['x-pcm-channels'], whole.headers['x-pcm-sample-rate']], ['6', '48000']);
  assert.strictEqual(whole.body.length, 6 * 2 * 48000 * 6, 'six seconds of 6 channels at 16 bit');
  const seek = await api(`/api/stream/pcm?path=${p}&quality=full&skipToSeconds=3`);
  const skip = parseInt(seek.headers['x-pcm-skip-samples'] || '0', 10);
  assert.ok(skip > 0 && skip <= 3 * 48000, 'skip reported: ' + skip);
  assert.ok(whole.body.subarray(skip * 12).equals(seek.body), 'seeked audio equals the same part of the whole song');
  const seg = await api(`/api/stream/pcm?path=${p}&quality=full&skipToSeconds=1&maxDurationSeconds=2`);
  assert.ok(seg.body.length > 0 && seg.body.length <= 2 * 48000 * 12 + 4096 * 12);
  const tone = await api('/api/stream/pcm?path=' + encodeURIComponent('Picked files/tone.nova') + '&quality=full');
  assert.strictEqual(tone.headers['x-pcm-channels'], '2');
  const flac = await api('/api/stream/pcm?path=' + encodeURIComponent('Picked files/plain.flac') + '&quality=full');
  assert.strictEqual(flac.status, 200); assert.ok(flac.body.length > 3 * 44100 * 4 * 0.9, 'a FLAC plays too (ffmpeg path)');
});

test('playlists and the saved queue/position work and are stored on disk', async () => {
  const pl = await send('POST', srv.origin + '/api/playlists', { name: 'Mine' }, cookie); assert.strictEqual(pl.status, 200);
  const add = await send('POST', srv.origin + `/api/playlists/${pl.json.id}/tracks`, { trackPath: 'Music/Album One/six.nova' }, cookie);
  assert.deepStrictEqual(add.json.trackPaths, ['Music/Album One/six.nova']);
  assert.strictEqual((await send('POST', srv.origin + `/api/playlists/${pl.json.id}/tracks`, { trackPath: 'Music/nope.nova' }, cookie)).status, 400);
  const st = await send('POST', srv.origin + '/api/state', { trackId: 'Music/Album One/six.nova', positionSeconds: 2.5, queue: ['Music/Album One/six.nova', 'Picked files/tone.nova'], queuePos: 0, repeatMode: 'all', shuffleEnabled: true }, cookie);
  assert.strictEqual(st.status, 200);
  const back = (await api('/api/state')).json();
  assert.deepStrictEqual([back.trackId, back.positionSeconds, back.queue.length, back.repeatMode, back.shuffleEnabled], ['Music/Album One/six.nova', 2.5, 2, 'all', true]);
  srv.flush();
  assert.ok(fs.statSync(path.join(data, 'local.sqlite')).size > 1000, 'database file written');
});

test('everything survives a restart (separate process): playlists, saved state, and a new folder added at run time shows up', { timeout: 60000 }, async () => {
  const code = `
    (async () => {
      const { startLocalServer } = require(${JSON.stringify(path.join(__dirname, '..', 'src', 'local', 'localServer'))});
      const http = require('http');
      const s = await startLocalServer({ dataDir: ${JSON.stringify(data)}, roots: [{ name: 'Music', dir: ${JSON.stringify(lib)} }], ffmpeg: 'ffmpeg', ffprobe: 'ffprobe' });
      const j = (path, cookie) => new Promise((res) => http.get({ hostname: '127.0.0.1', port: s.port, path, headers: { Cookie: cookie } }, (r) => { const c = []; r.on('data', (d) => c.push(d)); r.on('end', () => res(JSON.parse(Buffer.concat(c)))); }));
      const cookie = await new Promise((res) => http.get({ hostname: '127.0.0.1', port: s.port, path: '/__nova_local?k=' + s.key }, (r) => res(r.headers['set-cookie'][0].split(';')[0])));
      const out = { port: s.port, playlists: await j('/api/playlists', cookie), state: await j('/api/state', cookie), top1: (await j('/api/browse?path=', cookie)).dirs.map((d) => d.name) };
      s.setRoots([{ name: 'Music', dir: ${JSON.stringify(lib)} }, { name: 'Added later', dir: ${JSON.stringify(path.join(tmp, 'other'))} }]);
      out.top2 = (await j('/api/browse?path=', cookie)).dirs.map((d) => d.name);
      console.log('RESULT' + JSON.stringify(out)); await s.close(); process.exit(0);
    })().catch((e) => { console.error(e); process.exit(1); });`;
  const firstPort = srv.port;
  await srv.close(); srv = null;
  const r = spawnSync(process.execPath, ['-e', code], { encoding: 'utf8', timeout: 50000 });
  assert.strictEqual(r.status, 0, r.stderr);
  const out = JSON.parse(r.stdout.split('RESULT')[1]);
  assert.strictEqual(out.port, firstPort, 'same address after a restart, so the page keeps its own settings (localStorage is per address)');
  assert.deepStrictEqual(out.playlists.map((p) => [p.name, p.trackCount]), [['Mine', 1]]);
  assert.strictEqual(out.state.trackId, 'Music/Album One/six.nova'); assert.strictEqual(out.state.queue.length, 2);
  assert.deepStrictEqual(out.top1, ['Music']); assert.deepStrictEqual(out.top2, ['Added later', 'Music']);
});
