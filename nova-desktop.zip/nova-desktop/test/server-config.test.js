const test = require('node:test'), assert = require('node:assert'), fs = require('fs'), os = require('os'), path = require('path');
const sc = require('../src/serverConfig');
const { scanFolder } = require('../src/toolsPlan');
const { ToolsQueue } = require('../src/toolsQueue');

test('server addresses are normalised to https://host[:port] and anything else is refused', () => {
  const ok = { 'music.example.com': 'https://music.example.com', 'https://Music.Example.com/': 'https://music.example.com', ' https://h.example:8443/a/b?x=1 ': 'https://h.example:8443', 'https://h.example:443': 'https://h.example', 'localhost': 'https://localhost' };
  for (const [i, o] of Object.entries(ok)) assert.strictEqual(sc.normalize(i), o, i);
  for (const bad of ['', '   ', 'http://plain.example.com', 'ftp://x.example.com', 'nodots', 'https://user:pw@x.example.com', 'not a server', null, undefined]) assert.strictEqual(sc.normalize(bad), null, String(bad));
});
test('the chosen server is stored in the profile and read back; a corrupt file counts as "not chosen"', () => {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-sc-'));
  assert.strictEqual(sc.load(d), null);
  assert.strictEqual(sc.save(d, 'my.host.net/'), 'https://my.host.net');
  assert.strictEqual(sc.load(d), 'https://my.host.net');
  assert.throws(() => sc.save(d, 'http://nope.example.com'));
  assert.strictEqual(sc.load(d), 'https://my.host.net', 'a refused address leaves the stored one alone');
  fs.writeFileSync(path.join(d, 'server.json'), '{oops'); assert.strictEqual(sc.load(d), null);
});
test('"use files on this computer" is stored as a mode, remembers the last server, and choosing a server again switches back', () => {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-sc2-'));
  assert.strictEqual(sc.loadChoice(d), null);
  sc.save(d, 'music.example.org');
  assert.deepStrictEqual(sc.loadChoice(d), { kind: 'server', origin: 'https://music.example.org' });
  sc.saveLocal(d);
  assert.deepStrictEqual(sc.loadChoice(d), { kind: 'local' });
  assert.strictEqual(sc.load(d), 'https://music.example.org', 'the server address is still remembered');
  sc.save(d, 'other.example.org');
  assert.deepStrictEqual(sc.loadChoice(d), { kind: 'server', origin: 'https://other.example.org' });
  const d2 = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-sc3-')); sc.saveLocal(d2);
  assert.deepStrictEqual(sc.loadChoice(d2), { kind: 'local' }); assert.strictEqual(sc.load(d2), null);
});
test('queue planning: output location, sub-folders kept, name clashes avoided, finished files skipped, never overwrites the source', () => {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-plan-'));
  fs.mkdirSync(path.join(d, 'Album')); for (const f of ['a.flac', 'a.wav', 'Album/b.FLAC', 'Album/readme.txt']) fs.writeFileSync(path.join(d, f), 'x');
  const found = scanFolder(d, 'audio');
  assert.strictEqual(found.length, 3);
  const plan = (kind, items, settings) => { const q = new ToolsQueue({ log: () => {} }); const r = q.add(kind, items, settings); return { r, jobs: q.snapshot().jobs }; };
  const beside = plan('encode', found, {}).jobs.map((j) => path.relative(d, j.output)).sort();
  assert.deepStrictEqual(beside, [path.join('Album', 'b.nova'), 'a (2).nova', 'a.nova'].sort(), 'a.flac and a.wav both become a.nova: the second gets a different name');
  const out = path.join(d, 'out');
  const into = plan('encode', found, { outputDir: out }).jobs.map((j) => path.relative(out, j.output)).sort();
  assert.ok(into.includes(path.join('Album', 'b.nova')), 'sub-folders are kept under the output folder');
  fs.mkdirSync(path.join(out, 'Album'), { recursive: true }); fs.writeFileSync(path.join(out, 'Album', 'b.nova'), 'done');
  const again = plan('encode', found, { outputDir: out, skipExisting: true });
  assert.strictEqual(again.r.skipped, 1); assert.strictEqual(again.jobs.filter((j) => j.status === 'queued').length, 2);
  const dec = plan('decode', [{ path: path.join(d, 'x.wav') }], { format: 'wav' }).jobs[0];
  assert.notStrictEqual(dec.output, path.join(d, 'x.wav'), 'decoding x.wav to wav next to itself must not overwrite the input');
});
