// The real Library Tools page in Chromium, wired to a REAL ToolsQueue (real workers, real ffmpeg) instead of a stand-in:
// add files with different options, add more while running, reorder/remove, pause, stop, retry, overall progress.
const test = require('node:test'), assert = require('node:assert'), fs = require('fs'), os = require('os'), path = require('path');
const { execFileSync } = require('child_process');
const { ToolsQueue } = require('../src/toolsQueue');
const { scanFolder } = require('../src/toolsPlan');
let chromium = null;
for (const p of ['playwright', 'playwright-core', '/opt/npm-tools/node_modules/playwright', '/home/claude/nova-server/node_modules/playwright']) { try { ({ chromium } = require(p)); break; } catch (e) {} }

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-qui-'));
const ff = (...a) => execFileSync('ffmpeg', ['-v', 'error', '-y', ...a]);
test.before(() => {
  for (const [n, d] of [['a', 2], ['b', 5], ['c', 2]]) ff('-f', 'lavfi', '-i', `sine=frequency=${300 + d * 50}:duration=${d}:sample_rate=48000`, '-ac', '2', path.join(tmp, n + '.flac'));
});
test.after(() => fs.rmSync(tmp, { recursive: true, force: true }));

async function openPage(browser, queue, picks) {
  const page = await browser.newPage(); const errors = [];
  page.on('pageerror', (e) => errors.push(e.message)); page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await page.exposeFunction('__host', async (name, arg) => {
    switch (name) {
      case 'get': return queue.snapshot();
      case 'add': return queue.add(arg.kind, arg.items, arg.settings);
      case 'do': { const q = queue; switch (arg.action) { case 'start': q.start(); break; case 'pause': q.pause(); break; case 'stop': q.stop(); break; case 'threads': q.setThreads(arg.n); break; case 'remove': q.remove(arg.id); break; case 'move': q.move(arg.id, arg.to); break; case 'retry': q.retry(arg.id); break; case 'retryFailed': q.retryFailed(); break; case 'clearFinished': q.clearFinished(); break; } return { ok: true }; }
      case 'pickFiles': return picks.files.shift() || [];
      case 'pickFolder': return picks.folders.shift() || null;
      case 'pickOutputDir': return picks.out;
    }
  });
  queue.on('state', (s) => { page.evaluate((x) => window.__push(x), s).catch(() => {}); });
  await page.addInitScript(`(() => { const l = []; window.__push = (s) => l.forEach((f) => f(s));
    window.novaTools = { defaults: async () => ({ cores: 4, threads: 2, ffmpegOk: true }), pickFiles: (k) => __host('pickFiles', k), pickFolder: (k) => __host('pickFolder', k), pickOutputDir: () => __host('pickOutputDir'),
      queueGet: () => __host('get'), queueAdd: (r) => __host('add', r), queueDo: (r) => __host('do', r), onState: (cb) => { l.push(cb); return () => {}; },
      readTags: async () => [], playOpen: async () => ({ ok: false, error: 'n/a' }), playCredit() {}, playStop: async () => ({ ok: true }), onPlay: () => () => {} }; })();`);
  await page.goto('file://' + path.join(__dirname, '..', 'src', 'tools.html'));
  return { page, errors };
}
const rows = (page, list) => page.locator(list + ' .row').evaluateAll((rs) => rs.map((r) => ({ cls: r.className, name: r.querySelector('.name').firstChild.textContent, status: r.querySelector('.status').textContent, small: r.querySelector('small').textContent })));

test('queue UI: options are kept per file, files can be added while running, reorder/remove/pause/stop/retry, overall bar', { skip: !chromium, timeout: 180000 }, async () => {
  const browser = await chromium.launch();
  const out = path.join(tmp, 'out');
  const q = new ToolsQueue({ threads: 1, log: () => {} });
  const A = { path: path.join(tmp, 'a.flac'), rel: 'a.flac' }, B = { path: path.join(tmp, 'b.flac'), rel: 'b.flac' }, C = { path: path.join(tmp, 'c.flac'), rel: 'c.flac' };
  const { page, errors } = await openPage(browser, q, { files: [[A], [B], [C]], folders: [], out });
  assert.match(await page.textContent('#qtext'), /Queue is empty/);
  assert.strictEqual(await page.isDisabled('#qStart'), true);

  // 1st file with high compression ON, 2nd with it OFF and a chosen folder
  await page.check('#enHigh'); await page.selectOption('#enOutMode', 'folder');
  await page.click('#enAddFiles'); await page.waitForFunction(() => document.querySelectorAll('#enList .row').length === 1);
  await page.uncheck('#enHigh'); await page.uncheck('#enVerify');
  await page.click('#enAddFiles'); await page.waitForFunction(() => document.querySelectorAll('#enList .row').length === 2);
  let r = await rows(page, '#enList');
  assert.match(r[0].small, /high compression, verified/); assert.match(r[1].small, /standard, not verified/);
  assert.deepStrictEqual(r.map((x) => x.status), ['waiting', 'waiting']);
  assert.match(await page.textContent('#qtext'), /0 of 2 done · 2 waiting/);

  // reorder: move b above a
  await page.locator('#enList .row').nth(1).locator('[data-a=up]').click();
  await page.waitForFunction(() => document.querySelector('#enList .row .name').firstChild.textContent === 'b.flac');
  assert.strictEqual(await page.locator('#enList .row').first().locator('[data-a=up]').isDisabled(), true, 'the first waiting file cannot move up');

  // start, and add a third file while it runs
  await page.click('#qStart');
  await page.waitForFunction(() => document.querySelector('#enList .row.running'));
  await page.click('#enAddFiles');
  await page.waitForFunction(() => document.querySelectorAll('#enList .row').length === 3);
  assert.strictEqual(await page.isDisabled('#qPause'), false);
  // pause: the running job finishes, nothing else starts
  await page.click('#qPause');
  await page.waitForFunction(() => /paused/.test(document.getElementById('qtext').textContent) && !document.querySelector('#enList .row.running'), null, { timeout: 60000 });
  r = await rows(page, '#enList');
  assert.deepStrictEqual(r.map((x) => x.cls.split(' ')[1]), ['done', 'queued', 'queued']);
  assert.strictEqual(await page.textContent('#qStart'), '▶ Resume');
  // remove the last one (c), then resume and finish
  await page.locator('#enList .row').nth(2).locator('[data-a=remove]').click();
  await page.waitForFunction(() => document.querySelectorAll('#enList .row').length === 2);
  await page.click('#qStart');
  await page.waitForFunction(() => /2 of 2 done/.test(document.getElementById('qtext').textContent), null, { timeout: 60000 });
  assert.strictEqual(await page.evaluate(() => document.querySelector('#qoverall > i').style.width), '100%');
  assert.ok(fs.existsSync(path.join(out, 'a.nova')) && fs.existsSync(path.join(out, 'b.nova')));
  assert.ok(!fs.existsSync(path.join(out, 'c.nova')), 'the removed file was not converted');
  r = await rows(page, '#enList');
  assert.ok(r.every((x) => /\(\d+%\)$/.test(x.status)), 'finished rows show the size ratio: ' + JSON.stringify(r.map((x) => x.status)));

  // clear finished
  await page.click('#qClear'); await page.waitForFunction(() => document.querySelectorAll('#enList .row').length === 0);

  // failure + retry: a broken file fails alone, with its message on the row; fixing it and pressing retry works
  const bad = path.join(tmp, 'bad.flac'); fs.writeFileSync(bad, 'nope');
  await q.add('encode', [{ path: bad }], { outputDir: out });
  q.start();
  await page.waitForFunction(() => document.querySelector('#enList .row.failed'));
  assert.match((await rows(page, '#enList'))[0].small, /ffprobe|ffmpeg|audio/i);
  assert.strictEqual(await page.isDisabled('#qRetry'), false);
  fs.copyFileSync(A.path, bad);
  await page.click('#qRetry');
  await page.waitForFunction(() => document.querySelector('#enList .row.done'), null, { timeout: 30000 });

  // decode tab: a .nova file keeps the FLAC/WAV choice made when it was added
  await page.click('.tab[data-tab=decode]');
  await page.selectOption('#deFormat', 'wav');
  await page.evaluate(() => 0);
  const nova = path.join(out, 'a.nova');
  q.add('decode', [{ path: nova }], { outputDir: path.join(tmp, 'dec'), format: 'wav' });
  await page.waitForFunction(() => document.querySelectorAll('#deList .row').length === 1);
  assert.match((await rows(page, '#deList'))[0].small, /\[WAV\]/);
  assert.deepStrictEqual(errors, []);
  await browser.close();
});

test('stop button halts the running job and returns it to the queue', { skip: !chromium, timeout: 120000 }, async () => {
  const browser = await chromium.launch();
  const bin = path.join(tmp, 'fake'); fs.mkdirSync(bin, { recursive: true });
  const pidFile = path.join(tmp, 'p.pid');
  fs.writeFileSync(path.join(bin, 'ffprobe'), '#!/bin/sh\necho \'{"streams":[{"codec_type":"audio"}],"format":{}}\'\n', { mode: 0o755 });
  fs.writeFileSync(path.join(bin, 'ffmpeg'), `#!/bin/sh\necho $$ > ${pidFile}\nexec sleep 120\n`, { mode: 0o755 });
  const q = new ToolsQueue({ threads: 1, ffmpeg: path.join(bin, 'ffmpeg'), ffprobe: path.join(bin, 'ffprobe'), log: () => {} });
  const { page, errors } = await openPage(browser, q, { files: [[{ path: path.join(tmp, 'a.flac'), rel: 'a.flac' }]], folders: [], out: path.join(tmp, 'o2') });
  await page.click('#enAddFiles'); await page.click('#qStart');
  await page.waitForFunction(() => document.querySelector('#enList .row.running'));
  for (let i = 0; i < 100 && !fs.existsSync(pidFile); i++) await new Promise((r) => setTimeout(r, 50));
  const pid = parseInt(fs.readFileSync(pidFile, 'utf8'), 10);
  await page.click('#qStop');
  await page.waitForFunction(() => document.querySelector('#enList .row.queued') && !document.querySelector('#enList .row.running'));
  assert.match((await rows(page, '#enList'))[0].status, /stopped/);
  await new Promise((r) => setTimeout(r, 500));
  assert.throws(() => process.kill(pid, 0), 'the process the queue started is gone');
  assert.deepStrictEqual(errors, []);
  await browser.close();
});
