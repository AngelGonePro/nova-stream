// Real files, real ffmpeg, real worker threads: the conversion queue and the codec round trip.
const test = require('node:test'), assert = require('node:assert'), fs = require('fs'), os = require('os'), path = require('path');
const { execFileSync } = require('child_process');
const { ToolsQueue } = require('../src/toolsQueue');
const NovaCodec = require('../src/novaCodec');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-desk-'));
const ff = (...a) => execFileSync('ffmpeg', ['-v', 'error', '-y', ...a]);
const pcmMd5 = (f) => execFileSync('ffmpeg', ['-v', 'error', '-i', f, '-map', '0:a:0', '-f', 'md5', '-']).toString().trim();
const until = async (cond, ms = 60000, what = 'condition') => { const t0 = Date.now(); while (!cond()) { if (Date.now() - t0 > ms) throw new Error('timed out waiting for ' + what); await new Promise((r) => setTimeout(r, 25)); } };
const mk = (opts = {}) => { const logs = []; const q = new ToolsQueue({ threads: 2, log: (l) => logs.push(l), ...opts }); q.logs = logs; return q; };
const finished = (q) => new Promise((r) => q.once('finished', r));
const byInput = (q, name) => q.snapshot().jobs.find((j) => path.basename(j.input) === name);

test.before(() => {
  ff('-f', 'lavfi', '-i', 'color=c=red:s=64x64:d=1', '-frames:v', '1', path.join(tmp, 'cover.jpg'));
  ff('-f', 'lavfi', '-i', 'sine=frequency=330:duration=4:sample_rate=48000', '-f', 'lavfi', '-i', 'anoisesrc=d=4:c=pink:r=48000:a=0.1', '-filter_complex',
    '[0][1]amix=inputs=2,pan=7.1|c0=c0|c1=c1|c2=c0|c3=c1|c4=c0|c5=c1|c6=c0|c7=c1[a]', '-map', '[a]', '-c:a', 'flac', '-sample_fmt', 's32', path.join(tmp, 'eight.tmp.flac'));
  ff('-i', path.join(tmp, 'eight.tmp.flac'), '-i', path.join(tmp, 'cover.jpg'), '-map', '0:a', '-map', '1:v', '-c:a', 'flac', '-c:v', 'copy', '-disposition:v', 'attached_pic',
    '-metadata', 'title=Eight', '-metadata', 'artist=Tester', '-metadata', 'album=Rooms', path.join(tmp, 'eight.flac'));
  ff('-f', 'lavfi', '-i', 'sine=frequency=440:duration=3:sample_rate=44100', '-c:a', 'flac', '-sample_fmt', 's16', '-ac', '2', path.join(tmp, 'two.flac'));
});
test.after(() => { fs.rmSync(tmp, { recursive: true, force: true }); });

test('FLAC files are encoded to NOVA through the queue, each with its own settings, verified, keeping tags and cover; every launch is logged', { timeout: 240000 }, async () => {
  const q = mk(); const out = path.join(tmp, 'out');
  q.add('encode', [{ path: path.join(tmp, 'eight.flac') }], { outputDir: out, verify: true, highCompression: false });
  q.add('encode', [{ path: path.join(tmp, 'two.flac') }], { outputDir: out, verify: false, highCompression: true }); // different settings, added second
  const done = finished(q); const progress = [];
  q.on('state', (s) => { const j = s.jobs[0]; if (j.status === 'running') progress.push(j.frac); });
  q.start(); const c = await done;
  assert.deepStrictEqual([c.done, c.failed], [2, 0]);
  assert.ok(progress.some((f) => f > 0.1 && f < 0.9), 'progress is reported while encoding');
  const md = NovaCodec.readMetadata(new Uint8Array(fs.readFileSync(path.join(out, 'eight.nova'))));
  assert.strictEqual(md.numChannels, 8); assert.strictEqual(md.bitsPerSample, 24);
  assert.strictEqual(md.tags.title, 'Eight'); assert.strictEqual(md.tags.artist, 'Tester');
  assert.ok(md.picture && md.picture.data.length > 100, 'cover art carried over');
  assert.strictEqual(NovaCodec.readMetadata(new Uint8Array(fs.readFileSync(path.join(out, 'two.nova')))).bitsPerSample, 16);
  // settings captured per job, visible in the log
  const log = q.logs.join('\n');
  assert.match(log, /encode start: .*eight\.flac.*\(highCompression=false, verify=true\)/);
  assert.match(log, /encode start: .*two\.flac.*\(highCompression=true, verify=false\)/);
  assert.match(log, /verify: decoded audio is identical/);
  // every program launch with its full command, every temp file and rename
  assert.match(log, /exec: ffprobe -v error -show_streams -show_format -of json .*eight\.flac/);
  assert.match(log, /exec: ffmpeg -v error -y -i .*eight\.flac -map 0:a:0 -vn -map_metadata -1 -c:a pcm_s24le -f wav /);
  assert.match(log, /exit: ffmpeg code=0/);
  assert.match(log, /temp file: .*\.wav \(ffmpeg writes the decoded WAV here\)/);
  assert.match(log, /rename: .*eight\.nova\.part -> .*eight\.nova/);
  assert.match(log, /delete: .*\.wav/);
  assert.strictEqual(q.snapshot().overall.frac, 1);
  assert.ok(!fs.readdirSync(out).some((f) => f.endsWith('.part')));
});

test('NOVA -> FLAC and NOVA -> WAV reproduce exactly the original samples (the FLAC keeps tags and cover)', { timeout: 240000 }, async () => {
  const q = mk(); const back = path.join(tmp, 'back');
  for (const fmt of ['flac', 'wav']) q.add('decode', ['eight', 'two'].map((n) => ({ path: path.join(tmp, 'out', n + '.nova') })), { outputDir: path.join(back, fmt), format: fmt });
  const done = finished(q); q.start(); const c = await done;
  assert.deepStrictEqual([c.done, c.failed], [4, 0]);
  for (const n of ['eight', 'two']) for (const ext of ['flac', 'wav']) assert.strictEqual(pcmMd5(path.join(back, ext, n + '.' + ext)), pcmMd5(path.join(tmp, n + '.flac')), `${n}.${ext} samples differ from the original`);
  const tags = JSON.parse(execFileSync('ffprobe', ['-v', 'error', '-show_format', '-show_streams', '-of', 'json', path.join(back, 'flac', 'eight.flac')]).toString());
  assert.strictEqual(tags.format.tags.TITLE || tags.format.tags.title, 'Eight');
  assert.ok(tags.streams.some((s) => s.codec_type === 'video'), 'cover art present in the FLAC');
});

test('files can be added while the queue is running, and they run too', { timeout: 120000 }, async () => {
  const q = mk({ threads: 1 }); const out = path.join(tmp, 'live');
  q.add('encode', [{ path: path.join(tmp, 'eight.flac') }], { outputDir: out });
  const done = finished(q); q.start();
  await until(() => q.snapshot().counts.running === 1, 20000, 'first job to start');
  const r = q.add('encode', [{ path: path.join(tmp, 'two.flac') }], { outputDir: out });
  assert.strictEqual(r.added, 1);
  const c = await done;
  assert.strictEqual(c.done, 2);
  assert.ok(fs.existsSync(path.join(out, 'eight.nova')) && fs.existsSync(path.join(out, 'two.nova')));
});

test('queued jobs can be reordered and removed; duplicates and clashing output names are handled', { timeout: 120000 }, async () => {
  const q = mk({ threads: 1 }); const out = path.join(tmp, 'order'); const order = [];
  q.on('state', (s) => { for (const j of s.jobs) if (j.status === 'running' && !order.includes(j.id)) order.push(j.id); });
  fs.mkdirSync(path.join(tmp, 'a')); fs.mkdirSync(path.join(tmp, 'b'));
  fs.copyFileSync(path.join(tmp, 'two.flac'), path.join(tmp, 'a', 'same.flac')); fs.copyFileSync(path.join(tmp, 'two.flac'), path.join(tmp, 'b', 'same.flac'));
  const r1 = q.add('encode', [{ path: path.join(tmp, 'a', 'same.flac') }, { path: path.join(tmp, 'b', 'same.flac') }, { path: path.join(tmp, 'two.flac') }], { outputDir: out });
  assert.strictEqual(r1.added, 3);
  assert.strictEqual(q.add('encode', [{ path: path.join(tmp, 'two.flac') }], { outputDir: out }).duplicates, 1, 'the same waiting file is not queued twice');
  const jobs = q.snapshot().jobs;
  assert.notStrictEqual(jobs[0].output, jobs[1].output, 'two sources with one name get different outputs');
  assert.ok(q.move(jobs[2].id, 0)); // last -> first
  assert.ok(q.remove(jobs[1].id));
  assert.deepStrictEqual(q.snapshot().jobs.map((j) => j.id), [jobs[2].id, jobs[0].id]);
  const done = finished(q); q.start(); await done;
  assert.deepStrictEqual(order, [jobs[2].id, jobs[0].id]);
  assert.ok(!fs.existsSync(jobs[1].output), 'the removed job never ran');
});

test('pause starts no new job; start resumes', { timeout: 120000 }, async () => {
  const q = mk({ threads: 1 }); const out = path.join(tmp, 'pause');
  q.add('encode', [{ path: path.join(tmp, 'eight.flac') }, { path: path.join(tmp, 'two.flac') }], { outputDir: out });
  q.start(); await until(() => q.snapshot().counts.running === 1, 20000, 'start');
  q.pause();
  await until(() => q.snapshot().counts.done === 1, 60000, 'first job to finish');
  await new Promise((r) => setTimeout(r, 400));
  const s = q.snapshot();
  assert.deepStrictEqual([s.state, s.counts.running, s.counts.queued], ['paused', 0, 1]);
  const done = finished(q); q.start(); await done;
  assert.strictEqual(q.snapshot().counts.done, 2);
});

test('failures are isolated, readable, and can be retried; skip-existing skips', { timeout: 120000 }, async () => {
  const q = mk(); const out = path.join(tmp, 'fail');
  fs.writeFileSync(path.join(tmp, 'junk.flac'), 'not audio');
  q.add('encode', [{ path: path.join(tmp, 'junk.flac') }, { path: path.join(tmp, 'two.flac') }], { outputDir: out, skipExisting: true });
  let done = finished(q); q.start(); let c = await done;
  assert.deepStrictEqual([c.done, c.failed], [1, 1]);
  const junk = byInput(q, 'junk.flac');
  assert.match(junk.error, /ffprobe|ffmpeg|audio/i);
  assert.ok(!fs.existsSync(path.join(out, 'junk.nova')) && !fs.existsSync(path.join(out, 'junk.nova.part')), 'no half-written output');
  // fix the file, retry just that job
  fs.copyFileSync(path.join(tmp, 'two.flac'), path.join(tmp, 'junk.flac'));
  assert.ok(q.retry(junk.id)); done = finished(q); q.start(); c = await done;
  assert.strictEqual(byInput(q, 'junk.flac').status, 'done');
  // the same files again with skip-existing: both come back as already done and nothing runs
  const r = q.add('encode', [{ path: path.join(tmp, 'two.flac') }], { outputDir: out, skipExisting: true });
  assert.strictEqual(r.skipped, 1);
});

test('Stop kills the running ffmpeg/ffprobe process, removes half-written files and puts the job back in the queue', { timeout: 60000 }, async () => {
  // stand-ins for ffprobe/ffmpeg: the probe answers, the converter records its pid and then blocks
  const bin = path.join(tmp, 'fakebin'); fs.mkdirSync(bin);
  const pidFile = path.join(tmp, 'fake.pid');
  fs.writeFileSync(path.join(bin, 'ffprobe'), '#!/bin/sh\necho \'{"streams":[{"codec_type":"audio","bits_per_raw_sample":"16"}],"format":{}}\'\n', { mode: 0o755 });
  fs.writeFileSync(path.join(bin, 'ffmpeg'), `#!/bin/sh\necho $$ > ${pidFile}\nexec sleep 120\n`, { mode: 0o755 });
  const q = mk({ ffmpeg: path.join(bin, 'ffmpeg'), ffprobe: path.join(bin, 'ffprobe') });
  q.add('encode', [{ path: path.join(tmp, 'two.flac') }], { outputDir: path.join(tmp, 'stop') });
  q.start();
  await until(() => fs.existsSync(pidFile) && fs.readFileSync(pidFile, 'utf8').trim(), 20000, 'fake ffmpeg to start');
  const pid = parseInt(fs.readFileSync(pidFile, 'utf8'), 10);
  assert.doesNotThrow(() => process.kill(pid, 0), 'the converter process is alive');
  const tmpWavs = () => fs.readdirSync(os.tmpdir()).filter((f) => f.startsWith('nova-tools-') && f.endsWith('.wav'));
  q.stop();
  await until(() => { try { process.kill(pid, 0); return false; } catch (e) { return true; } }, 5000, 'the converter process to die');
  const s = q.snapshot();
  assert.deepStrictEqual([s.state, s.jobs[0].status, s.counts.running], ['idle', 'queued', 0]);
  assert.match(q.logs.join('\n'), /kill: SIGKILL \d+/);
  await new Promise((r) => setTimeout(r, 300));
  assert.deepStrictEqual(tmpWavs().filter((f) => f.includes(`-${process.pid}-`)), [], 'temporary WAV removed');
  await q.close();
});

test('overall progress and ETA follow the work done, weighted by file size', () => {
  let t = 1000; const q = new ToolsQueue({ now: () => t, log: () => {} });
  const mkjob = (id, size, status, frac) => ({ id, kind: 'encode', input: '/i' + id, output: '/o' + id, settings: {}, sizeBytes: size, status, frac, stage: '', error: null, result: null });
  q.jobs = [mkjob(1, 100, 'done', 1), mkjob(2, 100, 'running', 0.5), mkjob(3, 200, 'queued', 0)];
  q.state = 'running'; q.session = { startedAt: 1000, activeMs: 0, activeSince: 1000, baseBytes: 100 }; // job 1 was already done when this stretch began
  t = 11000; // 10 s of work since the start
  const s = q.snapshot();
  assert.strictEqual(Math.round(s.overall.frac * 100), 38); // (100 + 50) / 400
  assert.strictEqual(s.overall.elapsedMs, 10000);
  assert.strictEqual(s.overall.etaMs, 50000); // 50 bytes in 10 s -> 250 bytes left take 50 s
  q.state = 'idle';
});

test('waiting and failed jobs survive a restart of the app', () => {
  const file = path.join(tmp, 'q.json');
  const q = new ToolsQueue({ persistFile: file, log: () => {} });
  q.add('encode', [{ path: path.join(tmp, 'two.flac') }], { outputDir: path.join(tmp, 'persist'), highCompression: true });
  const q2 = new ToolsQueue({ persistFile: file, log: () => {} });
  const j = q2.snapshot().jobs;
  assert.strictEqual(j.length, 1); assert.strictEqual(j[0].status, 'queued'); assert.strictEqual(j[0].settings.highCompression, true);
  q2.add('encode', [{ path: path.join(tmp, 'eight.flac') }], { outputDir: path.join(tmp, 'persist') });
  assert.ok(q2.snapshot().jobs[1].id > j[0].id, 'ids keep counting up');
});
