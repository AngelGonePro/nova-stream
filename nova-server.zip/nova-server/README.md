# nova-server

A standalone web player + backend for local music: recursive `/data/music`
browsing, fully server-side decoding (NOVA and FLAC/WAV both decode on the
server — the browser never runs any decode work itself), account-based
queue/playback sync across devices, and per-user Last.fm scrobbling.

## What this is

This is a complete, self-contained app — open `http://<your-server>/` and
you get a full player: login, a folder browser for your music library,
search, queue, and playback. It does not share anything with (and doesn't
modify) any other NOVA player you may also be running — it's a separate
project with its own accounts and its own UI.

## Setup

1. `cp .env.example .env` and fill in real values — every value with
   `changeme` in it needs to be replaced. Generate the two secrets with:
   ```
   openssl rand -hex 32
   ```
2. Set `HOST_MUSIC_DIR` (in `.env`) to wherever your music actually lives on
   the host, and `NOVA_SERVER_PORT` to whichever host port you want this on
   (defaults to 4533). No Docker network setup needed — this publishes
   directly on the host, the same way your other stacks on this box do.
3. `docker compose up -d --build`
4. **Test locally first**, before touching the domain/proxy at all: open
   `http://<this-host's-LAN-IP>:<NOVA_SERVER_PORT>/` directly in a browser
   (e.g. `http://10.0.0.50:4533/` if you're on `nextcloud-debian`).
5. Once that works, point your reverse proxy (on its own separate VM) at
   `music.cosmoscraft.net` using `music.cosmoscraft.net.nginx.conf` — it's
   pre-filled with `10.0.0.50:4533` to match `nextcloud-debian`; adjust the
   IP/port if you changed `NOVA_SERVER_PORT` or run this somewhere else.
6. Log in with the admin account from `.env` (`ADMIN_USERNAME`/
   `ADMIN_PASSWORD`) — created automatically on first boot.

## API surface (all under `/api`)

- `POST /auth/register`, `/auth/login`, `/auth/logout`, `GET /auth/me`
- `GET /auth/devices`, `POST /auth/devices/:id/revoke` — see/revoke other
  logged-in devices
- `GET /browse?path=` — recursive local music directory listing
- `GET /browse/tags?path=` — lightweight per-track tag read (fast header read
  for `.nova`, ffprobe for everything else)
- `GET /stream/local?path=` — Range-supporting raw file stream (original
  bytes, no decode) — kept as an alternate path, not what the bundled
  frontend actually uses for playback
- `GET /stream/pcm?path=&quality=` — the primary playback path: fully
  server-decoded raw 16-bit PCM, streamed progressively as it decodes.
  `quality` is `full` (default), `reduced` (~32kHz), or `minimal` (~22kHz)
- `GET /state`, `POST /state` — saved queue/track/position, for resuming on
  reload or a different device
- `GET /lastfm/status`, `POST /lastfm/credentials` (your own API key+secret
  from last.fm/api/account/create), `POST /lastfm/link/start` +
  `/link/finish` (the desktop auth flow), `POST /lastfm/unlink`,
  `POST /lastfm/scrobble-enabled`, `POST /lastfm/now-playing`,
  `POST /lastfm/scrobble`
- `POST /logs/client-error` (unauthenticated, rate-limited — batched browser
  error reports), `GET /logs` (admin-only — recent server + client errors)

## Design notes worth knowing before extending this

- **All decode happens server-side, by design** — this was an explicit
  requirement, not the default recommendation. The bundled frontend fetches
  raw PCM from `/stream/pcm` and does no decode work itself, at any quality
  tier. `lib/pcmStream.js` handles both source types: `.nova` files decode
  via the codec's own streaming decoder (Node-compatible, same code as the
  browser players use), everything else via ffmpeg. `quality=reduced`/
  `minimal` genuinely resamples via ffmpeg, not just a label — verified
  directly against real audio.
- **Client-side playback scheduling matches the browser players' approach**
  (`public/app.js`) — multi-buffering (many small `AudioBuffer`s scheduled
  in sequence, never one buffer mutated while connected to a live source
  node — a confirmed Web Audio API race condition in WebKit/Blink) rather
  than one giant buffer. Reused directly from the NextCloud-backed player,
  where it was proven out across an extended debugging session.
- **Last.fm is per-user, not per-server.** Each account brings its own API
  key + secret; there's no shared server-wide app registration. Secrets are
  encrypted at rest (`lib/crypto.js`, AES-256-GCM) — losing `ENCRYPTION_KEY`
  makes existing stored Last.fm credentials unreadable (re-entering them
  fixes it) but doesn't touch account passwords, which are hashed separately.
- **Publishes directly on the host** (`NOVA_SERVER_PORT`, default 4533) —
  no shared Docker network with a proxy. Your proxy VM reaches this host by
  IP and port, the same pattern as your Nextcloud/Jellyfin stacks — nothing
  here needs to be joined to anything, and nothing collides with your other
  services' ports since each picks its own.
- **Multi-device sync here means Spotify-Connect-style continuity** (resume
  where the last device left off), not simultaneous multi-room playback
  control — `state.js` stores one queue/position per user, last write wins.
