(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);

  // ---------- Fetch helpers ----------
  async function api(path, options) {
    const resp = await fetch(path, Object.assign({ credentials: 'include' }, options));
    let data = null;
    try { data = await resp.json(); } catch (e) {}
    if (!resp.ok) throw new Error((data && data.error) || ('HTTP ' + resp.status));
    return data;
  }
  function apiPostJson(path, body) {
    return api(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
  }
  function apiDelete(path) {
    return api(path, { method: 'DELETE' });
  }

  // ---------- Client-side error reporting ----------
  // Captures console.error calls, uncaught exceptions, and unhandled promise
  // rejections, batches them, and periodically reports them to the server's log —
  // same mechanism proven out in the NextCloud-backed player, unchanged here.
  let clientErrorBuffer = [];
  const CLIENT_ERROR_FLUSH_INTERVAL_MS = 10000;
  const CLIENT_ERROR_BUFFER_MAX = 50;
  function bufferClientError(level, message, stack) {
    clientErrorBuffer.push({ level, message: String(message).slice(0, 2000), stack: stack ? String(stack).slice(0, 1000) : undefined, url: window.location.href });
    if (clientErrorBuffer.length > CLIENT_ERROR_BUFFER_MAX) clientErrorBuffer.shift();
  }
  function flushClientErrors(useBeacon) {
    if (!clientErrorBuffer.length) return;
    const entries = clientErrorBuffer;
    clientErrorBuffer = [];
    const body = JSON.stringify({ entries });
    if (useBeacon && navigator.sendBeacon) {
      navigator.sendBeacon('/api/logs/client-error', new Blob([body], { type: 'application/json' }));
    } else {
      fetch('/api/logs/client-error', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body, credentials: 'include' }).catch(() => {});
    }
  }
  function initClientErrorReporting() {
    const origConsoleError = console.error;
    console.error = function (...args) {
      origConsoleError.apply(console, args);
      const errArg = args.find(a => a instanceof Error);
      bufferClientError('error', args.map(a => a instanceof Error ? a.message : String(a)).join(' '), errArg && errArg.stack);
    };
    window.addEventListener('error', (e) => bufferClientError('error', e.message, e.error ? e.error.stack : undefined));
    window.addEventListener('unhandledrejection', (e) => {
      const reason = e.reason;
      bufferClientError('error', reason instanceof Error ? reason.message : String(reason), reason instanceof Error ? reason.stack : undefined);
    });
    setInterval(() => flushClientErrors(false), CLIENT_ERROR_FLUSH_INTERVAL_MS);
    window.addEventListener('pagehide', () => flushClientErrors(true));
  }

  // ---------- Auth ----------
  let currentUser = null;
  async function checkSession() {
    try {
      const me = await api('/api/auth/me');
      currentUser = me;
      onLoggedIn();
    } catch (e) {
      showLogin();
    }
  }
  function showLogin() {
    $('loginScreen').style.display = 'flex';
    $('appScreen').style.display = 'none';
  }
  function showApp() {
    $('loginScreen').style.display = 'none';
    $('appScreen').style.display = 'flex';
  }
  async function onLoggedIn() {
    showApp();
    $('whoami').textContent = currentUser.username + (currentUser.isAdmin ? ' (admin)' : '');
    await refreshLastfmStatus();
    await loadDevices();
    await loadPlaylists();
    await browseTo('');
    await restoreStateFromServer();
  }

  // ---------- Library / directory browsing ----------
  // Recursively browsing everything up front (like the NextCloud-backed player does)
  // would mean walking the whole tree before showing anything — for a large local
  // library that's a slow first load for no reason. Instead this browses one directory
  // at a time, like a normal file browser: click a folder, see its contents. Search
  // still needs the full flat list, so that's built lazily the first time it's used.
  let currentDirPath = '';
  let currentDirListing = { dirs: [], files: [] };
  let flatLibraryCache = null; // built lazily on first search
  let library = []; // currently-displayed track objects (either one directory's files, or search results)

  function trackFromFile(f) {
    return { id: 'local:' + f.path, localPath: f.path, name: f.name, tags: {}, picture: null, metaLoaded: false };
  }

  async function browseTo(path) {
    currentPlaylistId = null; // switching to folder browsing — a playlist may have been showing before
    try {
      const listing = await api('/api/browse?path=' + encodeURIComponent(path));
      currentDirPath = listing.path;
      currentDirListing = listing;
      library = listing.files.map(trackFromFile);
      renderBreadcrumbs();
      renderDirList();
      renderLibrary();
      loadTagsFor(library);
    } catch (err) {
      // Previously failed completely silently here — a network/auth/server error left
      // the library panel just blank with no indication anything went wrong, which is
      // indistinguishable from "this directory genuinely has no files in it". Now shows
      // an actual error so the two cases don't look identical.
      console.error('Failed to browse "' + (path || '(root)') + '":', err.message);
      $('viewTitle').textContent = 'Could not load library';
      $('viewCount').textContent = '';
      $('trackList').innerHTML = `<div style="padding:16px; color:var(--danger);">Error loading ${escapeHtml(path || 'the library')}: ${escapeHtml(err.message)}</div>`;
    }
  }

  function renderBreadcrumbs() {
    const parts = currentDirPath ? currentDirPath.split('/') : [];
    const crumbs = [{ label: 'Library', path: '' }];
    let acc = '';
    for (const p of parts) { acc = acc ? acc + '/' + p : p; crumbs.push({ label: p, path: acc }); }
    $('breadcrumbs').innerHTML = crumbs.map((c, i) =>
      `<div class="crumb" data-path="${escapeAttr(c.path)}">${'—'.repeat(i)} ${escapeHtml(c.label)}</div>`
    ).join('');
    $('breadcrumbs').querySelectorAll('.crumb').forEach(el => {
      el.addEventListener('click', () => browseTo(el.dataset.path));
    });
  }
  function renderDirList() {
    $('dirList').innerHTML = currentDirListing.dirs.map(d =>
      `<div class="dirRow" data-path="${escapeAttr(d.path)}">📁 ${escapeHtml(d.name)}</div>`
    ).join('');
    $('dirList').querySelectorAll('.dirRow').forEach(el => {
      el.addEventListener('click', () => browseTo(el.dataset.path));
    });
  }

  async function walkFullLibrary(relPath, out) {
    const listing = await api('/api/browse?path=' + encodeURIComponent(relPath));
    for (const f of listing.files) out.push(trackFromFile(f));
    for (const d of listing.dirs) await walkFullLibrary(d.path, out);
  }
  async function ensureFlatLibraryCache() {
    if (flatLibraryCache) return flatLibraryCache;
    flatLibraryCache = [];
    await walkFullLibrary('', flatLibraryCache);
    loadTagsFor(flatLibraryCache);
    return flatLibraryCache;
  }

  // ---------- Playlists ----------
  let playlists = []; // {id, name, trackCount}
  async function loadPlaylists() {
    try { playlists = await api('/api/playlists'); } catch (e) { playlists = []; }
    renderPlaylistList();
  }
  function renderPlaylistList() {
    $('playlistList').innerHTML = playlists.map(p =>
      `<div class="playlist-row${currentPlaylistId === p.id ? ' active' : ''}" data-pl-id="${p.id}">` +
      `<span class="plName">${escapeHtml(p.name)}</span><span class="plCount">${p.trackCount}</span>` +
      `<button class="plDeleteBtn" type="button" data-delete-pl="${p.id}" title="Delete playlist">✕</button>` +
      `</div>`
    ).join('');
    $('playlistList').querySelectorAll('.playlist-row').forEach(el => {
      el.addEventListener('click', (e) => {
        if (e.target.closest('.plDeleteBtn')) return;
        openPlaylist(parseInt(el.dataset.plId, 10));
      });
    });
    $('playlistList').querySelectorAll('[data-delete-pl]').forEach(el => {
      el.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (!confirm('Delete this playlist? The tracks themselves are untouched.')) return;
        await apiDelete('/api/playlists/' + el.dataset.deletePl);
        if (currentPlaylistId === parseInt(el.dataset.deletePl, 10)) { currentPlaylistId = null; browseTo(''); }
        loadPlaylists();
      });
    });
  }
  async function createNewPlaylist() {
    const name = prompt('Playlist name:');
    if (!name || !name.trim()) return;
    await apiPostJson('/api/playlists', { name: name.trim() });
    loadPlaylists();
  }
  async function openPlaylist(id) {
    currentPlaylistId = id;
    let playlist;
    try { playlist = await api('/api/playlists/' + id); } catch (e) { return; }
    await ensureFlatLibraryCache();
    library = playlist.trackPaths.map(p => trackById('local:' + p)).filter(Boolean);
    renderPlaylistList();
    renderLibrary();
  }
  async function removeTrackFromCurrentPlaylist(index) {
    if (!currentPlaylistId) return;
    await apiDelete(`/api/playlists/${currentPlaylistId}/tracks/${index}`);
    openPlaylist(currentPlaylistId); // reload to reflect the renumbered positions
    loadPlaylists(); // track count changed
  }
  function showAddToPlaylistMenu(trackId, anchorEl) {
    const menu = $('addToPlaylistMenu');
    const rect = anchorEl.getBoundingClientRect();
    menu.style.left = Math.min(rect.left, window.innerWidth - 200) + 'px';
    menu.style.top = (rect.bottom + 4) + 'px';
    menu.innerHTML = playlists.length
      ? playlists.map(p => `<div class="aptRow" data-target-pl="${p.id}">${escapeHtml(p.name)}</div>`).join('')
      : `<div class="aptEmpty">No playlists yet — create one from the sidebar first.</div>`;
    menu.querySelectorAll('[data-target-pl]').forEach(el => {
      el.addEventListener('click', async () => {
        menu.classList.remove('open');
        const localPath = trackId.startsWith('local:') ? trackId.slice(6) : trackId;
        try {
          await apiPostJson(`/api/playlists/${el.dataset.targetPl}/tracks`, { trackPath: localPath });
          loadPlaylists();
        } catch (e) { alert('Could not add track: ' + e.message); }
      });
    });
    menu.classList.add('open');
  }
  function closeAddToPlaylistMenu() { $('addToPlaylistMenu').classList.remove('open'); }

  async function runWithConcurrencyLimit(items, limit, worker) {
    let idx = 0;
    async function next() {
      while (idx < items.length) {
        const item = items[idx++];
        await worker(item);
      }
    }
    await Promise.all(Array.from({ length: Math.min(limit, items.length) }, next));
  }
  function loadTagsFor(tracks) {
    const needed = tracks.filter(t => !t.metaLoaded);
    if (!needed.length) return;
    runWithConcurrencyLimit(needed, 4, async (track) => {
      try {
        const tags = await api('/api/browse/tags?path=' + encodeURIComponent(track.localPath));
        track.tags = { title: tags.title || undefined, artist: tags.artist || undefined, album: tags.album || undefined };
      } catch (e) {}
      track.metaLoaded = true;
      renderLibraryRow(track);
    });
  }

  function trackById(id) {
    const inLibrary = library.find(t => t.id === id);
    if (inLibrary) return inLibrary;
    if (flatLibraryCache) return flatLibraryCache.find(t => t.id === id);
    return null;
  }
  function escapeHtml(s) { return String(s || '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }
  function escapeAttr(s) { return escapeHtml(s); }

  // ---------- Rendering: track list, queue ----------
  let queue = [], queuePos = -1, repeatMode = 'off', shuffleEnabled = false;

  function displayName(t) { return (t.tags.title || t.name); }
  function displayArtist(t) { return t.tags.artist || ''; }

  function artworkUrl(track) {
    return '/api/browse/artwork?path=' + encodeURIComponent(track.localPath);
  }
  let currentPlaylistId = null; // non-null when viewing a playlist's contents instead of a folder
  function renderLibrary() {
    $('viewTitle').textContent = currentPlaylistId ? (playlists.find(p => p.id === currentPlaylistId) || {}).name || 'Playlist' : (currentDirPath || 'Library');
    $('viewCount').textContent = `${library.length} track${library.length === 1 ? '' : 's'}`;
    if (!library.length && !currentDirListing.dirs.length && !currentPlaylistId) {
      // Genuinely empty, not an error — distinct from browseTo()'s catch block above,
      // which handles the "something went wrong" case. This is "the request succeeded
      // and there's honestly nothing here", which needs its own message too, or it's
      // indistinguishable from either of the other blank-looking states.
      $('trackList').innerHTML = `<div style="padding:16px; color:var(--muted);">No audio files found in ${escapeHtml(currentDirPath || 'the music library root')}. If you expected files here, double-check HOST_MUSIC_DIR in .env actually points at the folder containing them, and that the container was restarted after any change to it.</div>`;
      return;
    }
    if (!library.length && currentPlaylistId) {
      $('trackList').innerHTML = `<div style="padding:16px; color:var(--muted);">This playlist is empty. Add tracks from the Library view using the "+PL" button on any track.</div>`;
      return;
    }
    $('trackList').innerHTML = library.map((t, i) =>
      `<div class="track-row${queue[queuePos] === t.id ? ' playing' : ''}" data-id="${escapeAttr(t.id)}">` +
      `<img class="track-art" src="${artworkUrl(t)}" alt="" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'track-art placeholder',textContent:'♪'}))">` +
      `<div class="tInfo"><span class="tName">${escapeHtml(displayName(t))}</span><span class="tAlbum">${escapeHtml(t.tags.album || '')}</span></div>` +
      `<span class="tArtist">${escapeHtml(displayArtist(t))}</span>` +
      `<button class="tAddBtn" type="button" data-add-id="${escapeAttr(t.id)}" title="Add to queue">+</button>` +
      (currentPlaylistId
        ? `<button class="tAddBtn" type="button" data-remove-pl-idx="${i}" title="Remove from playlist">✕</button>`
        : `<button class="tAddBtn" type="button" data-add-pl-id="${escapeAttr(t.id)}" title="Add to playlist">+PL</button>`) +
      `</div>`
    ).join('');
    $('trackList').querySelectorAll('.track-row').forEach(el => {
      el.addEventListener('click', (e) => {
        if (e.target.closest('.tAddBtn')) return; // handled separately below — don't also jump to playing it
        playTrack(el.dataset.id, library.map(t => t.id));
      });
    });
    $('trackList').querySelectorAll('[data-add-id]').forEach(el => {
      el.addEventListener('click', (e) => { e.stopPropagation(); addToQueue(el.dataset.addId); });
    });
    $('trackList').querySelectorAll('[data-add-pl-id]').forEach(el => {
      el.addEventListener('click', (e) => { e.stopPropagation(); showAddToPlaylistMenu(el.dataset.addPlId, el); });
    });
    $('trackList').querySelectorAll('[data-remove-pl-idx]').forEach(el => {
      el.addEventListener('click', (e) => { e.stopPropagation(); removeTrackFromCurrentPlaylist(parseInt(el.dataset.removePlIdx, 10)); });
    });
  }
  function renderLibraryRow(track) {
    const row = $('trackList').querySelector(`.track-row[data-id="${CSS.escape(track.id)}"]`);
    if (row) {
      row.querySelector('.tName').textContent = displayName(track);
      row.querySelector('.tAlbum').textContent = track.tags.album || '';
      row.querySelector('.tArtist').textContent = displayArtist(track);
    }
  }

  // ---------- Queue management ----------
  function addToQueue(id) {
    if (!trackById(id)) return;
    queue.push(id);
    renderQueue();
  }
  function removeFromQueue(index) {
    if (index === queuePos) return; // don't remove what's actively loaded/playing — stop or skip first
    queue.splice(index, 1);
    if (index < queuePos) queuePos--; // shift to keep pointing at the same actual track
    renderQueue();
  }
  function moveQueueItem(index, direction) {
    const target = index + direction;
    if (target < 0 || target >= queue.length) return;
    [queue[index], queue[target]] = [queue[target], queue[index]];
    if (queuePos === index) queuePos = target;
    else if (queuePos === target) queuePos = index;
    renderQueue();
  }
  function renderQueue() {
    $('queueList').innerHTML = queue.map((id, i) => {
      const t = trackById(id);
      const isActive = i === queuePos;
      return `<div class="queue-row${isActive ? ' active' : ''}" data-idx="${i}">` +
        `<span class="qName">${escapeHtml(t ? displayName(t) : id)}</span>` +
        `<button class="qBtn" type="button" data-q-action="up" data-idx="${i}" title="Move up" ${i === 0 ? 'disabled' : ''}>↑</button>` +
        `<button class="qBtn" type="button" data-q-action="down" data-idx="${i}" title="Move down" ${i === queue.length - 1 ? 'disabled' : ''}>↓</button>` +
        `<button class="qBtn" type="button" data-q-action="remove" data-idx="${i}" title="Remove from queue" ${isActive ? 'disabled' : ''}>✕</button>` +
        `</div>`;
    }).join('');
    $('queueList').querySelectorAll('.queue-row').forEach(el => {
      el.addEventListener('click', (e) => {
        if (e.target.closest('.qBtn')) return; // buttons handle their own action below
        queuePos = parseInt(el.dataset.idx, 10); playTrack(queue[queuePos]);
      });
    });
    $('queueList').querySelectorAll('.qBtn').forEach(el => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        const idx = parseInt(el.dataset.idx, 10);
        if (el.dataset.qAction === 'up') moveQueueItem(idx, -1);
        else if (el.dataset.qAction === 'down') moveQueueItem(idx, 1);
        else if (el.dataset.qAction === 'remove') removeFromQueue(idx);
      });
    });
  }
  function updateShuffleRepeatUI() {
    $('repeatBtn').textContent = repeatMode === 'off' ? '🔁' : repeatMode === 'all' ? '🔁' : '🔂';
    $('repeatBtn').style.opacity = repeatMode === 'off' ? '0.5' : '1';
    $('shuffleBtn').style.opacity = shuffleEnabled ? '1' : '0.5';
  }
  function toggleRepeat() {
    repeatMode = repeatMode === 'off' ? 'all' : repeatMode === 'all' ? 'one' : 'off';
    updateShuffleRepeatUI();
  }
  function toggleShuffle() { shuffleEnabled = !shuffleEnabled; updateShuffleRepeatUI(); }

  let searchDebounce = null;
  async function onSearchInput() {
    const q = $('searchBox').value.trim().toLowerCase();
    clearTimeout(searchDebounce);
    if (!q) { library = currentDirListing.files.map(trackFromFile); renderLibrary(); loadTagsFor(library); return; }
    searchDebounce = setTimeout(async () => {
      const all = await ensureFlatLibraryCache();
      library = all.filter(t => displayName(t).toLowerCase().includes(q) || displayArtist(t).toLowerCase().includes(q));
      renderLibrary();
    }, 250);
  }

  function fmtTime(sec) {
    if (!isFinite(sec) || sec < 0) sec = 0;
    const m = Math.floor(sec / 60), s = Math.floor(sec % 60);
    return m + ':' + String(s).padStart(2, '0');
  }
  function setNowPlaying(track, statusText) {
    $('npTitle').textContent = displayName(track);
    $('npArtist').textContent = displayArtist(track);
    $('npAlbum').textContent = track.tags.album || '';
    $('npStatusText').textContent = statusText || '';
    const artEl = $('npArt');
    artEl.classList.remove('hidden');
    artEl.onerror = () => artEl.classList.add('hidden');
    const artUrl = artworkUrl(track);
    artEl.src = artUrl;
    if ('mediaSession' in navigator && 'MediaMetadata' in window) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: displayName(track), artist: displayArtist(track) || '', album: track.tags.album || '',
        // Absolute URL required here — MediaSession artwork is fetched by the OS lock-
        // screen surface itself, not by this page's own DOM, and a relative path isn't
        // guaranteed to resolve correctly in that context the way it does for an <img>
        // tag sitting in this document. Same endpoint the in-page thumbnails use, so if
        // a track has no embedded art this 404s and the lock screen just shows no image,
        // exactly like the in-page fallback already does — not treated as an error.
        artwork: [{ src: new URL(artUrl, window.location.href).href, sizes: '512x512', type: 'image/jpeg' }],
      });
    }
  }
  function setNpStatusText(t) { $('npStatusText').textContent = t; }

  // ---------- Playback engine ----------
  // Multi-buffering: a single AudioBuffer mutated while connected to a live, playing
  // AudioBufferSourceNode is a confirmed Web Audio API race condition in WebKit/Blink.
  // Decoded audio is scheduled as a sequence of separate, small buffers instead — each
  // fully populated before ever being connected to a source node, and never touched
  // again afterward. Identical architecture to the NextCloud-backed player's, proven
  // out there across an extended debugging session (crackling, mobile CPU limits,
  // rebuffer reliability) — reused here unchanged rather than re-derived.
  let audioCtx = null, currentBuffer = null;
  let playStartedAtCtxTime = 0, playOffset = 0, isPlaying = false, rafId = null;
  let scheduledSegments = [];
  let scheduledUpToSample = 0, scheduledUpToCtxTime = 0;
  let decodedUpToSample = 0;
  let decodeGenerationToken = 0; // see playTrack() — invalidates any still-running decode of whatever was playing before, so an abandoned decode can't corrupt state for whatever's playing now

  function isFirefox() { return /firefox/i.test(navigator.userAgent) && !/seamonkey/i.test(navigator.userAgent); }

  // Some browsers only reliably show OS-level media notifications/lock-screen controls
  // for audio actually flowing through an <audio>/<video> element — plain Web Audio API
  // playback (which is what this app uses for sample-accurate, multichannel-safe output)
  // isn't always enough on its own. This shadow element carries NO real audio at all —
  // just silence, entirely separate from the real playback graph — purely to satisfy
  // that "something is actively playing" check. A real, finite-duration looping file (via
  // a Blob URL) rather than a live MediaStream: some browsers only show media
  // notifications once an element has actually started producing decoded frames, which a
  // silent file does immediately and reliably.
  //
  // Deliberately NOT routing the real (potentially multichannel) audio through anything
  // like this: that would mean going through MediaStreamAudioDestinationNode, which has a
  // real, documented, still-unresolved spec bug where it doesn't reliably honor
  // channelCount above its default of 2 — a risk of silently downmixing this app's actual
  // multichannel output to stereo, far worse than missing lock-screen controls. The real
  // audio path stays completely untouched either way — same reasoning ported directly
  // from the NextCloud-backed player, where this exact mechanism was worked out.
  let shadowAudioEl = null;
  let shadowMediaStreamDest = null;
  function buildSilentWavBlobUrl() {
    const sampleRate = 8000, seconds = 6, bytesPerSample = 1; // 8-bit unsigned PCM — silence is the midpoint value (128), tiny file regardless of quality since there's no real content
    const dataSize = sampleRate * seconds * bytesPerSample;
    const buf = new ArrayBuffer(44 + dataSize);
    const dv = new DataView(buf);
    const writeStr = (offset, str) => { for (let i = 0; i < str.length; i++) dv.setUint8(offset + i, str.charCodeAt(i)); };
    writeStr(0, 'RIFF'); dv.setUint32(4, 36 + dataSize, true); writeStr(8, 'WAVE');
    writeStr(12, 'fmt '); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 1, true);
    dv.setUint32(24, sampleRate, true); dv.setUint32(28, sampleRate * bytesPerSample, true);
    dv.setUint16(32, bytesPerSample, true); dv.setUint16(34, 8, true);
    writeStr(36, 'data'); dv.setUint32(40, dataSize, true);
    const pcm = new Uint8Array(buf, 44, dataSize);
    pcm.fill(128); // 8-bit unsigned PCM silence is the midpoint, not zero
    return URL.createObjectURL(new Blob([buf], { type: 'audio/wav' }));
  }
  function ensureShadowMediaElement(ctx) {
    if (shadowAudioEl) return;
    try {
      shadowAudioEl = document.createElement('audio');
      if (isFirefox()) {
        // Firefox's media control system, per Mozilla's own support documentation, only
        // works for AUDIBLE <audio>/<video> elements — explicitly not Web Audio API
        // output, and explicitly not "inaudible media". A silent shadow element (what
        // non-Firefox browsers get below) is exactly the "inaudible" case Firefox
        // excludes — so for Firefox, this element needs to actually carry the real,
        // audible audio, routed here INSTEAD OF (not alongside) the direct
        // ctx.destination connection in scheduleSegment(), to avoid doubled/echoed
        // output. Always downmixed to exactly 2 channels first: MediaStreamAudioDestinationNode
        // doesn't reliably honor channelCount above its default of 2 — capping at 2
        // here sidesteps that bug, at the cost of losing discrete multichannel output
        // specifically on Firefox. A deliberate trade-off: working lock-screen controls
        // there vs. full channel fidelity there. Other browsers are unaffected either way.
        shadowMediaStreamDest = ctx.createMediaStreamDestination();
        shadowAudioEl.srcObject = shadowMediaStreamDest.stream;
        shadowAudioEl.volume = 1;
      } else {
        shadowAudioEl.src = buildSilentWavBlobUrl();
        shadowAudioEl.loop = true;
      }
      shadowAudioEl.setAttribute('playsinline', '');
      shadowAudioEl.style.display = 'none';
      document.body.appendChild(shadowAudioEl);
      shadowAudioEl.play().catch(() => {});
      // Defensive: some browsers route the OS-level lock-screen/notification play-pause
      // button to the actual <audio> element directly, rather than exclusively through
      // navigator.mediaSession's registered action handlers — in which case this shadow
      // element could get paused/resumed by the OS without ever calling this app's own
      // pausePlayback()/resumePlayback(), leaving its state (and the in-page button
      // icon) stuck out of sync, with the real audio unaffected either way. Both paths —
      // the registered MediaSession handlers AND these native element events — now
      // converge on the same pausePlayback()/resumePlayback() calls, so whichever
      // mechanism the OS actually uses, the app's state stays correct. Those functions
      // already guard on isPlaying, so redundant calls from both paths firing are
      // harmless no-ops, not a risk of double-toggling.
      shadowAudioEl.addEventListener('pause', () => pausePlayback());
      shadowAudioEl.addEventListener('play', () => resumePlayback());
    } catch (e) {
      // If this fails for any reason, the real audio path is entirely unaffected —
      // this is purely an attempt at OS integration, never load-bearing for playback.
    }
  }

  function ensureCtx() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const maxCh = audioCtx.destination.maxChannelCount || 2;
      try {
        audioCtx.destination.channelCount = Math.min(8, maxCh);
        audioCtx.destination.channelCountMode = 'explicit';
        audioCtx.destination.channelInterpretation = 'discrete';
      } catch (e) {}
      // Warm up the audio pipeline: browsers can briefly clip/glitch the very first real
      // sound played on a freshly-created AudioContext while the audio hardware pipeline
      // finishes initializing — a well-documented Web Audio quirk. Playing a near-instant
      // silent buffer immediately absorbs that startup cost before the actual track
      // starts.
      try {
        const warmup = audioCtx.createBufferSource();
        warmup.buffer = audioCtx.createBuffer(1, 1, audioCtx.sampleRate);
        warmup.connect(audioCtx.destination);
        warmup.start(0);
      } catch (e) {}
      ensureShadowMediaElement(audioCtx);
    }
    return audioCtx;
  }
  function currentTimeSec() { return isPlaying ? playOffset + (audioCtx.currentTime - playStartedAtCtxTime) : playOffset; }
  function stopSource() {
    for (const seg of scheduledSegments) { try { seg.source.onended = null; seg.source.stop(); } catch (e) {} }
    scheduledSegments = [];
  }

  let downmixGraphCache = null;
  function connectWithDownmix(ctx, src, sourceChannels, destChannelCount, destNode) {
    if (sourceChannels <= destChannelCount) { src.channelInterpretation = 'discrete'; src.connect(destNode); return; }
    if (destChannelCount === 2 && (sourceChannels === 6 || sourceChannels === 8)) {
      const cacheKey = sourceChannels + ':' + destChannelCount;
      let graph = (downmixGraphCache && downmixGraphCache.key === cacheKey) ? downmixGraphCache : null;
      if (!graph) {
        const merger = ctx.createChannelMerger(2);
        const limiter = ctx.createDynamicsCompressor();
        limiter.threshold.value = 0; limiter.knee.value = 0; limiter.ratio.value = 20;
        limiter.attack.value = 0.001; limiter.release.value = 0.1;
        merger.connect(limiter); limiter.connect(destNode);
        graph = { key: cacheKey, merger, limiter };
        downmixGraphCache = graph;
      }
      const splitter = ctx.createChannelSplitter(sourceChannels);
      src.connect(splitter);
      const SIDE = 1.0, CENTER = 0.707, SURROUND = 0.707, LFE_GAIN = 0.5;
      function route(channelIndex, leftGain, rightGain) {
        if (leftGain > 0) { const g = ctx.createGain(); g.gain.value = leftGain; splitter.connect(g, channelIndex); g.connect(graph.merger, 0, 0); }
        if (rightGain > 0) { const g = ctx.createGain(); g.gain.value = rightGain; splitter.connect(g, channelIndex); g.connect(graph.merger, 0, 1); }
      }
      route(0, SIDE, 0); route(1, 0, SIDE); route(2, CENTER, CENTER); route(3, LFE_GAIN, LFE_GAIN);
      route(4, SURROUND, 0); route(5, 0, SURROUND);
      if (sourceChannels === 8) { route(6, SURROUND, 0); route(7, 0, SURROUND); }
      return;
    }
    const splitter = ctx.createChannelSplitter(sourceChannels);
    const merger = ctx.createChannelMerger(destChannelCount);
    src.connect(splitter);
    const gainPerChannel = 1 / Math.ceil(sourceChannels / destChannelCount);
    for (let c = 0; c < sourceChannels; c++) {
      const gain = ctx.createGain(); gain.gain.value = gainPerChannel;
      splitter.connect(gain, c); gain.connect(merger, 0, c % destChannelCount);
    }
    merger.connect(destNode);
  }

  function scheduleSegment(fromSample, toSample, ctxStartTime) {
    const ctx = ensureCtx();
    const numCh = currentBuffer.numberOfChannels;
    const len = toSample - fromSample;
    const buf = ctx.createBuffer(numCh, len, currentBuffer.sampleRate);
    for (let c = 0; c < numCh; c++) buf.getChannelData(c).set(currentBuffer.getChannelData(c).subarray(fromSample, toSample));
    const src = ctx.createBufferSource();
    src.buffer = buf;
    if (isFirefox() && shadowMediaStreamDest) {
      connectWithDownmix(ctx, src, numCh, 2, shadowMediaStreamDest);
    } else {
      connectWithDownmix(ctx, src, numCh, ctx.destination.channelCount, ctx.destination);
    }
    const actualStartTime = Math.max(ctxStartTime, ctx.currentTime);
    const endCtxTime = actualStartTime + len / currentBuffer.sampleRate;
    const seg = { source: src, endSample: toSample, endCtxTime };
    src.onended = () => {
      scheduledSegments = scheduledSegments.filter(s => s !== seg);
      if (isPlaying && toSample >= currentBuffer.length && scheduledSegments.length === 0) onTrackEnded();
    };
    src.start(actualStartTime);
    scheduledSegments.push(seg);
    return seg;
  }
  const MAX_SEGMENT_SECONDS = 10;
  function extendScheduleIfPossible() {
    if (!isPlaying || !currentBuffer) return;
    if (scheduledUpToSample >= decodedUpToSample) return;
    if (scheduledUpToSample >= currentBuffer.length) return;
    const maxSamplesPerCall = Math.round(MAX_SEGMENT_SECONDS * currentBuffer.sampleRate);
    const targetSample = Math.min(decodedUpToSample, scheduledUpToSample + maxSamplesPerCall);
    const seg = scheduleSegment(scheduledUpToSample, targetSample, scheduledUpToCtxTime);
    scheduledUpToSample = targetSample;
    scheduledUpToCtxTime = seg.endCtxTime;
  }
  const SCHEDULE_EXTEND_MARGIN_SECONDS = 8;
  const MIN_SECONDS_BETWEEN_EXTENSIONS = 10;
  let lastExtendCtxTime = 0;
  function maybeExtendSchedule() {
    if (!isPlaying || !currentBuffer) return;
    if (scheduledUpToSample >= decodedUpToSample) return;
    if (scheduledUpToSample >= currentBuffer.length) return;
    const ctx = ensureCtx();
    const t = currentTimeSec();
    const scheduledAheadSeconds = (scheduledUpToSample / currentBuffer.sampleRate) - t;
    const timeSinceLastExtend = ctx.currentTime - lastExtendCtxTime;
    if (scheduledAheadSeconds < SCHEDULE_EXTEND_MARGIN_SECONDS || timeSinceLastExtend > MIN_SECONDS_BETWEEN_EXTENSIONS) {
      extendScheduleIfPossible();
      lastExtendCtxTime = ctx.currentTime;
    }
  }

  function startFrom(offset) {
    const ctx = ensureCtx();
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    stopSource();
    playOffset = offset;
    playStartedAtCtxTime = ctx.currentTime;
    isPlaying = true;
    scheduledUpToSample = Math.max(0, Math.min(currentBuffer.length, Math.round(offset * currentBuffer.sampleRate)));
    scheduledUpToCtxTime = ctx.currentTime;
    lastExtendCtxTime = ctx.currentTime;
    extendScheduleIfPossible();
    updateTransportUI();
    tickProgress();
    if (shadowAudioEl && shadowAudioEl.paused) shadowAudioEl.play().catch(() => {});
    if ('mediaSession' in navigator) {
      navigator.mediaSession.playbackState = 'playing';
      try { navigator.mediaSession.setPositionState({ duration: currentBuffer.duration, playbackRate: 1, position: offset }); } catch (e) {}
    }
  }
  function pausePlayback() {
    if (!isPlaying) return;
    playOffset = currentTimeSec();
    stopSource();
    isPlaying = false;
    updateTransportUI();
    // Keep the shadow element's own state in sync too — belt-and-suspenders alongside
    // its event listeners above, so it can't independently drift from the real state
    // regardless of which one the OS actually acted on first.
    if (shadowAudioEl && !shadowAudioEl.paused) shadowAudioEl.pause();
    if ('mediaSession' in navigator) navigator.mediaSession.playbackState = 'paused';
    saveStateToServer(true);
  }
  function resumePlayback() { if (isPlaying || !currentBuffer) return; startFrom(playOffset); }

  let seekWaitToken = 0;
  function seekTo(offset) {
    if (!currentBuffer) return;
    seekWaitToken++;
    const wasPlaying = isPlaying;
    stopSource();
    playOffset = Math.max(0, Math.min(currentBuffer.duration, offset));
    const targetSample = Math.floor(playOffset * currentBuffer.sampleRate);
    if (targetSample > decodedUpToSample) {
      isPlaying = false;
      updateTransportUI();
      waitForDecodeAndPlay(targetSample, playOffset);
      return;
    }
    if (wasPlaying) startFrom(playOffset); else updateTransportUI();
  }
  function waitForDecodeAndPlay(targetSample, offsetSeconds, waitingText) {
    const myToken = seekWaitToken;
    const track = trackById(queue[queuePos]);
    if (track) setNowPlaying(track, waitingText || 'Catching up to your seek position…');
    const check = () => {
      if (myToken !== seekWaitToken || !currentBuffer) { isRebuffering = false; return; }
      if (decodedUpToSample >= targetSample) {
        isRebuffering = false;
        if (track) setNowPlaying(track, 'Playing — buffering rest');
        startFrom(offsetSeconds);
        return;
      }
      setTimeout(check, 150);
    };
    check();
  }

  const REBUFFER_MARGIN_SECONDS = 2;
  const REBUFFER_RESUME_MARGIN_SECONDS = 6;
  let isRebuffering = false;
  function checkForRebuffer() {
    if (isRebuffering || !isPlaying || !currentBuffer) return;
    if (scheduledUpToSample >= currentBuffer.length) return;
    let t = currentTimeSec();
    let bufferedAheadSeconds = (scheduledUpToSample / currentBuffer.sampleRate) - t;
    if (bufferedAheadSeconds < SCHEDULE_EXTEND_MARGIN_SECONDS && scheduledUpToSample < decodedUpToSample) {
      extendScheduleIfPossible();
      t = currentTimeSec();
      bufferedAheadSeconds = (scheduledUpToSample / currentBuffer.sampleRate) - t;
    }
    const nothingScheduled = scheduledSegments.length === 0 && scheduledUpToSample < currentBuffer.length;
    if (bufferedAheadSeconds < REBUFFER_MARGIN_SECONDS || nothingScheduled) {
      isRebuffering = true;
      seekWaitToken++;
      const targetSample = Math.min(currentBuffer.length, Math.floor((t + REBUFFER_RESUME_MARGIN_SECONDS) * currentBuffer.sampleRate));
      pausePlayback();
      waitForDecodeAndPlay(targetSample, t, 'Buffering…');
    }
  }

  function tickProgress() {
    cancelAnimationFrame(rafId);
    function frame() {
      if (isPlaying) {
        const t = currentTimeSec();
        $('seekBar').value = currentBuffer ? (t / currentBuffer.duration) * 1000 : 0;
        $('timeCurrent').textContent = fmtTime(t);
        checkForRebuffer();
        saveStateToServer(false);
        const track = trackById(queue[queuePos]);
        if (track) maybeScrobble(track);
        rafId = requestAnimationFrame(frame);
      }
    }
    frame();
  }
  setInterval(() => { if (isPlaying) checkForRebuffer(); }, 500);
  setInterval(() => { maybeYieldToOtherDevice(); }, 8000);

  function updateAudioDiagnostics() {
    // Real, live numbers rather than a guess — what this browser actually reports it can
    // output, and (once a track has played) what the currently loaded track has and
    // whether the explicit downmix path engaged for it. maxChannelCount can be queried
    // without needing playback to have started: a throwaway AudioContext works fine.
    let maxCh;
    try {
      const probeCtx = new (window.AudioContext || window.webkitAudioContext)();
      maxCh = probeCtx.destination.maxChannelCount;
      probeCtx.close();
    } catch (e) { maxCh = 'unavailable'; }
    let trackLine = '<div>No track loaded yet — play something to see its channel info here.</div>';
    if (currentBuffer) {
      const srcCh = currentBuffer.numberOfChannels;
      const destCh = audioCtx ? audioCtx.destination.channelCount : maxCh;
      const downmixed = srcCh > destCh;
      trackLine = `<div><span class="k">Current track:</span> ${srcCh} channel${srcCh === 1 ? '' : 's'}</div>` +
        `<div><span class="k">Routing:</span> ${downmixed ? `mixed down to ${destCh} (browser reports fewer output channels than the track has)` : 'direct — full channel count sent straight through'}</div>`;
    }
    $('audioDiagnostics').innerHTML =
      `<div><span class="k">This browser reports it can output:</span> ${maxCh} channel${maxCh === 1 ? '' : 's'}</div>` + trackLine;
  }
  function setupMediaSessionHandlers() {
    if (!('mediaSession' in navigator)) return;
    const handlers = {
      play: () => resumePlayback(),
      pause: () => pausePlayback(),
      previoustrack: () => playPrevInQueue(),
      nexttrack: () => playNextInQueue(),
      seekto: (details) => { if (details.seekTime !== undefined && currentBuffer) seekTo(details.seekTime); },
    };
    // Not every browser supports every action type — setting an unsupported one can throw
    // in some implementations, so register each independently rather than letting one
    // failure prevent the rest from being set up.
    for (const [action, handler] of Object.entries(handlers)) {
      try { navigator.mediaSession.setActionHandler(action, handler); } catch (e) { /* unsupported action type — skip it */ }
    }
  }
  function updateTransportUI() {
    $('playPauseBtn').textContent = isPlaying ? '⏸' : '▶';
  }
  function onTrackEnded() {
    isPlaying = false;
    if ('mediaSession' in navigator) navigator.mediaSession.playbackState = 'paused';
    if (repeatMode === 'one') { playTrack(queue[queuePos]); return; }
    playNextInQueue();
  }
  function playNextInQueue() {
    if (queuePos + 1 < queue.length) { queuePos++; playTrack(queue[queuePos]); }
    else if (repeatMode === 'all' && queue.length > 0) { queuePos = 0; playTrack(queue[queuePos]); }
    else { updateTransportUI(); }
  }
  function playPrevInQueue() {
    if (currentTimeSec() > 3) { seekTo(0); return; }
    if (queuePos > 0) { queuePos--; playTrack(queue[queuePos]); }
  }

  // ---------- Server-decoded PCM consumption ----------
  let qualityMode = localStorage.getItem('novaQualityMode') || 'auto'; // 'auto' | 'full' | 'reduced' | 'minimal'
  let autoQualityTier = 'full'; // only used when qualityMode === 'auto', adjusted based on measured throughput
  function effectiveQualityTier() { return qualityMode === 'auto' ? autoQualityTier : qualityMode; }

  function maybeAdjustAutoQualityTier(measuredBytesPerSec, sourceSampleRate, sourceChannels) {
    if (qualityMode !== 'auto') return;
    const fullBytesPerSec = sourceSampleRate * sourceChannels * 2;
    const SAFETY_MARGIN_DOWN = 1.5, SAFETY_MARGIN_UP = 3.0;
    if (measuredBytesPerSec < fullBytesPerSec / SAFETY_MARGIN_DOWN) {
      if (autoQualityTier === 'full') autoQualityTier = 'reduced';
      else if (autoQualityTier === 'reduced') {
        const reducedBytesPerSec = 32000 * sourceChannels * 2;
        if (measuredBytesPerSec < reducedBytesPerSec / SAFETY_MARGIN_DOWN) autoQualityTier = 'minimal';
      }
    } else if (measuredBytesPerSec > fullBytesPerSec * SAFETY_MARGIN_UP && autoQualityTier !== 'full') {
      autoQualityTier = autoQualityTier === 'minimal' ? 'reduced' : 'full';
    }
    $('qualityAutoStatus').textContent = 'Currently using: ' + autoQualityTier;
  }

  // Fully server-decoded raw PCM (16-bit, interleaved) — the client does no LMS/rANS/
  // FLAC decode work at all, just accumulates bytes and writes them straight into an
  // AudioBuffer. Same interface as a client-side streaming decoder would have
  // (onReadyToPlay, decodedUpToSample) so the scheduling code above doesn't need to
  // know or care that the audio arrived pre-decoded rather than needing decoding.
  function getDecodedBufferFromServerPCM(track, onReadyToPlay) {
    return (async () => {
      const myGenerationToken = decodeGenerationToken;
      const quality = effectiveQualityTier();
      const url = '/api/stream/pcm?path=' + encodeURIComponent(track.localPath) + '&quality=' + quality;
      const resp = await fetch(url, { credentials: 'include' });
      if (!resp.ok) throw new Error('Server PCM stream failed: HTTP ' + resp.status);
      const sampleRate = parseInt(resp.headers.get('X-PCM-Sample-Rate'), 10);
      const numChannels = parseInt(resp.headers.get('X-PCM-Channels'), 10);
      const totalFrames = parseInt(resp.headers.get('X-PCM-Total-Frames'), 10);
      const bytesPerFrame = numChannels * 2;

      const ctx = ensureCtx();
      const audioBuffer = ctx.createBuffer(numChannels, totalFrames, sampleRate);
      audioBuffer.qualityTier = quality;
      if (myGenerationToken === decodeGenerationToken) decodedUpToSample = 0;

      const reader = resp.body.getReader();
      let carry = new Uint8Array(0);
      let calledReady = false;
      let totalBytesForThroughput = 0;
      const throughputStartMs = performance.now();
      let localDecodedUpTo = 0; // tracked locally too, so this decode's own onReadyToPlay/caching logic works even if the generation token has moved on

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        totalBytesForThroughput += value.byteLength;
        let combined;
        if (carry.length) { combined = new Uint8Array(carry.length + value.byteLength); combined.set(carry); combined.set(value, carry.length); }
        else combined = value;
        const usableFrames = Math.floor(combined.length / bytesPerFrame);
        const usableBytes = usableFrames * bytesPerFrame;
        carry = combined.slice(usableBytes);
        if (usableFrames > 0) {
          const view = new DataView(combined.buffer, combined.byteOffset, usableBytes);
          const startSample = localDecodedUpTo;
          for (let c = 0; c < numChannels; c++) {
            const dst = audioBuffer.getChannelData(c);
            for (let i = 0; i < usableFrames; i++) dst[startSample + i] = view.getInt16((i * numChannels + c) * 2, true) / 32768;
          }
          localDecodedUpTo = startSample + usableFrames;
          if (myGenerationToken === decodeGenerationToken) {
            decodedUpToSample = localDecodedUpTo;
            maybeExtendSchedule();
          }
        }
        if (!calledReady) {
          const bufferedSeconds = localDecodedUpTo / sampleRate;
          if (bufferedSeconds >= 3 || localDecodedUpTo >= totalFrames) { calledReady = true; onReadyToPlay(audioBuffer); }
        }
      }
      const elapsedSec = (performance.now() - throughputStartMs) / 1000;
      if (elapsedSec > 0.5) maybeAdjustAutoQualityTier(totalBytesForThroughput / elapsedSec, sampleRate, numChannels);
      if (!calledReady) onReadyToPlay(audioBuffer);
      return audioBuffer;
    })();
  }

  // ---------- Bounded decode cache ----------
  const decodeCache = new Map();
  const inFlightDecodes = new Map();
  function pruneCache(keepIds) {
    for (const id of decodeCache.keys()) if (!keepIds.includes(id)) decodeCache.delete(id);
  }
  async function getDecodedBufferFull(track) {
    if (decodeCache.has(track.id)) return decodeCache.get(track.id);
    if (inFlightDecodes.has(track.id)) return inFlightDecodes.get(track.id);
    const p = getDecodedBufferFromServerPCM(track, () => {}).then(ab => { decodeCache.set(track.id, ab); return ab; });
    inFlightDecodes.set(track.id, p);
    try { return await p; } finally { inFlightDecodes.delete(track.id); }
  }
  function prefetchNext() {
    const nextId = queue[queuePos + 1];
    if (!nextId) return;
    const track = trackById(nextId);
    if (!track) return;
    if (decodeCache.has(nextId) || inFlightDecodes.has(nextId)) return;
    getDecodedBufferFull(track).then(() => {
      pruneCache([queue[queuePos], queue[queuePos + 1]].filter(Boolean));
    }).catch(err => console.warn('Prefetch failed for', track.name, err));
  }

  // ---------- playTrack ----------
  async function playTrack(id, addQueueContext, startAtSeconds) {
    const track = trackById(id);
    if (!track) return;
    if (addQueueContext) { queue = addQueueContext; queuePos = queue.indexOf(id); }
    if (restoredPendingTrackId && id !== restoredPendingTrackId) restoredPendingTrackId = null; // picked something else — the deferred restore no longer applies
    stopSource(); isPlaying = false; currentBuffer = null;
    seekWaitToken++;
    // Invalidates any still-running decode of whatever was playing before THIS track
    // switch — decodeStreamingInWorker-equivalent PCM fetches have no abort mechanism
    // either, so an abandoned fetch's chunk loop would otherwise keep running in the
    // background and keep overwriting the shared decodedUpToSample with its own,
    // unrelated progress. See the NextCloud-backed player's fix for the full story —
    // same bug, same fix, applied here from the start rather than discovered later.
    decodeGenerationToken++;
    resetLastfmStateForNewTrack();
    saveStateToServer(true);
    const cached = decodeCache.has(id);
    const startAt = startAtSeconds || 0;
    $('playPauseBtn').disabled = true;

    if (cached) {
      currentBuffer = decodeCache.get(id);
      decodedUpToSample = currentBuffer.length; // fully decoded already — see the token comment above for why this must be set explicitly, not inherited from a stale prior decode
      $('playPauseBtn').disabled = false;
      setNowPlaying(track, 'Ready (cached)');
      updateQualityBadge(currentBuffer);
      $('timeTotal').textContent = fmtTime(currentBuffer.duration);
      startFrom(startAt);
      saveStateToServer(true); // isPlaying just flipped true — worth an immediate save rather than waiting for the throttled periodic one, so other devices see accurate status promptly
      maybeSendNowPlaying(track);
      renderQueue();
      pruneCache([queue[queuePos], queue[queuePos + 1]].filter(Boolean));
      prefetchNext();
      return;
    }

    setNowPlaying(track, 'Starting…');
    const t0 = performance.now();
    try {
      const fullBuffer = await getDecodedBufferFromServerPCM(track, (partialBuffer) => {
        currentBuffer = partialBuffer;
        $('playPauseBtn').disabled = false;
        const startedIn = ((performance.now() - t0) / 1000).toFixed(1);
        setNowPlaying(track, `Playing — buffering rest (started in ${startedIn}s)`);
        updateQualityBadge(partialBuffer);
        $('timeTotal').textContent = fmtTime(partialBuffer.duration);
        startFrom(startAt);
        saveStateToServer(true); // see the cached-path comment above — same reasoning
        maybeSendNowPlaying(track);
        renderQueue();
      });
      decodeCache.set(id, fullBuffer);
      setNowPlaying(track, 'Ready');
      pruneCache([queue[queuePos], queue[queuePos + 1]].filter(Boolean));
      prefetchNext();
    } catch (err) {
      setNowPlaying(track, 'Error: ' + err.message);
      $('playPauseBtn').disabled = false;
    }
  }
  function updateQualityBadge(buffer) {
    const badge = $('npQualityBadge');
    if (buffer.qualityTier && buffer.qualityTier !== 'full') {
      badge.textContent = buffer.qualityTier.toUpperCase();
      badge.classList.add('visible');
    } else {
      badge.classList.remove('visible');
    }
  }

  // ---------- Cross-device state sync ----------
  // A restored track is shown but NOT loaded — playTrack() opens a real server-side
  // decode stream immediately, and pausing playback right after doesn't stop that
  // stream: the fetch/decode loop in getDecodedBufferFromServerPCM keeps running to
  // completion regardless of playback state, since pausing only stops the audio
  // graph, not the network read loop feeding it. Calling playTrack() on every login
  // (to then immediately pause) was silently opening a full decode on the server on
  // every single page load — confirmed as the cause of unexplained server load and
  // audio starting for a moment on load. The actual decode only starts now when the
  // person deliberately presses play on a restored track.
  let restoredPendingTrackId = null, restoredPendingPositionSeconds = 0;
  function showRestoredNowPlaying(track, positionSeconds) {
    restoredPendingTrackId = track.id;
    restoredPendingPositionSeconds = positionSeconds;
    setNowPlaying(track, 'Paused — press play to resume');
    updateQualityBadge({});
    $('timeCurrent').textContent = fmtTime(positionSeconds);
    $('timeTotal').textContent = ''; // genuinely unknown until decode actually starts — nothing to compute this from without decoding
    $('seekBar').value = 0; // no known duration yet to compute a proportional position from
    $('playPauseBtn').disabled = false;
    $('playPauseBtn').textContent = '▶';
    if (!track.metaLoaded) {
      loadTagsFor([track]);
      // loadTagsFor updates the track object and the library ROW display once done, but
      // this track may not even be in the currently-visible library listing — refresh
      // the now-playing text specifically once its real tags are in, rather than leaving
      // the raw filename showing until the person picks something else.
      const checkTags = setInterval(() => {
        if (track.metaLoaded) {
          clearInterval(checkTags);
          if (restoredPendingTrackId === track.id) setNowPlaying(track, 'Paused — press play to resume');
        }
      }, 200);
    }
  }

  let lastStateSaveMs = 0;
  const STATE_SAVE_MIN_INTERVAL_MS = 15000;
  async function saveStateToServer(force) {
    const now = Date.now();
    if (!force && now - lastStateSaveMs < STATE_SAVE_MIN_INTERVAL_MS) return;
    lastStateSaveMs = now;
    try {
      await apiPostJson('/api/state', {
        trackId: queue[queuePos] || null,
        positionSeconds: currentBuffer ? currentTimeSec() : 0,
        queue, queuePos, repeatMode, shuffleEnabled, sourceMode: 'local',
        isPlaying,
      });
    } catch (e) { console.warn('[state] save failed:', e.message); }
  }
  let stateRestoredThisSession = false;
  async function restoreStateFromServer() {
    if (stateRestoredThisSession) return;
    stateRestoredThisSession = true;
    let state;
    try { state = await api('/api/state'); } catch (e) { return; }
    if (!state || !Array.isArray(state.queue) || !state.queue.length) return;
    // Every queued track needs to resolve against the full library, not just whatever
    // directory happens to be showing right now.
    await ensureFlatLibraryCache();
    const resolvedQueue = state.queue.filter(id => trackById(id));
    if (!resolvedQueue.length || !trackById(state.trackId)) return;
    queue = resolvedQueue;
    queuePos = Math.max(0, Math.min(resolvedQueue.length - 1, resolvedQueue.indexOf(state.trackId)));
    repeatMode = ['off', 'all', 'one'].includes(state.repeatMode) ? state.repeatMode : 'off';
    shuffleEnabled = !!state.shuffleEnabled;
    updateShuffleRepeatUI();
    renderQueue();
    showRestoredNowPlaying(trackById(state.trackId), state.positionSeconds || 0);
  }

  // ---------- Last.fm ----------
  let lastfmStatus = { configured: false, linked: false, username: null, scrobbleEnabled: true };
  let nowPlayingSentForCurrentTrack = false, scrobbledForCurrentTrack = false;
  function resetLastfmStateForNewTrack() { nowPlayingSentForCurrentTrack = false; scrobbledForCurrentTrack = false; }
  function lastfmEligible() { return lastfmStatus.linked && lastfmStatus.scrobbleEnabled; }
  async function maybeSendNowPlaying(track) {
    if (nowPlayingSentForCurrentTrack || !lastfmEligible()) return;
    nowPlayingSentForCurrentTrack = true;
    try {
      await apiPostJson('/api/lastfm/now-playing', {
        artist: track.tags.artist || '', track: track.tags.title || track.name, album: track.tags.album || '',
        duration: currentBuffer ? currentBuffer.duration : undefined,
      });
    } catch (e) { console.warn('[lastfm] now-playing failed:', e.message); }
  }
  async function maybeScrobble(track) {
    if (scrobbledForCurrentTrack || !lastfmEligible() || !currentBuffer) return;
    const duration = currentBuffer.duration;
    const playedSeconds = currentTimeSec();
    if (duration <= 30 || playedSeconds < Math.min(duration / 2, 240)) return;
    scrobbledForCurrentTrack = true;
    try {
      await apiPostJson('/api/lastfm/scrobble', {
        artist: track.tags.artist || '', track: track.tags.title || track.name, album: track.tags.album || '', duration, playedSeconds,
      });
    } catch (e) { console.warn('[lastfm] scrobble failed:', e.message); scrobbledForCurrentTrack = false; }
  }
  async function refreshLastfmStatus() {
    try { lastfmStatus = await api('/api/lastfm/status'); } catch (e) { lastfmStatus = { configured: false, linked: false, username: null, scrobbleEnabled: true }; }
    updateLastfmUI();
  }
  function updateLastfmUI() {
    $('lastfmNeedsCreds').classList.toggle('hidden', lastfmStatus.configured);
    $('lastfmNeedsLink').classList.toggle('hidden', !(lastfmStatus.configured && !lastfmStatus.linked));
    $('lastfmLinked').classList.toggle('hidden', !lastfmStatus.linked);
    if (lastfmStatus.linked) {
      $('lastfmUsernameDisplay').textContent = lastfmStatus.username;
      $('lastfmScrobbleToggle').checked = !!lastfmStatus.scrobbleEnabled;
    }
  }
  function showLastfmError(msg) { $('lastfmError').textContent = msg; $('lastfmError').style.display = 'inline'; }

  // ---------- Devices ----------
  async function loadDevices() {
    try {
      const [devices, stateDevices] = await Promise.all([api('/api/auth/devices'), api('/api/state/devices')]);
      let html = '';
      if (stateDevices.activeTrackId && stateDevices.activeDevice) {
        const isHere = stateDevices.activeDevice === (currentUser && currentUser.deviceLabel);
        const track = trackById(stateDevices.activeTrackId);
        html += `<div id="activeDeviceBanner">` +
          `<div><span class="k">${stateDevices.activeIsPlaying ? 'Playing' : 'Paused'} on:</span> ${escapeHtml(stateDevices.activeDevice)}${isHere ? ' (this device)' : ''}</div>` +
          `<div class="k2">${escapeHtml(track ? displayName(track) : stateDevices.activeTrackId)}</div>` +
          (isHere ? '' : `<button id="playHereBtn" type="button">Play here</button>`) +
          `</div>`;
      }
      html += devices.map(d =>
        `<div class="device-row"><span class="${d.isThisDevice ? 'thisDevice' : ''}">${escapeHtml(d.deviceLabel)}${d.isThisDevice ? ' (this device)' : ''}</span>${d.isThisDevice ? '' : `<button data-id="${d.id}" class="revokeBtn" type="button">Sign out</button>`}</div>`
      ).join('');
      $('deviceList').innerHTML = html;
      $('deviceList').querySelectorAll('.revokeBtn').forEach(btn => {
        btn.addEventListener('click', async () => { await apiPostJson('/api/auth/devices/' + btn.dataset.id + '/revoke'); loadDevices(); });
      });
      const playHereBtn = $('deviceList').querySelector('#playHereBtn');
      if (playHereBtn) playHereBtn.addEventListener('click', () => takeOverPlaybackHere(stateDevices));
    } catch (e) {}
  }

  // ---------- Device switching (Spotify-Connect-style "play here") ----------
  // Only one shared playback position per account (see the schema notes in lib/db.js) —
  // "switching devices" here means loading whatever's currently active elsewhere and
  // starting it on THIS device instead, at the same position. There's no push channel
  // to instantly silence the other device — it finds out and stops itself the next time
  // its own periodic state check notices a different device has taken over (see
  // maybeYieldToOtherDevice below), which is a several-second handoff window by design,
  // not a bug — building true instant multi-device control would need a whole separate
  // realtime channel (websockets or similar) this app doesn't have.
  async function takeOverPlaybackHere(stateDevices) {
    const track = trackById(stateDevices.activeTrackId);
    if (!track) return;
    await ensureFlatLibraryCache();
    const resolvedTrack = trackById(stateDevices.activeTrackId);
    if (!resolvedTrack) return;
    queue = [stateDevices.activeTrackId];
    queuePos = 0;
    renderQueue();
    $('settingsPanel').classList.remove('open');
    await playTrack(queue[queuePos]);
  }
  let lastKnownActiveDevice = null;
  async function maybeYieldToOtherDevice() {
    if (!isPlaying) return;
    try {
      const stateDevices = await api('/api/state/devices');
      if (lastKnownActiveDevice === null) lastKnownActiveDevice = stateDevices.activeDevice;
      const thisDeviceLabel = currentUser && currentUser.deviceLabel;
      if (stateDevices.activeDevice && stateDevices.activeDevice !== thisDeviceLabel && stateDevices.activeDevice !== lastKnownActiveDevice) {
        // Someone else explicitly took over since we last checked — stop here rather
        // than two devices playing the same account's audio at once.
        pausePlayback();
        setNpStatusText(`Paused — now playing on ${stateDevices.activeDevice}`);
      }
      lastKnownActiveDevice = stateDevices.activeDevice;
    } catch (e) {}
  }

  // ---------- Wiring ----------
  function wireEvents() {
    $('loginBtn').addEventListener('click', async () => {
      $('loginError').style.display = 'none';
      try {
        await apiPostJson('/api/auth/login', { username: $('loginUsername').value, password: $('loginPassword').value, deviceLabel: navigator.userAgent.slice(0, 60) });
        currentUser = await api('/api/auth/me');
        onLoggedIn();
      } catch (e) { $('loginError').textContent = e.message; $('loginError').style.display = 'block'; }
    });
    $('registerBtn').addEventListener('click', async () => {
      $('loginError').style.display = 'none';
      try {
        await apiPostJson('/api/auth/register', { username: $('loginUsername').value, password: $('loginPassword').value, deviceLabel: navigator.userAgent.slice(0, 60) });
        currentUser = await api('/api/auth/me');
        onLoggedIn();
      } catch (e) { $('loginError').textContent = e.message; $('loginError').style.display = 'block'; }
    });
    $('logoutBtn').addEventListener('click', async () => {
      try { await apiPostJson('/api/auth/logout'); } catch (e) {}
      currentUser = null; showLogin();
    });

    // Mobile drawers — sidebar/queue become off-canvas panels below the 860px
    // breakpoint (see the CSS); these buttons and the backdrop only do anything
    // there, harmless no-ops on desktop where .drawer-toggle/#drawerBackdrop stay hidden.
    function closeDrawers() {
      $('sidebar').classList.remove('open');
      $('queuePanel').classList.remove('open');
      $('drawerBackdrop').classList.remove('open');
    }
    function openDrawer(which) {
      closeDrawers();
      $(which).classList.add('open');
      $('drawerBackdrop').classList.add('open');
    }
    $('sidebarToggleBtn').addEventListener('click', () => openDrawer('sidebar'));
    $('queueToggleBtn').addEventListener('click', () => openDrawer('queuePanel'));
    $('drawerBackdrop').addEventListener('click', closeDrawers);
    // Picking a folder or a track is a natural "I'm done with this drawer" moment —
    // close it automatically rather than making the person dismiss it separately.
    $('dirList').addEventListener('click', closeDrawers);
    $('trackList').addEventListener('click', closeDrawers);

    $('settingsToggle').addEventListener('click', () => { $('settingsPanel').classList.add('open'); updateAudioDiagnostics(); });
    $('newPlaylistBtn').addEventListener('click', createNewPlaylist);
    document.addEventListener('click', (e) => {
      if (!e.target.closest('#addToPlaylistMenu') && !e.target.closest('[data-add-pl-id]')) closeAddToPlaylistMenu();
    });
    $('settingsCloseBtn').addEventListener('click', () => $('settingsPanel').classList.remove('open'));

    $('searchBox').addEventListener('input', onSearchInput);

    $('playPauseBtn').addEventListener('click', () => {
      if (!currentBuffer) {
        // Nothing decoded yet — either a restored track waiting for its first
        // deliberate play, or genuinely nothing selected at all.
        if (restoredPendingTrackId && queue[queuePos] === restoredPendingTrackId) {
          const resumeAt = restoredPendingPositionSeconds;
          restoredPendingTrackId = null;
          playTrack(queue[queuePos], null, resumeAt);
        }
        return;
      }
      if (isPlaying) pausePlayback(); else resumePlayback();
    });
    $('nextBtn').addEventListener('click', playNextInQueue);
    $('prevBtn').addEventListener('click', playPrevInQueue);
    $('repeatBtn').addEventListener('click', toggleRepeat);
    $('shuffleBtn').addEventListener('click', toggleShuffle);
    $('seekBar').addEventListener('input', () => { if (!currentBuffer) return; seekTo((parseFloat($('seekBar').value) / 1000) * currentBuffer.duration); });

    $('qualitySelect').value = qualityMode;
    $('qualityAutoStatus').style.display = qualityMode === 'auto' ? 'block' : 'none';
    $('qualitySelect').addEventListener('change', () => {
      qualityMode = $('qualitySelect').value;
      localStorage.setItem('novaQualityMode', qualityMode);
      $('qualityAutoStatus').style.display = qualityMode === 'auto' ? 'block' : 'none';
    });

    $('lastfmSaveCredsBtn').addEventListener('click', async () => {
      $('lastfmError').style.display = 'none';
      try { await apiPostJson('/api/lastfm/credentials', { apiKey: $('lastfmApiKey').value, apiSecret: $('lastfmApiSecret').value }); $('lastfmApiSecret').value = ''; await refreshLastfmStatus(); }
      catch (e) { showLastfmError(e.message); }
    });
    $('lastfmChangeCredsBtn').addEventListener('click', async () => {
      try { await apiPostJson('/api/lastfm/credentials/clear'); await refreshLastfmStatus(); } catch (e) { showLastfmError(e.message); }
    });
    $('lastfmLinkBtn').addEventListener('click', async () => {
      $('lastfmError').style.display = 'none';
      try {
        const { token, authUrl } = await apiPostJson('/api/lastfm/link/start');
        const popup = window.open(authUrl, 'lastfm-auth', 'width=500,height=650');
        let attempts = 0;
        const poll = setInterval(async () => {
          attempts++;
          if (attempts > 60 || (popup && popup.closed && attempts > 3)) { clearInterval(poll); return; }
          try {
            await apiPostJson('/api/lastfm/link/finish', { token });
            clearInterval(poll);
            if (popup && !popup.closed) popup.close();
            await refreshLastfmStatus();
          } catch (e) {}
        }, 2000);
      } catch (e) { showLastfmError(e.message); }
    });
    $('lastfmUnlinkBtn').addEventListener('click', async () => {
      try { await apiPostJson('/api/lastfm/unlink'); await refreshLastfmStatus(); } catch (e) { showLastfmError(e.message); }
    });
    $('lastfmScrobbleToggle').addEventListener('change', async () => {
      try { await apiPostJson('/api/lastfm/scrobble-enabled', { enabled: $('lastfmScrobbleToggle').checked }); } catch (e) { showLastfmError(e.message); }
    });
  }

  window.addEventListener('DOMContentLoaded', () => {
    initClientErrorReporting();
    wireEvents();
    setupMediaSessionHandlers();
    updateShuffleRepeatUI();
    checkSession();
  });
})();
