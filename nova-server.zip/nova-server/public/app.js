(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);

  // ---------- Fetch helpers ----------
  async function api(path, options) {
    const resp = await fetch(path, Object.assign({ credentials: 'include' }, options));
    let data = null;
    try { data = await resp.json(); } catch (e) {}
    if (!resp.ok) throw new Error((data && data.error) || ('HTTP ' + resp.status));
    return data;
  }
  function apiPostJson(path, body) {
    return api(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
  }
  function apiDelete(path) {
    return api(path, { method: 'DELETE' });
  }

  // ---------- Client-side error reporting ----------
  // Captures console.error calls, uncaught exceptions, and unhandled promise
  // rejections, batches them, and periodically reports them to the server's log —
  // same mechanism proven out in the NextCloud-backed player, unchanged here.
  let clientErrorBuffer = [];
  const CLIENT_ERROR_FLUSH_INTERVAL_MS = 10000;
  const CLIENT_ERROR_BUFFER_MAX = 50;
  function bufferClientError(level, message, stack) {
    clientErrorBuffer.push({ level, message: String(message).slice(0, 2000), stack: stack ? String(stack).slice(0, 1000) : undefined, url: window.location.href });
    if (clientErrorBuffer.length > CLIENT_ERROR_BUFFER_MAX) clientErrorBuffer.shift();
    // Real, direct fix for a completely fair complaint: logging has been
    // reactive all session, one hand-added line at a time, requiring a
    // rebuild-and-wait cycle every time a new blind spot showed up. This is
    // the ALREADY-EXISTING, established call site used throughout this file
    // for exactly this kind of warning/error — routing it here too, once,
    // means every current AND future call to bufferClientError anywhere in
    // this file automatically shows up in the on-device log, with no
    // separate patch needed per call site ever again.
    if (window.NovaNative && typeof nativeDebugLog === 'function') nativeDebugLog(`[${level}] ${message}`);
  }
  function flushClientErrors(useBeacon) {
    if (!clientErrorBuffer.length) return;
    const entries = clientErrorBuffer;
    clientErrorBuffer = [];
    const body = JSON.stringify({ entries });
    if (useBeacon && navigator.sendBeacon) {
      // sendBeacon has no failure callback at all — the browser guarantees
      // best-effort delivery even through page unload, which is exactly why this
      // path exists, but it also means there's no way to detect a failure here to
      // requeue from. Accepted as-is; the fetch path below is the one that can
      // and does recover.
      navigator.sendBeacon('/api/logs/client-error', new Blob([body], { type: 'application/json' }));
    } else {
      // Real, confirmed bug: this used to clear the buffer unconditionally BEFORE
      // the request even completed, then silently swallow any failure with no
      // retry — meaning entries were already gone the moment the request was
      // sent, regardless of whether it actually succeeded. On a connection bad
      // enough to be generating warnings worth logging in the first place, that
      // same connection is exactly the one most likely to also fail to DELIVER
      // the log about it — losing precisely the evidence most needed, right when
      // it's needed most. Failed entries now go back to the front of the buffer
      // so the next flush interval retries them, instead of losing them outright.
      fetch('/api/logs/client-error', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body, credentials: 'include' })
        .then(res => { if (!res.ok) throw new Error('HTTP ' + res.status); })
        .catch(() => { clientErrorBuffer = entries.concat(clientErrorBuffer).slice(-CLIENT_ERROR_BUFFER_MAX); });
    }
  }
  function initClientErrorReporting() {
    const origConsoleError = console.error;
    console.error = function (...args) {
      origConsoleError.apply(console, args);
      const errArg = args.find(a => a instanceof Error);
      bufferClientError('error', args.map(a => a instanceof Error ? a.message : String(a)).join(' '), errArg && errArg.stack);
    };
    window.addEventListener('error', (e) => bufferClientError('error', e.message, e.error ? e.error.stack : undefined));
    window.addEventListener('unhandledrejection', (e) => {
      const reason = e.reason;
      bufferClientError('error', reason instanceof Error ? reason.message : String(reason), reason instanceof Error ? reason.stack : undefined);
    });
    setInterval(() => flushClientErrors(false), CLIENT_ERROR_FLUSH_INTERVAL_MS);
    window.addEventListener('pagehide', () => flushClientErrors(true));
  }

  // ---------- Auth ----------
  let currentUser = null;
  async function checkSession() {
    try {
      const me = await api('/api/auth/me');
      currentUser = me;
      onLoggedIn();
    } catch (e) {
      showLogin();
    }
  }
  function showLogin() {
    $('loginScreen').style.display = 'flex';
    $('appScreen').style.display = 'none';
  }
  function showApp() {
    $('loginScreen').style.display = 'none';
    $('appScreen').style.display = 'flex';
  }
  async function onLoggedIn() {
    showApp();
    $('whoami').textContent = currentUser.username + (currentUser.isAdmin ? ' (admin)' : '');
    if ($('adminLink')) $('adminLink').style.display = currentUser.isAdmin ? '' : 'none';
    await loadPersistedThroughput();
    await refreshLastfmStatus();
    await loadDevices();
    await loadPlaylists();
    await browseTo('');
    await restoreStateFromServer();
  }

  // ---------- Library / directory browsing ----------
  // Recursively browsing everything up front (like the NextCloud-backed player does)
  // would mean walking the whole tree before showing anything — for a large local
  // library that's a slow first load for no reason. Instead this browses one directory
  // at a time, like a normal file browser: click a folder, see its contents. Search
  // still needs the full flat list, so that's built lazily the first time it's used.
  let currentDirPath = '';
  let currentDirListing = { dirs: [], files: [] };
  let flatLibraryCache = null; // built lazily on first search
  let library = []; // currently-displayed track objects (either one directory's files, or search results)

  function trackFromFile(f) {
    return { id: 'local:' + f.path, localPath: f.path, name: f.name, tags: {}, picture: null, metaLoaded: false };
  }

  async function browseTo(path) {
    currentPlaylistId = null; // switching to folder browsing — a playlist may have been showing before
    try {
      const listing = await api('/api/browse?path=' + encodeURIComponent(path));
      currentDirPath = listing.path;
      currentDirListing = listing;
      library = listing.files.map(trackFromFile);
      renderBreadcrumbs();
      renderDirList();
      renderLibrary();
      loadTagsFor(library);
    } catch (err) {
      // Previously failed completely silently here — a network/auth/server error left
      // the library panel just blank with no indication anything went wrong, which is
      // indistinguishable from "this directory genuinely has no files in it". Now shows
      // an actual error so the two cases don't look identical.
      console.error('Failed to browse "' + (path || '(root)') + '":', err.message);
      $('viewTitle').textContent = 'Could not load library';
      $('viewCount').textContent = '';
      $('trackList').innerHTML = `<div style="padding:16px; color:var(--danger);">Error loading ${escapeHtml(path || 'the library')}: ${escapeHtml(err.message)}</div>`;
    }
  }

  function renderBreadcrumbs() {
    const parts = currentDirPath ? currentDirPath.split('/') : [];
    const crumbs = [{ label: 'Library', path: '' }];
    let acc = '';
    for (const p of parts) { acc = acc ? acc + '/' + p : p; crumbs.push({ label: p, path: acc }); }
    $('breadcrumbs').innerHTML = crumbs.map((c, i) =>
      `<div class="crumb" data-path="${escapeAttr(c.path)}">${'—'.repeat(i)} ${escapeHtml(c.label)}</div>`
    ).join('');
    $('breadcrumbs').querySelectorAll('.crumb').forEach(el => {
      el.addEventListener('click', () => browseTo(el.dataset.path));
    });
  }
  function renderDirList() {
    $('dirList').innerHTML = currentDirListing.dirs.map(d =>
      `<div class="dirRow" data-path="${escapeAttr(d.path)}">📁 ${escapeHtml(d.name)}</div>`
    ).join('');
    $('dirList').querySelectorAll('.dirRow').forEach(el => {
      el.addEventListener('click', () => browseTo(el.dataset.path));
    });
  }

  async function walkFullLibrary(relPath, out) {
    const listing = await api('/api/browse?path=' + encodeURIComponent(relPath));
    for (const f of listing.files) out.push(trackFromFile(f));
    for (const d of listing.dirs) await walkFullLibrary(d.path, out);
  }
  async function ensureFlatLibraryCache() {
    if (flatLibraryCache) return flatLibraryCache;
    flatLibraryCache = [];
    await walkFullLibrary('', flatLibraryCache);
    loadTagsFor(flatLibraryCache);
    return flatLibraryCache;
  }

  // ---------- Playlists ----------
  let playlists = []; // {id, name, trackCount}
  async function loadPlaylists() {
    try { playlists = await api('/api/playlists'); } catch (e) { playlists = []; }
    renderPlaylistList();
  }
  function renderPlaylistList() {
    $('playlistList').innerHTML = playlists.map(p =>
      `<div class="playlist-row${currentPlaylistId === p.id ? ' active' : ''}" data-pl-id="${p.id}">` +
      `<span class="plName">${escapeHtml(p.name)}</span><span class="plCount">${p.trackCount}</span>` +
      `<button class="plDeleteBtn" type="button" data-delete-pl="${p.id}" title="Delete playlist">✕</button>` +
      `</div>`
    ).join('');
    $('playlistList').querySelectorAll('.playlist-row').forEach(el => {
      el.addEventListener('click', (e) => {
        if (e.target.closest('.plDeleteBtn')) return;
        openPlaylist(parseInt(el.dataset.plId, 10));
      });
    });
    $('playlistList').querySelectorAll('[data-delete-pl]').forEach(el => {
      el.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (!confirm('Delete this playlist? The tracks themselves are untouched.')) return;
        await apiDelete('/api/playlists/' + el.dataset.deletePl);
        if (currentPlaylistId === parseInt(el.dataset.deletePl, 10)) { currentPlaylistId = null; browseTo(''); }
        loadPlaylists();
      });
    });
  }
  async function createNewPlaylist() {
    const name = prompt('Playlist name:');
    if (!name || !name.trim()) return;
    await apiPostJson('/api/playlists', { name: name.trim() });
    loadPlaylists();
  }
  async function openPlaylist(id) {
    currentPlaylistId = id;
    let playlist;
    try { playlist = await api('/api/playlists/' + id); } catch (e) { return; }
    await ensureFlatLibraryCache();
    library = playlist.trackPaths.map(p => trackById('local:' + p)).filter(Boolean);
    renderPlaylistList();
    renderLibrary();
  }
  async function removeTrackFromCurrentPlaylist(index) {
    if (!currentPlaylistId) return;
    await apiDelete(`/api/playlists/${currentPlaylistId}/tracks/${index}`);
    openPlaylist(currentPlaylistId); // reload to reflect the renumbered positions
    loadPlaylists(); // track count changed
  }
  function showAddToPlaylistMenu(trackId, anchorEl) {
    const menu = $('addToPlaylistMenu');
    const rect = anchorEl.getBoundingClientRect();
    menu.style.left = Math.min(rect.left, window.innerWidth - 200) + 'px';
    menu.style.top = (rect.bottom + 4) + 'px';
    menu.innerHTML = playlists.length
      ? playlists.map(p => `<div class="aptRow" data-target-pl="${p.id}">${escapeHtml(p.name)}</div>`).join('')
      : `<div class="aptEmpty">No playlists yet — create one from the sidebar first.</div>`;
    menu.querySelectorAll('[data-target-pl]').forEach(el => {
      el.addEventListener('click', async () => {
        menu.classList.remove('open');
        const localPath = trackId.startsWith('local:') ? trackId.slice(6) : trackId;
        try {
          await apiPostJson(`/api/playlists/${el.dataset.targetPl}/tracks`, { trackPath: localPath });
          loadPlaylists();
        } catch (e) { alert('Could not add track: ' + e.message); }
      });
    });
    menu.classList.add('open');
  }
  function closeAddToPlaylistMenu() { $('addToPlaylistMenu').classList.remove('open'); }

  async function runWithConcurrencyLimit(items, limit, worker) {
    let idx = 0;
    async function next() {
      while (idx < items.length) {
        const item = items[idx++];
        await worker(item);
      }
    }
    await Promise.all(Array.from({ length: Math.min(limit, items.length) }, next));
  }
  function loadTagsFor(tracks) {
    const needed = tracks.filter(t => !t.metaLoaded);
    if (!needed.length) return;
    runWithConcurrencyLimit(needed, 4, async (track) => {
      try {
        const tags = await api('/api/browse/tags?path=' + encodeURIComponent(track.localPath));
        track.tags = { title: tags.title || undefined, artist: tags.artist || undefined, album: tags.album || undefined };
        track.numChannels = tags.numChannels || null; // used to pick a sane starting stream quality for multichannel tracks — see effectiveQualityTier's caller in getDecodedBufferFromServerPCM
      } catch (e) {}
      track.metaLoaded = true;
      renderLibraryRow(track);
    });
  }

  function trackById(id) {
    const inLibrary = library.find(t => t.id === id);
    if (inLibrary) return inLibrary;
    if (flatLibraryCache) return flatLibraryCache.find(t => t.id === id);
    return null;
  }
  function escapeHtml(s) { return String(s || '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }
  function escapeAttr(s) { return escapeHtml(s); }

  // ---------- Rendering: track list, queue ----------
  let queue = [], queuePos = -1, repeatMode = 'off', shuffleEnabled = false;

  function displayName(t) { return (t.tags.title || t.name); }
  function displayArtist(t) { return t.tags.artist || ''; }

  // Album grouping — ported from player.html (see AngelGonePro/nova-next-generation-
  // optimized-versatile-audio-codec's groupTracksByAlbum), same grouping/sort logic,
  // adapted to this app's track shape (identical: t.tags.album, t.tags.track,
  // t.tags.title, t.name all already match).
  const UNTITLED_ALBUM = 'Untitled Album';
  function groupTracksByAlbum(tracks) {
    const groups = new Map();
    for (const t of tracks) {
      const albumName = (t.tags.album && t.tags.album.trim()) || UNTITLED_ALBUM;
      if (!groups.has(albumName)) groups.set(albumName, []);
      groups.get(albumName).push(t);
    }
    const albumNames = [...groups.keys()].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }));
    return albumNames.map(albumName => {
      const albumTracks = groups.get(albumName).slice().sort((a, b) => {
        const an = parseInt(a.tags.track, 10), bn = parseInt(b.tags.track, 10);
        const aHas = !isNaN(an), bHas = !isNaN(bn);
        if (aHas && bHas && an !== bn) return an - bn;
        if (aHas !== bHas) return aHas ? -1 : 1;
        return displayName(a).localeCompare(displayName(b), undefined, { sensitivity: 'base' });
      });
      return { albumName, tracks: albumTracks };
    });
  }

  function artworkUrl(track) {
    return '/api/browse/artwork?path=' + encodeURIComponent(track.localPath);
  }
  let currentPlaylistId = null; // non-null when viewing a playlist's contents instead of a folder
  // Extracted from the old renderLibrary's inline template so both the grouped
  // (album view) and flat (playlist/search) layouts can share the exact same row
  // markup and event-wiring data-attributes — only the leading visual (artwork
  // thumbnail vs. track number) and whether the album subtitle shows changes
  // between the two, matching player.html's own inAlbumGroup option.
  function trackRowHtml(t, i, opts) {
    opts = opts || {};
    const leadingVisual = opts.inAlbumGroup
      ? `<div class="track-num">${escapeHtml(t.tags.track || '·')}</div>`
      : `<img class="track-art" src="${artworkUrl(t)}" alt="" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'track-art placeholder',textContent:'♪'}))">`;
    return `<div class="track-row${queue[queuePos] === t.id ? ' playing' : ''}" data-id="${escapeAttr(t.id)}">` +
      leadingVisual +
      `<div class="tInfo"><span class="tName">${escapeHtml(displayName(t))}</span>` +
      (opts.inAlbumGroup ? '' : `<span class="tAlbum">${escapeHtml(t.tags.album || '')}</span>`) +
      `</div>` +
      `<span class="tArtist">${escapeHtml(displayArtist(t))}</span>` +
      `<button class="tAddBtn" type="button" data-add-id="${escapeAttr(t.id)}" title="Add to queue">+</button>` +
      (currentPlaylistId
        ? `<button class="tAddBtn" type="button" data-remove-pl-idx="${i}" title="Remove from playlist">✕</button>`
        : `<button class="tAddBtn" type="button" data-add-pl-id="${escapeAttr(t.id)}" title="Add to playlist">+PL</button>`) +
      `</div>`;
  }
  function renderLibrary() {
    $('viewTitle').textContent = currentPlaylistId ? (playlists.find(p => p.id === currentPlaylistId) || {}).name || 'Playlist' : (currentDirPath || 'Library');
    $('viewCount').textContent = `${library.length} track${library.length === 1 ? '' : 's'}`;
    if (!library.length && !currentDirListing.dirs.length && !currentPlaylistId) {
      // Genuinely empty, not an error — distinct from browseTo()'s catch block above,
      // which handles the "something went wrong" case. This is "the request succeeded
      // and there's honestly nothing here", which needs its own message too, or it's
      // indistinguishable from either of the other blank-looking states.
      $('trackList').innerHTML = `<div style="padding:16px; color:var(--muted);">No audio files found in ${escapeHtml(currentDirPath || 'the music library root')}. If you expected files here, double-check HOST_MUSIC_DIR in .env actually points at the folder containing them, and that the container was restarted after any change to it.</div>`;
      return;
    }
    if (!library.length && currentPlaylistId) {
      $('trackList').innerHTML = `<div style="padding:16px; color:var(--muted);">This playlist is empty. Add tracks from the Library view using the "+PL" button on any track.</div>`;
      return;
    }
    // Album grouping — same conditions as player.html's own version: only in the
    // folder-browsing view, never a playlist (a playlist's own order is the point
    // of it), and never while actively searching (search results are their own
    // flat, relevance-ordered list, not something that reads naturally grouped
    // by album).
    const searchActive = !!$('searchBox').value.trim();
    if (!currentPlaylistId && !searchActive) {
      const groups = groupTracksByAlbum(library);
      $('trackList').innerHTML = groups.map(g => {
        const firstWithArt = g.tracks[0];
        return `<div class="album-group">
          <div class="album-header">
            <img class="album-header-art" src="${artworkUrl(firstWithArt)}" alt="" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'album-header-art placeholder',textContent:'♪'}))">
            <div class="album-header-info">
              <div class="album-header-name">${escapeHtml(g.albumName)}</div>
              <div class="album-header-count">${g.tracks.length} track${g.tracks.length === 1 ? '' : 's'}</div>
            </div>
          </div>
          <div class="album-tracks">
            ${g.tracks.map(t => trackRowHtml(t, 0, { inAlbumGroup: true })).join('')}
          </div>
        </div>`;
      }).join('');
    } else {
      $('trackList').innerHTML = library.map((t, i) => trackRowHtml(t, i)).join('');
    }
    $('trackList').querySelectorAll('.track-row').forEach(el => {
      el.addEventListener('click', (e) => {
        if (e.target.closest('.tAddBtn')) return; // handled separately below — don't also jump to playing it
        // Queue order matches what's actually displayed — album-grouped-and-sorted
        // when grouping is showing, library's own raw order otherwise (search
        // results, playlists) — same reasoning as player.html's own version.
        const playOrder = (!currentPlaylistId && !searchActive) ? groupTracksByAlbum(library).flatMap(g => g.tracks) : library;
        playTrack(el.dataset.id, playOrder.map(t => t.id));
      });
    });
    $('trackList').querySelectorAll('[data-add-id]').forEach(el => {
      el.addEventListener('click', (e) => { e.stopPropagation(); addToQueue(el.dataset.addId); });
    });
    $('trackList').querySelectorAll('[data-add-pl-id]').forEach(el => {
      el.addEventListener('click', (e) => { e.stopPropagation(); showAddToPlaylistMenu(el.dataset.addPlId, el); });
    });
    $('trackList').querySelectorAll('[data-remove-pl-idx]').forEach(el => {
      el.addEventListener('click', (e) => { e.stopPropagation(); removeTrackFromCurrentPlaylist(parseInt(el.dataset.removePlIdx, 10)); });
    });
  }
  let regroupDebounce = null;
  function renderLibraryRow(track) {
    const row = $('trackList').querySelector(`.track-row[data-id="${CSS.escape(track.id)}"]`);
    if (row) {
      row.querySelector('.tName').textContent = displayName(track);
      const albumEl = row.querySelector('.tAlbum');
      if (albumEl) albumEl.textContent = track.tags.album || ''; // absent when this row is inside an album group (no per-row album subtitle there)
      row.querySelector('.tArtist').textContent = displayArtist(track);
    }
    // Real gap found while porting album grouping: tags (including the album tag
    // grouping depends on) load asynchronously per-track, and this function only
    // ever patched one row's text in place — it never re-grouped anything. A
    // track whose album tag arrived AFTER the initial render would stay stuck
    // under "Untitled Album" forever, even once its real tag was known. Debounced
    // (not an immediate re-render per tag) since tags arrive in a burst — this
    // lets that whole burst settle once, rather than visibly re-grouping the list
    // repeatedly as each individual tag trickles in.
    if (!currentPlaylistId && !$('searchBox').value.trim()) {
      clearTimeout(regroupDebounce);
      regroupDebounce = setTimeout(renderLibrary, 300);
    }
  }

  // ---------- Queue management ----------
  function addToQueue(id) {
    if (!trackById(id)) return;
    queue.push(id);
    renderQueue();
  }
  function removeFromQueue(index) {
    if (index === queuePos) return; // don't remove what's actively loaded/playing — stop or skip first
    queue.splice(index, 1);
    if (index < queuePos) queuePos--; // shift to keep pointing at the same actual track
    renderQueue();
  }
  function moveQueueItem(index, direction) {
    const target = index + direction;
    if (target < 0 || target >= queue.length) return;
    [queue[index], queue[target]] = [queue[target], queue[index]];
    if (queuePos === index) queuePos = target;
    else if (queuePos === target) queuePos = index;
    renderQueue();
  }
  function renderQueue() {
    $('queueList').innerHTML = queue.map((id, i) => {
      const t = trackById(id);
      const isActive = i === queuePos;
      return `<div class="queue-row${isActive ? ' active' : ''}" data-idx="${i}">` +
        `<span class="qName">${escapeHtml(t ? displayName(t) : id)}</span>` +
        `<button class="qBtn" type="button" data-q-action="up" data-idx="${i}" title="Move up" ${i === 0 ? 'disabled' : ''}>↑</button>` +
        `<button class="qBtn" type="button" data-q-action="down" data-idx="${i}" title="Move down" ${i === queue.length - 1 ? 'disabled' : ''}>↓</button>` +
        `<button class="qBtn" type="button" data-q-action="remove" data-idx="${i}" title="Remove from queue" ${isActive ? 'disabled' : ''}>✕</button>` +
        `</div>`;
    }).join('');
    $('queueList').querySelectorAll('.queue-row').forEach(el => {
      el.addEventListener('click', (e) => {
        if (e.target.closest('.qBtn')) return; // buttons handle their own action below
        queuePos = parseInt(el.dataset.idx, 10); playTrack(queue[queuePos]);
      });
    });
    $('queueList').querySelectorAll('.qBtn').forEach(el => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        const idx = parseInt(el.dataset.idx, 10);
        if (el.dataset.qAction === 'up') moveQueueItem(idx, -1);
        else if (el.dataset.qAction === 'down') moveQueueItem(idx, 1);
        else if (el.dataset.qAction === 'remove') removeFromQueue(idx);
      });
    });
  }
  function updateShuffleRepeatUI() {
    $('repeatBtn').textContent = repeatMode === 'off' ? '🔁' : repeatMode === 'all' ? '🔁' : '🔂';
    $('repeatBtn').style.opacity = repeatMode === 'off' ? '0.5' : '1';
    $('shuffleBtn').style.opacity = shuffleEnabled ? '1' : '0.5';
  }
  function toggleRepeat() {
    repeatMode = repeatMode === 'off' ? 'all' : repeatMode === 'all' ? 'one' : 'off';
    updateShuffleRepeatUI();
  }
  function toggleShuffle() { shuffleEnabled = !shuffleEnabled; updateShuffleRepeatUI(); }

  let searchDebounce = null;
  async function onSearchInput() {
    const q = $('searchBox').value.trim().toLowerCase();
    clearTimeout(searchDebounce);
    if (!q) { library = currentDirListing.files.map(trackFromFile); renderLibrary(); loadTagsFor(library); return; }
    searchDebounce = setTimeout(async () => {
      const all = await ensureFlatLibraryCache();
      library = all.filter(t => displayName(t).toLowerCase().includes(q) || displayArtist(t).toLowerCase().includes(q));
      renderLibrary();
    }, 250);
  }

  function fmtTime(sec) {
    if (!isFinite(sec) || sec < 0) sec = 0;
    const m = Math.floor(sec / 60), s = Math.floor(sec % 60);
    return m + ':' + String(s).padStart(2, '0');
  }
  function setNowPlaying(track, statusText) {
    $('npTitle').textContent = displayName(track);
    $('npArtist').textContent = displayArtist(track);
    $('npAlbum').textContent = track.tags.album || '';
    $('npStatusText').textContent = statusText || '';
    const artEl = $('npArt');
    artEl.classList.remove('hidden');
    artEl.onerror = () => artEl.classList.add('hidden');
    const artUrl = artworkUrl(track);
    artEl.src = artUrl;
    if ('mediaSession' in navigator && 'MediaMetadata' in window) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: displayName(track), artist: displayArtist(track) || '', album: track.tags.album || '',
        // Absolute URL required here — MediaSession artwork is fetched by the OS lock-
        // screen surface itself, not by this page's own DOM, and a relative path isn't
        // guaranteed to resolve correctly in that context the way it does for an <img>
        // tag sitting in this document. Same endpoint the in-page thumbnails use, so if
        // a track has no embedded art this 404s and the lock screen just shows no image,
        // exactly like the in-page fallback already does — not treated as an error.
        artwork: [{ src: new URL(artUrl, window.location.href).href, sizes: '512x512', type: 'image/jpeg' }],
      });
    }
    // Real, direct fix for a pointed complaint: "why aren't you implementing
    // the same media info as the chrome one" — the answer is that native
    // mode's lock-screen update lived in a separate, manually-invoked
    // function (nativeUpdateNowPlaying) instead of hooking into THIS
    // function, which is the one thing the web path already calls
    // consistently everywhere track info changes. Calling it from here
    // means native mode's lock screen updates on exactly the same events,
    // at exactly the same time, as the web version's navigator.mediaSession
    // does — the same single source of truth, not two paths that can drift
    // out of sync with each other.
    if (window.NovaNative) nativeUpdateNowPlaying(track, isPlaying, currentBuffer ? currentBuffer.duration : (window.__nativeKnownDuration || 0), currentTimeSec());
  }
  function setNpStatusText(t) { $('npStatusText').textContent = t; }

  // ---------- Playback engine ----------
  // Multi-buffering: a single AudioBuffer mutated while connected to a live, playing
  // AudioBufferSourceNode is a confirmed Web Audio API race condition in WebKit/Blink.
  // Decoded audio is scheduled as a sequence of separate, small buffers instead — each
  // fully populated before ever being connected to a source node, and never touched
  // again afterward. Identical architecture to the NextCloud-backed player's, proven
  // out there across an extended debugging session (crackling, mobile CPU limits,
  // rebuffer reliability) — reused here unchanged rather than re-derived.
  let audioCtx = null, currentBuffer = null, masterGainNode = null, loudnessGainNode = null;
  let playStartedAtCtxTime = 0, playOffset = 0, isPlaying = false, rafId = null;
  // Tracks whether the seek bar is currently being dragged — see
  // tickProgress's own comment (in frame()) for exactly what this fixes.
  // Declared here, at module scope, specifically because frame() (also
  // module-scope) needs to read it and the seek bar's own pointerdown/
  // pointerup handlers (attached later, inside the UI-wiring function) need
  // to write it — a first attempt at this fix declared it inside that
  // nested function instead, which frame() has no visibility into at all;
  // caught before it shipped.
  let seekBarDragging = false;
  // Real, direct fix for a reported "timeline stuck" complaint: playOffset
  // in native mode only ever changed when a segment FETCH completed —
  // roughly every 60 seconds of content — not continuously as audio
  // actually played. That meant the displayed timeline was always going to
  // look frozen for long stretches between those updates and then jump,
  // network hiccups aside; a failed segment (visible in the report's own
  // log, an EOFException retrying right at the 120s mark) just made one
  // particular freeze longer and more obvious. These track a wall-clock
  // basis (when playOffset was last known-accurate, and what it was at that
  // moment) so currentTimeSec() can compute a smoothly advancing position
  // between segment boundaries, the same way the Web-Audio path already
  // does with audioCtx.currentTime — just using wall-clock time instead,
  // since native mode has no audio-graph clock to read from.
  let nativeOffsetBasisMs = 0, nativeOffsetBasisValue = 0;
  // Real, direct fix for a reported "timeline started moving 4 seconds
  // before any sound was actually audible" complaint: nativeSetPlayOffset
  // used to start the wall-clock basis immediately, at the same moment a
  // track/resume/seek was first REQUESTED — but real audio doesn't begin
  // until a network fetch completes and the native engine actually starts
  // writing to the AudioTrack, which can genuinely take a few real seconds.
  // This flag gates the wall-clock formula in currentTimeSec() — while
  // false, it returns the static playOffset instead of one that's already
  // advancing for time that hasn't actually been heard yet. Set true only
  // by the native engine's own onTrackBoundaryReached signal (see
  // NativeAudioBridge.kt), which fires at the moment audio genuinely starts.
  let nativeClockRunning = false;
  function nativeSetPlayOffset(seconds) {
    playOffset = seconds;
    nativeOffsetBasisMs = Date.now();
    nativeOffsetBasisValue = seconds;
  }
  // Called from native code (see the init block in NativeAudioBridge.kt)
  // the moment the first chunk of a track actually reaches the playback
  // thread — this is what actually starts the wall-clock formula, not the
  // moment playback was merely requested.
  window.__novaTrackAudioStarted = function () {
    nativeClockRunning = true;
    nativeOffsetBasisMs = Date.now();
    nativeOffsetBasisValue = playOffset;
    // Matches the Web-Audio path's own status text once real audio is
    // actually flowing (see waitForDecodeAndPlay's identical string) —
    // this is the direct fix for the status previously being stuck on
    // whatever it was set to at the start of playTrackNative, never
    // updated once playback genuinely began.
    setNpStatusText('Playing — buffering rest');
    // Real, direct fix for a confirmed automatic-pause complaint, traced
    // straight to its actual trigger via a device log: this set
    // nativeClockRunning correctly, but never told the MEDIA SESSION
    // itself that the state changed — only the on-screen status text.
    // The lock screen kept reporting STATE_BUFFERING indefinitely, since
    // nothing ever re-reported isBuffering:false once real audio genuinely
    // started. A track stuck showing "buffering" forever is itself an
    // abnormal state a connected device or the OS's media framework can
    // reasonably try to correct with its own automatic pause — which is
    // exactly what the log showed, arriving via window.__novaTransport,
    // not a button tap.
    const track = nativeCurrentTrackId && trackById(nativeCurrentTrackId);
    if (track) nativeUpdateNowPlaying(track, isPlaying, window.__nativeKnownDuration || 0, currentTimeSec());
  };
  /**
   * Real, direct fix for a confirmed "timeline keeps going past the
   * track's actual end" report — see onBufferingStateChanged's own
   * comment in NativeAudioEngine.kt for the full reasoning. The wall-clock
   * formula in currentTimeSec() has no way to know a genuine download
   * stall is happening — it just keeps counting real time elapsed
   * regardless. This freezes the displayed position the instant a stall
   * genuinely starts, and resumes counting from exactly that frozen value
   * the instant it genuinely ends, so a stall never contributes phantom
   * elapsed time to the display again.
   */
  // Real, direct addition alongside the auto-quality step-down system
  // above — the actual trigger for it. Tracks recent buffering-START
  // timestamps for whichever track is currently playing; if genuine
  // stalls keep recurring within a short window, that's the connection
  // telling this tier is too demanding right now, not one unlucky blip.
  // Reset whenever the track itself changes, so a new track always gets
  // a clean slate rather than inheriting a previous track's struggle
  // history.
  let recentBufferingStarts = [];
  let recentBufferingStartsTrackId = null;
  const AUTO_QUALITY_DOWNGRADE_WINDOW_MS = 30000;
  const AUTO_QUALITY_DOWNGRADE_THRESHOLD = 3;
  // Real, direct refactor extracting the shared downgrade-trigger logic —
  // now fed by TWO signals: an actual, complete stall (isBuffering=true)
  // and the proactive low-margin warning below, which can fire well
  // before playback ever actually runs dry. Both count as the same kind
  // of "connection struggling at this tier" evidence toward the same
  // threshold, so a connection that's continuously thin — never quite
  // stalling outright, per the original follow-up report — still gets
  // caught and downgraded, not just one that's already produced audible
  // gaps.
  function recordConnectionStruggleAndMaybeDowngrade(track) {
    if (!track || qualityMode !== 'auto') return;
    if (recentBufferingStartsTrackId !== track.id) {
      recentBufferingStartsTrackId = track.id;
      recentBufferingStarts = [];
    }
    const now = Date.now();
    recentBufferingStarts = recentBufferingStarts.filter(t => now - t < AUTO_QUALITY_DOWNGRADE_WINDOW_MS);
    recentBufferingStarts.push(now);
    if (recentBufferingStarts.length >= AUTO_QUALITY_DOWNGRADE_THRESHOLD && autoQualityTierIndex < AUTO_QUALITY_STEPS.length - 1) {
      autoQualityTierIndex++;
      recentBufferingStarts = []; // a fresh window for the NEW tier — don't let stalls already counted against the old tier immediately trigger another step down
      nativeDebugLog(`auto quality: stepping down to '${AUTO_QUALITY_STEPS[autoQualityTierIndex]}' after ${AUTO_QUALITY_DOWNGRADE_THRESHOLD} struggle signals in ${AUTO_QUALITY_DOWNGRADE_WINDOW_MS / 1000}s on trackId=${track.id}`);
      setNowPlaying(track, 'Lowering quality for a smoother connection…');
      nativeStartBufferedTrack(track.id, track, currentTimeSec());
    }
  }
  window.__novaBufferingStateChanged = function (isBuffering) {
    nativeSetPlayOffset(currentTimeSec()); // snapshot wherever the clock actually is right now, before changing whether it's running
    nativeClockRunning = !isBuffering;
    const track = nativeCurrentTrackId && trackById(nativeCurrentTrackId);
    if (track) nativeUpdateNowPlaying(track, isPlaying, window.__nativeKnownDuration || 0, currentTimeSec());
    if (isBuffering) recordConnectionStruggleAndMaybeDowngrade(track);
  };
  /**
   * Real, direct addition for a confirmed follow-up: a prebuffer margin
   * and reactive-to-actual-stalls quality downgrade only address a
   * track's start and stalls that have already happened. This is the
   * proactive half — native code fires this when the download's margin
   * ahead of playback is genuinely thin, even though nothing has actually
   * run dry yet, specifically so a connection that's continuously
   * struggling (the exact case in the follow-up report) gets caught and
   * downgraded before it produces another audible gap, not only after
   * enough of them have already happened to count as a pattern.
   */
  window.__novaBufferMarginLow = function () {
    const track = nativeCurrentTrackId && trackById(nativeCurrentTrackId);
    recordConnectionStruggleAndMaybeDowngrade(track);
  };
  // The actual fix for "gapless but wait until the song before it is
  // done" — resolved once native code confirms a track's actual LAST
  // audio chunk has genuinely, fully been written out (see
  // onTrackEndReached's own comment in NativeAudioEngine.kt). The fetch
  // loop's own "reached end" handling awaits this before ever starting the
  // next track, instead of starting it the moment all of the CURRENT
  // track's data merely finished downloading — those are very different
  // moments, and conflating them is what caused the early-start bugs this
  // was built to fix for good.
  //
  // A latch, not just a list of pending resolvers: the last chunk can
  // legitimately finish writing (and fire this) before the JS side even
  // reaches its own await — a genuinely possible race, not a hypothetical
  // one, given how little audio a short final segment can be. Without
  // latching, a signal that arrives early would simply be lost, and the
  // eventual await would hang forever waiting for one that already
  // happened. reachedFlag makes an early signal "sticky" until consumed.
  let nativeTrackEndResolvers = [];
  let nativeTrackEndReachedFlag = false;
  window.__novaTrackEndReached = function () {
    if (nativeTrackEndResolvers.length) {
      const resolvers = nativeTrackEndResolvers;
      nativeTrackEndResolvers = [];
      resolvers.forEach(r => r());
    } else {
      nativeTrackEndReachedFlag = true;
    }
  };
  function waitForNativeTrackEnd() {
    if (nativeTrackEndReachedFlag) { nativeTrackEndReachedFlag = false; return Promise.resolve(); }
    // Safety timeout — if this signal never arrives for any reason (a bug
    // elsewhere, a write that silently never completes), playback should
    // never hang indefinitely waiting for it; that would be a strictly
    // worse failure than the early-start bug this whole mechanism exists
    // to fix. 5s comfortably covers real AudioTrack buffer drain time.
    return new Promise(resolve => {
      let settled = false;
      const done = () => { if (settled) return; settled = true; resolve(); };
      nativeTrackEndResolvers.push(done);
      setTimeout(done, 5000);
    });
  }
  // Real, direct fix needed for the buffered path's own track-end
  // handling — waitForNativeTrackEnd's 5-second timeout is correct for
  // the OLD engine's use (called only once the last segment is already
  // arriving, seconds from the real end) but wrong here: this gets called
  // the MOMENT a buffered track starts, potentially minutes before it
  // actually ends. Reusing that function as-is would fire the timeout
  // early into every single track and skip to the next one after 5
  // seconds, every time. Same underlying signal, no premature timeout —
  // genuinely waits as long as the track actually takes to play.
  function waitForNativeTrackEndNoTimeout() {
    if (nativeTrackEndReachedFlag) { nativeTrackEndReachedFlag = false; return Promise.resolve(); }
    return new Promise(resolve => {
      nativeTrackEndResolvers.push(resolve);
    });
  }
  let scheduledSegments = [];
  let scheduledUpToSample = 0, scheduledUpToCtxTime = 0;
  let decodedUpToSample = 0;
  let pendingDecodeCheck = null; // set while waitForDecodeAndPlay's poll loop is active — see the heartbeat handler for why this gets invoked from there too
  let lastDisplayedT = null; // tracks the last displayed playback position, purely to detect and log a genuine backward jump — see the diagnostic in tickProgress
  let currentStreamStartMs = null; // when the current decode/stream attempt began (wall-clock) — used to estimate throughput from a rebuffer even if the stream never reaches a clean 'end'
  // Sliding window of recent (wall-clock ms, decodedUpToSample) snapshots — used
  // instead of a cumulative "total bytes since stream start" average for BOTH the
  // periodic in-progress measurement and the rebuffer-triggered one. Real,
  // confirmed bug in the cumulative approach: an initial burst (the required
  // upfront buffering before playback even starts naturally happens fast, since
  // nothing is competing with it yet) skews a since-the-start average upward
  // enough to look like it justifies full quality, even when the actual ongoing
  // SUSTAINED rate afterward — the number that actually determines whether
  // playback keeps up — is well below that. This tracks only the most recent
  // window (~12s) of real progress, which is far more representative of what the
  // connection can sustain right now.
  const THROUGHPUT_WINDOW_MS = 12000;
  let throughputWindow = []; // [{atMs, sample}]
  function recordThroughputSample(sampleValue) {
    const now = Date.now();
    throughputWindow.push({ atMs: now, sample: sampleValue });
    while (throughputWindow.length > 1 && now - throughputWindow[0].atMs > THROUGHPUT_WINDOW_MS) throughputWindow.shift();
  }
  function windowedBytesPerSec(numberOfChannels) {
    if (throughputWindow.length < 2) return null;
    const oldest = throughputWindow[0], newest = throughputWindow[throughputWindow.length - 1];
    const dtSec = (newest.atMs - oldest.atMs) / 1000;
    if (dtSec < 2) return null; // too short a window to trust yet
    const dSamples = newest.sample - oldest.sample;
    return (dSamples / dtSec) * numberOfChannels * 2;
  }
  let decodeGenerationToken = 0; // see playTrack() — invalidates any still-running decode of whatever was playing before, so an abandoned decode can't corrupt state for whatever's playing now

  function isFirefox() { return /firefox/i.test(navigator.userAgent) && !/seamonkey/i.test(navigator.userAgent); }

  // Some browsers only reliably show OS-level media notifications/lock-screen controls
  // for audio actually flowing through an <audio>/<video> element — plain Web Audio API
  // playback (which is what this app uses for sample-accurate, multichannel-safe output)
  // isn't always enough on its own. This shadow element carries NO real audio at all —
  // just silence, entirely separate from the real playback graph — purely to satisfy
  // that "something is actively playing" check. A real, finite-duration looping file (via
  // a Blob URL) rather than a live MediaStream: some browsers only show media
  // notifications once an element has actually started producing decoded frames, which a
  // silent file does immediately and reliably.
  //
  // Deliberately NOT routing the real (potentially multichannel) audio through anything
  // like this: that would mean going through MediaStreamAudioDestinationNode, which has a
  // real, documented, still-unresolved spec bug where it doesn't reliably honor
  // channelCount above its default of 2 — a risk of silently downmixing this app's actual
  // multichannel output to stereo, far worse than missing lock-screen controls. The real
  // audio path stays completely untouched either way — same reasoning ported directly
  // from the NextCloud-backed player, where this exact mechanism was worked out.
  let shadowAudioEl = null;
  let shadowMediaStreamDest = null;
  function buildSilentWavBlobUrl() {
    const sampleRate = 8000, seconds = 6, bytesPerSample = 1; // 8-bit unsigned PCM — silence is the midpoint value (128), tiny file regardless of quality since there's no real content
    const dataSize = sampleRate * seconds * bytesPerSample;
    const buf = new ArrayBuffer(44 + dataSize);
    const dv = new DataView(buf);
    const writeStr = (offset, str) => { for (let i = 0; i < str.length; i++) dv.setUint8(offset + i, str.charCodeAt(i)); };
    writeStr(0, 'RIFF'); dv.setUint32(4, 36 + dataSize, true); writeStr(8, 'WAVE');
    writeStr(12, 'fmt '); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 1, true);
    dv.setUint32(24, sampleRate, true); dv.setUint32(28, sampleRate * bytesPerSample, true);
    dv.setUint16(32, bytesPerSample, true); dv.setUint16(34, 8, true);
    writeStr(36, 'data'); dv.setUint32(40, dataSize, true);
    const pcm = new Uint8Array(buf, 44, dataSize);
    pcm.fill(128); // 8-bit unsigned PCM silence is the midpoint, not zero
    return URL.createObjectURL(new Blob([buf], { type: 'audio/wav' }));
  }
  function ensureShadowMediaElement(ctx) {
    if (shadowAudioEl) return;
    try {
      shadowAudioEl = document.createElement('audio');
      if (isFirefox()) {
        // Firefox's media control system, per Mozilla's own support documentation, only
        // works for AUDIBLE <audio>/<video> elements — explicitly not Web Audio API
        // output, and explicitly not "inaudible media". A silent shadow element (what
        // non-Firefox browsers get below) is exactly the "inaudible" case Firefox
        // excludes — so for Firefox, this element needs to actually carry the real,
        // audible audio, routed here INSTEAD OF (not alongside) the direct
        // ctx.destination connection in scheduleSegment(), to avoid doubled/echoed
        // output. Always downmixed to exactly 2 channels first: MediaStreamAudioDestinationNode
        // doesn't reliably honor channelCount above its default of 2 — capping at 2
        // here sidesteps that bug, at the cost of losing discrete multichannel output
        // specifically on Firefox. A deliberate trade-off: working lock-screen controls
        // there vs. full channel fidelity there. Other browsers are unaffected either way.
        shadowMediaStreamDest = ctx.createMediaStreamDestination();
        shadowAudioEl.srcObject = shadowMediaStreamDest.stream;
        shadowAudioEl.volume = 1;
      } else {
        shadowAudioEl.src = buildSilentWavBlobUrl();
        shadowAudioEl.loop = true;
      }
      shadowAudioEl.setAttribute('playsinline', '');
      shadowAudioEl.style.display = 'none';
      document.body.appendChild(shadowAudioEl);
      shadowAudioEl.play().catch(() => {});
      // Defensive: some browsers route the OS-level lock-screen/notification play-pause
      // button to the actual <audio> element directly, rather than exclusively through
      // navigator.mediaSession's registered action handlers — in which case this shadow
      // element could get paused/resumed by the OS without ever calling this app's own
      // pausePlayback()/resumePlayback(), leaving its state (and the in-page button
      // icon) stuck out of sync, with the real audio unaffected either way. Both paths —
      // the registered MediaSession handlers AND these native element events — now
      // converge on the same pausePlayback()/resumePlayback() calls, so whichever
      // mechanism the OS actually uses, the app's state stays correct. Those functions
      // already guard on isPlaying, so redundant calls from both paths firing are
      // harmless no-ops, not a risk of double-toggling.
      shadowAudioEl.addEventListener('pause', () => pausePlayback());
      shadowAudioEl.addEventListener('play', () => resumePlayback());
    } catch (e) {
      // If this fails for any reason, the real audio path is entirely unaffected —
      // this is purely an attempt at OS integration, never load-bearing for playback.
    }
  }

  function ensureCtx() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const maxCh = audioCtx.destination.maxChannelCount || 2;
      try {
        audioCtx.destination.channelCount = Math.min(8, maxCh);
        audioCtx.destination.channelCountMode = 'explicit';
        audioCtx.destination.channelInterpretation = 'discrete';
      } catch (e) {}
      // Master gain sits between every segment and the actual destination — lets
      // stopSource() below apply a fast ramp-down instead of an instant, hard cut.
      // Real, confirmed source of a click: found via a real recording where the user
      // tapped a track in the library while it was already playing partway through —
      // stopSource()'s old immediate .stop() cut the waveform off mid-amplitude with
      // no transition at all, a well-known source of an audible click whenever the
      // signal isn't at a zero-crossing at the moment of the cut (which it
      // essentially never is). The warmup buffer below intentionally stays connected
      // directly to destination, not through this — it's silent, nothing to click on.
      masterGainNode = audioCtx.createGain();
      masterGainNode.gain.value = 1;
      // Real, direct fix for a confirmed "center channel shifts left" complaint,
      // found by direct, line-by-line comparison against player.html — the one
      // playback path confirmed NOT to have this bug. player.html connects its
      // source straight to ctx.destination with nothing in between. This graph
      // routes through segGain -> masterGainNode -> loudnessGainNode first —
      // and connectWithDownmix only ever sets discrete interpretation on
      // whichever node gets passed in as its own "src" parameter (segGain, in
      // this chain). masterGainNode and loudnessGainNode themselves never got
      // the same explicit treatment, left running on the Web Audio API's own
      // defaults instead — the same gap the destination itself already had an
      // explicit fix for, just never carried through the rest of the chain
      // sitting in front of it. Set explicitly here, matching the destination's
      // own already-correct configuration, so multichannel content passes
      // through discrete at every single hop, not just the first and last.
      try {
        masterGainNode.channelCount = 8;
        masterGainNode.channelCountMode = 'explicit';
        masterGainNode.channelInterpretation = 'discrete';
      } catch (e) {}
      // Fixed safety-trim gain — normalization itself now happens server-side
      // (baked into the cached PCM before it ever reaches the client, see
      // lib/pcmStream.js), so this is just a small constant headroom trim, not
      // a per-track computed value — see applyLoudnessTrim below.
      loudnessGainNode = audioCtx.createGain();
      loudnessGainNode.gain.value = 1;
      try {
        loudnessGainNode.channelCount = 8;
        loudnessGainNode.channelCountMode = 'explicit';
        loudnessGainNode.channelInterpretation = 'discrete';
      } catch (e) {}
      masterGainNode.connect(loudnessGainNode);
      // Safety limiter downstream of the loudness boost — real, direct bug found
      // from a report of new clipping immediately after normalization shipped:
      // loudnessGainNode sat after every existing per-segment limiter in this
      // graph, so a boost on a quiet-but-dynamic track (low average level, real
      // peaks) had nothing left to catch those peaks from clipping past 0dBFS.
      // Real, more serious issue found while investigating a multichannel report:
      // DynamicsCompressorNode defaults to channelCount=2 with
      // channelCountMode='clamped-max' per the Web Audio spec — meaning it can
      // silently downmix anything above 2 channels to stereo. That's almost
      // certainly the real reason the existing per-segment limiter above
      // explicitly avoids this node type for multichannel/surround content, not
      // just the startup-ramp issue its own comment describes. This safety net
      // sits in the SHARED path for every track regardless of channel count, so
      // a DynamicsCompressorNode here risked silently collapsing 5.1/7.1 content
      // to stereo — a far worse regression than the clipping it was meant to
      // fix. WaveShaperNode applies its curve independently per channel with no
      // such channel-count restriction, so it's used here instead: a gentle soft
      // clip that's completely transparent (exactly 1:1) below 0.9 of full
      // scale, and only gently rounds off anything above that — a genuine safety
      // net for the rare peak the loudness boost pushes over, not a general
      // processing stage.
      const softClip = audioCtx.createWaveShaper();
      const curveLen = 2048;
      const curve = new Float32Array(curveLen);
      const softClipStart = 0.9;
      for (let i = 0; i < curveLen; i++) {
        const x = (i / (curveLen - 1)) * 2 - 1; // -1..1
        const ax = Math.abs(x);
        if (ax <= softClipStart) {
          curve[i] = x; // fully transparent below the threshold
        } else {
          // Smoothly compress the remaining headroom (softClipStart..1) into
          // (softClipStart..~0.99) using a tanh taper, so it approaches but
          // never quite reaches full scale even on a hard-clipped input.
          const over = (ax - softClipStart) / (1 - softClipStart); // 0..1
          const shaped = softClipStart + (1 - softClipStart) * Math.tanh(over * 2) / Math.tanh(2);
          curve[i] = Math.sign(x) * shaped;
        }
      }
      softClip.curve = curve;
      softClip.oversample = '2x';
      // Same fix as masterGainNode/loudnessGainNode above, for the same
      // reason — every node in this chain needs its own explicit discrete
      // treatment, not just the destination and the first hop. Missed here
      // originally for the same reason it was missed on the two gain nodes:
      // each node in Web Audio has its own independent channelCount/
      // channelCountMode/channelInterpretation, none of it inherited from
      // upstream or downstream neighbors.
      try {
        softClip.channelCount = 8;
        softClip.channelCountMode = 'explicit';
        softClip.channelInterpretation = 'discrete';
      } catch (e) {}
      loudnessGainNode.connect(softClip);
      // Direct, final-stage clipping detector — added after two earlier
      // attempts (checking the decoded source buffer for discontinuities,
      // then for sustained near-full-scale runs) both came back clean on a
      // fresh, post-deploy log covering a session where clipping was still
      // reported. That's real evidence: it means whatever's happening isn't
      // in the decoded audio DATA itself, which is all those two checks could
      // ever see — it has to be somewhere in this processing chain (the
      // downmix, the gain stages, or the soft-clip curve above) between the
      // decoded buffer and what actually reaches the speakers. Rather than
      // keep guessing at which specific stage, this measures the ACTUAL
      // final output directly, after every stage above has already been
      // applied — an AnalyserNode tapped off the very end of the chain,
      // polled periodically for the same sustained-near-full-scale pattern.
      // This is the one check that's structurally guaranteed to catch the
      // problem regardless of which upstream stage turns out to be
      // responsible, because it's downstream of all of them.
      const outputAnalyser = audioCtx.createAnalyser();
      outputAnalyser.fftSize = 2048;
      // Same fix, same reasoning — see softClip's own comment just above.
      try {
        outputAnalyser.channelCount = 8;
        outputAnalyser.channelCountMode = 'explicit';
        outputAnalyser.channelInterpretation = 'discrete';
      } catch (e) {}
      softClip.connect(outputAnalyser);
      outputAnalyser.connect(audioCtx.destination); // AnalyserNode is a pass-through tap, not an endpoint — audio must continue on to the real destination, or nothing plays at all
      const outputClipCheckBuf = new Float32Array(outputAnalyser.fftSize);
      let lastOutputClipLogMs = 0;
      setInterval(() => {
        if (!isPlaying) return;
        outputAnalyser.getFloatTimeDomainData(outputClipCheckBuf);
        const CLIP_THRESHOLD = 0.985;
        const CLIP_RUN_THRESHOLD = 12; // shorter than the source-buffer check's threshold — this window is only ~2048 samples (~43ms at 48kHz) total, not a full segment, so proportionally less room for a run to accumulate in before this check point moves on
        let longestRun = 0, currentRun = 0, worstPeak = 0;
        for (let i = 0; i < outputClipCheckBuf.length; i++) {
          const av = Math.abs(outputClipCheckBuf[i]);
          if (av >= CLIP_THRESHOLD) {
            currentRun++;
            if (av > worstPeak) worstPeak = av;
            if (currentRun > longestRun) longestRun = currentRun;
          } else {
            currentRun = 0;
          }
        }
        if (longestRun >= CLIP_RUN_THRESHOLD) {
          // Throttled — this poll runs every 200ms, and a real clipping
          // passage typically spans many consecutive polls, so without a
          // cooldown a single audible event could generate dozens of
          // near-identical log lines.
          const nowMs = Date.now();
          if (nowMs - lastOutputClipLogMs > 2000) {
            lastOutputClipLogMs = nowMs;
            bufferClientError('warn', `Genuine clipping at the FINAL AUDIO OUTPUT (post all processing — downmix, gain, soft-clip), t=${currentTimeSec().toFixed(1)}s: longest run ${longestRun}/${outputClipCheckBuf.length} samples, peak=${worstPeak.toFixed(4)}`);
          }
        }
      }, 200);
      // Warm up the audio pipeline: browsers can briefly clip/glitch the very first real
      // sound played on a freshly-created AudioContext while the audio hardware pipeline
      // finishes initializing — a well-documented Web Audio quirk. Playing a near-instant
      // silent buffer immediately absorbs that startup cost before the actual track
      // starts.
      try {
        const warmup = audioCtx.createBufferSource();
        warmup.buffer = audioCtx.createBuffer(1, 1, audioCtx.sampleRate);
        warmup.connect(audioCtx.destination);
        warmup.start(0);
      } catch (e) {}
      ensureShadowMediaElement(audioCtx);
    }
    return audioCtx;
  }
  // Volume normalization moved server-side (see populateCacheInBackground and
  // serveFromCache in lib/pcmStream.js) — computed once per track, over the
  // genuinely complete decoded audio, and baked directly into what gets
  // streamed to every client. That fixes the actual root cause of two
  // reported problems at once: the client's old version could only ever
  // analyze whatever had streamed in so far (capped at 30s even on its
  // "complete track" pass — a real bug in that cap, not just a limitation),
  // so a louder chorus later in a track could clip while the track still
  // read as not loud enough overall; and running that analysis over
  // potentially tens of millions of samples on every play was real,
  // avoidable CPU work on exactly the devices (mobile) least able to spare
  // it. What's left client-side is a small FIXED safety trim, not a
  // per-track computation — -1dB of headroom below whatever the server
  // already normalized to, so there's still real margin before the
  // soft-clip limiter downstream needs to do anything on a track the
  // server hasn't cached and normalized yet (a genuinely new upload's very
  // first play, before its background cache populate finishes).
  const LOUDNESS_SAFETY_TRIM_DB = -1;
  function applyLoudnessTrim() {
    if (!loudnessGainNode) return;
    loudnessGainNode.gain.value = loudnessNormalizationMode === 'off' ? 1 : Math.pow(10, LOUDNESS_SAFETY_TRIM_DB / 20);
  }
  // Native mode has no audioCtx at all — playOffset is kept up to date
  // directly there instead (see playTrackNative's own position tracking),
  // so reading it directly is both correct and necessary; the audioCtx-based
  // calculation below only ever applied to the Web Audio path in the first
  // place.
  // Native mode has no audioCtx at all — computed from a wall-clock basis
  // instead (see nativeSetPlayOffset above for why this exists and what it
  // fixes), the same principle as the Web-Audio branch's own
  // audioCtx.currentTime-based calculation just below it.
  function currentTimeSec() { return window.NovaNative ? ((isPlaying && nativeClockRunning) ? nativeOffsetBasisValue + (Date.now() - nativeOffsetBasisMs) / 1000 : playOffset) : (isPlaying ? playOffset + (audioCtx.currentTime - playStartedAtCtxTime) : playOffset); }
  function stopSource() {
    // Fades the master gain down fast (15ms — short enough to be inaudible as a
    // fade, long enough to avoid a hard discontinuity click) and schedules every
    // segment's actual .stop() to land at the same moment the fade completes, so
    // nothing gets cut off mid-amplitude. Both are scheduled together on the audio
    // clock, not sequenced with a JS-side wait, so this stays fully synchronous —
    // no delay added to pause, track-switch, or seek responsiveness.
    if (scheduledSegments.length && masterGainNode && audioCtx) {
      const now = audioCtx.currentTime;
      const FADE_SECONDS = 0.015;
      masterGainNode.gain.cancelScheduledValues(now);
      masterGainNode.gain.setValueAtTime(masterGainNode.gain.value, now); // anchor at wherever the gain actually is right now, not wherever it was last explicitly set to
      masterGainNode.gain.linearRampToValueAtTime(0, now + FADE_SECONDS);
      masterGainNode.gain.setValueAtTime(1, now + FADE_SECONDS); // restored immediately after, ready for whatever plays next
      for (const seg of scheduledSegments) { try { seg.source.onended = null; seg.source.stop(now + FADE_SECONDS); } catch (e) {} }
    } else {
      for (const seg of scheduledSegments) { try { seg.source.onended = null; seg.source.stop(); } catch (e) {} }
    }
    scheduledSegments = [];
  }

  let downmixGraphCache = null;
  // Shared, cached limiters — created once per channel-config and reused across every
  // segment, same reasoning as downmixGraphCache below: a DynamicsCompressorNode has a
  // real, confirmed ~100ms startup ramp, so recreating one per segment would mean
  // hitting that ramp at every segment boundary instead of once per track.
  //
  // -1dBFS ceiling, applied on every output path (direct passthrough included, which
  // previously had no limiting at all) — modern masters commonly have sample peaks
  // sitting right at or very near 0dBFS, and the true (inter-sample, reconstructed
  // analog) peak can briefly exceed that even when no individual sample does — a well-
  // documented phenomenon, not specific to this app. Reported as short, intermittent
  // crackling that persisted even after full decode (ruling out a scheduling/timing
  // cause) is consistent with that: occasional true-peak overshoots clipping at the
  // DAC. DynamicsCompressorNode is the closest tool Web Audio actually provides for
  // this — configured aggressively (high ratio, fast attack) to approximate a limiter,
  // but it's still an envelope-following compressor, not a mathematically-guaranteed
  // brick-wall ceiling, worth being upfront about rather than overselling it as a
  // perfect fix. The threshold itself is set to -3, not -1, further down — verified
  // directly with OfflineAudioContext: 20:1 is the maximum ratio the Web Audio spec
  // allows, and at that cap, a -1 threshold alone only pulls a sustained full-scale
  // signal down to about -0.32dB actual output. -3 measured at -1.02dB, which is what
  // actually delivers the requested -1dBFS ceiling in practice.
  let directLimiterCache = null;
  function getSharedLimiter(ctx, cacheKey, destNode) {
    if (directLimiterCache && directLimiterCache.key === cacheKey) return directLimiterCache.limiter;
    const limiter = ctx.createDynamicsCompressor();
    // -3, not -1 — empirically verified with OfflineAudioContext: DynamicsCompressorNode's
    // 20:1 ratio cap (a hard Web Audio spec limit) means a -1 threshold alone only
    // reaches ~-0.32dB actual output for a sustained full-scale signal; -3 measured at
    // ~-1.02dB, matching the requested -1dBFS ceiling.
    limiter.threshold.value = -3; limiter.knee.value = 0; limiter.ratio.value = 20;
    limiter.attack.value = 0.001; limiter.release.value = 0.1;
    // DynamicsCompressorNode applies automatic makeup gain per the Web Audio spec —
    // NOT specific to this threshold, and NOT limited to content actually being
    // compressed: measured directly, a signal 40dB below this threshold (nowhere near
    // engaging the limiter) still came out +1.71dB louder than it went in. Left
    // uncompensated, that's a real problem, not just an unwanted coloration — content
    // that was already safely under 0dBFS could get pushed toward clipping BY the
    // "fix" meant to prevent it. This gain node exactly cancels that measured offset,
    // so untouched (below-threshold) audio passes through at true unity gain, and the
    // -1dBFS ceiling above is measured post-compensation, not before it.
    const makeupCompensation = ctx.createGain();
    makeupCompensation.gain.value = 0.8213090408092926;
    limiter.connect(makeupCompensation);
    makeupCompensation.connect(destNode);
    directLimiterCache = { key: cacheKey, limiter };
    return limiter;
  }

  function connectWithDownmix(ctx, src, sourceChannels, destChannelCount, destNode) {
    if (sourceChannels <= destChannelCount) {
      src.channelInterpretation = 'discrete';
      if (sourceChannels <= 2) {
        // Limiter applies here (stereo/mono direct playback) — confirmed with a real,
        // commercially-mastered file that this is a genuine risk, not theoretical:
        // measured a real stereo track peaking at exactly 0.000dBFS (sample peak),
        // consistent with typical loudness-maximized mastering. Multichannel/surround
        // content, checked the same way against a real 7.1 file, told a different
        // story — measured -6.46dB on its loudest channel, nowhere near the ceiling —
        // so this branch below intentionally does NOT apply the same limiter.
        const cacheKey = 'direct:' + sourceChannels + ':' + destChannelCount + ':' + (destNode === masterGainNode ? 'main' : 'shadow');
        src.connect(getSharedLimiter(ctx, cacheKey, destNode));
      } else {
        // Direct multichannel passthrough — no limiter. This used to have one, added
        // on the (reasonable-sounding, but wrong for this specific path) assumption
        // that any direct-to-output path could theoretically benefit from a ceiling.
        // Real, measured data says otherwise for actual surround content, and the
        // limiter itself introduced a genuine regression here: DynamicsCompressorNode
        // has a real, confirmed startup ramp when first created, and this path had
        // never gone through any compressor before — every track start was newly
        // hitting that ramp on content that never needed limiting in the first place.
        // Reported as crackling that got WORSE, specifically at track start, specifically
        // for multichannel — exactly consistent with this being the cause. Removed
        // rather than patched with a warmup workaround, since there's no real signal
        // problem here to justify keeping a compressor in this path at all.
        src.connect(destNode);
      }
      return;
    }
    if (destChannelCount === 2 && (sourceChannels === 6 || sourceChannels === 8)) {
      const cacheKey = sourceChannels + ':' + destChannelCount + ':' + (destNode === masterGainNode ? 'main' : 'shadow');
      let graph = (downmixGraphCache && downmixGraphCache.key === cacheKey) ? downmixGraphCache : null;
      if (!graph) {
        const merger = ctx.createChannelMerger(2);
        const limiter = ctx.createDynamicsCompressor();
        // -6, not -3 like the other paths — this path sums multiple channels together
        // with fixed, non-normalized gains (up to ~3.6x scale in the worst case per the
        // safety-limiter note below), feeding a much hotter signal into the limiter than
        // a straightforward pass-through does. Verified empirically the same way: -3
        // here only reached about -0.3dB actual output on a full-scale worst-case test
        // (every channel simultaneously at full scale); -6 measured at ~-1.4dB, safely
        // under the -1dBFS target — measured post-compensation, see the makeup-gain
        // note in getSharedLimiter for why that matters and isn't optional.
        limiter.threshold.value = -6; limiter.knee.value = 0; limiter.ratio.value = 20;
        limiter.attack.value = 0.001; limiter.release.value = 0.1;
        const makeupCompensation6 = ctx.createGain();
        makeupCompensation6.gain.value = 0.6745382285005522; // cancels this threshold's own measured makeup-gain offset (+3.42dB) — different value than the shared limiter's, since a lower threshold produces a larger automatic makeup gain
        merger.connect(limiter); limiter.connect(makeupCompensation6); makeupCompensation6.connect(destNode);
        graph = { key: cacheKey, merger, limiter };
        downmixGraphCache = graph;
      }
      const splitter = ctx.createChannelSplitter(sourceChannels);
      src.connect(splitter);
      const SIDE = 1.0, CENTER = 0.707, SURROUND = 0.707, LFE_GAIN = 0.5;
      function route(channelIndex, leftGain, rightGain) {
        if (leftGain > 0) { const g = ctx.createGain(); g.gain.value = leftGain; splitter.connect(g, channelIndex); g.connect(graph.merger, 0, 0); }
        if (rightGain > 0) { const g = ctx.createGain(); g.gain.value = rightGain; splitter.connect(g, channelIndex); g.connect(graph.merger, 0, 1); }
      }
      route(0, SIDE, 0); route(1, 0, SIDE); route(2, CENTER, CENTER); route(3, LFE_GAIN, LFE_GAIN);
      route(4, SURROUND, 0); route(5, 0, SURROUND);
      if (sourceChannels === 8) { route(6, SURROUND, 0); route(7, 0, SURROUND); }
      return;
    }
    // Generic fallback downmix (any other source/dest channel combination) — same
    // shared-limiter treatment; this path had no ceiling either previously.
    const cacheKey = 'fallback:' + sourceChannels + ':' + destChannelCount + ':' + (destNode === masterGainNode ? 'main' : 'shadow');
    const limiter = getSharedLimiter(ctx, cacheKey, destNode);
    const splitter = ctx.createChannelSplitter(sourceChannels);
    const merger = ctx.createChannelMerger(destChannelCount);
    src.connect(splitter);
    const gainPerChannel = 1 / Math.ceil(sourceChannels / destChannelCount);
    for (let c = 0; c < sourceChannels; c++) {
      const gain = ctx.createGain(); gain.gain.value = gainPerChannel;
      splitter.connect(gain, c); gain.connect(merger, 0, c % destChannelCount);
    }
    merger.connect(limiter);
  }

  // Short crossfade at every scheduling boundary — the actual, standard fix for
  // this exact, well-documented Web Audio API issue (see MAX_SEGMENT_SECONDS's
  // own comment below: consecutive AudioBufferSourceNodes can produce audible
  // discontinuities even with fully sample-accurate scheduling). Previously only
  // mitigated by reducing HOW OFTEN a boundary happens (10s max -> 30s max),
  // never actually eliminated — and it was never reported as still audible
  // because playback never survived long enough to hit more than one or two
  // boundaries before the earlier rebuffering issue interrupted things first.
  // Now that playback reliably continues, this pre-existing, latent issue is
  // reachable and reported directly. 12ms is short enough to be inaudible as a
  // deliberate "fade" while being long enough to smooth the discontinuity — a
  // standard crossfade duration for splicing continuous, adjacent audio.
  const SEGMENT_CROSSFADE_SECONDS = 0.012;
  function scheduleSegment(fromSample, toSample, ctxStartTime) {
    const ctx = ensureCtx();
    const numCh = currentBuffer.numberOfChannels;
    const isFirstSegmentOfSession = scheduledSegments.length === 0;
    const isTrackEnding = toSample >= currentBuffer.length;
    // New diagnostic — the crackling reported after the crossfade fix produces NO
    // log output at all under any existing check (it doesn't trigger a rebuffer,
    // an out-of-bounds drop, or a segment failure), so there was no way to tell
    // whether it's a real discontinuity in the decoded sample data itself
    // (independent of the crossfade — that only smooths gain, not the underlying
    // waveform) versus something else entirely. Compares the actual jump in
    // sample value right at this segment's join point against the typical
    // sample-to-sample variation in the surrounding audio (not a fixed
    // threshold — a loud drum hit can legitimately have a big jump; what matters
    // is whether THIS jump is unusual relative to its own neighborhood). Cheap
    // (a few dozen sample reads per channel), only runs at segment boundaries,
    // not every frame.
    // Real gap found from a reported "still clipping" complaint on exactly the
    // multichannel (7.1/8ch) content this session has been testing with: this
    // only ever checked channel 0. A discontinuity confined to a rear or LFE
    // channel would never trip this check at all, which would explain hearing
    // something audible while this warning never fires. Now checks every
    // channel present, and reports which one(s) actually show it — so if this
    // fires next time, the log says exactly where to look instead of leaving
    // it a guess.
    if (!isFirstSegmentOfSession && fromSample > 20 && fromSample < currentBuffer.length - 1) {
      const WINDOW = 20;
      const flaggedChannels = [];
      let worstDelta = 0;
      for (let c = 0; c < numCh; c++) {
        const chData = currentBuffer.getChannelData(c);
        const joinDelta = Math.abs(chData[fromSample] - chData[fromSample - 1]);
        let localDeltaSum = 0;
        for (let i = 2; i <= WINDOW; i++) localDeltaSum += Math.abs(chData[fromSample - i + 1] - chData[fromSample - i]);
        const localAvgDelta = localDeltaSum / (WINDOW - 1);
        // Threshold matches the network-boundary check's own (lowered from
        // (0.05, x8) to (0.02, x4) there, applied consistently here too) —
        // same reasoning: a discontinuity subtle enough to stay under the old
        // threshold can still be genuinely audible.
        if (joinDelta > Math.max(0.02, localAvgDelta * 4)) {
          flaggedChannels.push(`ch${c}: joinDelta=${joinDelta.toFixed(4)} vs local avg=${localAvgDelta.toFixed(4)} (${(joinDelta / Math.max(localAvgDelta, 1e-6)).toFixed(1)}x)`);
          if (joinDelta > worstDelta) worstDelta = joinDelta;
        }
      }
      if (flaggedChannels.length > 0) {
        bufferClientError('warn', `Possible real sample discontinuity at segment join, sample=${fromSample} (${(fromSample / currentBuffer.sampleRate).toFixed(1)}s), ${numCh}ch buffer — flagged: ${flaggedChannels.join('; ')}`);
        // Real, direct gap found from a reported "still crackling every ~30s,
        // confirmed present even on desktop's direct 8-channel passthrough
        // (no downmix, no limiter in that path at all)" — ruling out both of
        // those as the cause and pointing back to this exact boundary. This
        // check used to only ever log — the crossfade at this same boundary
        // (see SEGMENT_CROSSFADE_SECONDS) smooths the GAIN/loudness of the
        // transition, but that's a different thing from the underlying
        // waveform actually being continuous: if a real value discontinuity
        // already exists in currentBuffer at this position (from however it
        // got there), fading the gain in and out around it doesn't remove
        // the click, it just fades it in and out too. Direct sample-domain
        // smoothing — the same fix already applied at the network boundary —
        // actually removes it, the same technique for the same underlying
        // problem, now applied at both boundaries instead of just one of
        // them.
        const SMOOTH_SAMPLES = Math.min(24, currentBuffer.length - fromSample - 1);
        if (SMOOTH_SAMPLES > 1) {
          for (let c = 0; c < numCh; c++) {
            const chData = currentBuffer.getChannelData(c);
            const before = chData[fromSample - 1];
            const targetTrend = chData[fromSample + SMOOTH_SAMPLES];
            for (let i = 0; i < SMOOTH_SAMPLES; i++) {
              const frac = (i + 1) / SMOOTH_SAMPLES;
              chData[fromSample + i] = before * (1 - frac) + targetTrend * frac;
            }
          }
        }
      }
    }
    // Genuinely different check from the discontinuity one above, added after
    // that one kept coming up empty against a reported "still clipping"
    // complaint — a fair, direct question about why the logging "wasn't
    // working". It wasn't broken; it was checking for the wrong thing. A
    // discontinuity is a click/pop from a misaligned join between two
    // buffers; clipping is a sustained run of samples pinned at or near full
    // scale from a signal that's simply too loud — completely different
    // symptoms in the data, and the join check was never going to catch the
    // second one no matter how long this ran. This scans the segment about
    // to actually play for that specific pattern: real digital clipping
    // shows up as many samples in a row sitting at the same extreme value
    // (not the varying, momentary peaks a loud-but-unclipped passage would
    // have), which is what CLIP_RUN_THRESHOLD looks for rather than just
    // counting isolated near-full-scale samples. Strided, not exhaustive —
    // a 30s multichannel segment can be millions of samples, and a sustained
    // clipped run (by definition many consecutive samples) is virtually
    // certain to still be caught even sampling every few samples rather than
    // every single one.
    {
      const CLIP_THRESHOLD = 0.985; // near enough to full scale to be clipping, not just a genuine loud peak
      const CLIP_STRIDE = 3;
      const CLIP_RUN_THRESHOLD = 24; // consecutive (in stride terms) clipped samples before this counts as a real run, not an isolated peak
      const clippedChannels = [];
      for (let c = 0; c < numCh; c++) {
        const chData = currentBuffer.getChannelData(c);
        let longestRun = 0, currentRun = 0, totalClippedSamples = 0, worstPeak = 0;
        for (let i = fromSample; i < toSample; i += CLIP_STRIDE) {
          const av = Math.abs(chData[i]);
          if (av >= CLIP_THRESHOLD) {
            currentRun++;
            totalClippedSamples++;
            if (av > worstPeak) worstPeak = av;
            if (currentRun > longestRun) longestRun = currentRun;
          } else {
            currentRun = 0;
          }
        }
        if (longestRun >= CLIP_RUN_THRESHOLD) {
          clippedChannels.push(`ch${c}: longest run ${longestRun} samples (stride ${CLIP_STRIDE}), ${totalClippedSamples} total clipped samples checked in this segment, peak=${worstPeak.toFixed(4)}`);
        }
      }
      if (clippedChannels.length > 0) {
        bufferClientError('warn', `Genuine clipping detected in segment ${(fromSample / currentBuffer.sampleRate).toFixed(1)}s-${(toSample / currentBuffer.sampleRate).toFixed(1)}s, ${numCh}ch buffer — ${clippedChannels.join('; ')}`);
      }
    }
    // Real bug in the first attempt at this fix, found directly by re-deriving the
    // timing: setting the previous segment's gain to ramp down to 0 exactly AT the
    // same instant the next segment's gain ramps up FROM 0 doesn't crossfade
    // anything — both signals are scheduled back-to-back with zero time overlap,
    // so they simply both pass through silence at the same single instant. That's
    // a momentary dip to near-zero at the boundary, not a crossfade, and never
    // actually smooths anything. A real crossfade requires both segments' audio to
    // genuinely play SIMULTANEOUSLY during the transition window — this segment now
    // starts fadeSeconds before its own nominal boundary time and its buffer backs
    // up into the tail of what the previous segment already covers, so there is
    // real overlap for the gain ramps to cross through.
    const fadeSeconds = isFirstSegmentOfSession ? 0 : Math.min(SEGMENT_CROSSFADE_SECONDS, (toSample - fromSample) / currentBuffer.sampleRate / 2, fromSample / currentBuffer.sampleRate);
    const fadeSamples = Math.round(fadeSeconds * currentBuffer.sampleRate);
    const actualFromSample = fromSample - fadeSamples;
    const len = toSample - actualFromSample;
    const buf = ctx.createBuffer(numCh, len, currentBuffer.sampleRate);
    for (let c = 0; c < numCh; c++) buf.getChannelData(c).set(currentBuffer.getChannelData(c).subarray(actualFromSample, toSample));
    const src = ctx.createBufferSource();
    src.buffer = buf;
    // Dedicated per-segment gain stage purely for the boundary crossfade above —
    // inserted ahead of the existing downmix/limiter chain, which every segment
    // already shares regardless of this fade.
    const segGain = ctx.createGain();
    src.connect(segGain);
    if (isFirefox() && shadowMediaStreamDest) {
      connectWithDownmix(ctx, segGain, numCh, 2, shadowMediaStreamDest);
    } else {
      connectWithDownmix(ctx, segGain, numCh, ctx.destination.channelCount, masterGainNode);
    }
    // Starts fadeSeconds earlier than the nominal boundary (ctxStartTime) — the
    // actual overlap that makes this a real crossfade rather than two adjacent
    // fades meeting at silence. endCtxTime still lands at the same nominal point
    // as before (actualStartTime is earlier by fadeSeconds, len is longer by the
    // same amount, so they cancel out) — the schedule bookkeeping in
    // extendScheduleIfPossible is unaffected by the overlap.
    const actualStartTime = Math.max(ctxStartTime - fadeSeconds, ctx.currentTime);
    const endCtxTime = actualStartTime + len / currentBuffer.sampleRate;
    // No fade-in for the very first segment of a playback session (scheduledSegments
    // starts empty each time startFrom() runs) — that's the actual start of audible
    // playback from the person's perspective, whether that's sample 0 or a resumed
    // position, and should begin immediately rather than with an artificial fade.
    // Likewise no fade-out for the segment that reaches the real end of the track —
    // the song should end naturally, not fade out on its own final segment boundary.
    if (isFirstSegmentOfSession) {
      segGain.gain.setValueAtTime(1, actualStartTime);
    } else {
      segGain.gain.setValueAtTime(0, actualStartTime);
      segGain.gain.linearRampToValueAtTime(1, actualStartTime + fadeSeconds);
    }
    if (!isTrackEnding) {
      const outFadeSeconds = Math.min(SEGMENT_CROSSFADE_SECONDS, len / currentBuffer.sampleRate / 2);
      segGain.gain.setValueAtTime(1, Math.max(actualStartTime + fadeSeconds, endCtxTime - outFadeSeconds));
      segGain.gain.linearRampToValueAtTime(0, endCtxTime);
    }
    const seg = { source: src, endSample: toSample, endCtxTime };
    src.onended = () => {
      scheduledSegments = scheduledSegments.filter(s => s !== seg);
      if (isPlaying && toSample >= currentBuffer.length && scheduledSegments.length === 0) onTrackEnded();
    };
    src.start(actualStartTime);
    scheduledSegments.push(seg);
    return seg;
  }
  // 30, not 10 — confirmed as a real contributor to crackling: with the old 10s max
  // and an 8s margin, a new segment (a new AudioBufferSourceNode, and for downmixed
  // multichannel content a fresh splitter+gain nodes too) got scheduled roughly every
  // ~2 seconds in steady-state playback, and far more often than that during the
  // initial buffering ramp-up specifically, since the margin check bypasses the
  // between-extensions throttle whenever the buffer is running low — which it always
  // is right at the start. Each of those transitions is a documented, general Web
  // Audio API risk (multiple source nodes can produce audible artifacts even with
  // fully sample-accurate scheduling, confirmed via prior research into this exact
  // issue), so cutting how often they happen at all is the direct fix. Verified
  // directly on the uploaded recording: real, measurable waveform discontinuities
  // clustered in dense bursts (not random single clicks) exactly where frequent
  // segment boundaries would be expected, both right at track start and recurring
  // periodically afterward. 30s pushes steady-state extensions out to roughly every
  // ~22s instead of ~2s — still bounded by whatever's actually been decoded so far
  // (this is only an upper limit, not a requirement), so it doesn't delay anything.
  const MAX_SEGMENT_SECONDS = 30;
  function extendScheduleIfPossible() {
    if (!isPlaying || !currentBuffer) return;
    if (scheduledUpToSample >= decodedUpToSample) return;
    if (scheduledUpToSample >= currentBuffer.length) return;
    const maxSamplesPerCall = Math.round(MAX_SEGMENT_SECONDS * currentBuffer.sampleRate);
    const targetSample = Math.min(decodedUpToSample, scheduledUpToSample + maxSamplesPerCall);
    const seg = scheduleSegment(scheduledUpToSample, targetSample, scheduledUpToCtxTime);
    scheduledUpToSample = targetSample;
    scheduledUpToCtxTime = seg.endCtxTime;
  }
  const SCHEDULE_EXTEND_MARGIN_SECONDS = 8;
  const MIN_SECONDS_BETWEEN_EXTENSIONS = 10;
  let lastExtendCtxTime = 0;
  // Minimum amount of newly-decoded, not-yet-scheduled audio required before
  // actually creating a new segment for it (when the track isn't ending — see
  // below). Confirmed as the real cause of dense crackling, not the segment-size
  // cap: maybeExtendSchedule fires on every single chunk arrival from the decode
  // worker, and whenever the buffer margin is below SCHEDULE_EXTEND_MARGIN_SECONDS
  // (which is normal and expected right after starting playback near the edge of
  // what's decoded, or during any catch-up period), it used to schedule a new
  // segment for whatever tiny amount of data had arrived — measured directly: 17
  // separate segments in ~2.6 seconds, several under 0.1s long, each one a real
  // AudioBufferSourceNode transition. This is what made the resume-position fix
  // look worse, not better — resuming closer to the decode edge means the margin
  // stays low exactly when small chunks are arriving fastest, which is when this
  // bug fires hardest. Batching small chunks into fewer, larger segments instead
  // fixes the actual mechanism, not just one trigger of it.
  const MIN_NEW_SEGMENT_SECONDS = 1.5;
  // Applies even when the buffer is genuinely running dry (scheduledAheadSeconds <=
  // 0) — measured directly that the plain "urgent, schedule whatever's there"
  // bypass was itself still producing sub-0.3s segments back to back, since the
  // moment playback catches up to what's scheduled can repeat every time a small
  // chunk trickles in. Requiring at least this much even under urgency accepts a
  // brief, genuine wait in the rare case nothing more is available yet (caught by
  // checkForRebuffer's own safety net regardless) rather than chaining more tiny
  // segment boundaries back to back.
  const MIN_NEW_SEGMENT_SECONDS_URGENT = 0.5;
  function maybeExtendSchedule() {
    if (!isPlaying || !currentBuffer) return;
    if (scheduledUpToSample >= decodedUpToSample) return;
    if (scheduledUpToSample >= currentBuffer.length) return;
    const ctx = ensureCtx();
    const t = currentTimeSec();
    const scheduledAheadSeconds = (scheduledUpToSample / currentBuffer.sampleRate) - t;
    // No longer also triggers on a periodic timeSinceLastExtend fallback — that
    // used to force an extension attempt every MIN_SECONDS_BETWEEN_EXTENSIONS (10s)
    // regardless of whether the margin genuinely needed topping up, which is exactly
    // what was causing a subtle but real, confirmed-by-report artifact every 10
    // seconds even on a fully-decoded, fully-cached track — an unnecessary segment
    // boundary being created on a timer when the current segment still had 20+
    // seconds of real margin left. Removing it is safe: checkForRebuffer already
    // calls into this same margin check on every animation frame (~60/sec) plus a
    // redundant 500ms interval as backup, so the margin condition alone is
    // re-evaluated far more often than every 10 seconds regardless — it will fire
    // reliably the moment there's a genuine need, with no gap in coverage.
    if (scheduledAheadSeconds < SCHEDULE_EXTEND_MARGIN_SECONDS) {
      const newAvailableSeconds = (decodedUpToSample - scheduledUpToSample) / currentBuffer.sampleRate;
      const trackEnding = decodedUpToSample >= currentBuffer.length;
      const requiredSeconds = scheduledAheadSeconds > 0 ? MIN_NEW_SEGMENT_SECONDS : MIN_NEW_SEGMENT_SECONDS_URGENT;
      // Below the minimum AND not urgent: skip this call rather than schedule a
      // tiny segment for it — the next chunk arrival (or the margin/throttle
      // conditions above) will catch it once enough has accumulated. Even in the
      // genuinely-urgent case (buffer already at or past empty), still requires the
      // smaller minimum above rather than scheduling literally whatever trickled in.
      if (newAvailableSeconds < requiredSeconds && !trackEnding) return;
      extendScheduleIfPossible();
      lastExtendCtxTime = ctx.currentTime;
    }
  }

  function startFrom(offset) {
    const ctx = ensureCtx();
    // Diagnostic only — chasing a real, confirmed-by-log report: playback restarts
    // from 0 mid-track (once from 102.5s, once from 9.5s — not track-ending
    // positions, so not a legitimate repeat-one loop). The existing tickProgress
    // diagnostic caught the SYMPTOM (displayed time jumping backward) but not the
    // CALLER — both occurrences had a 40+ minute gap with nothing else logged
    // immediately before them, so whatever triggers this isn't currently
    // instrumented at its actual source. Logging the caller's stack here, only for
    // the suspicious case (offset near 0 while a real position had already been
    // reached), targets the next real occurrence directly instead of guessing.
    if (offset < 1 && typeof lastDisplayedT === 'number' && lastDisplayedT > 5) {
      bufferClientError('warn', `startFrom(${offset.toFixed(2)}) called while lastDisplayedT=${lastDisplayedT.toFixed(1)}s — likely the source of the reported restart-to-0 bug. Stack: ${new Error().stack}`);
    }
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    stopSource();
    // Defensive clamp, regardless of caller: playOffset/scheduledUpToSample must
    // never be set beyond what's actually been decoded. currentTimeSec() is pure
    // wall-clock math from this starting point — it has no way to know whether
    // real audio was actually scheduled, so if offset ever exceeds what's decoded,
    // the reported playback position silently drifts ahead of the real audio with
    // nothing ever actually playing, and every later rebuffer cycle re-triggers
    // with that same impossible position, never recovering. Confirmed as a real,
    // reproducible failure from a production log (position reported at 78.8s while
    // only 21.1s had decoded) — fixed at its one likely source already, but this
    // makes it structurally impossible here too, regardless of which caller or
    // future code path might otherwise pass through a bad offset.
    const maxAvailableSeconds = currentBuffer ? decodedUpToSample / currentBuffer.sampleRate : 0;
    if (offset > maxAvailableSeconds) offset = maxAvailableSeconds;
    playOffset = offset;
    playStartedAtCtxTime = ctx.currentTime;
    isPlaying = true;
    scheduledUpToSample = Math.max(0, Math.min(currentBuffer.length, Math.round(offset * currentBuffer.sampleRate)));
    scheduledUpToCtxTime = ctx.currentTime;
    lastExtendCtxTime = ctx.currentTime;
    extendScheduleIfPossible();
    updateTransportUI();
    tickProgress();
    if (shadowAudioEl && shadowAudioEl.paused) shadowAudioEl.play().catch(() => {});
    if ('mediaSession' in navigator) {
      navigator.mediaSession.playbackState = 'playing';
      try { navigator.mediaSession.setPositionState({ duration: currentBuffer.duration, playbackRate: 1, position: offset }); } catch (e) {}
    }
  }
  function pausePlayback() {
    if (!isPlaying) return;
    playOffset = currentTimeSec();
    stopSource();
    isPlaying = false;
    updateTransportUI();
    // Keep the shadow element's own state in sync too — belt-and-suspenders alongside
    // its event listeners above, so it can't independently drift from the real state
    // regardless of which one the OS actually acted on first.
    if (shadowAudioEl && !shadowAudioEl.paused) shadowAudioEl.pause();
    if ('mediaSession' in navigator) navigator.mediaSession.playbackState = 'paused';
    saveStateToServer(true);
  }
  function resumePlayback() { if (isPlaying || !currentBuffer) return; startFrom(playOffset); }

  let seekWaitToken = 0;
  // See the visibilitychange handler (in wireEvents) for the full story — this is the
  // cooldown window during which the seek bar's own 'input' event is deliberately
  // ignored right after the page becomes visible again.
  let suppressSeekInputUntilMs = 0;
  function seekTo(offset) {
    if (!currentBuffer) return;
    seekWaitToken++;
    const wasPlaying = isPlaying;
    stopSource();
    playOffset = Math.max(0, Math.min(currentBuffer.duration, offset));
    const targetSample = Math.floor(playOffset * currentBuffer.sampleRate);
    if (targetSample > decodedUpToSample) {
      isPlaying = false;
      updateTransportUI();
      waitForDecodeAndPlay(targetSample, playOffset);
      return;
    }
    if (wasPlaying) startFrom(playOffset); else updateTransportUI();
  }
  function waitForDecodeAndPlay(targetSample, offsetSeconds, waitingText) {
    const myToken = seekWaitToken;
    const track = trackById(queue[queuePos]);
    if (track) setNowPlaying(track, waitingText || 'Catching up to your seek position…');
    // Real, confirmed gap: this poll loop previously had no timeout or recovery at
    // all — if the underlying stream genuinely stalled (a dropped connection, a
    // server hiccup) rather than just being slow, decodedUpToSample would simply
    // never reach the target and the UI would show "Buffering…" forever with no way
    // to recover short of a manual reload. Tracking whether decode is actually
    // making progress (not just polling) lets this tell the difference between
    // "still working, just slow" and "genuinely stuck", and retry the track fresh
    // from the same position in the latter case instead of waiting indefinitely.
    let lastProgressMs = Date.now();
    let lastDecodedSample = decodedUpToSample;
    const STALL_TIMEOUT_MS = 15000;
    const check = () => {
      if (myToken !== seekWaitToken || !currentBuffer) { isRebuffering = false; pendingDecodeCheck = null; return; }
      if (decodedUpToSample >= targetSample) {
        isRebuffering = false;
        pendingDecodeCheck = null;
        if (track) setNowPlaying(track, 'Playing — buffering rest');
        startFrom(offsetSeconds);
        return;
      }
      if (decodedUpToSample > lastDecodedSample) {
        lastDecodedSample = decodedUpToSample;
        lastProgressMs = Date.now();
      } else if (Date.now() - lastProgressMs > STALL_TIMEOUT_MS) {
        bufferClientError('warn', `Decode stall detected — no progress for ${STALL_TIMEOUT_MS}ms, retrying track from ${offsetSeconds.toFixed(1)}s. decodedUpToSample was stuck at ${(lastDecodedSample/currentBuffer.sampleRate).toFixed(1)}s, target was ${(targetSample/currentBuffer.sampleRate).toFixed(1)}s`);
        isRebuffering = false;
        pendingDecodeCheck = null;
        // Real, direct complaint: this used to unconditionally force 'ultra'
        // quality on every stall, regardless of cause — but a real, ZERO
        // progress for the full 15-second window is actually the signature of
        // a dead/hung connection (a WiFi-to-cellular handoff, a momentary
        // drop), not slow-but-steady bandwidth — genuine bandwidth starvation
        // usually still shows SOME slow progress, not a complete stop. Forcing
        // the lowest tier "proves" nothing about actual capacity in that case;
        // it just needlessly wrecks audio quality on a connection (e.g. 40+
        // Mbps) that never had a throughput problem in the first place. Passing
        // no override lets the normal, measured-throughput-based quality logic
        // decide instead — it already downgrades correctly when the connection
        // genuinely has been slow, and correctly stays at full quality when it
        // hasn't, rather than treating every stall as proof of a bandwidth
        // shortfall that was never actually there.
        if (track) playTrack(track.id, null, offsetSeconds, undefined);
        return;
      }
      // Exposed at module scope, alongside the regular setTimeout chain, so the
      // pcmWorker heartbeat (see its own comment for the full reasoning) can also
      // trigger this re-check directly — a message-driven call isn't subject to
      // the same background-tab timer throttling setTimeout is, so the 15-second
      // stall timer above keeps actually firing on schedule even when the tab is
      // backgrounded or the screen is locked, not stretched out to whatever
      // throttled interval the browser decides to allow.
      pendingDecodeCheck = check;
      setTimeout(check, 150);
    };
    check();
  }

  const REBUFFER_MARGIN_SECONDS = 2;
  const REBUFFER_RESUME_MARGIN_SECONDS = 6;
  let isRebuffering = false;
  function checkForRebuffer() {
    if (isRebuffering || !isPlaying || !currentBuffer) return;
    if (scheduledUpToSample >= currentBuffer.length) return;
    let t = currentTimeSec();
    let bufferedAheadSeconds = (scheduledUpToSample / currentBuffer.sampleRate) - t;
    if (bufferedAheadSeconds < SCHEDULE_EXTEND_MARGIN_SECONDS && scheduledUpToSample < decodedUpToSample) {
      // Routed through maybeExtendSchedule (not a direct extendScheduleIfPossible
      // call) so this shares the same minimum-new-segment-size gate — this call
      // site was a second, independent path around that gate, confirmed directly:
      // sub-0.5s segments were still appearing even after the first fix, coming
      // from here, not from maybeExtendSchedule's own callers.
      maybeExtendSchedule();
      t = currentTimeSec();
      bufferedAheadSeconds = (scheduledUpToSample / currentBuffer.sampleRate) - t;
    }
    const nothingScheduled = scheduledSegments.length === 0 && scheduledUpToSample < currentBuffer.length;
    if (bufferedAheadSeconds < REBUFFER_MARGIN_SECONDS || nothingScheduled) {
      isRebuffering = true;
      seekWaitToken++;
      const targetSample = Math.min(currentBuffer.length, Math.floor((t + REBUFFER_RESUME_MARGIN_SECONDS) * currentBuffer.sampleRate));
      // Logged (warn level, feeds the same pipeline as JS errors — visible via
      // GET /api/logs) specifically because a plain network stall doesn't throw or
      // reject anything on its own, so it would otherwise leave zero trace for the
      // admin log to show. This is the one piece of real, checkable evidence for
      // "still buffering" reports beyond a screenshot of the UI state.
      bufferClientError('warn', `Rebuffer triggered at t=${t.toFixed(1)}s, bufferedAhead=${bufferedAheadSeconds.toFixed(2)}s, nothingScheduled=${nothingScheduled}, decodedUpTo=${(decodedUpToSample/currentBuffer.sampleRate).toFixed(1)}s/${(currentBuffer.length/currentBuffer.sampleRate).toFixed(1)}s`);
      // Learn from this even though the stream hasn't (and may never) reach a clean
      // 'end' — see the note by currentStreamStartMs's declaration for why this
      // matters: without it, a connection struggling enough to always rebuffer
      // before a track finishes downloading could never produce the one
      // measurement needed to downgrade quality, and would just keep retrying at
      // 'full' forever. A rough estimate from whatever genuinely arrived before
      // this rebuffer is far more useful than no measurement at all.
      //
      // Uses the windowed rate (falls back to since-start only if the window
      // genuinely doesn't have enough data yet) — same fix as the periodic and
      // 'end' measurements above, and arguably matters even more here: this is
      // measured at the exact moment things are failing, so an initial-burst-
      // skewed average was directly capable of concluding "throughput is fine"
      // from the same struggling stream that just triggered the rebuffer.
      {
        const windowed = windowedBytesPerSec(currentBuffer.numberOfChannels);
        if (windowed !== null) {
          maybeAdjustAutoQualityTier(windowed, currentBuffer.sampleRate, currentBuffer.numberOfChannels);
        } else if (currentStreamStartMs) {
          const elapsedSec = (Date.now() - currentStreamStartMs) / 1000;
          if (elapsedSec > 0.5) {
            const estimatedBytesPerSec = (decodedUpToSample / elapsedSec) * currentBuffer.numberOfChannels * 2;
            maybeAdjustAutoQualityTier(estimatedBytesPerSec, currentBuffer.sampleRate, currentBuffer.numberOfChannels);
          }
        }
      }
      pausePlayback();
      waitForDecodeAndPlay(targetSample, t, 'Buffering…');
    }
  }

  function tickProgress() {
    cancelAnimationFrame(rafId);
    function frame() {
      if (isPlaying) {
        const t = currentTimeSec();
        // Diagnostic only — chasing a specific, repeated report: the web UI's own
        // displayed position visibly jumps backward during a rebuffer/stall retry,
        // while the OS media session (fed separately, via setPositionState) keeps
        // showing the correct, later position. Nothing found by reading the code
        // explains this definitively yet — this logs the exact moment and values
        // if the displayed t ever actually jumps backward by a meaningful amount,
        // to get real evidence instead of continuing to guess at the cause.
        if (typeof lastDisplayedT === 'number' && t < lastDisplayedT - 5) {
          bufferClientError('warn', `Display time jumped backward: was ${lastDisplayedT.toFixed(1)}s, now ${t.toFixed(1)}s. playOffset=${playOffset.toFixed(1)} playStartedAtCtxTime=${playStartedAtCtxTime.toFixed(2)} ctxCurrentTime=${audioCtx ? audioCtx.currentTime.toFixed(2) : 'n/a'}`);
        }
        lastDisplayedT = t;
        // Real gap fixed here too: currentBuffer is Web-Audio-only and
        // always null in native mode, so this always showed 0 there —
        // window.__nativeKnownDuration (set once the first segment's
        // response headers arrive) is the native-mode equivalent.
        const totalDurationSeconds = currentBuffer ? currentBuffer.duration : (window.__nativeKnownDuration || 0);
        // Real, direct bug found from a screen recording of the actual
        // problem, not just logs: this ran on every single animation frame
        // unconditionally, which meant it was fighting the user's own drag
        // in real time — resetting the slider back to the actual playback
        // position roughly 60 times a second, faster than a drag gesture
        // could visibly move it away. That's what "can't skip at all"
        // actually was: not a broken seek, a slider that was being reset
        // out from under the user's finger continuously. Guarded on
        // seekBarDragging (set by the seek bar's own pointerdown/pointerup
        // handlers) so this loop steps aside entirely while a drag is
        // actually in progress, the same principle virtually every media
        // player's own seek bar relies on.
        if (!seekBarDragging) $('seekBar').value = totalDurationSeconds ? (t / totalDurationSeconds) * 1000 : 0;
        $('timeCurrent').textContent = fmtTime(t);
        checkForRebuffer();
        saveStateToServer(false);
        const track = trackById(queue[queuePos]);
        if (track) maybeScrobble(track);
        rafId = requestAnimationFrame(frame);
      }
    }
    frame();
  }
  setInterval(() => { if (isPlaying) checkForRebuffer(); }, 500);
  setInterval(() => { maybeYieldToOtherDevice(); }, 8000);

  function updateAudioDiagnostics() {
    // Real, live numbers rather than a guess — what this browser actually reports it can
    // output, and (once a track has played) what the currently loaded track has and
    // whether the explicit downmix path engaged for it. maxChannelCount can be queried
    // without needing playback to have started: a throwaway AudioContext works fine.
    let maxCh;
    try {
      const probeCtx = new (window.AudioContext || window.webkitAudioContext)();
      maxCh = probeCtx.destination.maxChannelCount;
      probeCtx.close();
    } catch (e) { maxCh = 'unavailable'; }
    let trackLine = '<div>No track loaded yet — play something to see its channel info here.</div>';
    if (currentBuffer) {
      const srcCh = currentBuffer.numberOfChannels;
      const destCh = audioCtx ? audioCtx.destination.channelCount : maxCh;
      const downmixed = srcCh > destCh;
      trackLine = `<div><span class="k">Current track:</span> ${srcCh} channel${srcCh === 1 ? '' : 's'}</div>` +
        `<div><span class="k">Routing:</span> ${downmixed ? `mixed down to ${destCh} (browser reports fewer output channels than the track has)` : 'direct — full channel count sent straight through'}</div>`;
    }
    $('audioDiagnostics').innerHTML =
      `<div><span class="k">This browser reports it can output:</span> ${maxCh} channel${maxCh === 1 ? '' : 's'}</div>` + trackLine;
  }
  function setupMediaSessionHandlers() {
    if (!('mediaSession' in navigator)) return;
    const handlers = {
      play: () => resumePlayback(),
      pause: () => pausePlayback(),
      previoustrack: () => playPrevInQueue(),
      nexttrack: () => playNextInQueue(),
      seekto: (details) => { if (details.seekTime !== undefined && currentBuffer) seekTo(details.seekTime); },
    };
    // Not every browser supports every action type — setting an unsupported one can throw
    // in some implementations, so register each independently rather than letting one
    // failure prevent the rest from being set up.
    for (const [action, handler] of Object.entries(handlers)) {
      try { navigator.mediaSession.setActionHandler(action, handler); } catch (e) { /* unsupported action type — skip it */ }
    }
  }
  function updateTransportUI() {
    $('playPauseBtn').textContent = isPlaying ? '⏸' : '▶';
  }
  function onTrackEnded() {
    isPlaying = false;
    if ('mediaSession' in navigator) navigator.mediaSession.playbackState = 'paused';
    if (repeatMode === 'one') { playTrack(queue[queuePos]); return; }
    playNextInQueue();
  }
  function playNextInQueue(isGaplessContinuation) {
    if (queuePos + 1 < queue.length) { queuePos++; playTrack(queue[queuePos], null, undefined, undefined, undefined, isGaplessContinuation); }
    else if (repeatMode === 'all' && queue.length > 0) { queuePos = 0; playTrack(queue[queuePos], null, undefined, undefined, undefined, isGaplessContinuation); }
    else { updateTransportUI(); }
  }
  function playPrevInQueue() {
    // Real, direct bug found via code inspection: this called seekTo(0),
    // the Web-Audio-only function — which starts with `if (!currentBuffer)
    // return`, and currentBuffer is never set in native mode at all (the
    // same gap fixed in several other places this session). Every prev
    // press more than 3 seconds into a track was silently doing nothing in
    // native mode — not erroring, not logging, just a quiet no-op. Routed
    // to nativeSeek the same way every other seek path already checks for
    // native mode.
    if (currentTimeSec() > 3) { if (window.NovaNative) nativeSeek(0); else seekTo(0); return; }
    if (queuePos > 0) { queuePos--; playTrack(queue[queuePos]); }
  }

  // ---------- Server-decoded PCM consumption ----------
  let qualityMode = localStorage.getItem('novaQualityMode') || 'auto'; // 'auto' | 'full' | 'reduced' | 'minimal'
  // Real, direct addition for a confirmed "constantly skipping out,
  // unbearable to listen to" complaint — 'auto' mode used to just mean
  // "always use reduced," with no actual adaptive behavior behind the
  // name at all. This is the real thing: a step-down sequence auto mode
  // can actually move through when the current tier keeps proving too
  // demanding for the connection, and the tier currently in effect while
  // in auto mode. A manual quality choice ('full'/'reduced'/'minimal')
  // is left completely alone — the user picked that explicitly, so it's
  // never second-guessed here.
  const AUTO_QUALITY_STEPS = ['reduced', 'ultra', 'minimal'];
  let autoQualityTierIndex = 0;
  function effectiveQuality() {
    return (qualityMode && qualityMode !== 'auto') ? qualityMode : AUTO_QUALITY_STEPS[autoQualityTierIndex];
  }
  // Persisted per-device, same pattern as qualityMode — defaults on since this
  // was a direct feature request (volume varies noticeably between tracks).
  let loudnessNormalizationMode = localStorage.getItem('novaLoudnessNormalization') || 'on'; // 'on' | 'off'
  // Tracks the network's actual proven byte-rate capability (bytes/sec), NOT a tier
  // label — this is the real architectural fix. autoQualityTier used to be a single
  // shared label ('full'/'reduced'/'minimal') applied across every track regardless
  // of channel count, but the same label means very different absolute bandwidth for
  // a stereo track versus an 8-channel one (4x the data at the same tier). A
  // connection proven safe for stereo 'full' (~1.5Mbps) says nothing about whether
  // it's safe for 8-channel 'full' (~6Mbps) — confirmed as a real bug this way,
  // not theory: a stereo track playing fine at full quality, followed immediately by
  // a real 8-channel file, produced a genuine buffer-underrun stall (crackle, ~5s of
  // silence, crackle, recovery) a few seconds in — exactly consistent with 'full'
  // being carried over from the stereo track without ever being re-validated against
  // the 8-channel track's much higher actual bandwidth requirement. null = nothing
  // measured yet this session.
  //
  // Persisted server-side (per-account), not in localStorage — real, confirmed
  // gap found directly from a person testing across different browsers/devices:
  // localStorage is per-browser, so every fresh test session started over with
  // nothing learned, always retrying full quality and hitting the same wall
  // before ever downgrading. Server-side storage means what's learned actually
  // carries over regardless of which browser or device is being used to test or
  // listen from. Confirmed via actual production logs that this connection
  // repeatedly proved it could only sustain a fraction of real-time delivery for
  // full quality (rebuffer logs showing decode falling further and further
  // behind wall-clock playback time) — this is exactly what "sounds better after
  // buffering stops" describes: full quality genuinely can't keep up in real
  // time here, but a fully-downloaded track has no further network dependency.
  const THROUGHPUT_MAX_AGE_MS = 24 * 60 * 60 * 1000; // stale measurements expire rather than permanently capping quality — connections do improve (different wifi, different time of day), so this allows periodic re-discovery rather than a one-time-bad-measurement locking in a low tier forever
  let provenThroughputBytesPerSec = null;
  async function loadPersistedThroughput() {
    try {
      const saved = await api('/api/state/throughput');
      if (saved && typeof saved.bytesPerSec === 'number' && Date.now() - saved.atMs < THROUGHPUT_MAX_AGE_MS) {
        provenThroughputBytesPerSec = saved.bytesPerSec;
      }
    } catch (e) {}
  }

  // Given the currently-proven throughput (if any) and a SPECIFIC track's actual
  // channel count/sample rate, picks the safest tier for THAT track — recomputed
  // fresh per track rather than carried over as a shared label.
  function tierForTrack(numChannels, sampleRate) {
    if (provenThroughputBytesPerSec === null) return 'full'; // nothing measured yet (this session or a recent past one) — same optimistic default as before, which is fine for the common (stereo-first) case
    const SAFETY_MARGIN = 1.5;
    const fullBytesPerSec = sampleRate * numChannels * 2;
    if (provenThroughputBytesPerSec >= fullBytesPerSec * SAFETY_MARGIN) return 'full';
    const reducedBytesPerSec = 32000 * numChannels * 2;
    if (provenThroughputBytesPerSec >= reducedBytesPerSec * SAFETY_MARGIN) return 'reduced';
    const minimalBytesPerSec = 22050 * numChannels * 2;
    if (provenThroughputBytesPerSec >= minimalBytesPerSec * SAFETY_MARGIN) return 'minimal';
    // Confirmed necessary via real production logs: rebuffers kept recurring with
    // the same ~0.7x-realtime shortfall pattern even after the app had already
    // learned to downgrade from earlier failures — meaning the connection's real
    // sustained throughput sits below what 'minimal' itself needs (~706kbps
    // stereo). 'ultra' is now 16000Hz (~512kbps) — raised from the original
    // 11025Hz/~353kbps floor, which was tuned for a bandwidth-starvation theory
    // that turned out to be wrong for the case that prompted it; see ultra's own
    // comment in QUALITY_PRESETS for the full reasoning.
    return 'ultra';
  }

  function effectiveQualityTier(track) {
    if (qualityMode !== 'auto') return qualityMode;
    const numChannels = (track && track.numChannels) || 2; // default to stereo's bandwidth assumption if the channel count isn't known yet (tags still loading)
    return tierForTrack(numChannels, 48000); // 48000 is a conservative assumption when the real source rate isn't known yet — matches the common case, and this only affects which tier gets picked, not correctness (the real rate always comes from the stream's own header)
  }

  let pendingLowReading = null; // tracks a single low measurement awaiting confirmation — see below
  function maybeAdjustAutoQualityTier(measuredBytesPerSec, sourceSampleRate, sourceChannels) {
    if (qualityMode !== 'auto') return;
    // Real, direct root cause of a reported complaint: this used to overwrite the
    // persisted "learned" throughput from a SINGLE measurement, no matter what
    // caused it — including a rebuffer triggered by nothing more than a brief
    // connectivity drop (a WiFi/cellular handoff), which we'd already established
    // is the dominant real-world cause of rebuffers here, not genuine bandwidth
    // shortfall. A dead connection for a few seconds measures as near-zero
    // throughput even on a 40+ Mbps line — and since that single bad reading got
    // persisted to the server immediately, it permanently dragged quality down
    // for all FUTURE playback on a connection that never actually had a
    // bandwidth problem. Upgrades (a higher measurement) still apply immediately
    // — recovering quality is always safe. A DOWNGRADE now requires the same
    // low reading to show up twice in a row, with no higher reading in between —
    // filtering out a one-off drop while still catching a connection that's
    // genuinely, consistently struggling.
    if (provenThroughputBytesPerSec !== null && measuredBytesPerSec < provenThroughputBytesPerSec) {
      if (pendingLowReading === null) {
        pendingLowReading = measuredBytesPerSec;
        return; // wait for confirmation before actually persisting a downgrade
      }
      // Confirmed — a second low reading in a row with nothing higher in
      // between. Use the higher (more optimistic) of the two rather than the
      // lower, since even a genuinely struggling connection has natural
      // variance and the lower of two consecutive low readings could itself
      // still be pessimistic.
      measuredBytesPerSec = Math.max(pendingLowReading, measuredBytesPerSec);
      pendingLowReading = null;
    } else {
      pendingLowReading = null; // this reading wasn't low (or there's no baseline yet) — clear any pending downgrade
    }
    // Directly stores the raw measurement — channel-count-independent, so it
    // transfers correctly to the next track regardless of that track's own channel
    // count, unlike the old tier-label approach.
    provenThroughputBytesPerSec = measuredBytesPerSec;
    apiPostJson('/api/state/throughput', { bytesPerSec: measuredBytesPerSec }).catch(() => {});
    const tierNow = tierForTrack(sourceChannels, sourceSampleRate);
    $('qualityAutoStatus').textContent = 'Currently using: ' + tierNow;
  }

  // Fully server-decoded raw PCM (16-bit, interleaved) — the client does no LMS/rANS/
  // FLAC decode work at all, just accumulates bytes and writes them straight into an
  // AudioBuffer. Same interface as a client-side streaming decoder would have
  // (onReadyToPlay, decodedUpToSample) so the scheduling code above doesn't need to
  // know or care that the audio arrived pre-decoded rather than needing decoding.
  let pcmWorkerRequestCounter = 0;
  function getDecodedBufferFromServerPCM(track, startAtSeconds, onReadyToPlay, forceQuality, isPrefetch) {
    return new Promise((resolve, reject) => {
      // Real, serious bug found directly from a production log: prefetchNext()
      // calls this same function for the NEXT queued track, but never bumped
      // decodeGenerationToken first — meaning its own myGenerationToken capture
      // below was IDENTICAL to whatever the currently-PLAYING track's token
      // already was. Every state write in this function (decodedUpToSample,
      // throughput tracking, triggering checkForRebuffer) is gated on that token
      // matching, specifically so a stale/superseded fetch can't corrupt live
      // state — but that guard never anticipated two DIFFERENT, legitimately
      // concurrent fetches (the active track and a prefetch) sharing the same
      // token value. The prefetch's own progress (starting fresh from 0) was
      // silently overwriting the actively-playing track's decodedUpToSample,
      // making it look like decode had barely progressed while real playback
      // continued far ahead — triggering a false rebuffer. Confirmed directly:
      // a rebuffer logged at t=258.1s with decodedUpTo=13.7s, immediately
      // followed by a segment failing at position 0.0s — 0.0s is where a
      // prefetch starts, never where an established, minutes-in playback
      // session would be fetching from.
      //
      // Sentinel reasoning superseded — see the corrected approach below. The
      // token here stays real (identifies whether THIS fetch has been
      // superseded by a newer one, e.g. the person skipped tracks) — a separate,
      // explicit isPrefetch flag (below) governs which state writes are safe,
      // rather than conflating "should this keep running" with "should this
      // write to shared state" under one sentinel value. An earlier version of
      // this fix used a token sentinel that would never match — but fetchSegment
      // itself starts with the identical token check to decide whether to run
      // AT ALL, so that approach would have silently prevented prefetch from
      // ever fetching anything.
      const myGenerationToken = decodeGenerationToken;
      // forceQuality lets a retry bypass the normal "learned" tier decision
      // entirely — see its callers in playTrack for why: a retry that keeps
      // using the same tier that just failed, at a resume position that needs
      // even MORE buffer than the original attempt, is a losing bet repeating
      // itself. Confirmed via real logs showing exactly this cascade — a
      // rebuffer, a stall-retry, a premature-end retry, all at the same or a
      // later position with the same quality tier, ending in the track
      // restarting from 0 entirely. Forcing the lowest tier on retry gives it
      // the best actual chance of succeeding instead of repeating the failure.
      const quality = forceQuality || effectiveQualityTier(track);

      // The actual architectural fix, not another config tweak or timing guess.
      // Every previous attempt — backpressure deadlock, background-tab timer
      // throttling, quality-tier retry, EPIPE handling — was a real, legitimate
      // bug, fixed and confirmed working in isolation, and NONE of them changed
      // the reported failure at all: same position, same pattern, even on a
      // fast, low-latency, bufferbloat-clean connection, only on mobile. That
      // consistency across every other variable is itself the signal: this was
      // never really about bandwidth, latency, timers, or backpressure — it's
      // that one continuous HTTP response spanning an entire multi-minute track
      // has to stay perfectly healthy the WHOLE time, on a real-world mobile
      // path, for the whole song, every single time. Any transient hiccup
      // anywhere along that path derails the whole thing, and recovering meant
      // restarting from scratch. No streaming service actually works this way —
      // they fetch in small, independent, bounded segments, so a single bad
      // moment costs one small segment's retry, not the entire remaining track.
      // 60s balances that resilience against the server's own re-decode cost:
      // the codec's skip-ahead already requires decoding from sample 0 up to
      // each segment's start (real, required cost, not a bug — see its own
      // comment below), so very short segments would mean rapidly growing
      // server-side re-decode overhead for segments deep into a long track.
      const SEGMENT_DURATION_SECONDS = 60;
      // Raised from 3 to 5, with exponential backoff replacing the old fixed
      // 500ms delay — a real, direct gap found from production logs: all 3
      // retries were happening back-to-back within about 1.5 seconds total
      // (500ms apart each), which is nowhere near enough to ride out a
      // multi-second network hiccup — a WiFi-to-cellular handoff alone can
      // easily take several seconds. 500ms/1s/2s/4s/8s gives roughly 15.5
      // seconds of total retry window before this segment gives up and
      // escalates to playTrack's own connection-error retry, a real chance to
      // ride out exactly the kind of transient drop these logs kept showing.
      const MAX_SEGMENT_RETRIES = 5;
      const segmentRetryDelayMs = (retryCount) => Math.min(500 * Math.pow(2, retryCount), 8000);

      let audioBuffer = null, sampleRate = null, numChannels = null;
      let calledReady = false;
      let totalBytesForThroughput = 0;
      let lastPeriodicMeasureSec = 0; // tracks the last elapsedSec a periodic in-progress throughput measurement was taken, so a long-running successful stream can update the persisted estimate well before it fully finishes
      let lastEndSample = 0; // tracked independently of the generation-token-guarded global decodedUpToSample, so the 'end' handler below can tell exactly how much has actually decoded, regardless of whether the token has since moved on
      const throughputStartMs = performance.now();
      // Also recorded at module scope (see currentStreamStartMs below) — real,
      // confirmed gap: throughput was previously only ever measured once a stream
      // FULLY finished ('end' message), which meant a connection struggling badly
      // enough to keep triggering rebuffers before a track ever finished downloading
      // could never actually produce a measurement at all — stuck permanently
      // retrying at 'full' quality, never getting the one data point needed to
      // downgrade. checkForRebuffer below now estimates throughput from whatever
      // genuinely arrived before the rebuffer, so the system learns from the
      // struggle itself instead of needing a clean success to learn anything.
      if (myGenerationToken === decodeGenerationToken && !isPrefetch) currentStreamStartMs = Date.now();

      function fetchSegment(segmentStartSeconds, retryCount) {
        // Real, direct regression found from this exact line, in two
        // different failed forms now — worth being honest about the
        // back-and-forth: first this silently returned with no resolve/
        // reject (the actual "next track never starts" bug — nothing ever
        // settled this promise). Then it was changed to reject on mismatch,
        // which fixed that but broke something else just as real: a
        // prefetch's OWN token is captured once, when the prefetch starts —
        // and playTrack() always bumps decodeGenerationToken at ITS OWN
        // start, including the exact moment it's consuming a prefetch for
        // the very track becoming active. So a prefetch still mid-retry at
        // the moment it's legitimately being consumed would see its own
        // "become active" as if it had been superseded by something else,
        // and reject itself — killing the fast-start path it exists for.
        // The actual fix: this check doesn't apply to prefetch fetches at
        // all. A prefetch never writes to shared, token-gated state anyway
        // (isPrefetch guards that separately, elsewhere in this function) —
        // the only thing this check ever needed to protect. Its own bounded
        // retry logic (MAX_SEGMENT_RETRIES) is what determines when its
        // promise settles, based on real network success/failure — never on
        // an unrelated track-switch race. An abandoned, never-consumed
        // prefetch still settles on its own via that same bounded retry
        // logic; nothing waits on it in that case, so a few extra seconds of
        // background fetching is a fine, minor cost, not a hang.
        if (!isPrefetch && myGenerationToken !== decodeGenerationToken) { reject(new Error('Superseded by a newer track switch')); return; }
        // Tracks whether the next 'chunk' message is this network segment's FIRST
        // one — used below to test specifically for a discontinuity at the
        // network-segment boundary (every SEGMENT_DURATION_SECONDS), which is a
        // different, independent set of positions from the client-side scheduling
        // boundaries the existing discontinuity check in scheduleSegment covers.
        // Investigating a real, specific report: audio quality worse at reduced
        // quality tiers than at 'full' — the one structural difference between them
        // is that every non-'full' tier pipes decoded audio through a FRESH ffmpeg
        // resampling process for every network segment (full quality never spawns
        // ffmpeg at all), so this targets exactly the boundary where a resampler
        // filter's startup transient could plausibly land.
        let isFirstChunkOfThisSegment = true;
        // skipToSeconds is the actual architectural fix for resuming late in a
        // track: without it, every resume — regardless of position — required the
        // server to decode AND retransmit the entire song from sample 0 forward,
        // meaning the amount of data that had to cross the network before playback
        // could even begin grew with how far into the track you were resuming.
        // maxDurationSeconds bounds THIS request to one segment — see its own
        // comment in routes/stream.js for the full reasoning.
        const url = new URL('/api/stream/pcm?path=' + encodeURIComponent(track.localPath) + '&quality=' + quality + '&skipToSeconds=' + segmentStartSeconds + '&maxDurationSeconds=' + SEGMENT_DURATION_SECONDS, window.location.href).href;
        const requestId = ++pcmWorkerRequestCounter;
        const worker = new Worker('/pcmWorker.js');

        worker.onmessage = (e) => {
          const msg = e.data;
          if (msg.requestId !== requestId) return; // defensive — each segment fetch gets its own worker, so this shouldn't cross-fire, but cheap to check
          if (msg.type === 'heartbeat') {
            // Message-driven trigger for checkForRebuffer, alongside its existing
            // main-thread timer calls — a message event handler on the main thread
            // isn't subject to the same background-tab throttling that
            // setInterval/requestAnimationFrame are, so this keeps the rebuffer
            // recovery loop actually running promptly even when the tab is
            // backgrounded or the screen is locked.
            if (myGenerationToken === decodeGenerationToken && !isPrefetch) {
              checkForRebuffer();
              if (pendingDecodeCheck) pendingDecodeCheck();
            }
            return;
          }
          if (msg.type === 'header') {
            if (!audioBuffer) {
              // Allocated once, from the FIRST segment's header — msg.totalFrames is
              // the file's real, full length regardless of which segment this is, so
              // every later segment reuses this same buffer rather than each
              // allocating its own.
              sampleRate = msg.sampleRate;
              numChannels = msg.numChannels;
              const ctx = ensureCtx();
              audioBuffer = ctx.createBuffer(numChannels, msg.totalFrames, sampleRate);
              audioBuffer.qualityTier = quality;
              if (myGenerationToken === decodeGenerationToken && !isPrefetch) { decodedUpToSample = 0; throughputWindow = []; }
            }
          } else if (msg.type === 'chunk') {
            totalBytesForThroughput += (msg.endSample - msg.startSample) * numChannels * 2;
            // Defensive bound, alongside the server-side clamp in pcmStream.js — a
            // real, confirmed crash traced directly from a production log
            // ("RangeError: offset is out of bounds" at Float32Array.set) where
            // msg.startSample ended up exceeding audioBuffer.length. The server-side
            // fix addresses the actual source, but this guard means a chunk that
            // somehow still doesn't fit gets silently dropped instead of crashing
            // the whole page — losing one chunk's worth of audio is recoverable
            // (the rebuffer/stall-recovery machinery already handles gaps), a hard
            // crash is not.
            // Real, confirmed bug found directly from two separate production
            // logs: this used to drop the ENTIRE chunk whenever it slightly
            // overflowed audioBuffer.length, even when only the last sample or two
            // was actually out of bounds. First occurrence was a harmless 1-sample
            // overshoot; a later one carried the same off-by-one but on a chunk
            // that happened to be ~77,851 samples (~1.8s) — dropping that whole
            // chunk instead of just the 1 sample past the end meant discarding
            // 1.8 real seconds of audio for the sake of 1 sample, which is exactly
            // the kind of audible gap this was reported as "crackling". Trimming to
            // whatever actually fits keeps everything genuinely in range instead of
            // discarding valid, in-bounds audio alongside the invalid tail.
            if (myGenerationToken === decodeGenerationToken && audioBuffer && msg.startSample < audioBuffer.length) {
              const availableFrames = audioBuffer.length - msg.startSample;
              const framesToWrite = Math.min(availableFrames, msg.channels[0].length);
              if (framesToWrite < msg.channels[0].length) {
                bufferClientError('warn', 'Trimmed out-of-bounds PCM chunk: startSample=' + msg.startSample + ' length=' + msg.channels[0].length + ' bufferLength=' + audioBuffer.length + ' — wrote ' + framesToWrite + ' of ' + msg.channels[0].length + ' frames');
              }
              for (let c = 0; c < numChannels; c++) audioBuffer.getChannelData(c).set(msg.channels[c].subarray(0, framesToWrite), msg.startSample);
              // Network-segment boundary check — see this segment's own comment
              // above for the full reasoning. Only meaningful when there's real
              // preceding audio to compare against (not the track's very first
              // segment) and enough headroom for the comparison window.
              if (isFirstChunkOfThisSegment && segmentStartSeconds > 0 && msg.startSample > 20) {
                // Real, direct gap found from a "small snap/crackle" description
                // — the classic signature of a genuine sample discontinuity, not
                // sustained clipping. This detection-and-fix only ever checked
                // channel 0 to decide whether to trigger the smoothing below —
                // the exact same blind spot found and fixed on the OTHER
                // discontinuity check (in scheduleSegment) earlier, but never
                // applied here. The smoothing loop itself already covers every
                // channel once triggered; the gap was upstream of that, in
                // deciding whether to trigger at all. On 7.1/8ch content, a
                // discontinuity confined to a rear or LFE channel would never
                // trip channel 0's check, so the fix that would have silenced
                // it never ran — for any channel, including the affected one.
                const WINDOW = 20;
                let worstJoinDelta = 0, worstLocalAvgDelta = 0, anyFlagged = false;
                for (let c = 0; c < numChannels; c++) {
                  const chData = audioBuffer.getChannelData(c);
                  const joinDelta = Math.abs(chData[msg.startSample] - chData[msg.startSample - 1]);
                  let localDeltaSum = 0;
                  for (let i = 2; i <= WINDOW; i++) localDeltaSum += Math.abs(chData[msg.startSample - i + 1] - chData[msg.startSample - i]);
                  const localAvgDelta = localDeltaSum / (WINDOW - 1);
                  // Threshold lowered from (0.05, x8) to (0.02, x4) — a direct
                  // response to a reported "snap/crackle every ~60s" complaint
                  // still happening after this same check was already extended
                  // to all channels. An UNCONDITIONAL version (smoothing every
                  // boundary regardless of detection) was tried and reverted
                  // after directly testing it: linearly interpolating between
                  // two points on a curved waveform doesn't perfectly retrace
                  // that curve, so applying it even where no real discontinuity
                  // exists measurably altered already-clean audio (confirmed
                  // directly: ~0.055 magnitude change on a signal with zero
                  // actual jump) — trading one periodic artifact for a
                  // different one, not a real fix. Lowering the threshold
                  // instead catches subtler real discontinuities without
                  // touching joins that were never actually broken.
                  if (joinDelta > Math.max(0.02, localAvgDelta * 4)) {
                    anyFlagged = true;
                    if (joinDelta > worstJoinDelta) { worstJoinDelta = joinDelta; worstLocalAvgDelta = localAvgDelta; }
                  }
                }
                if (anyFlagged) {
                  bufferClientError('warn', `Possible network-segment-boundary discontinuity at sample=${msg.startSample} (${segmentStartSeconds.toFixed(1)}s, quality=${quality}), ${numChannels}ch buffer — worst channel: joinDelta=${worstJoinDelta.toFixed(4)} vs local avg=${worstLocalAvgDelta.toFixed(4)} (${(worstJoinDelta / Math.max(worstLocalAvgDelta, 1e-6)).toFixed(1)}x)`);
                  // Direct fix, not just detection — gated on anyFlagged (see
                  // the threshold comment just above for why this stays
                  // conditional rather than unconditional). Short linear ramp
                  // of the new segment's own first few samples, from the last
                  // known-good value toward this segment's actual trend,
                  // directly in the sample data — the standard technique for
                  // removing a real inter-block click.
                  const SMOOTH_SAMPLES = Math.min(24, framesToWrite - 1); // ~0.5ms at 44.1kHz — short enough to be inaudible as its own effect; -1 so targetTrend below always reads an already-written sample, never past what this chunk actually delivered
                  if (SMOOTH_SAMPLES > 1) {
                    for (let c = 0; c < numChannels; c++) {
                      const chData = audioBuffer.getChannelData(c);
                      const before = chData[msg.startSample - 1];
                      const targetTrend = chData[msg.startSample + SMOOTH_SAMPLES]; // value this segment is already trending toward, past the ramp window
                      for (let i = 0; i < SMOOTH_SAMPLES; i++) {
                        const frac = (i + 1) / SMOOTH_SAMPLES;
                        chData[msg.startSample + i] = before * (1 - frac) + targetTrend * frac;
                      }
                    }
                  }
                }
              }
              isFirstChunkOfThisSegment = false;
            } else if (myGenerationToken === decodeGenerationToken) {
              // startSample itself is already at/past the buffer's end — genuinely
              // nothing valid in this chunk to keep, unlike the trim case above.
              bufferClientError('warn', 'Dropped out-of-bounds PCM chunk: startSample=' + msg.startSample + ' length=' + msg.channels[0].length + ' bufferLength=' + (audioBuffer ? audioBuffer.length : 0));
            }
            lastEndSample = msg.endSample;
            // Real, direct fix for a genuinely desktop-specific concern:
            // this measures how fast decode progresses, which in practice
            // is gated almost entirely by how fast new bytes arrive — but
            // the desktop app's own local disk cache (see preload.js) can
            // serve an already-downloaded segment nearly instantly,
            // making the connection look artificially faster than it
            // really is. That could trigger a quality upgrade the ACTUAL
            // network can't sustain once a segment that isn't cached is
            // needed. window.__novaCacheServedRecently is set by the
            // desktop fetch-patch immediately before returning a cached
            // response, and consumed (reset) here — exactly the one
            // measurement it would have skewed gets skipped, nothing else
            // about this system changes, and on every other platform
            // (where this flag is never set at all) this is a pure no-op.
            const wasCacheServed = window.__novaCacheServedRecently === true;
            window.__novaCacheServedRecently = false;
            if (!isPrefetch && !wasCacheServed) recordThroughputSample(msg.endSample);
            if (myGenerationToken === decodeGenerationToken && !isPrefetch) {
              decodedUpToSample = msg.endSample;
              maybeExtendSchedule();
            }
            // Real, confirmed gap: throughput used to only ever get (re-)measured once
            // a stream reached a clean 'end' — meaning a session that starts
            // conservatively low (correctly remembering an earlier bad connection
            // moment) had no way to notice a track was actually downloading just fine
            // until that track finished entirely. Checking in periodically on an
            // ongoing, successfully-progressing stream lets a recovered connection
            // get recognized and upgraded much sooner.
            //
            // Uses the windowed (recent-only) rate, not the cumulative since-start
            // average — see windowedBytesPerSec's own comment for why that average
            // was itself a real bug.
            {
              const windowed = windowedBytesPerSec(numChannels);
              const elapsedSec = (performance.now() - throughputStartMs) / 1000;
              if (!isPrefetch && windowed !== null && elapsedSec - lastPeriodicMeasureSec >= 5) {
                lastPeriodicMeasureSec = elapsedSec;
                maybeAdjustAutoQualityTier(windowed, sampleRate, numChannels);
              }
            }
            if (!calledReady) {
              const bufferedSeconds = msg.endSample / sampleRate;
              // Higher bar when resampling (quality !== 'full') — measured directly:
              // the ffmpeg hop this path adds has ~500ms more startup latency than
              // direct pass-through even in a fast local test. 3 buffered seconds was
              // tuned against the direct path's more predictable latency; giving the
              // resampled path more margin means a real hiccup in that hop is more
              // likely to be absorbed by buffer already built up.
              //
              // Must account for startAtSeconds, not just count seconds decoded from
              // the start of the file — confirmed as a real, reproducible bug via a
              // real recording: resuming a paused track at a non-zero position called
              // this ready after only a few seconds decoded FROM THE BEGINNING of the
              // file, nowhere near the actual resume point.
              const minBufferSeconds = (quality === 'full' ? 20 : 25) + startAtSeconds;
              if (bufferedSeconds >= minBufferSeconds || msg.endSample >= audioBuffer.length) { calledReady = true; onReadyToPlay(audioBuffer); }
            }
          } else if (msg.type === 'end') {
            worker.terminate();
            const windowedFinal = windowedBytesPerSec(numChannels);
            const elapsedSec = (performance.now() - throughputStartMs) / 1000;
            if (!isPrefetch) {
              if (windowedFinal !== null) maybeAdjustAutoQualityTier(windowedFinal, sampleRate, numChannels);
              else if (elapsedSec > 0.5) maybeAdjustAutoQualityTier(totalBytesForThroughput / elapsedSec, sampleRate, numChannels);
            }
            const trackFullyComplete = audioBuffer && lastEndSample >= audioBuffer.length;
            if (trackFullyComplete) {
              if (!calledReady) { calledReady = true; onReadyToPlay(audioBuffer); }
              resolve(audioBuffer);
            } else {
              // This segment's bounded duration was reached, but the track itself
              // isn't done — this is the normal, expected case in a segmented fetch,
              // not a premature failure. Request the next bounded segment rather than
              // treating "ended before the whole track" as an error.
              fetchSegment(lastEndSample / sampleRate, 0);
            }
          } else if (msg.type === 'error') {
            worker.terminate();
            // Retry just THIS segment — the actual resilience win of segmenting at
            // all. A hiccup partway through now costs one small segment's worth of
            // re-fetching (at most SEGMENT_DURATION_SECONDS of redundant work), not
            // the entire remaining track restarting from scratch.
            if (retryCount < MAX_SEGMENT_RETRIES && myGenerationToken === decodeGenerationToken) {
              bufferClientError('warn', `Segment fetch failed at ${segmentStartSeconds.toFixed(1)}s (attempt ${retryCount + 1}/${MAX_SEGMENT_RETRIES}): ${msg.message}. Retrying just this segment.`);
              setTimeout(() => fetchSegment(segmentStartSeconds, retryCount + 1), segmentRetryDelayMs(retryCount));
            } else {
              reject(new Error(msg.message));
            }
          }
        };
        worker.onerror = (err) => {
          worker.terminate();
          // Real, confirmed miss: an earlier attempt at this added an
          // onunhandledrejection handler INSIDE the worker itself — but that
          // posts through the normal message channel (msg.type === 'error'),
          // which already had a real message; it does nothing for THIS handler,
          // worker.onerror, which fires for a different class of failure
          // entirely (an uncaught exception that crashes the worker outright,
          // reported via the browser's own ErrorEvent). err.message was
          // apparently empty for whatever's actually happening here, on this
          // specific mobile browser, for however many production occurrences —
          // pulling every other property ErrorEvent actually carries (filename,
          // line/col, the underlying .error object and ITS message/stack) is
          // the direct fix: get real information from what's actually
          // available instead of assuming .message is always populated.
          const errorDetail = [
            err.message,
            err.filename ? `at ${err.filename}:${err.lineno}:${err.colno}` : null,
            err.error && err.error.message && err.error.message !== err.message ? `underlying: ${err.error.message}` : null,
            err.error && err.error.stack ? `stack: ${err.error.stack}` : null,
          ].filter(Boolean).join(' | ') || '(no detail available on this ErrorEvent)';
          if (retryCount < MAX_SEGMENT_RETRIES && myGenerationToken === decodeGenerationToken) {
            bufferClientError('warn', `Segment worker error at ${segmentStartSeconds.toFixed(1)}s (attempt ${retryCount + 1}/${MAX_SEGMENT_RETRIES}): ${errorDetail}. Retrying just this segment.`);
            setTimeout(() => fetchSegment(segmentStartSeconds, retryCount + 1), segmentRetryDelayMs(retryCount));
          } else {
            reject(new Error('PCM worker error: ' + errorDetail));
          }
        };
        worker.postMessage({ url, requestId });
      }

      fetchSegment(startAtSeconds, 0);
    });
  }

  // ---------- Server-side caching now handles fast re-access ----------
  // decodeCache (a client-side Map holding full, already-decoded AudioBuffers
  // for tracks not currently playing) removed per explicit direction: the
  // server's own PCM cache (lib/pcmCache.js) now serves this exact role —
  // re-fetching an already-played track is fast because the SERVER skips
  // decoding entirely and serves straight from its cached file, not because
  // this client's own memory happened to still be holding a copy. inFlightDecodes
  // stays — a different, still-needed job: making sure two concurrent requests
  // for the same not-yet-fetched track (e.g. prefetch racing a manual track
  // switch) share one in-flight fetch instead of firing two.
  const inFlightDecodes = new Map();
  // Single-slot next-track prefetch — bounded to exactly one track's buffer,
  // never more, and only ever the immediate next queue position. This is
  // narrower than the old decodeCache it replaces (that could accumulate
  // several tracks' worth over a session via prev/repeat navigation); this
  // holds at most one extra track, purely so the one transition that
  // actually needs to be seamless — into whatever plays next — can start
  // instantly instead of needing a fresh fetch at the exact moment playback
  // reaches it. Direct, reported regression from removing decodeCache
  // entirely: the server's own PCM cache made re-fetching fast, but "fast"
  // still means a real network round-trip at the transition instant, which
  // is audible as a gap — this restores true instant-start specifically for
  // the next track, without going back to holding arbitrarily many tracks.
  let nextTrackPrefetch = null; // { id, promise }
  async function getDecodedBufferFull(track) {
    if (inFlightDecodes.has(track.id)) return inFlightDecodes.get(track.id);
    // isPrefetch=true — see its full reasoning in getDecodedBufferFromServerPCM's
    // own comment: this is the only caller ever meant to fetch a track that
    // ISN'T the one actively playing, so it must never be allowed to write into
    // the active track's shared decode/playback state.
    const p = getDecodedBufferFromServerPCM(track, 0, () => {}, undefined, true);
    inFlightDecodes.set(track.id, p);
    try { return await p; } finally { inFlightDecodes.delete(track.id); }
  }
  function prefetchNext() {
    const nextId = queue[queuePos + 1];
    if (!nextId) { nextTrackPrefetch = null; return; }
    if (nextTrackPrefetch && nextTrackPrefetch.id === nextId) return; // already prefetching/prefetched exactly this one
    const track = trackById(nextId);
    if (!track) return;
    // Fetching AND holding the result now (unlike the discard-immediately
    // version this replaces) — the held buffer is what playTrack below uses
    // for an instant start. Still only ever one slot: assigning a new one
    // here replaces whatever was previously prefetched, so this can never
    // grow into holding more than the single, current "next" track.
    nextTrackPrefetch = { id: nextId, promise: getDecodedBufferFull(track).catch(err => { console.warn('Prefetch failed for', track.name, err); return null; }) };
  }

  // ---------- playTrack ----------
  // ---------- Native-app mode (Android wrapper) ----------
  // Self-contained block, reached only when window.NovaNative exists (see
  // MainActivity.kt / NativeAudioBridge.kt in nova-android/). Every function
  // and variable below is used ONLY by this path — nothing here is called
  // from, or changes the behavior of, the regular Web-Audio browser path
  // below it.
  const nativeFetchResolvers = new Map(); // requestId -> {resolve, reject}
  let nativeRequestCounter = 0;
  window.__novaNativeCallback = function (jsonStr) {
    let msg;
    try { msg = JSON.parse(jsonStr); } catch (e) { return; }
    const resolver = nativeFetchResolvers.get(msg.requestId);
    if (!resolver) return;
    nativeFetchResolvers.delete(msg.requestId);
    if (msg.success) resolver.resolve(msg.headers || {});
    else resolver.reject(new Error(msg.error || 'native fetch failed'));
  };
  // The other half of the headers-arrive-early fix — see notifyJsHeaders's
  // own comment in NativeAudioBridge.kt for the full story. Fires as soon
  // as a segment's HTTP response headers are available, independent of
  // (and well before) whatever nativeFetchSegment's own promise resolution
  // is waiting on, which needs the entire body downloaded first. This is
  // what actually establishes the real duration promptly — previously it
  // only ever became known after a full, potentially large segment
  // download finished, which is why every seek attempted before that point
  // kept finding no known duration to seek within, and the lock screen
  // never had a duration to report either.
  window.__novaHeadersCallback = function (jsonStr) {
    let msg;
    try { msg = JSON.parse(jsonStr); } catch (e) { return; }
    const headers = msg.headers;
    nativeDebugLog(`__novaHeadersCallback received: ${jsonStr}`);
    if (!headers || !headers.sampleRate || !headers.totalFrames) { nativeDebugLog('__novaHeadersCallback: missing sampleRate/totalFrames, ignoring'); return; }
    const durationSeconds = Number(headers.totalFrames) / Number(headers.sampleRate);
    if (!durationSeconds || !isFinite(durationSeconds)) { nativeDebugLog(`__novaHeadersCallback: computed duration invalid (${durationSeconds}), ignoring`); return; }
    window.__nativeKnownDuration = durationSeconds;
    nativeDebugLog(`__novaHeadersCallback: window.__nativeKnownDuration set to ${durationSeconds}`);
    $('timeTotal').textContent = fmtTime(durationSeconds);
    const track = nativeCurrentTrackId && trackById(nativeCurrentTrackId);
    if (track) nativeUpdateNowPlaying(track, isPlaying, durationSeconds, currentTimeSec());
  };
  // Hardware/lock-screen transport buttons (see PlaybackService.kt) route
  // here — reuses the exact same functions the on-screen buttons already
  // call, rather than a second, native-side implementation of play/pause/
  // next/prev state.
  window.__novaTransport = function (action, value) {
    if (action === 'play') { if (window.NovaNative) nativeResume(); else resumePlayback(); }
    else if (action === 'pause') { if (window.NovaNative) nativePause(); else pausePlayback(); }
    else if (action === 'next') playNextInQueue();
    else if (action === 'prev') playPrevInQueue();
    else if (action === 'seek') {
      // Real, direct fix for a confirmed "seeking from media info still
      // causes static" complaint — the in-app seek bar already has a
      // 250ms settle-before-committing debounce specifically because
      // rapid scrubbing was confirmed, via an actual spectrogram, to
      // cause exactly this. That protection was never extended to a
      // lock-screen/media-session seek arriving through this exact same
      // path — and Android's own lock-screen seek control can be dragged
      // too, generating its own rapid stream of position updates with
      // nothing here to coalesce them. Same debounce, same reasoning,
      // applied to the one seek entry point that never had it.
      if (window.NovaNative) {
        if (mediaSessionSeekTimer) clearTimeout(mediaSessionSeekTimer);
        mediaSessionSeekTimer = setTimeout(() => {
          mediaSessionSeekTimer = null;
          nativeSeek((value || 0) / 1000);
        }, 250);
      } else {
        seekTo((value || 0) / 1000);
      }
    }
  };
  let mediaSessionSeekTimer = null;

  let nativeCurrentTrackId = null;
  let lastPlayTrackNativeId = null, lastPlayTrackNativeMs = 0, lastPlayTrackNativeStartAtSeconds = undefined; // debounce state — see playTrackNative's own comment for what this guards against
  let nativeGenerationToken = 0; // same purpose as the Web-Audio path's decodeGenerationToken — invalidates a still-in-flight native fetch loop when a newer playTrackNative call supersedes it
  let nativePaused = false;

  // Sends a line to the same on-screen debug panel native code writes to
  // (see DebugOverlay.kt) — added specifically because native-side logging
  // alone couldn't show whether the JS side ever got far enough to ask
  // native code to do anything in the first place. Silently does nothing
  // outside native mode or before the bridge exists.
  function nativeDebugLog(msg) {
    if (!window.NovaNative) return;
    try { window.NovaNative.postMessage(JSON.stringify({ type: 'debugLog', message: msg })); } catch (e) {}
  }

  function nativeFetchSegment(url, sampleRate, channels, isFirstOfTrack, isRetry, isLastSegmentOfTrack) {
    nativeDebugLog(`nativeFetchSegment called: ${url}`);
    const requestId = 'r' + (nativeRequestCounter++);
    return new Promise((resolve, reject) => {
      nativeFetchResolvers.set(requestId, { resolve, reject });
      window.NovaNative.postMessage(JSON.stringify({ type: 'fetchSegment', url, sampleRate, channels, isFirstOfTrack, isRetry: !!isRetry, isLastSegmentOfTrack: !!isLastSegmentOfTrack, requestId, generation: nativeGenerationToken }));
      nativeDebugLog(`fetchSegment postMessage sent, requestId=${requestId}`);
    });
  }

  // The actual fix for "should start loading the next track in the
  // background like the web UI does" — fire-and-forget by design, nothing
  // awaits this directly. Called once the current track's own fetch loop
  // determines it's fetching its LAST needed segment, well before that
  // track actually ends, so the download genuinely overlaps with the
  // current track still playing rather than starting only once it's over.
  // Real, direct fix for a reported "still no seamless playback" complaint,
  // traced to an actual timing problem in a device log: a seek landed only
  // ~9.5 seconds from the end of a track, and the prefetch was requesting a
  // full 60-second segment (~30MB for 8-channel content) — nowhere near
  // enough lead time to finish on a connection that's shown repeated
  // timeouts all session for much smaller requests. A prefetch only needs
  // to bridge the gap until the normal fetch loop can take back over, not
  // download as much as a regular segment does — a much smaller request has
  // a real chance of finishing within whatever lead time happens to be
  // available, however little that turns out to be.
  const PREFETCH_DURATION_SECONDS = 15;

  function nativePrefetchNext(track) {
    if (!window.NovaNative || !track) return;
    const url = new URL('/api/stream/pcm?path=' + encodeURIComponent(track.localPath) + '&quality=' + effectiveQuality() + '&skipToSeconds=0&maxDurationSeconds=' + PREFETCH_DURATION_SECONDS, window.location.href).href;
    nativeDebugLog(`nativePrefetchNext called for trackId=${track.id}: ${url}`);
    window.NovaNative.postMessage(JSON.stringify({ type: 'prefetchSegment', url, trackId: track.id, sampleRate: 44100, channels: 2 }));
  }

  // Attempts to use an already-prefetched segment instead of starting a
  // fresh fetch — resolves with the real headers if a matching prefetch was
  // ready in time, or rejects if none was available (too slow, or none was
  // ever requested), in which case the normal fetch loop below falls back
  // to fetching this segment itself exactly as it always did. A prefetch is
  // purely an optimization; nothing about normal playback depends on one
  // ever succeeding.
  function nativeConsumePrefetch(trackId) {
    const requestId = 'r' + (nativeRequestCounter++);
    return new Promise((resolve, reject) => {
      nativeFetchResolvers.set(requestId, { resolve, reject });
      window.NovaNative.postMessage(JSON.stringify({ type: 'consumePrefetch', trackId, requestId, generation: nativeGenerationToken }));
    });
  }

  // Real, direct fix for a confirmed "still doing it" complaint — a device
  // log showed the actual pattern clearly once the pause-responsiveness
  // fix (rejecting in-flight fetches immediately) made each individual
  // toggle fast: it wasn't one stuck action anymore, it was many GENUINE,
  // rapid pause/resume calls in quick succession — from the on-screen
  // button AND from window.__novaTransport (lock screen / a connected
  // device), sometimes interleaved. Each one legitimately started or
  // stopped playback, and each one cycled the real audio hardware, which
  // is the confirmed source of the static/click artifacts several rounds
  // back. Making each individual cycle respond faster never addressed the
  // volume of cycles happening in the first place. Shared between both
  // functions (rather than only guarding the on-screen button) so a rapid
  // sequence is caught regardless of which path it arrives through — a
  // call within 400ms of the last one is ignored outright.
  let lastPauseResumeToggleMs = 0;
  function nativePause() {
    // Real, direct diagnostic addition after a confirmed "still doing the
    // same thing" report even after the nativeClockRunning fix — this
    // means either that fix didn't address the real cause, or nativePause
    // is being triggered by something other than the OS media framework
    // entirely. This is the one thing that can actually distinguish those:
    // a real stack trace of whatever called this function, the same way
    // playTrackNative already logs its own callers.
    nativeDebugLog(`nativePause called, stack=${(new Error().stack || '').split('\n').slice(1, 6).join(' | ')}`);
    const nowToggle = Date.now();
    if (nowToggle - lastPauseResumeToggleMs < 400) {
      nativeDebugLog(`Ignoring nativePause within 400ms of the last pause/resume toggle (${nowToggle - lastPauseResumeToggleMs}ms since)`);
      return;
    }
    lastPauseResumeToggleMs = nowToggle;
    nativePaused = true;
    // Real, direct fix for a confirmed "pause not forcing itself through
    // while still catching up" complaint — a device log showed the actual
    // mechanism: an in-flight fetch's own await can't return until the
    // underlying network call resolves on its own, which can take up to
    // 15 seconds per attempt. Setting nativePaused alone does nothing
    // until the fetch loop gets a chance to check it, which only happens
    // once that await returns — so a pause tapped mid-fetch had no visible
    // effect until the network genuinely finished, however long that took.
    // Immediately rejecting every pending resolver here makes that await
    // return right away instead of waiting on the network, so the loop's
    // own generation/pause checks — which already exist and already work
    // correctly — get to run immediately rather than whenever the network
    // happens to get around to it.
    nativeFetchResolvers.forEach(r => r.reject(new Error('Paused')));
    nativeFetchResolvers.clear();
    // Real, direct fix for a confirmed gap found via code inspection: this
    // rejects the JS-side promise waiting on a fetch, but never stopped
    // the underlying NATIVE request at all — and never told native code
    // this was happening, since 'stopAndFlush' carried no generation. The
    // native fetch loop's own staleness check (myGeneration !=
    // currentGeneration, already correct and already used everywhere
    // else) never fires for a pause specifically, because currentGeneration
    // was never updated for one — only 'start' messages ever touched it.
    // An in-flight fetch at the moment of pause kept running in the
    // background regardless, and kept enqueueing its data once it
    // eventually completed, even though the user had already paused —
    // contaminating the queue for whatever plays next. Bumping the
    // generation here and sending it through is what actually makes
    // native code's own existing check catch this case too, the same way
    // it already catches every other supersession.
    nativeGenerationToken++;
    window.NovaNative.postMessage(JSON.stringify({ type: 'stopAndFlush', generation: nativeGenerationToken, reason: 'nativePause' }));
    // stopAndFlush discards whatever was queued natively — the fetch loop
    // below (still running, gated on nativeGenerationToken) will simply stop
    // sending new segments once it notices nativePaused, rather than trying
    // to "pause mid-buffer" the way the Web Audio path can. Resuming re-fetches
    // from the current position, same tradeoff noted in the README under
    // "pause-resume in native mode".
    //
    // Real, direct bug found from a reported "pause/resume just restarts
    // the song" complaint, confirmed exactly in the log: nativeResume kept
    // reading playOffset directly, but this function never actually SAVED
    // an accurate position into it — playOffset only changes at discrete
    // points (track start, each segment boundary), so pausing shortly after
    // starting (before the first segment had even advanced) meant it was
    // still sitting at 0, and resuming always restarted from there. The
    // wall-clock fix made currentTimeSec() compute the real, continuously-
    // advancing position — but only while isPlaying is still true, and
    // nothing here was ever capturing that value before flipping isPlaying
    // to false, at which point currentTimeSec() falls back to that same
    // stale playOffset anyway. Captured here, before isPlaying changes.
    nativeSetPlayOffset(currentTimeSec());
    isPlaying = false;
    updateTransportUI();
    const track = nativeCurrentTrackId && trackById(nativeCurrentTrackId);
    // setNowPlaying (not a direct nativeUpdateNowPlaying call) — same
    // single-source-of-truth reasoning as everywhere else this was fixed:
    // this keeps the on-screen status text ("Paused") and the lock screen
    // in sync from the one function, rather than two separate updates that
    // can drift apart.
    if (track) setNowPlaying(track, 'Paused');
  }
  function nativeResume() {
    // Real, direct bug in my own previous fix, found immediately on
    // report: the debounce timestamp was being consumed here even for a
    // call that turns out to be a no-op (already playing, or no current
    // track) — and Android's media session framework legitimately sends
    // redundant "play" events sometimes (audio focus changes, Bluetooth
    // reconnects), completely harmless on their own. But consuming the
    // debounce window on a no-op meant a genuine pause tap landing shortly
    // after one of those got silently swallowed too — the app's internal
    // paused state fell out of sync with what actually got reported to
    // the lock screen, which is exactly what "media info broken" was.
    // Fixed by only consuming the debounce window once a call is known to
    // actually change something, not on every call regardless of effect.
    if (!nativePaused || !nativeCurrentTrackId) return;
    const nowToggle = Date.now();
    if (nowToggle - lastPauseResumeToggleMs < 400) {
      nativeDebugLog(`Ignoring nativeResume within 400ms of the last pause/resume toggle (${nowToggle - lastPauseResumeToggleMs}ms since)`);
      return;
    }
    lastPauseResumeToggleMs = nowToggle;
    nativePaused = false;
    // Real, direct bug found via code inspection after a confirmed
    // "seeking freezes the position" report, traced through a targeted
    // diagnostic that proved it rather than guessed: nativePause()
    // correctly sets isPlaying=false, but this function — the ONLY place
    // that's supposed to undo that — never once set it back to true.
    // currentTimeSec() only advances when isPlaying AND nativeClockRunning
    // are both true; with isPlaying permanently stuck false after any
    // pause, every seek/resume afterward reported a real, correctly-
    // computed position that the display then immediately discarded,
    // falling back to the frozen playOffset every time. This is the
    // actual, confirmed cause of the frozen-position diagnostic output.
    isPlaying = true;
    // Real, direct bug found via code inspection after a confirmed "press
    // play, button doesn't update" complaint: this sets the underlying
    // state correctly, but nothing here ever calls updateTransportUI() —
    // the buffered path (nativeSeekBuffered) doesn't call it either, so
    // for a resume of an already-buffered track, literally nothing in this
    // whole chain ever told the button to change. Called unconditionally
    // here, once, right after the state itself changes — covers both the
    // buffered path and the old restart path the same way.
    updateTransportUI();
    const track = trackById(nativeCurrentTrackId);
    if (!track) return;
    // The other half of the buffered-playback fix — resuming a track
    // that's already been (or is still being) downloaded should be just
    // as instant as any other in-buffer seek, not a full restart. Falls
    // back to the old restart path only if the target position genuinely
    // isn't downloaded yet.
    if (nativeCurrentTrackId === bufferedTrackId) {
      // nativeSeekBuffered now handles its own restart-at-new-position
      // internally rather than ever falling back to the old engine — see
      // its own comment for why. It always resolves true for this case.
      nativeSeekBuffered(playOffset || 0);
      return;
    }
    playTrackNative(nativeCurrentTrackId, track, playOffset || 0);
  }

  // Native mode has no way to "seek mid-buffer" the way the Web-Audio path
  // can — same tradeoff already noted for pause/resume (see nativePause's
  // own comment) — so a seek is really just a restart at a new position:
  // stop whatever's currently fetching/playing, then start over from that
  // position, letting the fetch loop's own skipToSeconds request the right
  // spot from the server directly rather than downloading and discarding
  // everything before it.
  // ==================== Buffered (whole-track) playback ====================
  // The actual architecture change requested directly, after a real,
  // confirmed explanation of why other apps (Apple Music, Amazon Music,
  // anything built on ExoPlayer) don't have this problem: they download a
  // track's whole content once and seek within an in-memory buffer,
  // completely avoiding the network request + audio-hardware cycle this
  // whole session has been trying to make individually safer. This is a
  // parallel path to the existing segment-fetch-loop one above, used for a
  // genuinely fresh track start (not a gapless continuation, which keeps
  // using the existing, already-working queue path untouched — rewriting
  // both systems in one pass was a real, avoidable risk not worth taking).
  let bufferedTrackId = null; // which track ID (if any) currently has an active buffered download/playback — null if the current track is using the old queue path instead (e.g. a gapless continuation)
  // Real, direct addition needed for deep-seek restarts (see
  // nativeSeekBufferedRestart's own comment): the buffer's own byte space
  // always starts at 0, but that 0 doesn't necessarily correspond to
  // absolute track position 0 anymore once a restart has happened. Every
  // byte-offset computation for a seek needs to subtract this to land in
  // the CURRENT buffer's own relative space, not the absolute track time.
  let bufferedStartOffsetSeconds = 0;
  let nativeTrackDurationSeconds = null;
  let nativeTrackBytesPerSecond = null; // sampleRate * channels * 2 (16-bit) — computed once real headers arrive, used to convert a seek target in seconds to a byte offset for seekWithinBuffer

  window.__novaTrackDurationKnown = function (jsonStr) {
    let msg;
    try { msg = JSON.parse(jsonStr); } catch (e) { return; }
    if (msg.trackId !== bufferedTrackId) return; // stale — for a track that's no longer current
    if (!msg.totalFrames || !msg.sampleRate || !msg.channels) return;
    const durationSeconds = Number(msg.totalFrames) / Number(msg.sampleRate);
    if (!durationSeconds || !isFinite(durationSeconds)) return;
    nativeTrackDurationSeconds = durationSeconds;
    nativeTrackBytesPerSecond = Number(msg.sampleRate) * Number(msg.channels) * 2;
    window.__nativeKnownDuration = durationSeconds;
    $('timeTotal').textContent = fmtTime(durationSeconds);
    const track = nativeCurrentTrackId && trackById(nativeCurrentTrackId);
    if (track) nativeUpdateNowPlaying(track, isPlaying, durationSeconds, currentTimeSec());
  };

  /**
   * Real, direct fix for a confirmed "not playing the next song after
   * skipping" report — traced to a genuine, previously-unhandled gap:
   * if a track's download never succeeds even once (a real HTTP 404 in
   * the log that caused this fix — the file was simply unreachable),
   * nothing on the native side ever creates a playback thread for it,
   * and nothing was watching for that condition at all. Playback just
   * went silent, permanently, with no error shown and no attempt to
   * move on. This is that missing watch — skips to the next track the
   * same way a normal track ending does, rather than stalling forever
   * on one broken file.
   */
  window.__novaTrackDownloadFailed = function (jsonStr) {
    let msg;
    try { msg = JSON.parse(jsonStr); } catch (e) { return; }
    if (msg.trackId !== nativeCurrentTrackId) return; // stale — for a track the user has already moved on from by the time this arrived
    nativeDebugLog(`__novaTrackDownloadFailed: trackId=${msg.trackId} could not be downloaded at all — skipping to the next track`);
    const track = trackById(msg.trackId);
    if (track) setNowPlaying(track, 'Could not load this track — skipping…');
    playNextInQueue();
  };

  /**
   * The actual seamless-transition completion — fires only after native
   * code has already swapped the AudioTrack's own data source to the next
   * track's buffer, with no pause or gap in the audio itself. Everything
   * here is pure state bookkeeping catching up to what already happened:
   * which track is "current," the displayed metadata, and chaining the
   * NEXT prefetch so this keeps working for every track in the queue, not
   * just the first transition.
   */
  window.__novaSeamlessTrackSwap = function (jsonStr) {
    let msg;
    try { msg = JSON.parse(jsonStr); } catch (e) { return; }
    const track = trackById(msg.trackId);
    if (!track) return;
    // Real, direct fix for a confirmed bug: the engine promotes the
    // BUFFER (nextTrackBuffer -> currentTrackBuffer) the instant this
    // swap happens, but the download loop feeding it was still governed
    // by the prefetch's own generation counter and buffer accessors —
    // left unpromoted, that loop's own appends silently miss their
    // target the moment the swap happens, and the now-current track's
    // download effectively stalls right when it becomes current. Sent
    // first, before anything else below, so the SAME already-running
    // download keeps feeding this track without interruption.
    if (window.NovaNative) {
      window.NovaNative.postMessage(JSON.stringify({ type: 'promoteNextTrackDownload', trackId: msg.trackId }));
    }
    // Explicit "done with this track" cache-release signal — same
    // reasoning as playTrack's own identical call: best-effort, the TTL
    // sweep is the real safety net if this doesn't land.
    const outgoingTrack = nativeCurrentTrackId && trackById(nativeCurrentTrackId);
    if (outgoingTrack && outgoingTrack.id !== track.id) {
      fetch('/api/stream/pcm/release', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ path: outgoingTrack.localPath }), credentials: 'include' }).catch(() => {});
    }
    nativeCurrentTrackId = track.id;
    bufferedTrackId = track.id;
    bufferedStartOffsetSeconds = 0;
    // Real, direct fix for a confirmed "timeline issue" report that
    // persisted after the buffering-stall fix — a genuinely different,
    // more fundamental bug: this used to set playOffset directly, but
    // never touched nativeOffsetBasisMs/nativeOffsetBasisValue — the
    // actual variables the wall-clock formula in currentTimeSec() reads
    // while nativeClockRunning is true, which it stays straight through a
    // seamless swap. That left a real window, on every single seamless
    // swap, where the display kept counting up from the OLD track's stale
    // basis instead of actually resetting — not corrected until the new
    // track's first chunk eventually arrived and reset it through a
    // separate path. That gap is brief per swap, but accumulates across
    // every transition in a queue, which is exactly why the overshoot
    // got worse the further into the queue playback got. nativeSetPlayOffset
    // resets both playOffset AND the basis together, atomically, so the
    // display genuinely reflects 0 the instant the swap itself happens,
    // not some time after.
    nativeSetPlayOffset(0);
    nativeTrackDurationSeconds = null;
    nativeTrackBytesPerSecond = null;
    window.__nativeKnownDuration = 0;
    if (msg.totalFrames && msg.sampleRate && msg.channels) {
      const durationSeconds = Number(msg.totalFrames) / Number(msg.sampleRate);
      if (durationSeconds && isFinite(durationSeconds)) {
        nativeTrackDurationSeconds = durationSeconds;
        nativeTrackBytesPerSecond = Number(msg.sampleRate) * Number(msg.channels) * 2;
        window.__nativeKnownDuration = durationSeconds;
        $('timeTotal').textContent = fmtTime(durationSeconds);
      }
    }
    // Advance the queue position the same way the old engine's own
    // gapless transition does — repeat-all wraps back to the start.
    const curIdx = queue.indexOf(track.id, queuePos);
    if (curIdx >= 0) queuePos = curIdx;
    else if (queuePos + 1 < queue.length && queue[queuePos + 1] === track.id) queuePos = queuePos + 1;
    else if (repeatMode === 'all' && queue.length > 0 && queue[0] === track.id) queuePos = 0;
    updateTransportUI();
    setNowPlaying(track, 'Playing — buffering rest');
    nativeDebugLog(`__novaSeamlessTrackSwap: now playing trackId=${track.id}`);
    // Chain the prefetch forward — without this, only the very first
    // transition in a queue would ever be gapless.
    if (repeatMode !== 'one') {
      const nextIdx = queuePos + 1 < queue.length ? queuePos + 1 : (repeatMode === 'all' && queue.length > 0 ? 0 : -1);
      const nextTrack = nextIdx >= 0 ? trackById(queue[nextIdx]) : null;
      if (nextTrack && window.NovaNative) {
        const quality = effectiveQuality();
        // Real, direct fix for a confirmed "keeps skipping out/buffering"
        // report — traced to a genuine resource-contention pattern: the
        // prefetch for the NEXT track used to start decoding immediately,
        // at the exact same moment the CURRENT track's own download does.
        // On a server without CPU to spare, decoding two full multichannel
        // tracks at once can leave neither one comfortably faster than
        // real-time — exactly the "cursor and downloadedBytes constantly
        // nearly equal" pattern in the report, on the track actually being
        // listened to. A short, deliberate delay here gives the current
        // track's own download real priority through its most vulnerable
        // early window, before the prefetch starts competing for the same
        // resources — a few seconds costs the prefetch almost nothing
        // against a track that's minutes long, but meaningfully reduces
        // contention exactly when a fresh download most needs to build up
        // a real lead over playback.
        setTimeout(() => {
          window.NovaNative.postMessage(JSON.stringify({
            type: 'prepareNextTrackDownload',
            path: nextTrack.localPath, quality, trackId: nextTrack.id, sampleRate: 44100, channels: 2, startAtSeconds: 0,
          }));
        }, 5000);
      }
    }
  };

  const nativeSeekWithinBufferResolvers = new Map(); // requestId -> {resolve, reject}
  window.__novaSeekWithinBufferResult = function (jsonStr) {
    let msg;
    try { msg = JSON.parse(jsonStr); } catch (e) { return; }
    const resolver = nativeSeekWithinBufferResolvers.get(msg.requestId);
    if (!resolver) return;
    nativeSeekWithinBufferResolvers.delete(msg.requestId);
    resolver.resolve(!!msg.succeeded);
  };

  /**
   * Starts genuinely fresh buffered playback for a track: stops whatever
   * the old queue-based engine was doing (if anything), then kicks off the
   * whole-track background download. Playback begins natively the moment
   * the first real bytes arrive — this function doesn't wait for the
   * download to progress any further than that.
   */
  function nativeStartBufferedTrack(id, track, startAtSeconds) {
    if (!window.NovaNative) return;
    nativeGenerationToken++;
    nativePaused = false;
    isPlaying = true;
    playOffset = startAtSeconds || 0;
    nativeClockRunning = false;
    nativeCurrentTrackId = id;
    bufferedTrackId = id;
    nativeTrackDurationSeconds = null;
    window.__nativeKnownDuration = 0;
    updateTransportUI();
    tickProgress();
    setNowPlaying(track, 'Buffering…');
    // Stops the OLD queue path's own thread/AudioTrack state cleanly before
    // this new one takes over — the same shared stop function pause
    // already uses, so this is a real, known-safe stop, not a new one.
    window.NovaNative.postMessage(JSON.stringify({ type: 'stopAndFlush', generation: nativeGenerationToken, reason: 'nativeStartBufferedTrack' }));
    // Real, direct fix for a confirmed OutOfMemoryError, traced via a real
    // crash log to a stale next-track prefetch that nothing was stopping
    // on a hard track switch — it kept downloading indefinitely into a
    // buffer for a track that was no longer relevant. Every hard track
    // start now explicitly stops whatever prefetch was running before,
    // unconditionally — not relying on a NEW prefetch (below) to
    // eventually supersede it, since nothing guaranteed that always
    // happened promptly enough, or at all.
    window.NovaNative.postMessage(JSON.stringify({ type: 'stopNextTrackDownload' }));
    const quality = effectiveQuality();
    window.NovaNative.postMessage(JSON.stringify({
      type: 'startTrackDownload',
      path: track.localPath, quality, trackId: id, sampleRate: 44100, channels: 2, startAtSeconds: Math.floor(startAtSeconds || 0),
    }));
    // Real, direct fix for a confirmed "doesn't go to the next track,
    // timeline just keeps running past the actual song" bug — native code
    // already correctly fires the track-end signal once this buffered
    // track reaches its true end (onTrackEndReached, wired the same way
    // for both engines). But that signal was only ever CONSUMED by the
    // old engine's own fetch loop — the buffered path never once listened
    // for it, so the signal fired into nothing and playback just kept
    // going with no next-track logic ever triggered at all. myGenToken
    // captured here, checked before acting, is what keeps a stale
    // listener from an OLD buffered session (superseded by a seek/restart
    // since) from wrongly advancing the queue after the fact.
    const myGenTokenForTrackEnd = nativeGenerationToken;
    waitForNativeTrackEndNoTimeout().then(() => {
      if (nativeGenerationToken !== myGenTokenForTrackEnd) return; // superseded by a seek, pause, or new track since — not actually this track ending
      playNextInQueue();
    });
    // The actual gapless piece requested explicitly — begins downloading
    // the NEXT queued track's audio now, while this one plays, into its
    // own separate buffer. Matches the old engine's own "what counts as
    // next" logic (repeat-all wraps to the start, repeat-one has no
    // separate next track to prefetch at all) so behavior stays
    // consistent between the two engines.
    if (repeatMode !== 'one') {
      const nextIdx = queuePos + 1 < queue.length ? queuePos + 1 : (repeatMode === 'all' && queue.length > 0 ? 0 : -1);
      const nextTrack = nextIdx >= 0 ? trackById(queue[nextIdx]) : null;
      if (nextTrack) {
        // Same delay, same reasoning, as the seamless-swap chain's own
        // copy of this fix — a fresh track start needs its own download
        // to have real priority through its most vulnerable early window
        // just as much as a mid-queue transition does.
        setTimeout(() => {
          window.NovaNative.postMessage(JSON.stringify({
            type: 'prepareNextTrackDownload',
            path: nextTrack.localPath, quality, trackId: nextTrack.id, sampleRate: 44100, channels: 2, startAtSeconds: 0,
          }));
        }, 5000);
      }
    }
    // Real, direct fix needed alongside startAtSeconds support — this
    // buffer's own byte space now starts at 0 for THIS position, not
    // absolute track position 0. Every subsequent seek's byte-offset math
    // needs to know that to land in the right place within this buffer.
    bufferedStartOffsetSeconds = startAtSeconds || 0;
    nativeDebugLog(`nativeStartBufferedTrack: id=${id}, startAtSeconds=${startAtSeconds}`);
  }

  /**
   * The actual fix. Tries an in-memory seek within the current track's
   * buffer first — if that track is even using the buffered path at all,
   * and if the target position has actually been downloaded yet. Only
   * falls back to the old, genuinely destructive restart-based seek for
   * whatever doesn't meet both of those conditions (an unbuffered/gapless-
   * continued track, or a seek landing ahead of what's downloaded so far).
   */
  async function nativeSeekBuffered(offsetSeconds) {
    if (!nativeCurrentTrackId || nativeCurrentTrackId !== bufferedTrackId || !window.NovaNative) return false;
    const track = trackById(nativeCurrentTrackId);
    if (!track) return false;
    if (!nativeTrackDurationSeconds || !nativeTrackBytesPerSecond) return false; // don't know the real format/duration yet — can't compute a byte offset safely
    // Real, direct fix needed alongside deep-seek restart support: this
    // buffer's own byte space is relative to bufferedStartOffsetSeconds,
    // not absolute track position 0, once a restart has happened at least
    // once. Subtracting it here is what keeps this math correct across
    // any number of restarts, not just the very first buffer.
    const relativeSeconds = Math.max(0, offsetSeconds) - bufferedStartOffsetSeconds;
    if (relativeSeconds < 0) {
      // Seeking to before what this buffer even covers — same as landing
      // beyond what's downloaded, just in the other direction. Handled the
      // same way: restart the buffered system at the new position, never
      // the old engine.
      nativeDebugLog(`nativeSeekBuffered: target (${offsetSeconds}) is before this buffer's start (${bufferedStartOffsetSeconds}) — restarting buffered system there instead`);
      nativeStartBufferedTrack(nativeCurrentTrackId, track, Math.max(0, offsetSeconds));
      return true;
    }
    const byteOffset = Math.floor(relativeSeconds * nativeTrackBytesPerSecond);
    const requestId = 'sb' + (nativeRequestCounter++);
    const succeeded = await new Promise(resolve => {
      nativeSeekWithinBufferResolvers.set(requestId, { resolve, reject: () => resolve(false) });
      window.NovaNative.postMessage(JSON.stringify({ type: 'seekWithinBuffer', trackId: nativeCurrentTrackId, byteOffset, requestId }));
    });
    if (succeeded) {
      playOffset = Math.max(0, offsetSeconds);
      nativeSetPlayOffset(playOffset);
      // Real, direct bug found and fixed here: nativeSetPlayOffset sets the
      // position basis but never touches nativeClockRunning — without this,
      // currentTimeSec() keeps returning the static playOffset forever
      // after a buffered seek, even though real audio is genuinely playing
      // and advancing underneath it. A position reported as permanently
      // frozen while state says "playing" is exactly the condition that
      // legitimately looks stuck to the OS/media framework, which is what
      // was triggering an automatic pause after every single seek — a
      // real device log showed stopAndFlush firing with reason=nativePause
      // immediately after each one, no button tap involved at all.
      nativeClockRunning = true;
      nativeDebugLog(`nativeSeekBuffered: succeeded, offsetSeconds=${offsetSeconds}, byteOffset=${byteOffset}, currentTimeSec()=${currentTimeSec()}`);
    } else {
      // Real, direct architecture fix requested explicitly: this used to
      // return false here, letting the caller fall back to the old
      // queue-based engine — but that engine's own AudioTrack cycling is
      // the actual, confirmed source of the static this whole buffered
      // system exists to eliminate. Falling back to it, even just for
      // deep seeks, reintroduced exactly the bug this was built to fix.
      // Restarting THIS SAME buffered system at the new position instead
      // — same mechanism a fresh track start already uses — means a deep
      // seek never touches the old engine at all, just shows a real,
      // honest "buffering" wait while the download catches up to wherever
      // was requested.
      nativeDebugLog(`nativeSeekBuffered: target not yet downloaded — restarting buffered system at offsetSeconds=${offsetSeconds} instead of falling back to the old engine`);
      nativeStartBufferedTrack(nativeCurrentTrackId, track, Math.max(0, offsetSeconds));
      return true;
    }
    return succeeded;
  }
  // ==================== End buffered (whole-track) playback ====================

  /**
   * Real, direct fix for a confirmed server-overload issue — traced to
   * actual HTTP 502s and a null exception in a device log, correlated
   * with a seek bar stuck on "Catching up" for the rest of a whole
   * recording. Falling back from a buffered seek to the old fetch path
   * never stopped the background whole-track download, so both ended up
   * hammering the server for the SAME file at the SAME time — plausibly
   * doubling the load the server has to sequentially decode through for
   * this one track. Called at every fallback point, before the old path
   * starts its own requests.
   */
  function nativeStopBufferedDownload() {
    if (!window.NovaNative) return;
    window.NovaNative.postMessage(JSON.stringify({ type: 'stopTrackDownload' }));
    // Real, direct regression found via code inspection after a repeated
    // "media info always falls back to the old seeking" complaint: this
    // used to also null bufferedTrackId immediately here — but that
    // disabled the fast, in-memory seek path for the REST of this track's
    // playback, forever, the very first time any seek needed a fallback.
    // Everything downloaded before that one fallback point is still
    // sitting in memory and still perfectly valid for instant seeks back
    // into that range — nulling it out here threw that away. The queue-
    // based engine genuinely taking over (see playTrackNative's own
    // comment) is the right moment to disable this, not the mere decision
    // to fall back for one specific seek.
  }

  function nativeSeek(offsetSeconds) {
    if (!nativeCurrentTrackId) return;
    const track = trackById(nativeCurrentTrackId);
    if (!track) return;
    nativePaused = false;
    if (nativeCurrentTrackId === bufferedTrackId) {
      // Same as nativeResume's own call — see nativeSeekBuffered's own
      // comment for why this no longer has (or needs) a fallback branch.
      nativeSeekBuffered(offsetSeconds);
      return;
    }
    playTrackNative(nativeCurrentTrackId, track, Math.max(0, offsetSeconds));
  }

  // The actual fix for a reported "no media info in the lock screen"
  // complaint — see PlaybackService.updateNowPlaying's own comment in the
  // Android project for the full story (the pipes existed, nothing ever
  // called them). window.NovaNative.postMessage here is the only way JS can
  // reach the native MediaSession at all; there's no other bridge for it.
  function nativeUpdateNowPlaying(track, isPlaying, durationSeconds, positionSeconds) {
    if (!window.NovaNative) return;
    window.NovaNative.postMessage(JSON.stringify({
      type: 'updateNowPlaying',
      title: displayName(track), artist: displayArtist(track), album: track.tags.album || '',
      durationSeconds: durationSeconds || 0, positionSeconds: positionSeconds || 0, isPlaying,
      // Real, direct fix for a confirmed feedback loop, traced to an
      // actual sequence in a device log: reporting STATE_PLAYING with a
      // position that never advances (because real audio hasn't actually
      // started yet — see nativeClockRunning) is a plausible, reasonable
      // trigger for a connected device or the media framework to read
      // playback as stuck and reissue its own play command — which lands
      // right back at nativeResume, restarts the same fetch, reports the
      // same static position again, and repeats. Reporting STATE_BUFFERING
      // instead whenever the position genuinely isn't moving yet tells
      // anything watching "this is expected, don't intervene" rather than
      // implying playback that silently failed to actually start.
      isBuffering: !nativeClockRunning,
      // Real gap found from a direct "no album artwork in media info" report
      // — this was never sent at all before. Sent as a URL, not image data —
      // native code fetches and decodes it itself (see NativeAudioBridge's
      // handleUpdateNowPlaying), since MediaMetadataCompat needs an actual
      // Bitmap, unlike the web's own navigator.mediaSession.metadata, which
      // accepts a URL directly because the browser handles the fetch itself.
      artworkUrl: new URL(artworkUrl(track), window.location.href).href,
    }));
  }

  async function playTrackNative(id, track, startAtSeconds, isGaplessContinuation) {
    // Capturing the call stack directly — this has been called a second
    // time immediately after the first chunk of audio arrives, in every
    // report so far, and reasoning about the codebase from the outside
    // hasn't found the actual trigger. This answers it definitively instead
    // of guessing again.
    nativeDebugLog(`playTrackNative ENTERED: id=${id}, track=${displayName(track)}, startAtSeconds=${startAtSeconds}, gapless=${isGaplessContinuation}, stack=${(new Error().stack || '').split('\n').slice(1, 5).join(' | ')}`);
    // Real, direct fix for a reported "restarting itself" complaint —
    // stack traces now confirm this is TWO calls landing back-to-back from
    // the exact same click-handler code path (HTMLDivElement.<anonymous>,
    // the track row's own listener), both with startAtSeconds=undefined —
    // consistent with a single physical tap somehow producing two click
    // events, not two deliberate taps. Rather than track down that
    // underlying event-duplication mechanism blind, this guards against its
    // actual effect directly: a genuinely identical re-invocation (same
    // track, same "just clicked, no explicit position" shape) landing
    // within an implausibly short window of the last one is treated as a
    // duplicate and ignored. Deliberately narrow — undefined startAtSeconds
    // only, not any same-id call — so a real repeat-one restart (which
    // legitimately reuses the same id) or a deliberate quick re-click are
    // never blocked by this, only an all-but-simultaneous duplicate is.
    const now = Date.now();
    if (id === lastPlayTrackNativeId && startAtSeconds === undefined && (now - lastPlayTrackNativeMs) < 800) {
      nativeDebugLog(`Ignoring duplicate playTrackNative call for the same track within 800ms (${now - lastPlayTrackNativeMs}ms since the last one)`);
      return;
    }
    // Real, direct fix for a confirmed feedback loop found directly in a
    // device log: nativeResume kept re-firing at the exact same position,
    // called each time through window.__novaTransport — i.e. the media-
    // session transport path (lock screen / a connected device), not a
    // direct button tap. The likely mechanism: every successful fetch
    // reports the SAME static position to the media session (real audio
    // hadn't started yet — see nativeClockRunning's own reasoning), which
    // a connected device can reasonably read as "still stuck," and
    // reissues its own play command to nudge it — which lands right back
    // here, restarts the same fetch, reports the same static position
    // again, and repeats. The original duplicate-guard above only ever
    // covered a bare re-click (startAtSeconds === undefined) — resume
    // always passes an explicit position, so it never caught this. Same
    // principle, widened: a same-track call landing within 800ms of the
    // last one, at essentially the same position (a tenth of a second of
    // slop for floating-point drift), is treated as the same duplicate
    // regardless of whether that position is undefined or an explicit
    // number.
    const startAtSecondsMatches = startAtSeconds === lastPlayTrackNativeStartAtSeconds
      || (typeof startAtSeconds === 'number' && typeof lastPlayTrackNativeStartAtSeconds === 'number' && Math.abs(startAtSeconds - lastPlayTrackNativeStartAtSeconds) < 0.1);
    if (id === lastPlayTrackNativeId && startAtSecondsMatches && (now - lastPlayTrackNativeMs) < 800) {
      nativeDebugLog(`Ignoring duplicate playTrackNative call for the same track+position within 800ms (${now - lastPlayTrackNativeMs}ms since the last one)`);
      return;
    }
    lastPlayTrackNativeId = id;
    lastPlayTrackNativeMs = now;
    lastPlayTrackNativeStartAtSeconds = startAtSeconds;
    nativeGenerationToken++;
    const myToken = nativeGenerationToken;
    // The other half of the "pause not forcing itself through" fix — the
    // exact same problem applies to a new seek/resume/track-start arriving
    // while a PREVIOUS generation's fetch is still in-flight: that stale
    // fetch's own generation check is already correct and would already
    // abandon it, but only once its await naturally returns, which could
    // be seconds away on a slow or timing-out connection. Rejecting
    // whatever's still pending here means a new seek interrupts a stale
    // one immediately instead of both waiting on the same slow network
    // call to finish on its own first.
    nativeFetchResolvers.forEach(r => r.reject(new Error('Superseded by a newer playTrackNative call')));
    nativeFetchResolvers.clear();
    // Real, direct fix for "still took the same amount of time" — traced to
    // an actual reason in a device log: a seek within the SAME track was
    // resetting the known duration to 0 every time, even though the track
    // itself (and therefore its real duration) hadn't changed. That meant
    // the prefetch-trigger check couldn't fire until THIS seek's own first
    // fetch succeeded — which, on the connection this session has
    // repeatedly shown struggling, could itself take several retries and a
    // real amount of time, eating directly into the prefetch's available
    // lead time before it even started. Preserving the duration across a
    // same-track seek/resume lets the prefetch trigger fire immediately,
    // running concurrently with this seek's own fetch retries instead of
    // only after they finish.
    const isSameTrackAsBefore = (nativeCurrentTrackId === id);
    const preservedKnownDuration = isSameTrackAsBefore ? (window.__nativeKnownDuration || 0) : 0;
    nativeCurrentTrackId = id;
    nativePaused = false;
    isPlaying = true;
    // Sets the correct target position immediately (so pausing again before
    // any audio ever starts still resumes from the right place), but does
    // NOT start the wall-clock formula — that's deferred to
    // window.__novaTrackAudioStarted, fired only once real audio actually
    // begins. See nativeClockRunning's own comment for the full reasoning.
    playOffset = startAtSeconds || 0;
    nativeClockRunning = false;
    // Real, direct bug found from a reported "button doesn't update" complaint:
    // nativePause calls this, but nothing in the start/resume path ever did —
    // isPlaying flipping to true never actually reflected in the play/pause
    // icon, or anything else this function drives, until the NEXT pause.
    updateTransportUI();
    // The actual fix for "probably does the same with other UI elements" —
    // tickProgress is what drives the seek bar, time display, rebuffer
    // checks, and scrobbling, and it was NEVER called anywhere in native
    // mode at all — only the Web-Audio path's own startFrom() ever starts
    // it. Every one of those was silently inert in native mode until now.
    tickProgress();
    // Reset here, before setNowPlaying runs — without this, a brand-new
    // track would briefly report the PREVIOUS track's duration to the lock
    // screen (this is a plain global, it doesn't clear itself between
    // tracks), until the new track's own first-segment headers arrive.
    // Preserved instead of zeroed for a same-track seek — see
    // preservedKnownDuration's own comment above for why.
    window.__nativeKnownDuration = preservedKnownDuration;
    // Real, direct fix for "should say seeking or buffering... instead it
    // says ready" — matches the exact status text patterns the Web-Audio
    // path already uses (waitForDecodeAndPlay: 'Buffering…' for a fresh
    // start, 'Catching up to your seek position…' for a seek/resume to a
    // specific position) rather than a native-mode-only 'Ready' that never
    // reflected what was actually happening. Cleared to 'Playing' once
    // __novaTrackAudioStarted fires — see that function's own update.
    setNowPlaying(track, (startAtSeconds && startAtSeconds > 0) ? 'Catching up to your seek position…' : 'Buffering…');
    // Real, additional gap found while fixing the button click handler: the
    // button starts disabled in the HTML, and nothing in this function ever
    // enabled it — meaning even a correct click handler would never have
    // received a click at all, since a disabled button doesn't fire click
    // events in the first place.
    $('playPauseBtn').disabled = false;
    renderQueue();
    saveStateToServer(true);
    maybeSendNowPlaying(track);
    nativeDebugLog('past setup, about to send start message');

    window.NovaNative.postMessage(JSON.stringify({ type: 'start', generation: nativeGenerationToken, gaplessContinuation: !!isGaplessContinuation }));
    nativeDebugLog('start message sent, entering fetch loop');

    // Quality deliberately NOT auto-selected here — see README's own note on
    // this: the Web-Audio path's adaptive, measured-throughput logic
    // (maybeAdjustAutoQualityTier) isn't reimplemented for native mode in
    // this pass. Real bug caught before shipping: this originally referenced
    // a variable (currentAutoQuality) that doesn't exist anywhere in this
    // file — qualityMode is the actual one, set from the same Settings
    // dropdown. When it's 'auto' (meaning "let the adaptive system decide"),
    // there is no adaptive system running here to decide, so this falls back
    // to 'reduced' specifically rather than passing 'auto' straight to the
    // server (which expects one of full/reduced/minimal/ultra — sending
    // 'auto' literally would silently fall through to full quality server-
    // side, the least safe default for a connection that selected auto
    // specifically because it might not handle full quality well).
    const quality = effectiveQuality();
    // Reverted back to the original, PROVEN 60s-bounded-segment design —
    // real, direct honesty about this: an attempt to fix buffering by
    // switching to one continuous unbounded fetch (streaming the rest of the
    // track in a single request) was shipped without being able to test it
    // myself, and a direct report came back that playback stopped working
    // entirely afterward ("Ready" shown, nothing ever plays) — a regression
    // from "plays with crackling/buffering issues" to "doesn't play at all".
    // Rather than guess again at what specifically broke in that rewrite,
    // this reverts to the bounded-segment version that was already
    // confirmed, by direct report, to actually produce audio. The buffering
    // problem that rewrite was trying to solve is still real and still
    // unsolved — but a worse regression is not an acceptable trade for
    // attempting to fix a lesser one, especially not a second time in a row
    // without being able to verify the fix first.
    const SEGMENT_DURATION_SECONDS = 60;
    const MAX_SEGMENT_RETRIES = 5;

    // Real, direct bug found from a reported "pause/resume restarts the
    // song" complaint — confirmed by tracing the actual math, not just
    // guessed at again: this used to round DOWN to the nearest 60s boundary
    // before ever making the request. Resuming from, say, 14.119s rounded
    // to 0 — meaning the ACTUAL AUDIO requested and played was the very
    // start of the track, while the on-screen timer (driven by a separate
    // variable, playOffset, which correctly held 14.119) kept counting up
    // from there regardless. The timer looked right; the audio being heard
    // was wrong — exactly what "restarts the song" describes, since what's
    // actually audible really did restart even though the number on screen
    // didn't. The server itself never required 60s-aligned positions (its
    // skipToSeconds accepts any value) — this rounding was purely a client-
    // side artifact of how the segment-advance loop computes its own next
    // position, and it was wrongly applied to the FIRST fetch too, not just
    // subsequent ones. Fixed by using the exact requested position for that
    // first fetch; only fetches after that (genuinely sequential, advancing
    // through the track from wherever this first one actually started) step
    // by SEGMENT_DURATION_SECONDS.
    let segmentStartSeconds = startAtSeconds || 0;
    let isFirstFetchOfTrack = true;
    // Seeded from the preserved value (see isSameTrackAsBefore's own
    // comment above) when this is a seek/resume within the same track —
    // lets the prefetch trigger below fire on the very first loop
    // iteration, before this seek's own fetch has even been attempted, let
    // alone succeeded.
    let knownTotalSeconds = preservedKnownDuration > 0 ? preservedKnownDuration : null;
    let hasPrefetchedNext = false; // guards against triggering the prefetch more than once per track

    // The other half of the prefetch fix — tries to consume an
    // already-downloaded segment before the main loop below ever makes a
    // network request for this track's first segment. Only attempted for a
    // genuine gapless continuation (a natural end-of-track transition,
    // where a prefetch would have had a real chance to run ahead of time);
    // a hard track switch has no such lead time and goes straight to the
    // normal fetch path. If no prefetch is ready, this changes nothing —
    // the loop below proceeds exactly as it always did, starting from
    // segmentStartSeconds=0.
    if (isGaplessContinuation && window.NovaNative) {
      try {
        const headers = await nativeConsumePrefetch(id);
        nativeDebugLog(`consumePrefetch resolved successfully: ${JSON.stringify(headers)}`);
        if (headers.sampleRate && headers.totalFrames) {
          knownTotalSeconds = Number(headers.totalFrames) / Number(headers.sampleRate);
          window.__nativeKnownDuration = knownTotalSeconds;
          $('timeTotal').textContent = fmtTime(knownTotalSeconds);
          nativeUpdateNowPlaying(track, true, knownTotalSeconds, 0);
        }
        isFirstFetchOfTrack = false;
        segmentStartSeconds = PREFETCH_DURATION_SECONDS; // the prefetch covered [0, PREFETCH_DURATION_SECONDS) — the loop below picks up from here
        if (knownTotalSeconds !== null && segmentStartSeconds >= knownTotalSeconds) {
          // Edge case: a track short enough that the single prefetched
          // segment already covers the whole thing — advance immediately
          // rather than let the loop below make a pointless follow-up
          // request for content past the end of the file. Also waits for
          // this same track's genuine drain signal (see the native
          // consumePrefetch handler's own computation of this) before
          // starting the one after it — same principle as the main loop's
          // "reached end" handling, just for this rarer, single-segment
          // case.
          await waitForNativeTrackEnd();
          if (nativeGenerationToken === myToken) { if (repeatMode === 'one') { playTrackNative(id, track, 0, true); } else { playNextInQueue(true); } }
          return;
        }
      } catch (err) {
        nativeDebugLog(`consumePrefetch unavailable, falling back to a normal fetch: ${err.message}`);
      }
    }

    nativeDebugLog(`about to check loop condition: nativeGenerationToken=${nativeGenerationToken}, myToken=${myToken}, nativePaused=${nativePaused}`);
    while (nativeGenerationToken === myToken && !nativePaused) {
      nativeDebugLog(`loop iteration: segmentStartSeconds=${segmentStartSeconds}, quality=${quality}`);
      // Early trigger, using a preserved same-track duration if available —
      // see preservedKnownDuration's own comment for why this matters: it
      // lets the prefetch start running CONCURRENTLY with this iteration's
      // own fetch attempt (retries included), rather than only after that
      // fetch finally succeeds. The check inside the retry loop below
      // remains as the fallback for when duration isn't already known here
      // (a genuinely fresh track, or a hard track switch).
      if (!hasPrefetchedNext && knownTotalSeconds !== null && (segmentStartSeconds + SEGMENT_DURATION_SECONDS) >= knownTotalSeconds && repeatMode !== 'one') {
        hasPrefetchedNext = true;
        const nextIdx = queuePos + 1 < queue.length ? queuePos + 1 : (repeatMode === 'all' && queue.length > 0 ? 0 : -1);
        const nextTrack = nextIdx >= 0 ? trackById(queue[nextIdx]) : null;
        if (nextTrack) nativePrefetchNext(nextTrack);
      }
      const url = new URL('/api/stream/pcm?path=' + encodeURIComponent(track.localPath) + '&quality=' + quality + '&skipToSeconds=' + segmentStartSeconds + '&maxDurationSeconds=' + SEGMENT_DURATION_SECONDS, window.location.href).href;
      let succeeded = false;
      let wasLastSegmentOfTrack = false; // set inside the try block below — read after the retry loop to decide whether to actually wait for real playback to finish before transitioning
      for (let attempt = 0; attempt < MAX_SEGMENT_RETRIES && nativeGenerationToken === myToken && !nativePaused; attempt++) {
        try {
          const isLastSegmentOfTrack = knownTotalSeconds !== null && (segmentStartSeconds + SEGMENT_DURATION_SECONDS) >= knownTotalSeconds;
          wasLastSegmentOfTrack = isLastSegmentOfTrack;
          const headers = await nativeFetchSegment(url, 44100, 2, isFirstFetchOfTrack, attempt > 0, isLastSegmentOfTrack);
          nativeDebugLog(`fetch resolved successfully: ${JSON.stringify(headers)}`);
          if (headers.sampleRate && headers.totalFrames) {
            knownTotalSeconds = Number(headers.totalFrames) / Number(headers.sampleRate);
            window.__nativeKnownDuration = knownTotalSeconds; // read by setNowPlaying's own native-mode branch as a fallback when currentBuffer (Web-Audio-only) doesn't exist
            $('timeTotal').textContent = fmtTime(knownTotalSeconds);
            nativeUpdateNowPlaying(track, true, knownTotalSeconds, segmentStartSeconds);
            // Real bug found and fixed here: this used to be checked at the
            // TOP of the loop, before each iteration's own fetch, using
            // whatever duration a PREVIOUS iteration had already
            // established. That silently never fired for a track where the
            // very first fetch already turns out to be the only one needed
            // (exactly what happens seeking near the end of a track, as a
            // direct report showed) — there's no "next iteration" for that
            // check to ever run in that case. Checked immediately here
            // instead, the moment this fetch's own duration becomes known,
            // regardless of whether this is iteration one or ten — this is
            // what actually guarantees the prefetch gets a chance to run
            // while whatever was just enqueued is still being played,
            // rather than depending on the loop happening to continue.
            if (!hasPrefetchedNext && (segmentStartSeconds + SEGMENT_DURATION_SECONDS) >= knownTotalSeconds && repeatMode !== 'one') {
              hasPrefetchedNext = true;
              const nextIdx = queuePos + 1 < queue.length ? queuePos + 1 : (repeatMode === 'all' && queue.length > 0 ? 0 : -1);
              const nextTrack = nextIdx >= 0 ? trackById(queue[nextIdx]) : null;
              if (nextTrack) nativePrefetchNext(nextTrack);
            }
          }
          succeeded = true;
          isFirstFetchOfTrack = false;
          break;
        } catch (err) {
          nativeDebugLog(`fetch REJECTED: ${err.message}`);
          bufferClientError('warn', `Native segment fetch failed at ${segmentStartSeconds.toFixed(1)}s (attempt ${attempt + 1}/${MAX_SEGMENT_RETRIES}): ${err.message}`);
          if (!nativePaused && nativeGenerationToken === myToken) await new Promise(r => setTimeout(r, Math.min(8000, 500 * Math.pow(2, attempt))));
        }
      }
      if (nativeGenerationToken !== myToken || nativePaused) return;
      if (!succeeded) {
        // Every retry exhausted for this segment — same fallback already
        // applied on the Web-Audio path for the equivalent permanent-failure
        // case: move on to whatever's next in the queue rather than leaving
        // playback stuck forever on one unreachable segment.
        playNextInQueue();
        return;
      }
      segmentStartSeconds += SEGMENT_DURATION_SECONDS;
      nativeSetPlayOffset(segmentStartSeconds); // resyncs the wall-clock basis to this fresh, accurate position — corrects any drift from a slow or retried fetch, rather than letting it accumulate
      if (knownTotalSeconds !== null && segmentStartSeconds >= knownTotalSeconds) {
        // Reached the end of this track's actual duration — advance the
        // queue, the same transition point onTrackEnded handles on the
        // Web-Audio path. Marked gapless=true specifically here: this fetch
        // loop has already returned cleanly (it's not being interrupted or
        // superseded by anything), so there's no stale in-flight data for
        // the next track to worry about — the one case where skipping the
        // AudioTrack flush is actually safe, and the only place this flag
        // should ever be passed as true.
        //
        // Real, adjacent gap found and fixed here too: onTrackEnded (the
        // Web-Audio path's own end-of-track handler) checks repeatMode ===
        // 'one' before ever reaching playNextInQueue — this native handler
        // never called onTrackEnded at all, so repeat-one was silently
        // never honored in native mode; it always just advanced to the
        // next track regardless of the setting.
        //
        // The actual fix for "gapless but wait until the song before it is
        // done": all of this used to fire the instant the fetch above
        // resolved — meaning the moment the data merely finished
        // downloading, regardless of how much of it (seconds of buffered-
        // ahead audio) hadn't been played yet. Now, when this segment was
        // itself marked as the track's last one, this waits for native
        // code's own confirmation that the actual last chunk has been
        // fully written out before starting the next track at all — the
        // real moment this track's audio is done, not an approximation of
        // it. The next track's data can still (and does) finish loading in
        // the background well before this resolves — only the moment its
        // audio is allowed to actually start playing is gated here.
        if (wasLastSegmentOfTrack) await waitForNativeTrackEnd();
        if (nativeGenerationToken === myToken) {
          if (repeatMode === 'one') playTrackNative(id, track, 0, true);
          else playNextInQueue(true);
        }
        return;
      }
    }
  }

  async function playTrack(id, addQueueContext, startAtSeconds, forceQualityOverride, connectionRetryCount, isGaplessContinuation) {
    const track = trackById(id);
    if (!track) return;
    // Explicit "done with this track" signal to the server's PCM cache — see
    // its own comment in routes/stream.js for why this is the PRIMARY deletion
    // path, not just a nice-to-have (the server's TTL sweep is the safety net
    // for when this never arrives, not the intended everyday mechanism).
    // Captured before anything below reassigns queue/queuePos, and only fired
    // when the outgoing track is actually DIFFERENT from what's starting now —
    // repeat-one calls playTrack with the SAME id, where releasing would be
    // actively counterproductive (deleting the cache moments before needing it
    // again). Best-effort: a failed release call here just means the TTL sweep
    // catches it later instead, never something worth surfacing to the user.
    {
      const outgoingId = queue[queuePos];
      if (outgoingId && outgoingId !== id) {
        const outgoingTrack = trackById(outgoingId);
        if (outgoingTrack) {
          fetch('/api/stream/pcm/release', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ path: outgoingTrack.localPath }), credentials: 'include' }).catch(() => {});
        }
      }
    }
    if (addQueueContext) { queue = addQueueContext; queuePos = queue.indexOf(id); }
    // Native-app mode: when running inside the Android wrapper (see
    // nova-android/), window.NovaNative exists (injected by
    // WebViewCompat.addWebMessageListener) and actual audio playback is
    // handled entirely natively via AudioTrack — see NativeAudioEngine.kt for
    // why. This branch hands off to a separate, much simpler function rather
    // than threading native-mode checks through the entire Web-Audio-specific
    // logic below, which stays completely untouched for every browser user.
    if (window.NovaNative) {
      // The actual architecture fix's entry point — a genuinely fresh
      // track start (not a gapless continuation, not a resume/seek of a
      // track already playing) uses the new buffered path: download once,
      // seek freely within it afterward. Gapless continuations deliberately
      // keep using the existing, already-working queue path — see
      // nativeStartBufferedTrack's own comment for why rewriting both at
      // once wasn't worth the risk.
      if (!isGaplessContinuation && startAtSeconds === undefined) { nativeStartBufferedTrack(id, track, startAtSeconds); return; }
      playTrackNative(id, track, startAtSeconds, isGaplessContinuation);
      return;
    }
    if (restoredPendingTrackId && id !== restoredPendingTrackId) restoredPendingTrackId = null; // picked something else — the deferred restore no longer applies
    stopSource(); isPlaying = false; currentBuffer = null;
    seekWaitToken++;
    // Invalidates any still-running decode of whatever was playing before THIS track
    // switch — decodeStreamingInWorker-equivalent PCM fetches have no abort mechanism
    // either, so an abandoned fetch's chunk loop would otherwise keep running in the
    // background and keep overwriting the shared decodedUpToSample with its own,
    // unrelated progress. See the NextCloud-backed player's fix for the full story —
    // same bug, same fix, applied here from the start rather than discovered later.
    decodeGenerationToken++;
    const myGenerationToken = decodeGenerationToken; // captured now — see guards below for why every UI-affecting callback in this function needs to check against it
    resetLastfmStateForNewTrack();
    saveStateToServer(true);
    const startAt = startAtSeconds || 0;
    $('playPauseBtn').disabled = true;

    // Bounded fast-start path: only ever checks the single next-track prefetch
    // slot (never a general cache) — see prefetchNext's own comment for why
    // this exists and how it stays bounded to one track. Cleared immediately
    // once consumed, so it can never be reused stale for a later, different
    // play of the same track.
    if (nextTrackPrefetch && nextTrackPrefetch.id === id) {
      const prefetched = nextTrackPrefetch;
      nextTrackPrefetch = null;
      // No artificial timeout here anymore — see fetchSegment's own comment
      // (in getDecodedBufferFromServerPCM) for the actual fix: the reason
      // this could ever hang forever was a real bug there (a superseded
      // fetch settling neither resolve nor reject), not something that
      // needed compensating for out here with a timer. Two different, wrong
      // timeout values (15s, then 90s) were each their own real regression —
      // one cut off genuine progress and forced expensive full restarts, the
      // other meant waiting up to 90s before falling back on an actually-
      // stuck case. Neither was ever the right fix; a promise that reliably
      // settles on its own needs no race against a guessed number at all.
      const fullBuffer = await prefetched.promise.catch(() => null);
      if (fullBuffer && myGenerationToken === decodeGenerationToken) {
        currentBuffer = fullBuffer;
        decodedUpToSample = currentBuffer.length; // fully decoded already — see the token comment above for why this must be set explicitly, not inherited from a stale prior decode
        $('playPauseBtn').disabled = false;
        setNowPlaying(track, 'Ready');
        updateQualityBadge(currentBuffer);
        $('timeTotal').textContent = fmtTime(currentBuffer.duration);
        applyLoudnessTrim(); // fixed trim now — no per-buffer analysis needed, see the function's own comment
        startFrom(startAt);
        saveStateToServer(true); // isPlaying just flipped true — worth an immediate save rather than waiting for the throttled periodic one, so other devices see accurate status promptly
        maybeSendNowPlaying(track);
        renderQueue();
        prefetchNext();
        return;
      }
      // Prefetch failed or got superseded by a newer track switch while it was
      // in flight — falls through to the normal streaming fetch below exactly
      // as if there had been no prefetch at all.
    }

    setNowPlaying(track, 'Starting…');
    const t0 = performance.now();
    // Forces the lowest quality tier on any retry, bypassing the normal
    // "learned" tier decision — see the forceQuality comment in
    // getDecodedBufferFromServerPCM for the full reasoning. A retry happening
    // at all means the previous attempt already failed, often at a resume
    // position needing even more buffer than the original — repeating the
    // same tier is repeating the same losing bet.
    //
    // Explicit forceQualityOverride, not an overloaded retry counter — real,
    // confirmed bug found directly from a production log: a single "retryCount"
    // used for both bounding retries AND deciding whether to force quality down
    // meant a connection-error retry (below) always forced 'ultra' too, even
    // though a transient server error (an HTTP 502, unrelated to bandwidth) is
    // not a throughput signal at all. Callers now say explicitly what quality
    // (if any) they want forced — only the genuine stall-detection retry in
    // waitForDecodeAndPlay passes 'ultra', since that one actually does mean "no
    // data arrived for 15 real seconds."
    const forceQuality = forceQualityOverride;
    try {
      const fullBuffer = await getDecodedBufferFromServerPCM(track, startAt, (partialBuffer) => {
        // Guarded: getDecodedBufferFromServerPCM has no abort mechanism (see the
        // decodeGenerationToken comment above), so this callback can still fire for a
        // track the person has already switched away from — the fetch/decode itself
        // keeps running in the background regardless of what playTrack() has moved on
        // to since. Confirmed as a real bug, not just theoretical: without this guard,
        // a stale callback could both revert the now-playing display back to the old
        // track's info AND, worse, actually call startFrom() and overwrite
        // currentBuffer with the old track's buffer — restarting the wrong audio out
        // from under whatever the person actually selected next.
        if (myGenerationToken !== decodeGenerationToken) return;
        currentBuffer = partialBuffer;
        $('playPauseBtn').disabled = false;
        const startedIn = ((performance.now() - t0) / 1000).toFixed(1);
        setNowPlaying(track, `Playing — buffering rest (started in ${startedIn}s)`);
        updateQualityBadge(partialBuffer);
        $('timeTotal').textContent = fmtTime(partialBuffer.duration);
        applyLoudnessTrim(); // fixed trim now — no per-buffer analysis needed, see the function's own comment
        startFrom(startAt);
        saveStateToServer(true); // see the cached-path comment above — same reasoning
        maybeSendNowPlaying(track);
        renderQueue();
        // Real, direct bug found from a reported "next track doesn't start
        // seamlessly" complaint: prefetchNext() used to only fire after
        // `await getDecodedBufferFromServerPCM(...)` fully resolved below —
        // which, with the segmented-fetch architecture, doesn't happen until
        // EVERY segment up to the end of the CURRENT track has arrived. That
        // can take nearly the entire length of the track, leaving prefetch for
        // the NEXT one starting far too late to ever finish downloading before
        // it's actually needed — defeating the entire point of prefetching in
        // the background while the current track plays.
        //
        // Real, direct regression from the FIRST attempt at this fix, confirmed
        // directly from a production log: firing prefetchNext() immediately here
        // meant the CURRENT track's own ongoing segment fetches were now running
        // CONCURRENTLY with the prefetch's segment fetches for the entire
        // remaining runtime — two separate segment fetches for the same 60.0s
        // boundary, 6 milliseconds apart, confirmed the collision directly. On a
        // connection that already drops frequently (well-established throughout
        // this whole session), that sustained contention between the track
        // actually playing and a background download is very likely what showed
        // up as repeated pause/resume cycles. Delaying prefetch start gives the
        // current track's own critical, playback-blocking fetch a real head
        // start through its most vulnerable early stretch, while still starting
        // well before all but the shortest tracks would end.
        const prefetchDelayMs = 45000;
        setTimeout(() => { if (myGenerationToken === decodeGenerationToken) prefetchNext(); }, prefetchDelayMs);
      }, forceQuality);
      if (myGenerationToken === decodeGenerationToken) {
        setNowPlaying(track, 'Ready');
        // No second applyLoudnessTrim() call needed here — unlike the old per-buffer
        // analysis this replaced, the trim is a fixed value that doesn't change once
        // set at playback start.
      }
    } catch (err) {
      if (myGenerationToken === decodeGenerationToken) {
        // Real, confirmed bug found directly from a production log: this retry
        // used to only fire for an error message ('Stream ended prematurely')
        // that no longer exists since the segmented-fetch rewrite — "ended before
        // the whole track" is now the NORMAL case there, not an error. The only
        // error a segmented fetch can still reject with is a genuine, exhausted
        // segment failure (e.g. a transient HTTP 502 from the server/proxy,
        // nothing to do with the connection's actual bandwidth) — and since that
        // message never matched the old check, this retry was dead code: a
        // failure just showed an error and stopped, silently relying on the
        // separate, much slower (15+ second) stall-detection path in
        // checkForRebuffer to eventually notice and recover — and that path
        // forces the lowest quality tier, appropriate for an actual bandwidth
        // stall but not for a one-off server error. Retrying here immediately,
        // WITHOUT forcing quality down, fixes both: faster recovery, and no
        // longer misdiagnosing an infrastructure hiccup as a bandwidth problem.
        // Bounded to one retry so a persistently broken connection still
        // surfaces a real error rather than looping forever.
        // Real bug, confirmed directly from a production log and stack trace: this
        // retry restarted the ENTIRE track from `startAt` — the position playTrack
        // was originally called with — rather than wherever playback had actually
        // reached by the time a segment deep into the track failed. That code path
        // existed before too but was dead (gated on an error message that no
        // longer occurs), so the bug was latent until the fix that made this retry
        // actually fire — this retry itself is what caused the reported restart.
        // Must resume from the real current position, not the original call's.
        const resumeFrom = currentTimeSec();
        // Raised from 1 to 2 — consistent with the segment-level retry increase
        // above, for the same reason: a genuinely flaky connection deserves more
        // than one more chance at this outer level too, now that it's reached
        // here at all (meaning the segment-level backoff already spent ~15s
        // trying and still didn't recover).
        if ((connectionRetryCount || 0) < 2) {
          setNowPlaying(track, 'Connection dropped, retrying…');
          setTimeout(() => { if (myGenerationToken === decodeGenerationToken) playTrack(id, null, resumeFrom, forceQualityOverride, (connectionRetryCount || 0) + 1); }, 1500 * ((connectionRetryCount || 0) + 1));
          return;
        }
        setNowPlaying(track, 'Error: ' + err.message);
        $('playPauseBtn').disabled = false;
        // Real, direct bug found from a reported "next track doesn't play"
        // complaint: this used to just stop here — show the error, re-enable
        // the button, and do nothing else. A track that permanently fails
        // (every segment retry AND both connection-level retries exhausted —
        // genuinely possible on a connection flaky enough, which this whole
        // session has established this one can be) left the queue stuck
        // forever: onTrackEnded only ever fires when a track reaches its
        // natural end, which a permanently-failed track never does, so
        // nothing ever advanced to whatever was queued next.
        //
        // Real regression THIS fix caused, reported directly: this rejection
        // fires when the DOWNLOAD promise for the whole track fails — which
        // isn't the same thing as playback having failed. If the track had
        // already been playing fine for a while and was genuinely approaching
        // its natural end when one LATE segment exhausted its retries, this
        // used to force a skip via playNextInQueue() at the same moment the
        // track's own real onended event was about to fire naturally too —
        // a double-advance that skipped straight past whatever the prefetch
        // had specifically prepared for queuePos+1, landing on the track
        // after it instead. That's exactly what broke the seamless
        // transition. Only forces a skip now when playback genuinely never
        // got going at all (isPlaying still false here) — the original bug
        // this was meant to fix. If the track WAS actively playing, this
        // leaves queue advancement to the real completion/stall paths
        // (onTrackEnded, checkForRebuffer) that are already the actual
        // authority on whether playback is still alive, rather than a
        // download-promise rejection racing against them.
        if (!isPlaying) playNextInQueue();
      }
    }
  }
  function updateQualityBadge(buffer) {
    const badge = $('npQualityBadge');
    if (buffer.qualityTier && buffer.qualityTier !== 'full') {
      badge.textContent = buffer.qualityTier.toUpperCase();
      badge.classList.add('visible');
    } else {
      badge.classList.remove('visible');
    }
  }

  // ---------- Cross-device state sync ----------
  // A restored track is shown but NOT loaded — playTrack() opens a real server-side
  // decode stream immediately, and pausing playback right after doesn't stop that
  // stream: the fetch/decode loop in getDecodedBufferFromServerPCM keeps running to
  // completion regardless of playback state, since pausing only stops the audio
  // graph, not the network read loop feeding it. Calling playTrack() on every login
  // (to then immediately pause) was silently opening a full decode on the server on
  // every single page load — confirmed as the cause of unexplained server load and
  // audio starting for a moment on load. The actual decode only starts now when the
  // person deliberately presses play on a restored track.
  let restoredPendingTrackId = null, restoredPendingPositionSeconds = 0;
  function showRestoredNowPlaying(track, positionSeconds) {
    restoredPendingTrackId = track.id;
    restoredPendingPositionSeconds = positionSeconds;
    setNowPlaying(track, 'Paused — press play to resume');
    updateQualityBadge({});
    $('timeCurrent').textContent = fmtTime(positionSeconds);
    $('timeTotal').textContent = ''; // genuinely unknown until decode actually starts — nothing to compute this from without decoding
    $('seekBar').value = 0; // no known duration yet to compute a proportional position from
    $('playPauseBtn').disabled = false;
    $('playPauseBtn').textContent = '▶';
    if (!track.metaLoaded) {
      loadTagsFor([track]);
      // loadTagsFor updates the track object and the library ROW display once done, but
      // this track may not even be in the currently-visible library listing — refresh
      // the now-playing text specifically once its real tags are in, rather than leaving
      // the raw filename showing until the person picks something else.
      const checkTags = setInterval(() => {
        if (track.metaLoaded) {
          clearInterval(checkTags);
          if (restoredPendingTrackId === track.id) setNowPlaying(track, 'Paused — press play to resume');
        }
      }, 200);
    }
  }

  let lastStateSaveMs = 0;
  const STATE_SAVE_MIN_INTERVAL_MS = 15000;
  async function saveStateToServer(force) {
    const now = Date.now();
    if (!force && now - lastStateSaveMs < STATE_SAVE_MIN_INTERVAL_MS) return;
    lastStateSaveMs = now;
    try {
      await apiPostJson('/api/state', {
        trackId: queue[queuePos] || null,
        positionSeconds: currentBuffer ? currentTimeSec() : 0,
        queue, queuePos, repeatMode, shuffleEnabled, sourceMode: 'local',
        isPlaying,
      });
    } catch (e) { console.warn('[state] save failed:', e.message); }
  }
  let stateRestoredThisSession = false;
  async function restoreStateFromServer() {
    if (stateRestoredThisSession) return;
    stateRestoredThisSession = true;
    let state;
    try { state = await api('/api/state'); } catch (e) { return; }
    if (!state || !Array.isArray(state.queue) || !state.queue.length) return;
    // Every queued track needs to resolve against the full library, not just whatever
    // directory happens to be showing right now.
    await ensureFlatLibraryCache();
    const resolvedQueue = state.queue.filter(id => trackById(id));
    if (!resolvedQueue.length || !trackById(state.trackId)) return;
    queue = resolvedQueue;
    queuePos = Math.max(0, Math.min(resolvedQueue.length - 1, resolvedQueue.indexOf(state.trackId)));
    repeatMode = ['off', 'all', 'one'].includes(state.repeatMode) ? state.repeatMode : 'off';
    shuffleEnabled = !!state.shuffleEnabled;
    updateShuffleRepeatUI();
    renderQueue();
    showRestoredNowPlaying(trackById(state.trackId), state.positionSeconds || 0);
  }

  // ---------- Last.fm ----------
  let lastfmStatus = { configured: false, linked: false, username: null, scrobbleEnabled: true };
  let nowPlayingSentForCurrentTrack = false, scrobbledForCurrentTrack = false;
  function resetLastfmStateForNewTrack() { nowPlayingSentForCurrentTrack = false; scrobbledForCurrentTrack = false; }
  function lastfmEligible() { return lastfmStatus.linked && lastfmStatus.scrobbleEnabled; }
  async function maybeSendNowPlaying(track) {
    if (nowPlayingSentForCurrentTrack || !lastfmEligible()) return;
    nowPlayingSentForCurrentTrack = true;
    try {
      await apiPostJson('/api/lastfm/now-playing', {
        artist: track.tags.artist || '', track: track.tags.title || track.name, album: track.tags.album || '',
        duration: currentBuffer ? currentBuffer.duration : undefined,
      });
    } catch (e) { console.warn('[lastfm] now-playing failed:', e.message); }
  }
  async function maybeScrobble(track) {
    // Real gap fixed here too — same currentBuffer (Web-Audio-only) issue as
    // the seek bar, silently meaning scrobbling never worked in native mode.
    const duration = currentBuffer ? currentBuffer.duration : (window.__nativeKnownDuration || 0);
    if (scrobbledForCurrentTrack || !lastfmEligible() || !duration) return;
    const playedSeconds = currentTimeSec();
    // Mirrors the server's own qualifiesForScrobble exactly (see
    // lib/lastfm.js) — this client-side check is just to avoid firing a
    // request that the server would reject anyway; the server re-validates
    // independently regardless; this is not the actual enforcement.
    const pct = (typeof lastfmStatus.scrobbleThresholdPercent === 'number' && lastfmStatus.scrobbleThresholdPercent > 0) ? lastfmStatus.scrobbleThresholdPercent : 50;
    const requiredSeconds = pct === 50 ? Math.min(duration / 2, 240) : duration * (pct / 100);
    if (duration <= 30 || playedSeconds < requiredSeconds) return;
    scrobbledForCurrentTrack = true;
    try {
      await apiPostJson('/api/lastfm/scrobble', {
        artist: track.tags.artist || '', track: track.tags.title || track.name, album: track.tags.album || '', duration, playedSeconds,
      });
    } catch (e) { console.warn('[lastfm] scrobble failed:', e.message); scrobbledForCurrentTrack = false; }
  }
  async function refreshLastfmStatus() {
    try { lastfmStatus = await api('/api/lastfm/status'); } catch (e) { lastfmStatus = { configured: false, linked: false, username: null, scrobbleEnabled: true, scrobbleThresholdPercent: 50 }; }
    updateLastfmUI();
  }
  function updateLastfmUI() {
    $('lastfmNeedsCreds').classList.toggle('hidden', lastfmStatus.configured);
    $('lastfmNeedsLink').classList.toggle('hidden', !(lastfmStatus.configured && !lastfmStatus.linked));
    $('lastfmLinked').classList.toggle('hidden', !lastfmStatus.linked);
    if (lastfmStatus.linked) {
      $('lastfmUsernameDisplay').textContent = lastfmStatus.username;
      $('lastfmScrobbleToggle').checked = !!lastfmStatus.scrobbleEnabled;
      $('lastfmScrobbleThreshold').value = lastfmStatus.scrobbleThresholdPercent || 50;
      $('lastfmScrobbleThresholdLabel').textContent = (lastfmStatus.scrobbleThresholdPercent || 50) + '%';
    }
  }
  function showLastfmError(msg) { $('lastfmError').textContent = msg; $('lastfmError').style.display = 'inline'; }

  // ---------- Devices ----------
  async function loadDevices() {
    try {
      const [devices, stateDevices] = await Promise.all([api('/api/auth/devices'), api('/api/state/devices')]);
      let html = '';
      if (stateDevices.activeTrackId && stateDevices.activeDevice) {
        const isHere = stateDevices.activeDevice === (currentUser && currentUser.deviceLabel);
        const track = trackById(stateDevices.activeTrackId);
        html += `<div id="activeDeviceBanner">` +
          `<div><span class="k">${stateDevices.activeIsPlaying ? 'Playing' : 'Paused'} on:</span> ${escapeHtml(stateDevices.activeDevice)}${isHere ? ' (this device)' : ''}</div>` +
          `<div class="k2">${escapeHtml(track ? displayName(track) : stateDevices.activeTrackId)}</div>` +
          (isHere ? '' : `<button id="playHereBtn" type="button">Play here</button>`) +
          `</div>`;
      }
      html += devices.map(d =>
        `<div class="device-row"><span class="${d.isThisDevice ? 'thisDevice' : ''}">${escapeHtml(d.deviceLabel)}${d.isThisDevice ? ' (this device)' : ''}</span>${d.isThisDevice ? '' : `<button data-id="${d.id}" class="revokeBtn" type="button">Sign out</button>`}</div>`
      ).join('');
      $('deviceList').innerHTML = html;
      $('deviceList').querySelectorAll('.revokeBtn').forEach(btn => {
        btn.addEventListener('click', async () => { await apiPostJson('/api/auth/devices/' + btn.dataset.id + '/revoke'); loadDevices(); });
      });
      const playHereBtn = $('deviceList').querySelector('#playHereBtn');
      if (playHereBtn) playHereBtn.addEventListener('click', () => takeOverPlaybackHere(stateDevices));
    } catch (e) {}
  }

  // ---------- Device switching (Spotify-Connect-style "play here") ----------
  // Only one shared playback position per account (see the schema notes in lib/db.js) —
  // "switching devices" here means loading whatever's currently active elsewhere and
  // starting it on THIS device instead, at the same position. There's no push channel
  // to instantly silence the other device — it finds out and stops itself the next time
  // its own periodic state check notices a different device has taken over (see
  // maybeYieldToOtherDevice below), which is a several-second handoff window by design,
  // not a bug — building true instant multi-device control would need a whole separate
  // realtime channel (websockets or similar) this app doesn't have.
  async function takeOverPlaybackHere(stateDevices) {
    const track = trackById(stateDevices.activeTrackId);
    if (!track) return;
    await ensureFlatLibraryCache();
    const resolvedTrack = trackById(stateDevices.activeTrackId);
    if (!resolvedTrack) return;
    queue = [stateDevices.activeTrackId];
    queuePos = 0;
    renderQueue();
    $('settingsPanel').classList.remove('open');
    await playTrack(queue[queuePos]);
  }
  let lastKnownActiveDevice = null;
  async function maybeYieldToOtherDevice() {
    if (!isPlaying) return;
    try {
      const stateDevices = await api('/api/state/devices');
      if (lastKnownActiveDevice === null) lastKnownActiveDevice = stateDevices.activeDevice;
      const thisDeviceLabel = currentUser && currentUser.deviceLabel;
      if (stateDevices.activeDevice && stateDevices.activeDevice !== thisDeviceLabel && stateDevices.activeDevice !== lastKnownActiveDevice) {
        // Someone else explicitly took over since we last checked — stop here rather
        // than two devices playing the same account's audio at once.
        pausePlayback();
        setNpStatusText(`Paused — now playing on ${stateDevices.activeDevice}`);
      }
      lastKnownActiveDevice = stateDevices.activeDevice;
    } catch (e) {}
  }

  // ---------- Wiring ----------
  function wireEvents() {
    // A real reported bug: backgrounding the browser app (switching apps, locking the
    // phone) and returning to it could leave the seek bar showing a stale touch/pointer
    // state from right before backgrounding — the browser can replay or synthesize an
    // input event based on that stale position once the page is visible again, which
    // this app's own 'input' handler would take as a genuine, deliberate seek, jumping
    // to wherever that stale position happened to be. Two layers of defense: blur the
    // seek bar the moment the page goes hidden (removes any active touch/focus state
    // outright, so there's nothing left to replay), and ignore any 'input' event that
    // fires in the brief window right after becoming visible again, in case a stale
    // event still gets through some other way. Neither layer depends on the other.
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        $('seekBar').blur();
      } else {
        suppressSeekInputUntilMs = Date.now() + 500;
      }
    });

    $('loginBtn').addEventListener('click', async () => {
      $('loginError').style.display = 'none';
      try {
        await apiPostJson('/api/auth/login', { username: $('loginUsername').value, password: $('loginPassword').value, deviceLabel: navigator.userAgent.slice(0, 60) });
        currentUser = await api('/api/auth/me');
        onLoggedIn();
      } catch (e) { $('loginError').textContent = e.message; $('loginError').style.display = 'block'; }
    });
    $('registerBtn').addEventListener('click', async () => {
      $('loginError').style.display = 'none';
      try {
        await apiPostJson('/api/auth/register', { username: $('loginUsername').value, password: $('loginPassword').value, deviceLabel: navigator.userAgent.slice(0, 60) });
        currentUser = await api('/api/auth/me');
        onLoggedIn();
      } catch (e) { $('loginError').textContent = e.message; $('loginError').style.display = 'block'; }
    });
    $('logoutBtn').addEventListener('click', async () => {
      try { await apiPostJson('/api/auth/logout'); } catch (e) {}
      currentUser = null; showLogin();
    });

    // Mobile drawers — sidebar/queue become off-canvas panels below the 860px
    // breakpoint (see the CSS); these buttons and the backdrop only do anything
    // there, harmless no-ops on desktop where .drawer-toggle/#drawerBackdrop stay hidden.
    function closeDrawers() {
      $('sidebar').classList.remove('open');
      $('queuePanel').classList.remove('open');
      $('drawerBackdrop').classList.remove('open');
    }
    function openDrawer(which) {
      closeDrawers();
      $(which).classList.add('open');
      $('drawerBackdrop').classList.add('open');
    }
    $('sidebarToggleBtn').addEventListener('click', () => openDrawer('sidebar'));
    $('queueToggleBtn').addEventListener('click', () => openDrawer('queuePanel'));
    $('drawerBackdrop').addEventListener('click', closeDrawers);
    // Picking a folder or a track is a natural "I'm done with this drawer" moment —
    // close it automatically rather than making the person dismiss it separately.
    $('dirList').addEventListener('click', closeDrawers);
    $('trackList').addEventListener('click', closeDrawers);

    $('settingsToggle').addEventListener('click', () => { $('settingsPanel').classList.add('open'); updateAudioDiagnostics(); });
    $('newPlaylistBtn').addEventListener('click', createNewPlaylist);
    document.addEventListener('click', (e) => {
      if (!e.target.closest('#addToPlaylistMenu') && !e.target.closest('[data-add-pl-id]')) closeAddToPlaylistMenu();
    });
    $('settingsCloseBtn').addEventListener('click', () => $('settingsPanel').classList.remove('open'));

    $('searchBox').addEventListener('input', onSearchInput);

    $('playPauseBtn').addEventListener('click', () => {
      // Real, direct bug found from a reported "no ui buttons work"
      // complaint: this checked `currentBuffer`, which is Web-Audio-only —
      // native mode never sets it at all, so this unconditionally hit the
      // "nothing decoded yet" branch and silently did nothing, every time,
      // regardless of what was actually playing.
      if (window.NovaNative) {
        if (nativePaused) nativeResume(); else nativePause();
        return;
      }
      if (!currentBuffer) {
        // Nothing decoded yet — either a restored track waiting for its first
        // deliberate play, or genuinely nothing selected at all.
        if (restoredPendingTrackId && queue[queuePos] === restoredPendingTrackId) {
          const resumeAt = restoredPendingPositionSeconds;
          restoredPendingTrackId = null;
          playTrack(queue[queuePos], null, resumeAt);
        }
        return;
      }
      if (isPlaying) pausePlayback(); else resumePlayback();
    });
    // Real, direct fix for a confirmed "nothing starts after skip" report,
    // traced to an exact type bug: playNextInQueue's own parameter is
    // isGaplessContinuation, meant to be a boolean passed by automatic
    // track-end callers — but bound directly here as a raw DOM click
    // handler, the browser calls it with the click's PointerEvent as that
    // same first argument. A PointerEvent is truthy, so every manual
    // "Next" press was being misread as a genuine gapless continuation,
    // routing it into the older, legacy segment-fetch path (deliberately
    // kept only for real automatic transitions) instead of the newer,
    // far more robust buffered system every other track start in this
    // whole session already goes through — the legacy path has none of
    // that system's retry/recovery, which is exactly why it froze
    // completely the moment a pause interrupted it. Wrapped so a manual
    // click can never pass anything through as this argument.
    $('nextBtn').addEventListener('click', () => playNextInQueue());
    $('prevBtn').addEventListener('click', playPrevInQueue);
    $('repeatBtn').addEventListener('click', toggleRepeat);
    $('shuffleBtn').addEventListener('click', toggleShuffle);
    $('seekBar').addEventListener('pointerdown', () => { seekBarDragging = true; });
    // Real, direct fix for a confirmed static complaint — a spectrogram of
    // an actual recording showed a full 10-SECOND stretch of genuine,
    // uniform full-spectrum noise, and the matching device log showed why:
    // nine distinct seeks fired back-to-back as the seek head was dragged
    // rapidly across the track, exploring several positions in quick
    // succession. Each individual seek is a legitimate, correct action —
    // this isn't the earlier "change fires multiple times per drag" bug,
    // pointerup already only fires once per real touch. But at nine real,
    // separate touches in a few seconds, the underlying audio hardware
    // itself cannot keep rebuilding that fast, no matter how correct the
    // software logic driving each individual rebuild is. This is a
    // different class of fix: debounce the SEEK ACTION, not the event —
    // rapid, repeated touches only commit the actual native seek once
    // scrubbing has genuinely paused for a moment, using whichever
    // position was touched last. A single deliberate seek still fires
    // promptly (250ms after release, imperceptible on its own); a rapid
    // scrubbing burst collapses into one real hardware transition instead
    // of nine.
    let pendingSeekTimer = null;
    $('seekBar').addEventListener('pointerup', () => {
      seekBarDragging = false;
      // The actual, robust fix — real evidence from a device log proved my
      // prior assumption wrong: 'change' on this platform (mobile WebView,
      // touch-driven range input) can fire MULTIPLE times during a single
      // continuous drag, not once on release the way it reliably does with
      // mouse input on desktop. That log showed nine separate 'change'
      // firings across one drag gesture, each one attempting its own
      // restart-seek — exactly the cascade this was supposed to prevent,
      // just moved from 'input' to 'change' rather than actually fixed.
      // pointerup is the one event guaranteed to fire exactly once, at the
      // exact moment a touch/mouse actually releases — driving the seek
      // from here instead removes the dependency on 'change' firing a
      // specific number of times at all. The 'change' listener below no
      // longer performs the seek itself, only keeps its own diagnostic
      // logging, so an unexpected extra 'change' firing is now harmless.
      if (!window.NovaNative) return;
      if (Date.now() < suppressSeekInputUntilMs) return;
      if (pendingSeekTimer) { clearTimeout(pendingSeekTimer); pendingSeekTimer = null; }
      // Real, direct bug found via code inspection after a repeated "seeks,
      // then jumps back to the old position" complaint: this read
      // $('seekBar').value INSIDE the timeout callback — 250ms AFTER
      // release, not at the moment you actually dragged to. In between,
      // the live position-update loop keeps writing to that same slider's
      // value to reflect actual playback — so by the time this callback
      // ran, it could easily be reading back whatever the CURRENT position
      // is, not where you dragged to, and would seek to that instead.
      // Capturing the real target now, at the moment of release, and
      // closing over that value instead of re-reading the DOM later, is
      // what actually fixes this rather than masking it with more delay.
      const targetValue = parseFloat($('seekBar').value);
      pendingSeekTimer = setTimeout(() => {
        pendingSeekTimer = null;
        const totalDurationSeconds = window.__nativeKnownDuration || 0;
        if (!totalDurationSeconds) return; // nothing meaningful to seek to yet — duration hasn't been reported by any segment fetch
        nativeSeek((targetValue / 1000) * totalDurationSeconds);
      }, 250);
    });
    $('seekBar').addEventListener('input', () => {
      // Real, direct bug found from a reported "seeking just resets to the
      // start" complaint: 'input' fires CONTINUOUSLY while a range slider is
      // being dragged — every incremental position along the drag, not just
      // once at the end — completely standard HTML behavior, not something
      // native mode's design ever accounted for. Each one was triggering a
      // full network-restart seek, immediately abandoning the previous
      // still-in-flight one before it could ever complete — which is also
      // why the duration/media-session timeline never got reported: the
      // fetch that would have delivered it kept getting cut off mid-request
      // by the next drag increment's own restart. The Web-Audio path
      // doesn't have this same severity (a nearby seek there can reuse
      // already-decoded data, no network request required), so this was
      // left as native-mode-only unchanged behavior for years worth of
      // testing here — never actually broken for that path, only for this
      // one. Native mode's actual seek now only fires on 'change' (below,
      // which only fires once, on release/commit) — 'input' still runs for
      // the Web-Audio path exactly as it always did.
      if (window.NovaNative) return;
      if (!currentBuffer) return;
      // See the visibilitychange handler below for why this guard exists — a stale
      // touch/pointer state replayed right as the page becomes visible again could
      // otherwise fire this as a real seek to wherever the slider happened to end up.
      if (Date.now() < suppressSeekInputUntilMs) return;
      seekTo((parseFloat($('seekBar').value) / 1000) * currentBuffer.duration);
    });
    $('seekBar').addEventListener('change', () => {
      // Diagnostic only now — see the pointerup handler above for the
      // actual seek trigger and the full reasoning for why it moved there.
      // Kept here purely to keep visibility into how many times 'change'
      // actually fires per drag on a given device, in case that's ever
      // useful again.
      if (!window.NovaNative) return;
      nativeDebugLog(`seekBar 'change' fired (diagnostic only, no longer triggers a seek), value=${$('seekBar').value}, knownDuration=${window.__nativeKnownDuration}`);
    });

    $('qualitySelect').value = qualityMode;
    $('qualityAutoStatus').style.display = qualityMode === 'auto' ? 'block' : 'none';
    $('qualitySelect').addEventListener('change', () => {
      qualityMode = $('qualitySelect').value;
      localStorage.setItem('novaQualityMode', qualityMode);
      $('qualityAutoStatus').style.display = qualityMode === 'auto' ? 'block' : 'none';
    });

    $('lastfmSaveCredsBtn').addEventListener('click', async () => {
      $('lastfmError').style.display = 'none';
      try { await apiPostJson('/api/lastfm/credentials', { apiKey: $('lastfmApiKey').value, apiSecret: $('lastfmApiSecret').value }); $('lastfmApiSecret').value = ''; await refreshLastfmStatus(); }
      catch (e) { showLastfmError(e.message); }
    });
    $('lastfmChangeCredsBtn').addEventListener('click', async () => {
      try { await apiPostJson('/api/lastfm/credentials/clear'); await refreshLastfmStatus(); } catch (e) { showLastfmError(e.message); }
    });
    $('lastfmLinkBtn').addEventListener('click', async () => {
      $('lastfmError').style.display = 'none';
      try {
        const { token, authUrl } = await apiPostJson('/api/lastfm/link/start');
        const popup = window.open(authUrl, 'lastfm-auth', 'width=500,height=650');
        let attempts = 0;
        const poll = setInterval(async () => {
          attempts++;
          if (attempts > 60 || (popup && popup.closed && attempts > 3)) { clearInterval(poll); return; }
          try {
            await apiPostJson('/api/lastfm/link/finish', { token });
            clearInterval(poll);
            if (popup && !popup.closed) popup.close();
            await refreshLastfmStatus();
          } catch (e) {}
        }, 2000);
      } catch (e) { showLastfmError(e.message); }
    });
    $('lastfmUnlinkBtn').addEventListener('click', async () => {
      try { await apiPostJson('/api/lastfm/unlink'); await refreshLastfmStatus(); } catch (e) { showLastfmError(e.message); }
    });
    $('lastfmScrobbleToggle').addEventListener('change', async () => {
      try { await apiPostJson('/api/lastfm/scrobble-enabled', { enabled: $('lastfmScrobbleToggle').checked }); } catch (e) { showLastfmError(e.message); }
    });
    // 'input' (fires continuously while dragging) updates the visible label
    // immediately for responsiveness; the actual save is debounced onto
    // 'change' (fires once, on release) so dragging the slider doesn't fire
    // a network request per pixel moved.
    $('lastfmScrobbleThreshold').addEventListener('input', () => {
      $('lastfmScrobbleThresholdLabel').textContent = $('lastfmScrobbleThreshold').value + '%';
    });
    $('lastfmScrobbleThreshold').addEventListener('change', async () => {
      const percent = parseInt($('lastfmScrobbleThreshold').value, 10);
      try {
        await apiPostJson('/api/lastfm/scrobble-threshold', { percent });
        lastfmStatus.scrobbleThresholdPercent = percent;
      } catch (e) { showLastfmError(e.message); }
    });
  }

  window.addEventListener('DOMContentLoaded', () => {
    initClientErrorReporting();
    wireEvents();
    setupMediaSessionHandlers();
    updateShuffleRepeatUI();
    checkSession();
  });
})();
