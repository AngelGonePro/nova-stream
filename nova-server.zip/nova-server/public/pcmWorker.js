// Fetches the server-decoded PCM stream and parses it into Float32 sample chunks
// entirely on this worker thread — the main thread only ever receives already-parsed
// chunks via postMessage, never touches the raw bytes or does the interleaved-to-
// planar conversion itself. This mirrors exactly why web.html runs its own NOVA decode
// in a Worker: the main thread also has to handle Web Audio API scheduling (starting
// AudioBufferSourceNodes at precise times), and any long-running synchronous work
// competing for that same thread — even just parsing bytes, confirmed fast in
// isolation but still real, repeated work during active decode — risks delaying a
// scheduled segment's start just enough to be audible as a crackle. A dedicated
// worker removes that contention entirely, regardless of how fast the parsing itself
// measures in isolation.

self.onmessage = async (e) => {
  const { url, requestId } = e.data;
  try {
    const resp = await fetch(url, { credentials: 'include' });
    if (!resp.ok) {
      self.postMessage({ requestId, type: 'error', message: 'Server PCM stream failed: HTTP ' + resp.status });
      return;
    }
    const sampleRate = parseInt(resp.headers.get('X-PCM-Sample-Rate'), 10);
    const numChannels = parseInt(resp.headers.get('X-PCM-Channels'), 10);
    const totalFrames = parseInt(resp.headers.get('X-PCM-Total-Frames'), 10);
    // Real, required fix alongside the server's skip-ahead feature: without this,
    // a stream that starts transmitting from partway through a track (skipping
    // the network cost of retransmitting audio the client doesn't need) would
    // have its first received byte silently misinterpreted as sample 0 — every
    // subsequent startSample/endSample would be wrong by exactly the skipped
    // amount, writing decoded audio into the wrong position in the client's
    // buffer entirely.
    const skipSamples = parseInt(resp.headers.get('X-PCM-Skip-Samples'), 10) || 0;
    const bytesPerFrame = numChannels * 2;
    self.postMessage({ requestId, type: 'header', sampleRate, numChannels, totalFrames });

    const reader = resp.body.getReader();
    let carry = new Uint8Array(0);
    let localDecodedUpTo = skipSamples;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      let combined;
      if (carry.length) { combined = new Uint8Array(carry.length + value.byteLength); combined.set(carry); combined.set(value, carry.length); }
      else combined = value;
      const usableFrames = Math.floor(combined.length / bytesPerFrame);
      const usableBytes = usableFrames * bytesPerFrame;
      carry = combined.slice(usableBytes);
      if (usableFrames > 0) {
        const view = new DataView(combined.buffer, combined.byteOffset, usableBytes);
        const channels = [];
        for (let c = 0; c < numChannels; c++) {
          const arr = new Float32Array(usableFrames);
          for (let i = 0; i < usableFrames; i++) arr[i] = view.getInt16((i * numChannels + c) * 2, true) / 32768;
          channels.push(arr);
        }
        const startSample = localDecodedUpTo;
        localDecodedUpTo += usableFrames;
        // Transfer, not copy: these Float32Arrays are freshly allocated above, not
        // shared with anything this worker still needs afterward — safe to hand off
        // the underlying buffers directly rather than structured-cloning them.
        self.postMessage({ requestId, type: 'chunk', channels, startSample, endSample: localDecodedUpTo }, channels.map(c => c.buffer));
      }
    }
    self.postMessage({ requestId, type: 'end', totalDecoded: localDecodedUpTo });
  } catch (err) {
    self.postMessage({ requestId, type: 'error', message: err.message });
  }
};
