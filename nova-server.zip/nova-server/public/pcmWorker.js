// Fetches the server-decoded PCM stream and parses it into Float32 sample chunks
// entirely on this worker thread — the main thread only ever receives already-parsed
// chunks via postMessage, never touches the raw bytes or does the interleaved-to-
// planar conversion itself. This mirrors exactly why web.html runs its own NOVA decode
// in a Worker: the main thread also has to handle Web Audio API scheduling (starting
// AudioBufferSourceNodes at precise times), and any long-running synchronous work
// competing for that same thread — even just parsing bytes, confirmed fast in
// isolation but still real, repeated work during active decode — risks delaying a
// scheduled segment's start just enough to be audible as a crackle. A dedicated
// worker removes that contention entirely, regardless of how fast the parsing itself
// measures in isolation.

self.onmessage = async (e) => {
  const { url, requestId } = e.data;
  let heartbeatInterval = null;
  // Real, confirmed gap found from many production logs: worker.onerror on the
  // main thread kept reporting these failures with message=undefined, giving
  // no actual information about what went wrong. That handler fires for
  // uncaught exceptions in this worker — but an unhandled promise rejection
  // (distinct from a synchronously-thrown error) doesn't reliably populate
  // ErrorEvent.message the same way in every browser, which is exactly the
  // shape of failure an async function like this one can produce if something
  // throws outside the try/catch below (e.g. during setup, or from
  // postMessage itself if a value turns out non-cloneable). Catching it here
  // explicitly and posting a real error message means the main thread's retry
  // logging finally gets an actual reason instead of "undefined".
  self.onunhandledrejection = (ev) => {
    self.postMessage({ requestId, type: 'error', message: 'Unhandled rejection in PCM worker: ' + (ev.reason && ev.reason.message ? ev.reason.message : String(ev.reason)) });
  };
  try {
    const resp = await fetch(url, { credentials: 'include' });
    if (!resp.ok) {
      self.postMessage({ requestId, type: 'error', message: 'Server PCM stream failed: HTTP ' + resp.status });
      return;
    }
    const sampleRate = parseInt(resp.headers.get('X-PCM-Sample-Rate'), 10);
    const numChannels = parseInt(resp.headers.get('X-PCM-Channels'), 10);
    const totalFrames = parseInt(resp.headers.get('X-PCM-Total-Frames'), 10);
    // Real, required fix alongside the server's skip-ahead feature: without this,
    // a stream that starts transmitting from partway through a track (skipping
    // the network cost of retransmitting audio the client doesn't need) would
    // have its first received byte silently misinterpreted as sample 0 — every
    // subsequent startSample/endSample would be wrong by exactly the skipped
    // amount, writing decoded audio into the wrong position in the client's
    // buffer entirely.
    const skipSamples = parseInt(resp.headers.get('X-PCM-Skip-Samples'), 10) || 0;
    const bytesPerFrame = numChannels * 2;
    self.postMessage({ requestId, type: 'header', sampleRate, numChannels, totalFrames });

    // Real, confirmed-by-report bug this addresses: mobile browsers aggressively
    // throttle MAIN-THREAD timers (setInterval, requestAnimationFrame) once a tab
    // is backgrounded or the screen locks — exactly the normal way someone
    // listens to music on a phone, using the lock-screen media controls this app
    // already sets up. Reported directly: the exact same failure pattern
    // persisted on a faster, lower-latency network, but ONLY on mobile, never on
    // desktop — where the tab naturally stays foregrounded. That's the signature
    // of main-thread timer throttling, not network or server behavior, since
    // every server/network theory tested clean. checkForRebuffer's own recovery
    // loop runs entirely on main-thread timers (setInterval/setTimeout), which is
    // exactly what gets throttled. This Worker's own timers are NOT subject to
    // the same background throttling — sending a periodic heartbeat from here
    // gives the main thread a message-driven trigger to check on itself that
    // keeps working even when its own timers are being suppressed.
    heartbeatInterval = setInterval(() => {
      self.postMessage({ requestId, type: 'heartbeat' });
    }, 500);

    const reader = resp.body.getReader();
    let carry = new Uint8Array(0);
    let localDecodedUpTo = skipSamples;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      let combined;
      if (carry.length) { combined = new Uint8Array(carry.length + value.byteLength); combined.set(carry); combined.set(value, carry.length); }
      else combined = value;
      const usableFrames = Math.floor(combined.length / bytesPerFrame);
      const usableBytes = usableFrames * bytesPerFrame;
      carry = combined.slice(usableBytes);
      if (usableFrames > 0) {
        // Direct Int16Array indexing instead of DataView.getInt16() per sample —
        // DataView method calls carry real per-call overhead that's negligible on
        // a desktop CPU but adds up fast on a constrained mobile CPU, especially
        // competing for cycles inside a Worker. Confirmed as the likely real
        // bottleneck via a direct, controlled A/B test: curl pulling this exact
        // same stream through the exact same full public URL (server, tunnel,
        // nginx, Cloudflare — the entire path) delivered at 1.26MB/sec, 6.6x
        // realtime — while the actual app struggled on-device with the identical
        // network path. Nothing server-side or network-side explains that gap;
        // this parsing loop is the one piece of the path never actually isolated
        // and tested until now. Typed-array indexing is JIT-compiled to direct
        // memory access in virtually every modern engine, versus a DataView
        // method call's extra indirection on every single sample.
        let samples16;
        if (combined.byteOffset % 2 === 0) {
          samples16 = new Int16Array(combined.buffer, combined.byteOffset, usableBytes / 2);
        } else {
          // Defensive fallback only — an odd byteOffset would misalign an Int16Array
          // view. combined is always a freshly-allocated Uint8Array here (byteOffset
          // 0) except when it's `value` directly from reader.read(), whose own
          // byteOffset isn't strictly guaranteed by spec to be 0. Copies to a fresh,
          // aligned buffer rather than risk reading garbage.
          samples16 = new Int16Array(combined.slice(0, usableBytes).buffer);
        }
        const channels = [];
        for (let c = 0; c < numChannels; c++) {
          const arr = new Float32Array(usableFrames);
          for (let i = 0; i < usableFrames; i++) arr[i] = samples16[i * numChannels + c] / 32768;
          channels.push(arr);
        }
        const startSample = localDecodedUpTo;
        localDecodedUpTo += usableFrames;
        // Transfer, not copy: these Float32Arrays are freshly allocated above, not
        // shared with anything this worker still needs afterward — safe to hand off
        // the underlying buffers directly rather than structured-cloning them.
        self.postMessage({ requestId, type: 'chunk', channels, startSample, endSample: localDecodedUpTo }, channels.map(c => c.buffer));
      }
    }
    self.postMessage({ requestId, type: 'end', totalDecoded: localDecodedUpTo });
    clearInterval(heartbeatInterval);
  } catch (err) {
    if (heartbeatInterval) clearInterval(heartbeatInterval);
    self.postMessage({ requestId, type: 'error', message: err.message });
  }
};
