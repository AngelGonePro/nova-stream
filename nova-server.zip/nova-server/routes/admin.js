const express = require('express');
const db = require('../lib/db');
const auth = require('../lib/auth');
const libraryAccess = require('../lib/libraryAccess');
const musicBrowser = require('../lib/musicBrowser');
const logger = require('../lib/logger');

const router = express.Router();

// Every route in this file is admin-only — applied once here rather than
// repeated on each individual route below.
router.use(auth.requireAdmin);

function validUsername(u) { return typeof u === 'string' && /^[a-zA-Z0-9_-]{3,32}$/.test(u); }
function validPassword(p) { return typeof p === 'string' && p.length >= 8; }

// ---------- users ----------

router.get('/users', (req, res) => {
  const rows = db.prepare('SELECT id, username, is_admin, library_access_mode, created_at FROM users ORDER BY username').all();
  res.json(rows.map(r => ({
    id: r.id, username: r.username, isAdmin: !!r.is_admin,
    libraryAccessMode: r.library_access_mode, createdAt: r.created_at,
  })));
});

router.post('/users', (req, res) => {
  const { username, password, isAdmin } = req.body || {};
  if (!validUsername(username)) return res.status(400).json({ error: 'Username must be 3-32 characters: letters, numbers, _ or -' });
  if (!validPassword(password)) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (existing) return res.status(409).json({ error: 'Username already taken' });
  const hash = auth.hashPassword(password);
  const info = db.prepare('INSERT INTO users (username, password_hash, is_admin) VALUES (?, ?, ?)').run(username, hash, isAdmin ? 1 : 0);
  logger.warn('[admin] User created', { by: req.user.username, newUser: username, isAdmin: !!isAdmin });
  res.json({ ok: true, id: info.lastInsertRowid, username });
});

router.put('/users/:id/password', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const { password } = req.body || {};
  if (!validPassword(password)) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  const user = db.prepare('SELECT username FROM users WHERE id = ?').get(id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  const hash = auth.hashPassword(password);
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, id);
  // Every existing session for this account is invalidated — a password
  // change is exactly the moment an admin most likely wants any device
  // logged in under the OLD password (a lost phone, a compromised account)
  // to actually be signed out, not silently still-valid.
  db.prepare('DELETE FROM sessions WHERE user_id = ?').run(id);
  logger.warn('[admin] Password changed', { by: req.user.username, targetUser: user.username });
  res.json({ ok: true });
});

router.put('/users/:id/admin', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const { isAdmin } = req.body || {};
  if (id === req.user.id && !isAdmin) return res.status(400).json({ error: "Can't remove your own admin access" });
  const user = db.prepare('SELECT username FROM users WHERE id = ?').get(id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  db.prepare('UPDATE users SET is_admin = ? WHERE id = ?').run(isAdmin ? 1 : 0, id);
  logger.warn('[admin] Admin status changed', { by: req.user.username, targetUser: user.username, isAdmin: !!isAdmin });
  res.json({ ok: true });
});

router.delete('/users/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (id === req.user.id) return res.status(400).json({ error: "Can't delete your own account" });
  const user = db.prepare('SELECT username FROM users WHERE id = ?').get(id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  // Sessions, playback_state, playlists (and playlist_tracks via that FK), and
  // user_track_access all cascade automatically — every one of those tables
  // was created with ON DELETE CASCADE referencing users(id).
  db.prepare('DELETE FROM users WHERE id = ?').run(id);
  logger.warn('[admin] User deleted', { by: req.user.username, deletedUser: user.username });
  res.json({ ok: true });
});

// ---------- per-user library access ----------

router.get('/users/:id/access', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const user = db.prepare('SELECT id FROM users WHERE id = ?').get(id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({
    mode: libraryAccess.getAccessMode(id),
    grants: libraryAccess.getGrants(id).map(g => ({ path: g.path, isFolder: !!g.is_folder })),
  });
});

router.put('/users/:id/access', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const user = db.prepare('SELECT username FROM users WHERE id = ?').get(id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  const { mode, grants } = req.body || {};
  if (mode !== 'all' && mode !== 'restricted') return res.status(400).json({ error: "mode must be 'all' or 'restricted'" });
  libraryAccess.setAccessMode(id, mode);
  if (mode === 'restricted') {
    if (!Array.isArray(grants)) return res.status(400).json({ error: 'grants must be an array when mode is restricted' });
    // Validates every path actually resolves within the music library before
    // storing it — the same resolveSafe boundary check every other file
    // access in this app already goes through, so a grant can never be used
    // to smuggle an out-of-bounds path into the allow-list.
    for (const g of grants) {
      try { musicBrowser.resolveSafe(g.path); } catch (e) { return res.status(400).json({ error: `Invalid path: ${g.path}` }); }
    }
    libraryAccess.setGrants(id, grants);
  }
  logger.warn('[admin] Library access changed', { by: req.user.username, targetUser: user.username, mode, grantCount: mode === 'restricted' ? (grants || []).length : null });
  res.json({ ok: true });
});

// Reuses the same directory listing the regular library browser uses — the
// admin access picker needs to walk the same folder tree to let an admin
// select albums/artists/individual tracks to grant.
router.get('/browse', (req, res) => {
  try {
    res.json(musicBrowser.listDirectory(req.query.path || ''));
  } catch (e) {
    if (e.code === 'EOUTOFBOUNDS') return res.status(400).json({ error: 'Invalid path' });
    if (e.code === 'ENOENT') return res.status(404).json({ error: 'Not found' });
    if (e.code === 'ENOTDIR') return res.status(400).json({ error: 'Not a directory' });
    res.status(500).json({ error: 'Failed to browse' });
  }
});

module.exports = router;
