const express = require('express');
const rateLimit = require('express-rate-limit');
const db = require('../lib/db');
const auth = require('../lib/auth');

const router = express.Router();

// Deliberately generous but non-zero: this is a small self-hosted app for
// personal/family use, not a public service, so the main threat model is
// automated credential-stuffing bots hitting it if it's ever exposed
// publicly — not a legitimate user needing hundreds of attempts.
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20, standardHeaders: true, legacyHeaders: false });

function validUsername(u) { return typeof u === 'string' && /^[a-zA-Z0-9_-]{3,32}$/.test(u); }

router.post('/register', loginLimiter, (req, res) => {
  if (process.env.REGISTRATION_ENABLED === 'false') {
    return res.status(403).json({ error: 'Registration is disabled on this server — ask the admin for an account' });
  }
  const { username, password, deviceLabel } = req.body || {};
  if (!validUsername(username)) return res.status(400).json({ error: 'Username must be 3-32 characters: letters, numbers, _ or -' });
  if (typeof password !== 'string' || password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (existing) return res.status(409).json({ error: 'Username already taken' });

  const hash = auth.hashPassword(password);
  const info = db.prepare('INSERT INTO users (username, password_hash) VALUES (?, ?)').run(username, hash);
  const token = auth.createSession(info.lastInsertRowid, deviceLabel || 'Unknown device');
  auth.setSessionCookie(res, token);
  res.json({ ok: true, username });
});

router.post('/login', loginLimiter, (req, res) => {
  const { username, password, deviceLabel } = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user || !auth.verifyPassword(password || '', user.password_hash)) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }
  const token = auth.createSession(user.id, deviceLabel || 'Unknown device');
  auth.setSessionCookie(res, token);
  res.json({ ok: true, username: user.username });
});

router.post('/logout', (req, res) => {
  if (req.sessionToken) auth.destroySession(req.sessionToken);
  auth.clearSessionCookie(res);
  res.json({ ok: true });
});

router.get('/me', auth.requireAuth, (req, res) => {
  res.json({
    username: req.user.username,
    isAdmin: req.user.isAdmin,
    lastfmUsername: req.user.lastfmUsername,
    lastfmLinked: req.user.lastfmLinked,
    lastfmScrobbleEnabled: req.user.lastfmScrobbleEnabled,
  });
});

// Lists every device currently logged in as this user — lets the UI show
// "also active on: iPhone, desktop" and lets a person sign a lost/old device
// out remotely without changing their password.
router.get('/devices', auth.requireAuth, (req, res) => {
  const rows = db.prepare(
    'SELECT token, device_label, created_at, last_seen_at FROM sessions WHERE user_id = ? ORDER BY last_seen_at DESC'
  ).all(req.user.id);
  res.json(rows.map(r => ({
    id: r.token.slice(0, 8), // short, non-sensitive id for the UI — never expose the real session token to itself
    isThisDevice: r.token === req.sessionToken,
    deviceLabel: r.device_label,
    createdAt: r.created_at,
    lastSeenAt: r.last_seen_at,
  })));
});

router.post('/devices/:shortId/revoke', auth.requireAuth, (req, res) => {
  const rows = db.prepare('SELECT token FROM sessions WHERE user_id = ?').all(req.user.id);
  const match = rows.find(r => r.token.startsWith(req.params.shortId));
  if (!match) return res.status(404).json({ error: 'Device not found' });
  db.prepare('DELETE FROM sessions WHERE token = ?').run(match.token);
  res.json({ ok: true });
});

module.exports = router;
