const express = require('express');
const { spawn } = require('child_process');
const musicBrowser = require('../lib/musicBrowser');
const NovaCodec = require('../lib/novaCodec');
const fs = require('fs');
const path = require('path');

const router = express.Router();

router.get('/', (req, res) => {
  try {
    const listing = musicBrowser.listDirectory(req.query.path || '');
    res.json(listing);
  } catch (e) {
    if (e.code === 'EOUTOFBOUNDS') return res.status(400).json({ error: 'Invalid path' });
    if (e.code === 'ENOENT') return res.status(404).json({ error: 'Not found' });
    if (e.code === 'ENOTDIR') return res.status(400).json({ error: 'Not a directory' });
    res.status(500).json({ error: 'Failed to list directory' });
  }
});

// Reads tags for one file, quickly: for .nova files, NovaCodec.readMetadata only reads
// the header (not a full decode), so this stays cheap even for large multichannel
// files. For everything else, ffprobe reads the container's own tags. Mirrors the
// existing NextCloud library's pattern of a lightweight, per-track metadata fetch.
function readNovaTags(absPath) {
  const bytes = fs.readFileSync(absPath);
  const meta = NovaCodec.readMetadata(new Uint8Array(bytes.buffer, bytes.byteOffset, bytes.byteLength));
  return { title: (meta.tags && meta.tags.title) || null, artist: (meta.tags && meta.tags.artist) || null, album: (meta.tags && meta.tags.album) || null };
}
function probeTagsViaFfprobe(absPath) {
  return new Promise((resolve) => {
    const ffprobePath = (process.env.FFMPEG_PATH || 'ffmpeg').replace(/ffmpeg$/, 'ffprobe');
    const args = ['-v', 'error', '-show_entries', 'format_tags=title,artist,album', '-of', 'json', absPath];
    const proc = spawn(ffprobePath, args);
    let out = '';
    proc.stdout.on('data', (d) => out += d.toString());
    // Resolves with nulls on any failure rather than rejecting — a track with
    // unreadable tags should still show up in the library (filename fallback
    // is handled client-side), not break the whole listing.
    proc.on('error', () => resolve({ title: null, artist: null, album: null }));
    proc.on('close', () => {
      try {
        const tags = (JSON.parse(out).format || {}).tags || {};
        resolve({ title: tags.title || null, artist: tags.artist || null, album: tags.album || null });
      } catch (e) { resolve({ title: null, artist: null, album: null }); }
    });
  });
}

router.get('/tags', async (req, res) => {
  let absPath;
  try {
    absPath = musicBrowser.fileAbsPath(req.query.path || '');
  } catch (e) {
    if (e.code === 'EOUTOFBOUNDS') return res.status(400).json({ error: 'Invalid path' });
    if (e.code === 'ENOENT') return res.status(404).json({ error: 'Not found' });
    return res.status(400).json({ error: 'Not a file' });
  }
  try {
    const tags = path.extname(absPath).toLowerCase() === '.nova' ? readNovaTags(absPath) : await probeTagsViaFfprobe(absPath);
    res.json(tags);
  } catch (e) {
    res.json({ title: null, artist: null, album: null }); // same graceful-fallback rule as above
  }
});

module.exports = router;
