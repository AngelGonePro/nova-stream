const express = require('express');
const { spawn } = require('child_process');
const musicBrowser = require('../lib/musicBrowser');
const libraryAccess = require('../lib/libraryAccess');
const NovaCodec = require('../lib/novaCodec');
const fs = require('fs');
const path = require('path');

const router = express.Router();

router.get('/', (req, res) => {
  try {
    const listing = musicBrowser.listDirectory(req.query.path || '');
    // Restricted accounts only ever see what they've actually been granted —
    // a folder shows up if it's granted outright, or if anything is granted
    // somewhere underneath it (so navigation can still reach what's actually
    // accessible), and a file shows up only if it's individually granted or
    // covered by a granted parent folder. Unrestricted accounts ('all', the
    // default every existing user already had) see the same listing exactly
    // as before this existed.
    if (libraryAccess.getAccessMode(req.user.id) === 'restricted' && !req.user.isAdmin) {
      const grants = libraryAccess.getGrants(req.user.id);
      listing.dirs = listing.dirs.filter(d => grants.some(g => {
        const gPath = g.path.replace(/^\/+/, '');
        const dPath = d.path.replace(/^\/+/, '');
        return dPath === gPath || dPath.startsWith(gPath + '/') || (g.is_folder && gPath.startsWith(dPath + '/'));
      }));
      listing.files = listing.files.filter(f => libraryAccess.canAccess(req.user, f.path));
    }
    res.json(listing);
  } catch (e) {
    if (e.code === 'EOUTOFBOUNDS') return res.status(400).json({ error: 'Invalid path' });
    if (e.code === 'ENOENT') return res.status(404).json({ error: 'Not found' });
    if (e.code === 'ENOTDIR') return res.status(400).json({ error: 'Not a directory' });
    res.status(500).json({ error: 'Failed to list directory' });
  }
});

// Reads tags for one file, quickly: for .nova files, NovaCodec.readMetadata only reads
// the header (not a full decode), so this stays cheap even for large multichannel
// files. For everything else, ffprobe reads the container's own tags. Mirrors the
// existing NextCloud library's pattern of a lightweight, per-track metadata fetch.
function readNovaTags(absPath) {
  const bytes = fs.readFileSync(absPath);
  const meta = NovaCodec.readMetadata(new Uint8Array(bytes.buffer, bytes.byteOffset, bytes.byteLength));
  // numChannels included alongside the usual title/artist/album — the client uses
  // this to pick a sane starting stream quality for multichannel tracks before the
  // stream itself has even started, rather than discovering the channel count only
  // after already committing to a bandwidth tier. Cheap to include: readMetadata
  // only reads the file's small header, not any actual audio data.
  return { title: (meta.tags && meta.tags.title) || null, artist: (meta.tags && meta.tags.artist) || null, album: (meta.tags && meta.tags.album) || null, numChannels: meta.numChannels };
}
function probeTagsViaFfprobe(absPath) {
  return new Promise((resolve) => {
    const ffprobePath = (process.env.FFMPEG_PATH || 'ffmpeg').replace(/ffmpeg$/, 'ffprobe');
    // channels added to -show_entries alongside the existing tag fields — same
    // reasoning as readNovaTags above: lets the client know channel count before
    // committing to a starting stream quality.
    const args = ['-v', 'error', '-show_entries', 'format_tags=title,artist,album:stream=channels', '-of', 'json', absPath];
    const proc = spawn(ffprobePath, args);
    let out = '';
    proc.stdout.on('data', (d) => out += d.toString());
    // Resolves with nulls on any failure rather than rejecting — a track with
    // unreadable tags should still show up in the library (filename fallback
    // is handled client-side), not break the whole listing.
    proc.on('error', () => resolve({ title: null, artist: null, album: null, numChannels: null }));
    proc.on('close', () => {
      try {
        const parsed = JSON.parse(out);
        const tags = (parsed.format || {}).tags || {};
        const numChannels = (parsed.streams && parsed.streams[0] && parsed.streams[0].channels) || null;
        resolve({ title: tags.title || null, artist: tags.artist || null, album: tags.album || null, numChannels });
      } catch (e) { resolve({ title: null, artist: null, album: null, numChannels: null }); }
    });
  });
}

router.get('/tags', async (req, res) => {
  let absPath;
  try {
    absPath = musicBrowser.fileAbsPath(req.query.path || '');
  } catch (e) {
    if (e.code === 'EOUTOFBOUNDS') return res.status(400).json({ error: 'Invalid path' });
    if (e.code === 'ENOENT') return res.status(404).json({ error: 'Not found' });
    return res.status(400).json({ error: 'Not a file' });
  }
  if (!libraryAccess.canAccess(req.user, req.query.path || '')) return res.status(403).json({ error: 'Not permitted' });
  try {
    const tags = path.extname(absPath).toLowerCase() === '.nova' ? readNovaTags(absPath) : await probeTagsViaFfprobe(absPath);
    res.json(tags);
  } catch (e) {
    res.json({ title: null, artist: null, album: null }); // same graceful-fallback rule as above
  }
});

// Embedded cover art — .nova files carry it directly in their own header (same
// NovaCodec.readMetadata() call the tags route already uses, just reading the
// picture field this time instead of tags); everything else goes through ffmpeg,
// which can pull an attached-picture stream out of FLAC/MP3/M4A/etc. containers.
// No art embedded is the common case for a lot of files, not an error — a plain
// 404 for that, same graceful-fallback spirit as /tags, lets the client just show
// a placeholder instead of surfacing this as something broken.
router.get('/artwork', async (req, res) => {
  let absPath;
  try {
    absPath = musicBrowser.fileAbsPath(req.query.path || '');
  } catch (e) {
    if (e.code === 'EOUTOFBOUNDS') return res.status(400).json({ error: 'Invalid path' });
    if (e.code === 'ENOENT') return res.status(404).json({ error: 'Not found' });
    return res.status(400).json({ error: 'Not a file' });
  }
  if (!libraryAccess.canAccess(req.user, req.query.path || '')) return res.status(403).end();

  if (path.extname(absPath).toLowerCase() === '.nova') {
    try {
      const bytes = fs.readFileSync(absPath);
      const meta = NovaCodec.readMetadata(new Uint8Array(bytes.buffer, bytes.byteOffset, bytes.byteLength));
      if (!meta.picture || !meta.picture.data || !meta.picture.data.length) return res.status(404).end();
      res.set('Content-Type', meta.picture.mime || 'image/jpeg');
      res.set('Cache-Control', 'private, max-age=86400'); // artwork for a given file never changes without the file itself changing
      res.end(Buffer.from(meta.picture.data));
    } catch (e) {
      res.status(404).end();
    }
    return;
  }

  // ffmpeg extraction — ask only for the attached-picture stream (-an drops audio,
  // -vcodec copy avoids re-encoding whatever image format is already embedded),
  // written to stdout as a single image, not a video stream.
  const ffmpegPath = process.env.FFMPEG_PATH || 'ffmpeg';
  const args = ['-v', 'error', '-i', absPath, '-an', '-vcodec', 'copy', '-f', 'image2pipe', '-'];
  const proc = spawn(ffmpegPath, args);
  const chunks = [];
  let responded = false;
  proc.stdout.on('data', (d) => chunks.push(d));
  proc.on('error', () => { if (!responded) { responded = true; res.status(404).end(); } });
  proc.on('close', (code) => {
    if (responded) return;
    responded = true;
    const buf = Buffer.concat(chunks);
    if (code !== 0 || !buf.length) return res.status(404).end();
    // ffmpeg doesn't report the format directly on this path — sniff the first
    // few bytes rather than assuming, since embedded art is JPEG most of the
    // time but PNG often enough to be worth actually checking.
    const isPng = buf.length > 8 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47;
    res.set('Content-Type', isPng ? 'image/png' : 'image/jpeg');
    res.set('Cache-Control', 'private, max-age=86400');
    res.end(buf);
  });
});

module.exports = router;
