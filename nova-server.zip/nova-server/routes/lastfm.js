const express = require('express');
const db = require('../lib/db');
const auth = require('../lib/auth');
const lastfm = require('../lib/lastfm');
const secretCrypto = require('../lib/crypto');

const router = express.Router();

function getFullUserRow(userId) {
  return db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
}

router.get('/status', auth.requireAuth, (req, res) => {
  const row = getFullUserRow(req.user.id);
  res.json({
    // "configured" means THIS user has entered their own API key+secret —
    // there is no server-wide Last.fm app registration to fall back on.
    configured: !!(row.lastfm_api_key && row.lastfm_api_secret_enc),
    apiKey: row.lastfm_api_key || null, // safe to return — it's not the secret
    linked: !!row.lastfm_session_key_enc,
    username: row.lastfm_username,
    scrobbleEnabled: !!row.lastfm_scrobble_enabled,
  });
});

// Saves this user's own Last.fm API key + secret (from last.fm/api/account/
// create). Re-saving clears any existing session link, since a session key
// obtained under the old credentials won't necessarily be valid under new
// ones — cleanest to just require re-linking.
router.post('/credentials', auth.requireAuth, (req, res) => {
  const { apiKey, apiSecret } = req.body || {};
  if (!apiKey || !apiSecret || typeof apiKey !== 'string' || typeof apiSecret !== 'string') {
    return res.status(400).json({ error: 'apiKey and apiSecret are required' });
  }
  db.prepare(`
    UPDATE users SET lastfm_api_key = ?, lastfm_api_secret_enc = ?,
      lastfm_username = NULL, lastfm_session_key_enc = NULL
    WHERE id = ?
  `).run(apiKey.trim(), secretCrypto.encrypt(apiSecret.trim()), req.user.id);
  res.json({ ok: true });
});

router.post('/credentials/clear', auth.requireAuth, (req, res) => {
  db.prepare(`
    UPDATE users SET lastfm_api_key = NULL, lastfm_api_secret_enc = NULL,
      lastfm_username = NULL, lastfm_session_key_enc = NULL
    WHERE id = ?
  `).run(req.user.id);
  res.json({ ok: true });
});

// Step 1+2 of the desktop auth flow, using THIS user's own stored API key.
router.post('/link/start', auth.requireAuth, async (req, res) => {
  const row = getFullUserRow(req.user.id);
  if (!row.lastfm_api_key || !row.lastfm_api_secret_enc) {
    return res.status(400).json({ error: 'Save your Last.fm API key and secret first' });
  }
  try {
    const apiSecret = secretCrypto.decrypt(row.lastfm_api_secret_enc);
    const token = await lastfm.getToken(row.lastfm_api_key, apiSecret);
    res.json({ token, authUrl: lastfm.authUrl(row.lastfm_api_key, token) });
  } catch (e) {
    res.status(502).json({ error: 'Failed to start Last.fm authorization: ' + e.message });
  }
});

// Step 3: called after the person has approved on last.fm's site.
router.post('/link/finish', auth.requireAuth, async (req, res) => {
  const { token } = req.body || {};
  if (!token) return res.status(400).json({ error: 'Missing token' });
  const row = getFullUserRow(req.user.id);
  if (!row.lastfm_api_key || !row.lastfm_api_secret_enc) {
    return res.status(400).json({ error: 'Save your Last.fm API key and secret first' });
  }
  try {
    const apiSecret = secretCrypto.decrypt(row.lastfm_api_secret_enc);
    const { sessionKey, username } = await lastfm.getSession(row.lastfm_api_key, apiSecret, token);
    db.prepare('UPDATE users SET lastfm_username = ?, lastfm_session_key_enc = ? WHERE id = ?')
      .run(username, secretCrypto.encrypt(sessionKey), req.user.id);
    res.json({ ok: true, username });
  } catch (e) {
    // error code 14 specifically means "not authorized yet" — the person
    // hasn't clicked approve on last.fm's page yet, distinct from a real failure.
    if (e.lastfmCode === 14) return res.status(409).json({ error: 'Not approved yet — finish authorizing on the Last.fm page first' });
    res.status(502).json({ error: 'Failed to complete Last.fm authorization: ' + e.message });
  }
});

router.post('/unlink', auth.requireAuth, (req, res) => {
  db.prepare('UPDATE users SET lastfm_username = NULL, lastfm_session_key_enc = NULL WHERE id = ?').run(req.user.id);
  res.json({ ok: true });
});

router.post('/scrobble-enabled', auth.requireAuth, (req, res) => {
  const enabled = !!(req.body && req.body.enabled);
  db.prepare('UPDATE users SET lastfm_scrobble_enabled = ? WHERE id = ?').run(enabled ? 1 : 0, req.user.id);
  res.json({ ok: true, enabled });
});

// Returns the decrypted credentials needed to make an authenticated call, or
// null if this user hasn't linked / has scrobbling turned off — callers
// treat null as "silently skip", not an error, since most tracks played
// won't need this checked at all if the person doesn't use Last.fm.
function getCredentialsOrNull(userId) {
  const row = getFullUserRow(userId);
  if (!row.lastfm_api_key || !row.lastfm_api_secret_enc || !row.lastfm_session_key_enc || !row.lastfm_scrobble_enabled) return null;
  return {
    apiKey: row.lastfm_api_key,
    apiSecret: secretCrypto.decrypt(row.lastfm_api_secret_enc),
    sessionKey: secretCrypto.decrypt(row.lastfm_session_key_enc),
  };
}

router.post('/now-playing', auth.requireAuth, async (req, res) => {
  const creds = getCredentialsOrNull(req.user.id);
  if (!creds) return res.json({ ok: true, skipped: true });
  const { artist, track, album, duration } = req.body || {};
  if (!artist || !track) return res.status(400).json({ error: 'artist and track are required' });
  try {
    await lastfm.updateNowPlaying(creds.apiKey, creds.apiSecret, creds.sessionKey, { artist, track, album, duration });
    res.json({ ok: true });
  } catch (e) {
    res.status(502).json({ error: 'Last.fm now-playing update failed: ' + e.message });
  }
});

router.post('/scrobble', auth.requireAuth, async (req, res) => {
  const creds = getCredentialsOrNull(req.user.id);
  if (!creds) return res.json({ ok: true, skipped: true });
  const { artist, track, album, duration, playedSeconds, timestamp } = req.body || {};
  if (!artist || !track || typeof duration !== 'number' || typeof playedSeconds !== 'number') {
    return res.status(400).json({ error: 'artist, track, duration, and playedSeconds are required' });
  }
  // Enforced server-side too, not just trusted from the client.
  if (!lastfm.qualifiesForScrobble(playedSeconds, duration)) {
    return res.status(400).json({ error: 'Track does not yet qualify for scrobbling' });
  }
  try {
    await lastfm.scrobble(creds.apiKey, creds.apiSecret, creds.sessionKey, { artist, track, album, duration, timestamp });
    res.json({ ok: true });
  } catch (e) {
    res.status(502).json({ error: 'Last.fm scrobble failed: ' + e.message });
  }
});

module.exports = router;
