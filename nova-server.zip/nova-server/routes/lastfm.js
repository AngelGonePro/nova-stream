const express = require('express');
const db = require('../lib/db');
const auth = require('../lib/auth');
const lastfm = require('../lib/lastfm');
const secretCrypto = require('../lib/crypto');

const router = express.Router();

function getFullUserRow(userId) {
  return db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
}

router.get('/status', auth.requireAuth, (req, res) => {
  const row = getFullUserRow(req.user.id);
  res.json({
    // "configured" means THIS user has entered their own API key+secret —
    // there is no server-wide Last.fm app registration to fall back on.
    configured: !!(row.lastfm_api_key && row.lastfm_api_secret_enc),
    apiKey: row.lastfm_api_key || null, // safe to return — it's not the secret
    linked: !!row.lastfm_session_key_enc,
    username: row.lastfm_username,
    scrobbleEnabled: !!row.lastfm_scrobble_enabled,
    scrobbleThresholdPercent: row.lastfm_scrobble_threshold_percent,
  });
});

// Saves this user's own Last.fm API key + secret (from last.fm/api/account/
// create). Re-saving clears any existing session link, since a session key
// obtained under the old credentials won't necessarily be valid under new
// ones — cleanest to just require re-linking.
router.post('/credentials', auth.requireAuth, (req, res) => {
  const { apiKey, apiSecret } = req.body || {};
  if (!apiKey || !apiSecret || typeof apiKey !== 'string' || typeof apiSecret !== 'string') {
    return res.status(400).json({ error: 'apiKey and apiSecret are required' });
  }
  db.prepare(`
    UPDATE users SET lastfm_api_key = ?, lastfm_api_secret_enc = ?,
      lastfm_username = NULL, lastfm_session_key_enc = NULL
    WHERE id = ?
  `).run(apiKey.trim(), secretCrypto.encrypt(apiSecret.trim()), req.user.id);
  res.json({ ok: true });
});

router.post('/credentials/clear', auth.requireAuth, (req, res) => {
  db.prepare(`
    UPDATE users SET lastfm_api_key = NULL, lastfm_api_secret_enc = NULL,
      lastfm_username = NULL, lastfm_session_key_enc = NULL
    WHERE id = ?
  `).run(req.user.id);
  res.json({ ok: true });
});

// Turns Last.fm's numeric error codes into something a person can act on.
function connectErrorMessage(e) {
  if (!e.lastfmCode) return 'Could not reach Last.fm: ' + e.message;
  const said = ' (Last.fm said: "' + e.message + '")';
  switch (e.lastfmCode) {
    case 4: return 'Last.fm rejected that username or password' + said;
    case 10: return 'Last.fm does not recognise that API key — check it was copied exactly' + said;
    case 13: return 'The API secret does not match that API key — check it was copied exactly' + said;
    case 26: return 'Last.fm has suspended this API key' + said;
    case 29: return 'Last.fm is rate-limiting requests — wait a minute and try again' + said;
    default: return 'Last.fm error ' + e.lastfmCode + said;
  }
}

// Connects this user's Last.fm account from the API key + secret + username + password, in one step.
// Key and secret may be left blank to reuse the ones already saved (e.g. reconnecting after a
// disconnect). The password is used for this one request and is neither stored nor logged; only the
// session key Last.fm returns is kept (encrypted, like the secret).
router.post('/connect', auth.requireAuth, async (req, res) => {
  const row = getFullUserRow(req.user.id);
  const body = req.body || {};
  const apiKey = (typeof body.apiKey === 'string' ? body.apiKey.trim() : '') || row.lastfm_api_key || '';
  let apiSecret = typeof body.apiSecret === 'string' ? body.apiSecret.trim() : '';
  if (!apiSecret && row.lastfm_api_secret_enc) { try { apiSecret = secretCrypto.decrypt(row.lastfm_api_secret_enc); } catch (e) { apiSecret = ''; } }
  const username = typeof body.username === 'string' ? body.username.trim() : '';
  const password = typeof body.password === 'string' ? body.password : '';
  if (!apiKey || !apiSecret) return res.status(400).json({ error: 'Enter your Last.fm API key and API secret' });
  if (!username || !password) return res.status(400).json({ error: 'Enter your Last.fm username and password' });
  try {
    const { sessionKey, username: confirmedName } = await lastfm.getMobileSession(apiKey, apiSecret, username, password);
    db.prepare('UPDATE users SET lastfm_api_key = ?, lastfm_api_secret_enc = ?, lastfm_username = ?, lastfm_session_key_enc = ? WHERE id = ?')
      .run(apiKey, secretCrypto.encrypt(apiSecret), confirmedName, secretCrypto.encrypt(sessionKey), req.user.id);
    res.json({ ok: true, username: confirmedName });
  } catch (e) {
    res.status(e.lastfmCode ? 400 : 502).json({ error: connectErrorMessage(e) });
  }
});

router.post('/unlink', auth.requireAuth, (req, res) => {
  db.prepare('UPDATE users SET lastfm_username = NULL, lastfm_session_key_enc = NULL WHERE id = ?').run(req.user.id);
  res.json({ ok: true });
});

router.post('/scrobble-enabled', auth.requireAuth, (req, res) => {
  const enabled = !!(req.body && req.body.enabled);
  db.prepare('UPDATE users SET lastfm_scrobble_enabled = ? WHERE id = ?').run(enabled ? 1 : 0, req.user.id);
  res.json({ ok: true, enabled });
});

router.post('/scrobble-threshold', auth.requireAuth, (req, res) => {
  const pct = req.body && req.body.percent;
  if (typeof pct !== 'number' || !Number.isFinite(pct) || pct < 1 || pct > 100) {
    return res.status(400).json({ error: 'percent must be a number between 1 and 100' });
  }
  db.prepare('UPDATE users SET lastfm_scrobble_threshold_percent = ? WHERE id = ?').run(Math.round(pct), req.user.id);
  res.json({ ok: true, percent: Math.round(pct) });
});

// Returns the decrypted credentials needed to make an authenticated call, or
// null if this user hasn't linked / has scrobbling turned off — callers
// treat null as "silently skip", not an error, since most tracks played
// won't need this checked at all if the person doesn't use Last.fm.
function getCredentialsOrNull(userId) {
  const row = getFullUserRow(userId);
  if (!row.lastfm_api_key || !row.lastfm_api_secret_enc || !row.lastfm_session_key_enc || !row.lastfm_scrobble_enabled) return null;
  return {
    apiKey: row.lastfm_api_key,
    apiSecret: secretCrypto.decrypt(row.lastfm_api_secret_enc),
    sessionKey: secretCrypto.decrypt(row.lastfm_session_key_enc),
  };
}

router.post('/now-playing', auth.requireAuth, async (req, res) => {
  const creds = getCredentialsOrNull(req.user.id);
  if (!creds) return res.json({ ok: true, skipped: true });
  const { artist, track, album, duration } = req.body || {};
  if (!artist || !track) return res.status(400).json({ error: 'artist and track are required' });
  try {
    await lastfm.updateNowPlaying(creds.apiKey, creds.apiSecret, creds.sessionKey, { artist, track, album, duration });
    res.json({ ok: true });
  } catch (e) {
    res.status(502).json({ error: 'Last.fm now-playing update failed: ' + e.message });
  }
});

router.post('/scrobble', auth.requireAuth, async (req, res) => {
  const creds = getCredentialsOrNull(req.user.id);
  if (!creds) return res.json({ ok: true, skipped: true });
  const { artist, track, album, duration, playedSeconds, timestamp } = req.body || {};
  if (!artist || !track || typeof duration !== 'number' || typeof playedSeconds !== 'number') {
    return res.status(400).json({ error: 'artist, track, duration, and playedSeconds are required' });
  }
  // Enforced server-side too, not just trusted from the client.
  const userRow = getFullUserRow(req.user.id);
  if (!lastfm.qualifiesForScrobble(playedSeconds, duration, userRow.lastfm_scrobble_threshold_percent)) {
    return res.status(400).json({ error: 'Track does not yet qualify for scrobbling' });
  }
  try {
    await lastfm.scrobble(creds.apiKey, creds.apiSecret, creds.sessionKey, { artist, track, album, duration, timestamp });
    res.json({ ok: true });
  } catch (e) {
    res.status(502).json({ error: 'Last.fm scrobble failed: ' + e.message });
  }
});

module.exports = router;
