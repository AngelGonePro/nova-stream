const express = require('express');
const rateLimit = require('express-rate-limit');
const logger = require('../lib/logger');
const auth = require('../lib/auth');

const router = express.Router();

// No auth required — a login failure or a crash on the login screen itself is
// exactly the kind of thing worth capturing, and requiring a session here would
// silently drop reports from anyone not yet logged in. Rate-limited instead,
// since this is the one endpoint an already-broken or malicious client could
// hammer freely without ever needing valid credentials.
const clientErrorLimiter = rateLimit({ windowMs: 60 * 1000, max: 30, standardHeaders: true, legacyHeaders: false });

// Accepts a BATCH of entries in one call (see the client-side buffering in app.js) —
// one request per batch, not one per error, so a flurry of console.error calls during
// a real crash doesn't itself become a flood of separate HTTP requests.
router.post('/client-error', clientErrorLimiter, (req, res) => {
  const { entries } = req.body || {};
  if (!Array.isArray(entries) || !entries.length) return res.status(400).json({ error: 'entries must be a non-empty array' });
  const capped = entries.slice(0, 50); // a single batch can't itself be used to write hundreds of lines in one call
  for (const e of capped) {
    const context = {
      url: typeof e.url === 'string' ? e.url.slice(0, 300) : undefined,
      userAgent: typeof req.headers['user-agent'] === 'string' ? req.headers['user-agent'].slice(0, 200) : undefined,
      username: req.user ? req.user.username : undefined, // present if they happened to be logged in when it happened
      stack: typeof e.stack === 'string' ? e.stack.slice(0, 1000) : undefined,
    };
    if (e.level === 'warn') logger.clientWarn(e.message, context);
    else logger.clientError(e.message, context);
  }
  res.json({ ok: true, accepted: capped.length });
});

// Convenience for looking at recent errors without needing shell/docker exec access
// on the host — admin-only since it can include user-agent strings and usernames.
router.get('/', auth.requireAdmin, (req, res) => {
  const limit = Math.min(500, parseInt(req.query.limit, 10) || 200);
  res.json({ entries: logger.readRecent(limit), maxLines: logger.MAX_LINES, maxBytes: logger.MAX_BYTES });
});

module.exports = router;
