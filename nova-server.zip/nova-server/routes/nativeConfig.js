const express = require('express');
const auth = require('../lib/auth');

const router = express.Router();

// Buffering policy for the Android app's native audio engine. The app is a thin shell (audio output + lock
// screen controls); everything tunable lives here and is pushed to it by the page at startup, so changing a
// value is an .env edit plus a server restart, never a new APK.
function intFromEnv(name, fallback, min, max) {
  const n = parseInt(process.env[name], 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

router.get('/', auth.requireAuth, (req, res) => {
  res.json({
    prebufferSeconds: intFromEnv('NATIVE_PREBUFFER_SECONDS', 15, 1, 120),
    rebufferSeconds: intFromEnv('NATIVE_REBUFFER_SECONDS', 10, 0, 120),
    lowMarginSeconds: intFromEnv('NATIVE_LOW_MARGIN_SECONDS', 6, 1, 120),
  });
});

module.exports = router;
