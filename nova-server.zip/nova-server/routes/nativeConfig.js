const express = require('express');
const auth = require('../lib/auth');

const router = express.Router();

// Buffering policy for the Android app's native audio engine. The app is a thin shell (audio output + lock
// screen controls); everything tunable lives here and is pushed to it by the page at startup, so changing a
// value is an .env edit plus a server restart, never a new APK.
function intFromEnv(name, fallback, min, max) {
  const n = parseInt(process.env[name], 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

router.get('/', auth.requireAuth, (req, res) => {
  res.json({
    prebufferSeconds: intFromEnv('NATIVE_PREBUFFER_SECONDS', 15, 1, 120),
    rebufferSeconds: intFromEnv('NATIVE_REBUFFER_SECONDS', 10, 0, 120),
    lowMarginSeconds: intFromEnv('NATIVE_LOW_MARGIN_SECONDS', 6, 1, 120),
    // Page-side only (not sent to the engine): when a next-track download was cancelled because the current track
    // was running low, and by default every next-track download waits until this many seconds of the current track remain.
    prefetchLateLeadSeconds: intFromEnv('NATIVE_PREFETCH_LATE_LEAD_SECONDS', 90, 5, 600),
    // Page-side only: CONNECTION_PROBES=off stops the app downloading speed-test data (login, resume, periodic) and
    // makes quality climb one tier at a time after a quiet period instead of being decided by a measurement.
    // Engine setting (apps that can render surround): NATIVE_SURROUND=off keeps the stereo mix even when the phone reports
    // spatial audio or a multichannel output. Apps without surround support ignore it.
    surroundOutput: !/^(off|0|false|no)$/i.test(String(process.env.NATIVE_SURROUND || '').trim()),
    // Page-side only: AUTO_QUALITY_STEP_DOWN=on lets a stall / low buffer drop quality mid-song (the old behaviour, which loses
    // the 5.1/7.1 channels and jumps the audio when the swap lands). Default off: the app stops, refills the buffer and resumes.
    autoStepDown: /^(on|1|true|yes)$/i.test(String(process.env.AUTO_QUALITY_STEP_DOWN || '').trim()),
    connectionProbes: !/^(off|0|false|no)$/i.test(String(process.env.CONNECTION_PROBES || '').trim()),
  });
});

// Connection probe: the page downloads a few MB from here for a couple of seconds (on login, when the network
// changes, when the app comes back to the foreground) to see what the current connection can actually sustain,
// and picks the audio quality from that instead of finding out by stalling. Random bytes so no proxy can compress
// them into something that measures faster than the real link.
const crypto = require('crypto');
router.get('/probe', auth.requireAuth, (req, res) => {
  const maxBytes = intFromEnv('NATIVE_PROBE_MAX_BYTES', 12000000, 100000, 50000000);
  let remaining = Math.min(maxBytes, Math.max(1, parseInt(req.query.bytes, 10) || maxBytes));
  res.set({ 'Content-Type': 'application/octet-stream', 'Content-Length': String(remaining), 'Cache-Control': 'no-store', 'Content-Encoding': 'identity', 'X-Accel-Buffering': 'no' });
  let closed = false;
  res.on('close', () => { closed = true; });
  const pump = () => {
    while (!closed && remaining > 0) {
      const n = Math.min(remaining, 16384);
      remaining -= n;
      const ok = res.write(crypto.randomBytes(n)); // fresh bytes every write: a repeated block would be compressible
      if (!ok && remaining > 0) { res.once('drain', pump); return; }
    }
    if (!closed) res.end();
  };
  pump();
});

module.exports = router;
