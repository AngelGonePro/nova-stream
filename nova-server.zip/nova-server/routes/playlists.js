const express = require('express');
const db = require('../lib/db');
const auth = require('../lib/auth');
const musicBrowser = require('../lib/musicBrowser');

const router = express.Router();
router.use(auth.requireAuth);

function playlistWithTracks(playlistId, userId) {
  const playlist = db.prepare('SELECT * FROM playlists WHERE id = ? AND user_id = ?').get(playlistId, userId);
  if (!playlist) return null;
  const tracks = db.prepare('SELECT track_path, position FROM playlist_tracks WHERE playlist_id = ? ORDER BY position').all(playlistId);
  return {
    id: playlist.id, name: playlist.name,
    createdAt: playlist.created_at, updatedAt: playlist.updated_at,
    trackPaths: tracks.map(t => t.track_path),
  };
}
function touchPlaylist(playlistId) {
  db.prepare("UPDATE playlists SET updated_at = strftime('%s','now') WHERE id = ?").run(playlistId);
}
// A stored path could point at a file that's since been moved, renamed, or deleted —
// checked here rather than trusted blindly, so a stale entry fails cleanly with a
// clear reason instead of surfacing as a confusing playback error much later.
function validateTrackPath(trackPath) {
  try {
    const abs = musicBrowser.fileAbsPath(trackPath);
    return true;
  } catch (e) {
    return false;
  }
}

router.get('/', (req, res) => {
  const rows = db.prepare('SELECT id, name, created_at, updated_at FROM playlists WHERE user_id = ? ORDER BY updated_at DESC').all(req.user.id);
  const counts = db.prepare('SELECT playlist_id, COUNT(*) as c FROM playlist_tracks WHERE playlist_id IN (SELECT id FROM playlists WHERE user_id = ?) GROUP BY playlist_id').all(req.user.id);
  const countMap = new Map(counts.map(c => [c.playlist_id, c.c]));
  res.json(rows.map(r => ({ id: r.id, name: r.name, createdAt: r.created_at, updatedAt: r.updated_at, trackCount: countMap.get(r.id) || 0 })));
});

router.post('/', (req, res) => {
  const name = (req.body && req.body.name || '').trim();
  if (!name) return res.status(400).json({ error: 'Playlist name is required' });
  if (name.length > 200) return res.status(400).json({ error: 'Playlist name is too long' });
  const result = db.prepare('INSERT INTO playlists (user_id, name) VALUES (?, ?)').run(req.user.id, name);
  res.json(playlistWithTracks(result.lastInsertRowid, req.user.id));
});

router.get('/:id', (req, res) => {
  const playlist = playlistWithTracks(req.params.id, req.user.id);
  if (!playlist) return res.status(404).json({ error: 'Playlist not found' });
  res.json(playlist);
});

router.patch('/:id', (req, res) => {
  const name = (req.body && req.body.name || '').trim();
  if (!name) return res.status(400).json({ error: 'Playlist name is required' });
  const result = db.prepare("UPDATE playlists SET name = ?, updated_at = strftime('%s','now') WHERE id = ? AND user_id = ?").run(name, req.params.id, req.user.id);
  if (result.changes === 0) return res.status(404).json({ error: 'Playlist not found' });
  res.json(playlistWithTracks(req.params.id, req.user.id));
});

router.delete('/:id', (req, res) => {
  const result = db.prepare('DELETE FROM playlists WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
  if (result.changes === 0) return res.status(404).json({ error: 'Playlist not found' });
  res.json({ ok: true });
});

router.post('/:id/tracks', (req, res) => {
  const playlist = db.prepare('SELECT id FROM playlists WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!playlist) return res.status(404).json({ error: 'Playlist not found' });
  const trackPath = req.body && req.body.trackPath;
  if (!trackPath || typeof trackPath !== 'string') return res.status(400).json({ error: 'trackPath is required' });
  if (!validateTrackPath(trackPath)) return res.status(400).json({ error: 'That file could not be found in your music library' });
  const maxPos = db.prepare('SELECT COALESCE(MAX(position), -1) as m FROM playlist_tracks WHERE playlist_id = ?').get(req.params.id).m;
  db.prepare('INSERT INTO playlist_tracks (playlist_id, track_path, position) VALUES (?, ?, ?)').run(req.params.id, trackPath, maxPos + 1);
  touchPlaylist(req.params.id);
  res.json(playlistWithTracks(req.params.id, req.user.id));
});

router.delete('/:id/tracks/:position', (req, res) => {
  const playlist = db.prepare('SELECT id FROM playlists WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!playlist) return res.status(404).json({ error: 'Playlist not found' });
  const position = parseInt(req.params.position, 10);
  db.prepare('DELETE FROM playlist_tracks WHERE playlist_id = ? AND position = ?').run(req.params.id, position);
  // Renumber positions to stay contiguous — simpler for reordering later than leaving
  // gaps, and the table is per-playlist small enough that this is cheap regardless.
  const remaining = db.prepare('SELECT id FROM playlist_tracks WHERE playlist_id = ? ORDER BY position').all(req.params.id);
  const renumber = db.prepare('UPDATE playlist_tracks SET position = ? WHERE id = ?');
  const tx = db.transaction((rows) => { rows.forEach((row, i) => renumber.run(i, row.id)); });
  tx(remaining);
  touchPlaylist(req.params.id);
  res.json(playlistWithTracks(req.params.id, req.user.id));
});

module.exports = router;
