const express = require('express');
const db = require('../lib/db');
const auth = require('../lib/auth');

const router = express.Router();

router.get('/', auth.requireAuth, (req, res) => {
  const row = db.prepare('SELECT * FROM playback_state WHERE user_id = ?').get(req.user.id);
  if (!row) return res.json(null);
  let queue = [];
  try { queue = JSON.parse(row.queue_json); } catch (e) {}
  res.json({
    trackId: row.track_id,
    positionSeconds: row.position_seconds,
    queue,
    queuePos: row.queue_pos,
    repeatMode: row.repeat_mode,
    shuffleEnabled: !!row.shuffle_enabled,
    sourceMode: row.source_mode,
    isPlaying: !!row.is_playing,
    updatedAt: row.updated_at,
    updatedByDevice: row.updated_by_device,
  });
});

// Every logged-in device (lib/db.js's sessions table) plus the single shared
// playback state — there's one playback position per ACCOUNT, not per device
// (Spotify-Connect-style continuity, not simultaneous multi-room control, same
// as the rest of this app's design) — so "which device is active" just means
// "which device most recently touched that shared state", and isPlaying on it
// tells the UI whether that's currently live playback or just a paused position.
router.get('/devices', auth.requireAuth, (req, res) => {
  const sessions = db.prepare('SELECT device_label, last_seen_at FROM sessions WHERE user_id = ? ORDER BY last_seen_at DESC').all(req.user.id);
  const state = db.prepare('SELECT track_id, is_playing, updated_by_device, updated_at FROM playback_state WHERE user_id = ?').get(req.user.id);
  res.json({
    devices: sessions.map(s => ({
      deviceLabel: s.device_label,
      lastSeenAt: s.last_seen_at,
      isThisDevice: s.device_label === req.user.deviceLabel,
    })),
    activeDevice: state ? state.updated_by_device : null,
    activeTrackId: state ? state.track_id : null,
    activeIsPlaying: state ? !!state.is_playing : false,
    activeUpdatedAt: state ? state.updated_at : null,
  });
});

// Server-side (per-account, not per-browser) storage for the learned connection
// throughput used to auto-pick a sustainable streaming quality tier. See the
// migration comment in lib/db.js for why this moved out of localStorage.
router.get('/throughput', auth.requireAuth, (req, res) => {
  const row = db.prepare('SELECT proven_throughput_bps, proven_throughput_at FROM playback_state WHERE user_id = ?').get(req.user.id);
  if (!row || row.proven_throughput_bps == null) return res.json(null);
  res.json({ bytesPerSec: row.proven_throughput_bps, atMs: row.proven_throughput_at });
});
router.post('/throughput', auth.requireAuth, (req, res) => {
  const { bytesPerSec } = req.body || {};
  if (typeof bytesPerSec !== 'number' || !isFinite(bytesPerSec) || bytesPerSec < 0) return res.status(400).json({ error: 'bytesPerSec must be a non-negative number' });
  // Upserts just these two columns — INSERT with defaults for the rest of the row
  // covers a brand-new account with no playback_state row yet; ON CONFLICT covers
  // the far more common case where one already exists from normal playback.
  db.prepare(`
    INSERT INTO playback_state (user_id, proven_throughput_bps, proven_throughput_at)
    VALUES (@userId, @bytesPerSec, strftime('%s','now') * 1000)
    ON CONFLICT(user_id) DO UPDATE SET
      proven_throughput_bps = excluded.proven_throughput_bps,
      proven_throughput_at = excluded.proven_throughput_at
  `).run({ userId: req.user.id, bytesPerSec });
  res.json({ ok: true });
});

// Upserts the whole state in one call — the client is expected to call this
// periodically during playback (every ~10-15s is plenty, this doesn't need
// to be per-frame) and on pause/track-change/seek, not on every tick.
router.post('/', auth.requireAuth, (req, res) => {
  const { trackId, positionSeconds, queue, queuePos, repeatMode, shuffleEnabled, sourceMode, isPlaying } = req.body || {};
  if (!Array.isArray(queue)) return res.status(400).json({ error: 'queue must be an array' });
  const queueJson = JSON.stringify(queue.slice(0, 2000)); // sane upper bound, not a hard product limit
  db.prepare(`
    INSERT INTO playback_state (user_id, track_id, position_seconds, queue_json, queue_pos, repeat_mode, shuffle_enabled, source_mode, is_playing, updated_at, updated_by_device)
    VALUES (@userId, @trackId, @positionSeconds, @queueJson, @queuePos, @repeatMode, @shuffleEnabled, @sourceMode, @isPlaying, strftime('%s','now'), @deviceLabel)
    ON CONFLICT(user_id) DO UPDATE SET
      track_id = excluded.track_id, position_seconds = excluded.position_seconds,
      queue_json = excluded.queue_json, queue_pos = excluded.queue_pos,
      repeat_mode = excluded.repeat_mode, shuffle_enabled = excluded.shuffle_enabled,
      source_mode = excluded.source_mode, is_playing = excluded.is_playing,
      updated_at = excluded.updated_at, updated_by_device = excluded.updated_by_device
  `).run({
    userId: req.user.id,
    trackId: trackId || null,
    positionSeconds: typeof positionSeconds === 'number' ? positionSeconds : 0,
    queueJson,
    queuePos: Number.isInteger(queuePos) ? queuePos : 0,
    repeatMode: ['off', 'all', 'one'].includes(repeatMode) ? repeatMode : 'off',
    shuffleEnabled: shuffleEnabled ? 1 : 0,
    sourceMode: ['local', 'network'].includes(sourceMode) ? sourceMode : 'local',
    isPlaying: isPlaying ? 1 : 0,
    deviceLabel: req.user.deviceLabel,
  });
  res.json({ ok: true });
});

module.exports = router;
