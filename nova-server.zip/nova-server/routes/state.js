const express = require('express');
const db = require('../lib/db');
const auth = require('../lib/auth');

const router = express.Router();

router.get('/', auth.requireAuth, (req, res) => {
  const row = db.prepare('SELECT * FROM playback_state WHERE user_id = ?').get(req.user.id);
  if (!row) return res.json(null);
  let queue = [];
  try { queue = JSON.parse(row.queue_json); } catch (e) {}
  res.json({
    trackId: row.track_id,
    positionSeconds: row.position_seconds,
    queue,
    queuePos: row.queue_pos,
    repeatMode: row.repeat_mode,
    shuffleEnabled: !!row.shuffle_enabled,
    sourceMode: row.source_mode,
    updatedAt: row.updated_at,
    updatedByDevice: row.updated_by_device,
  });
});

// Upserts the whole state in one call — the client is expected to call this
// periodically during playback (every ~10-15s is plenty, this doesn't need
// to be per-frame) and on pause/track-change/seek, not on every tick.
router.post('/', auth.requireAuth, (req, res) => {
  const { trackId, positionSeconds, queue, queuePos, repeatMode, shuffleEnabled, sourceMode } = req.body || {};
  if (!Array.isArray(queue)) return res.status(400).json({ error: 'queue must be an array' });
  const queueJson = JSON.stringify(queue.slice(0, 2000)); // sane upper bound, not a hard product limit
  db.prepare(`
    INSERT INTO playback_state (user_id, track_id, position_seconds, queue_json, queue_pos, repeat_mode, shuffle_enabled, source_mode, updated_at, updated_by_device)
    VALUES (@userId, @trackId, @positionSeconds, @queueJson, @queuePos, @repeatMode, @shuffleEnabled, @sourceMode, strftime('%s','now'), @deviceLabel)
    ON CONFLICT(user_id) DO UPDATE SET
      track_id = excluded.track_id, position_seconds = excluded.position_seconds,
      queue_json = excluded.queue_json, queue_pos = excluded.queue_pos,
      repeat_mode = excluded.repeat_mode, shuffle_enabled = excluded.shuffle_enabled,
      source_mode = excluded.source_mode, updated_at = excluded.updated_at,
      updated_by_device = excluded.updated_by_device
  `).run({
    userId: req.user.id,
    trackId: trackId || null,
    positionSeconds: typeof positionSeconds === 'number' ? positionSeconds : 0,
    queueJson,
    queuePos: Number.isInteger(queuePos) ? queuePos : 0,
    repeatMode: ['off', 'all', 'one'].includes(repeatMode) ? repeatMode : 'off',
    shuffleEnabled: shuffleEnabled ? 1 : 0,
    sourceMode: ['local', 'network'].includes(sourceMode) ? sourceMode : 'local',
    deviceLabel: req.user.deviceLabel,
  });
  res.json({ ok: true });
});

module.exports = router;
