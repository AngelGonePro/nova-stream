const express = require('express');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const musicBrowser = require('../lib/musicBrowser');
const libraryAccess = require('../lib/libraryAccess');
const pcmStream = require('../lib/pcmStream');
const logger = require('../lib/logger');

const router = express.Router();

const MIME_BY_EXT = {
  '.flac': 'audio/flac', '.wav': 'audio/wav', '.wave': 'audio/wav',
  '.aiff': 'audio/aiff', '.aif': 'audio/aiff', '.m4a': 'audio/mp4',
  '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.ape': 'audio/x-ape', '.wv': 'audio/x-wavpack',
};

// Straight-through file serve WITH Range support — kept as an alternate path
// (e.g. for a future "download original" feature), but /pcm below is what
// the player actually uses for playback: full server-side decode to raw PCM.
function serveWithRange(req, res, absPath) {
  const stat = fs.statSync(absPath);
  const ext = path.extname(absPath).toLowerCase();
  const mime = MIME_BY_EXT[ext] || 'application/octet-stream';
  const range = req.headers.range;

  if (!range) {
    res.writeHead(200, { 'Content-Type': mime, 'Content-Length': stat.size, 'Accept-Ranges': 'bytes' });
    fs.createReadStream(absPath).pipe(res);
    return;
  }
  const match = /^bytes=(\d*)-(\d*)$/.exec(range);
  if (!match) { res.writeHead(416, { 'Content-Range': `bytes */${stat.size}` }); return res.end(); }
  let start = match[1] ? parseInt(match[1], 10) : 0;
  let end = match[2] ? parseInt(match[2], 10) : stat.size - 1;
  if (isNaN(start) || isNaN(end) || start > end || end >= stat.size) {
    res.writeHead(416, { 'Content-Range': `bytes */${stat.size}` });
    return res.end();
  }
  res.writeHead(206, {
    'Content-Type': mime, 'Content-Range': `bytes ${start}-${end}/${stat.size}`,
    'Content-Length': end - start + 1, 'Accept-Ranges': 'bytes',
  });
  fs.createReadStream(absPath, { start, end }).pipe(res);
}

// Reduced-quality path for slow connections (e.g. accessing this server
// remotely while traveling): pipes the source through ffmpeg to a lower
// sample rate / bit depth FLAC on the fly, never writing a temp file.
// Range requests aren't meaningful against a live transcode, so this path
// doesn't support seeking mid-stream the way the direct path does — the
// client is expected to only use quality=reduced when it's already decided
// bandwidth is the constraint, not when the person wants to scrub around.
const QUALITY_PRESETS = {
  reduced: ['-ar', '32000', '-sample_fmt', 's16'],  // 32kHz/16-bit — still clean, ~40% of typical source bitrate
  minimal: ['-ar', '22050', '-sample_fmt', 's16'],  // 22.05kHz/16-bit — for genuinely poor connections
};
function serveTranscoded(req, res, absPath, presetArgs) {
  const ffmpegPath = process.env.FFMPEG_PATH || 'ffmpeg';
  const args = ['-hide_banner', '-loglevel', 'error', '-i', absPath, ...presetArgs, '-f', 'flac', 'pipe:1'];
  const ff = spawn(ffmpegPath, args);
  res.writeHead(200, { 'Content-Type': 'audio/flac', 'Accept-Ranges': 'none' });
  ff.stdout.pipe(res);
  ff.stderr.on('data', (d) => logger.error('[ffmpeg] ' + d.toString().trim()));
  ff.on('error', (err) => { logger.error('[ffmpeg] failed to start: ' + err.message); if (!res.headersSent) res.status(500).end(); });
  req.on('close', () => { try { ff.kill('SIGKILL'); } catch (e) {} });
}

router.get('/local', (req, res) => {
  let absPath;
  try {
    absPath = musicBrowser.fileAbsPath(req.query.path || '');
  } catch (e) {
    if (e.code === 'EOUTOFBOUNDS') return res.status(400).json({ error: 'Invalid path' });
    if (e.code === 'ENOENT') return res.status(404).json({ error: 'Not found' });
    if (e.code === 'ENOTFILE') return res.status(400).json({ error: 'Not a file' });
    return res.status(500).json({ error: 'Failed to open file' });
  }
  if (!libraryAccess.canAccess(req.user, req.query.path || '')) return res.status(403).json({ error: 'Not permitted' });
  const quality = req.query.quality;
  if (quality && QUALITY_PRESETS[quality]) {
    return serveTranscoded(req, res, absPath, QUALITY_PRESETS[quality]);
  }
  serveWithRange(req, res, absPath);
});

// Primary playback path: fully server-decoded raw PCM (16-bit, interleaved),
// so the client does no LMS/rANS/FLAC decode work at all — just accumulates
// bytes and writes them straight into an AudioBuffer. quality=reduced/
// minimal resamples down for slow connections (see lib/pcmStream.js for the
// exact presets and why 16-bit was chosen for this path specifically).
const VALID_PCM_QUALITIES = new Set(['full', 'reduced', 'minimal', 'ultra']);
router.get('/pcm', async (req, res) => {
  let absPath;
  try {
    absPath = musicBrowser.fileAbsPath(req.query.path || '');
  } catch (e) {
    if (e.code === 'EOUTOFBOUNDS') return res.status(400).json({ error: 'Invalid path' });
    if (e.code === 'ENOENT') return res.status(404).json({ error: 'Not found' });
    if (e.code === 'ENOTFILE') return res.status(400).json({ error: 'Not a file' });
    return res.status(500).json({ error: 'Failed to open file' });
  }
  if (!libraryAccess.canAccess(req.user, req.query.path || '')) return res.status(403).json({ error: 'Not permitted' });
  const quality = VALID_PCM_QUALITIES.has(req.query.quality) ? req.query.quality : 'full';
  // Real, confirmed architectural bug: resuming late in a track always redecoded
  // AND retransmitted the entire song from sample 0 forward, even though the
  // client only wants audio starting at the resume point. NOVA's adaptive
  // prediction genuinely needs sequential decode from 0 for correctness, but
  // decode itself is fast (measured ~7x realtime) — the actual bottleneck on a
  // slow connection is the NETWORK carrying data the client is just going to
  // discard anyway while it waits to catch up to the resume point. Confirmed via
  // real logs showing a rebuffer position that stayed essentially fixed (~78s)
  // regardless of buffer-size increases — the wrong signature for "runs dry after
  // N seconds of playback" and the right signature for "every resume attempt
  // pays the same fixed cost to re-transmit data it doesn't need," since a bigger
  // buffer does nothing to reduce how much has to cross the wire before playback
  // can even begin. skipToSeconds lets the server decode from 0 (correctness) but
  // withhold sending chunks over the network until decode reaches that point —
  // so resuming at any position costs roughly the same, small amount of network
  // transfer to get started, not an amount that grows with how far into the
  // track you're resuming.
  const skipToSeconds = Math.max(0, parseFloat(req.query.skipToSeconds) || 0);
  // Segmented delivery — the actual architectural fix, not another config tweak.
  // A single continuous HTTP response spanning a full multi-minute track has to
  // stay perfectly healthy the entire time; any transient hiccup anywhere along
  // a long real-world path can derail the whole thing, and recovering means
  // re-requesting from scratch. Real streaming services never do this — they
  // fetch in small, independent segments, so a single bad moment costs one
  // small retry, not the whole stream. maxDurationSeconds lets the client
  // request a bounded segment instead of "the rest of the track" — the server
  // gracefully ends the response once that much has been sent, exactly like
  // reaching the real end of the file.
  const maxDurationSeconds = req.query.maxDurationSeconds ? Math.max(1, parseFloat(req.query.maxDurationSeconds)) : null;
  try {
    await pcmStream.streamFileAsPCM(absPath, res, quality, skipToSeconds, maxDurationSeconds);
  } catch (e) {
    logger.error('[stream/pcm] ' + e.message, { stack: e.stack });
    if (!res.headersSent) res.status(500).json({ error: 'Failed to decode/stream audio' });
  }
});

// Explicit "done with this track" signal from the client — the primary PCM
// cache deletion path (the TTL sweep in lib/pcmCache.js is the safety net for
// when this never arrives at all, not the intended everyday mechanism). Fired
// whenever playback moves on from a track — see its call site in app.js for
// exactly when.
router.post('/pcm/release', (req, res) => {
  let absPath;
  try {
    absPath = musicBrowser.fileAbsPath(req.body && req.body.path || '');
  } catch (e) {
    // A release call for a path that's already gone, invalid, or was never
    // cached in the first place isn't a real error worth surfacing to the
    // client — there's nothing actionable it could do differently, and the
    // outcome (nothing to release) is the same either way.
    return res.json({ ok: true, released: false });
  }
  // Same defensive wrapping as streamFileAsPCM in pcmStream.js — this is a
  // best-effort cleanup call, never something that should be able to surface
  // as a hard failure to the client.
  let released = false;
  try {
    const pcmCache = require('../lib/pcmCache');
    released = pcmCache.releaseNow(absPath);
  } catch (e) {
    logger.error('[pcmCache] Release call failed: ' + e.message, { path: absPath });
  }
  res.json({ ok: true, released });
});

module.exports = router;
