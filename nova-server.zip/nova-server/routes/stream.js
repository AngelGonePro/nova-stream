const express = require('express');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const musicBrowser = require('../lib/musicBrowser');
const pcmStream = require('../lib/pcmStream');
const logger = require('../lib/logger');

const router = express.Router();

const MIME_BY_EXT = {
  '.flac': 'audio/flac', '.wav': 'audio/wav', '.wave': 'audio/wav',
  '.aiff': 'audio/aiff', '.aif': 'audio/aiff', '.m4a': 'audio/mp4',
  '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.ape': 'audio/x-ape', '.wv': 'audio/x-wavpack',
};

// Straight-through file serve WITH Range support — kept as an alternate path
// (e.g. for a future "download original" feature), but /pcm below is what
// the player actually uses for playback: full server-side decode to raw PCM.
function serveWithRange(req, res, absPath) {
  const stat = fs.statSync(absPath);
  const ext = path.extname(absPath).toLowerCase();
  const mime = MIME_BY_EXT[ext] || 'application/octet-stream';
  const range = req.headers.range;

  if (!range) {
    res.writeHead(200, { 'Content-Type': mime, 'Content-Length': stat.size, 'Accept-Ranges': 'bytes' });
    fs.createReadStream(absPath).pipe(res);
    return;
  }
  const match = /^bytes=(\d*)-(\d*)$/.exec(range);
  if (!match) { res.writeHead(416, { 'Content-Range': `bytes */${stat.size}` }); return res.end(); }
  let start = match[1] ? parseInt(match[1], 10) : 0;
  let end = match[2] ? parseInt(match[2], 10) : stat.size - 1;
  if (isNaN(start) || isNaN(end) || start > end || end >= stat.size) {
    res.writeHead(416, { 'Content-Range': `bytes */${stat.size}` });
    return res.end();
  }
  res.writeHead(206, {
    'Content-Type': mime, 'Content-Range': `bytes ${start}-${end}/${stat.size}`,
    'Content-Length': end - start + 1, 'Accept-Ranges': 'bytes',
  });
  fs.createReadStream(absPath, { start, end }).pipe(res);
}

// Reduced-quality path for slow connections (e.g. accessing this server
// remotely while traveling): pipes the source through ffmpeg to a lower
// sample rate / bit depth FLAC on the fly, never writing a temp file.
// Range requests aren't meaningful against a live transcode, so this path
// doesn't support seeking mid-stream the way the direct path does — the
// client is expected to only use quality=reduced when it's already decided
// bandwidth is the constraint, not when the person wants to scrub around.
const QUALITY_PRESETS = {
  reduced: ['-ar', '32000', '-sample_fmt', 's16'],  // 32kHz/16-bit — still clean, ~40% of typical source bitrate
  minimal: ['-ar', '22050', '-sample_fmt', 's16'],  // 22.05kHz/16-bit — for genuinely poor connections
};
function serveTranscoded(req, res, absPath, presetArgs) {
  const ffmpegPath = process.env.FFMPEG_PATH || 'ffmpeg';
  const args = ['-hide_banner', '-loglevel', 'error', '-i', absPath, ...presetArgs, '-f', 'flac', 'pipe:1'];
  const ff = spawn(ffmpegPath, args);
  res.writeHead(200, { 'Content-Type': 'audio/flac', 'Accept-Ranges': 'none' });
  ff.stdout.pipe(res);
  ff.stderr.on('data', (d) => logger.error('[ffmpeg] ' + d.toString().trim()));
  ff.on('error', (err) => { logger.error('[ffmpeg] failed to start: ' + err.message); if (!res.headersSent) res.status(500).end(); });
  req.on('close', () => { try { ff.kill('SIGKILL'); } catch (e) {} });
}

router.get('/local', (req, res) => {
  let absPath;
  try {
    absPath = musicBrowser.fileAbsPath(req.query.path || '');
  } catch (e) {
    if (e.code === 'EOUTOFBOUNDS') return res.status(400).json({ error: 'Invalid path' });
    if (e.code === 'ENOENT') return res.status(404).json({ error: 'Not found' });
    if (e.code === 'ENOTFILE') return res.status(400).json({ error: 'Not a file' });
    return res.status(500).json({ error: 'Failed to open file' });
  }
  const quality = req.query.quality;
  if (quality && QUALITY_PRESETS[quality]) {
    return serveTranscoded(req, res, absPath, QUALITY_PRESETS[quality]);
  }
  serveWithRange(req, res, absPath);
});

// Primary playback path: fully server-decoded raw PCM (16-bit, interleaved),
// so the client does no LMS/rANS/FLAC decode work at all — just accumulates
// bytes and writes them straight into an AudioBuffer. quality=reduced/
// minimal resamples down for slow connections (see lib/pcmStream.js for the
// exact presets and why 16-bit was chosen for this path specifically).
const VALID_PCM_QUALITIES = new Set(['full', 'reduced', 'minimal']);
router.get('/pcm', async (req, res) => {
  let absPath;
  try {
    absPath = musicBrowser.fileAbsPath(req.query.path || '');
  } catch (e) {
    if (e.code === 'EOUTOFBOUNDS') return res.status(400).json({ error: 'Invalid path' });
    if (e.code === 'ENOENT') return res.status(404).json({ error: 'Not found' });
    if (e.code === 'ENOTFILE') return res.status(400).json({ error: 'Not a file' });
    return res.status(500).json({ error: 'Failed to open file' });
  }
  const quality = VALID_PCM_QUALITIES.has(req.query.quality) ? req.query.quality : 'full';
  try {
    await pcmStream.streamFileAsPCM(absPath, res, quality);
  } catch (e) {
    logger.error('[stream/pcm] ' + e.message, { stack: e.stack });
    if (!res.headersSent) res.status(500).json({ error: 'Failed to decode/stream audio' });
  }
});

module.exports = router;
