require('dotenv').config();
const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const path = require('path');

const auth = require('./lib/auth');
const logger = require('./lib/logger');
const authRoutes = require('./routes/auth');
const browseRoutes = require('./routes/browse');
const streamRoutes = require('./routes/stream');
const stateRoutes = require('./routes/state');
const lastfmRoutes = require('./routes/lastfm');
const logsRoutes = require('./routes/logs');

// Fails loudly and immediately rather than starting in a half-configured
// state that only breaks once someone hits the affected feature — these are
// the two values every other module assumes exist.
for (const required of ['SESSION_SECRET', 'ENCRYPTION_KEY']) {
  if (!process.env[required] || process.env[required].startsWith('changeme')) {
    console.error(`[startup] ${required} is not set (or still the placeholder) in .env — refusing to start. See .env.example.`);
    process.exit(1);
  }
}

// Last-resort net for anything that escapes every route's own try/catch — without
// this, an uncaught exception in, say, an async callback with no surrounding handler
// would either crash the whole process silently or vanish with nothing recorded.
// Deliberately still exits after logging: swallowing an uncaught exception and
// continuing to run in a possibly-corrupted state is worse than a clean restart
// (the docker-compose "restart: unless-stopped" policy handles bringing it back up).
process.on('uncaughtException', (err) => {
  logger.error('Uncaught exception: ' + err.message, { stack: err.stack });
  process.exit(1);
});
process.on('unhandledRejection', (reason) => {
  const message = reason instanceof Error ? reason.message : String(reason);
  const stack = reason instanceof Error ? reason.stack : undefined;
  logger.error('Unhandled promise rejection: ' + message, { stack });
});

auth.ensureAdminAccount();

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '256kb' }));
app.use(cookieParser());
app.use(cors({ origin: process.env.PUBLIC_ORIGIN, credentials: true }));
app.use(auth.sessionMiddleware);

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.use('/api/auth', authRoutes);
app.use('/api/browse', auth.requireAuth, browseRoutes);
app.use('/api/stream', auth.requireAuth, streamRoutes);
app.use('/api/state', stateRoutes); // individual routes apply requireAuth themselves
app.use('/api/lastfm', lastfmRoutes); // individual routes apply requireAuth themselves
app.use('/api/logs', logsRoutes); // client-error reporting is unauthenticated; log viewing applies requireAdmin itself

// The standalone frontend for this backend — plain static files, no build step. Sits
// behind the same auth as everything else: the API routes above all still require
// their own login, this just serves the HTML/JS/CSS that calls them.
app.use(express.static(path.join(__dirname, 'public')));

// Generic error handler — catches anything a route didn't handle itself
// (thrown synchronous errors, malformed JSON bodies) so the response is
// always valid JSON, never an unhandled stack trace leaked to the client.
app.use((err, req, res, next) => {
  logger.error(err.message, { stack: err.stack, path: req.path, method: req.method });
  if (res.headersSent) return next(err);
  res.status(500).json({ error: 'Internal server error' });
});

const port = parseInt(process.env.PORT, 10) || 4533;
app.listen(port, () => {
  console.log(`[startup] nova-server listening on :${port}`);
  console.log(`[startup] MUSIC_DIR = ${process.env.MUSIC_DIR || '/data/music'}`);
  console.log(`[startup] error log: ${logger.LOG_PATH} (max ${logger.MAX_LINES} lines / ${(logger.MAX_BYTES/1024).toFixed(0)}KB)`);
});
