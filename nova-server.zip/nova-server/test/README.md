# Tests

`npm test` starts the real server, drives the real page in a real browser, and runs the page's real buffering code
against simulated events. The browser tests skip themselves if Playwright/ffmpeg aren't installed.

## "Does this update need an APK rebuild?"

`native-contract.json` is a snapshot of what the installed APK can do (messages it understands, callbacks it
invokes, settings it accepts). `contract.test.js` fails if the server-delivered page uses anything outside it.

- Test passes: the change is server-only. Deploy the server, done.
- Test fails with "REQUIRES AN APK REBUILD": the change needs a new native capability. Rebuild the APK, then run
  `node test/extract-android-contract.js ../nova-android` to refresh the snapshot.

Buffering behaviour (`NATIVE_PREBUFFER_SECONDS`, `NATIVE_REBUFFER_SECONDS`, `NATIVE_LOW_MARGIN_SECONDS` in `.env`)
is tunable from the server with no rebuild.
