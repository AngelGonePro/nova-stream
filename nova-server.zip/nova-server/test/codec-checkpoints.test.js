// A decode resumed from a checkpoint must produce exactly the samples a full decode produces from that point, for
// every predictor/cascade mode and channel count. This is what lets the server start decoding anywhere in a song.
const test = require('node:test'), assert = require('node:assert');
const NovaCodec = require('../lib/novaCodec');
const BLOCK = 4096;

function makeWav(numChannels, seconds, sr) {
  const n = Math.round(sr * seconds), channels = [];
  let seed = 7; const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296 - 0.5; };
  for (let c = 0; c < numChannels; c++) {
    const x = new Int32Array(n);
    for (let i = 0; i < n; i++) {
      const env = 0.5 + 0.5 * Math.sin(i / 9000 + c);
      x[i] = Math.round(env * 6000 * Math.sin(2 * Math.PI * (180 + 40 * c) * i / sr) + 2500 * Math.sin(2 * Math.PI * (2300 + 11 * c) * i / sr) + 900 * rnd() + (i % 30011 < 40 ? 7000 * rnd() : 0));
    }
    channels.push(x);
  }
  return { sampleRate: sr, numChannels, bitsPerSample: 16, numFrames: n, channels };
}
function decodeAll(bytes, opts, perChunk, snapEvery) {
  const d = NovaCodec.createStreamingDecoder(bytes, opts);
  const out = []; const snaps = [];
  while (!d.isDone()) {
    if (snapEvery && d.nextBlockIndex() % snapEvery === 0) snaps.push(d.snapshot());
    const ch = d.decodeNextChunk(perChunk);
    out.push({ start: ch.startSample, channels: ch.channels.map(a => Int32Array.from(a)) });
  }
  return { out, snaps };
}
const concat = (chunks, c, fromSample) => {
  const parts = chunks.filter(k => k.start >= fromSample).map(k => k.channels[c]);
  const len = parts.reduce((a, p) => a + p.length, 0), r = new Int32Array(len); let o = 0;
  for (const p of parts) { r.set(p, o); o += p.length; }
  return r;
};

for (const [name, ch, hc] of [['8ch, fast modes', 8, false], ['8ch, 128-order cascade (mode 3)', 8, true], ['stereo, 4-stage cascade (mode 4)', 2, true], ['stereo, fast modes', 2, false], ['mono', 1, true]]) {
  test(`resume from any checkpoint is bit-identical to a full decode — ${name}`, () => {
    const wav = makeWav(ch, 4.5, 48000);
    const bytes = new Uint8Array(NovaCodec.encode(wav, { tags: {}, picture: null }, null, { highCompression: hc }).buffer);
    const modes = NovaCodec.createStreamingDecoder(bytes).usesHighCompression;
    if (hc) assert.ok(modes, 'test signal must actually select a high-compression cascade');
    const ref = decodeAll(bytes, null, 3, 3);
    assert.ok(ref.snaps.length >= 4, 'several checkpoints');
    for (const snap of ref.snaps) {
      if (snap.blockIdx === 0) continue;
      const got = decodeAll(bytes, { resume: snap }, 3, 0);
      for (let c = 0; c < ch; c++) {
        const a = concat(ref.out, c, snap.startSample), b = concat(got.out, c, snap.startSample);
        assert.strictEqual(b.length, a.length, `channel ${c} length from block ${snap.blockIdx}`);
        assert.ok(a.every((v, i) => v === b[i]), `channel ${c} differs after resuming at block ${snap.blockIdx}`);
      }
    }
  });
}

test('a checkpoint survives being copied through structured clone (what a worker thread receives)', () => {
  const wav = makeWav(2, 3, 44100);
  const bytes = new Uint8Array(NovaCodec.encode(wav, { tags: {}, picture: null }, null, { highCompression: true }).buffer);
  const ref = decodeAll(bytes, null, 3, 3);
  const snap = structuredClone(ref.snaps[2]);
  const got = decodeAll(bytes, { resume: snap }, 3, 0);
  for (let c = 0; c < 2; c++) assert.ok(concat(ref.out, c, snap.startSample).every((v, i) => v === concat(got.out, c, snap.startSample)[i]));
});
