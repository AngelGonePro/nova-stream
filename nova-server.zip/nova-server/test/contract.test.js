// Verifies that the server-delivered page (public/app.js) only uses what the installed APK actually provides.
// If this fails, the change you just made needs an APK rebuild (or must be reworked to avoid it).
const test = require('node:test'), assert = require('node:assert'), fs = require('fs'), path = require('path');
const contract = JSON.parse(fs.readFileSync(path.join(__dirname, 'native-contract.json'), 'utf8'));
const app = fs.readFileSync(path.join(__dirname, '..', 'public', 'app.js'), 'utf8');

test('every message the page sends to the native app is one the APK handles', () => {
  const sent = new Set([...app.matchAll(/type:\s*'([A-Za-z]+)'/g)].map(m => m[1]));
  // `type:` also appears in non-bridge objects; only consider names that are posted to NovaNative.
  const posted = new Set();
  for (const m of app.matchAll(/NovaNative\.postMessage\(JSON\.stringify\(\{([\s\S]{0,600}?)\}\)\)/g)) {
    const t = m[1].match(/type:\s*'([A-Za-z]+)'/); if (t) posted.add(t[1]);
  }
  assert.ok(posted.size >= 10, 'could not find the page\'s native messages (code layout changed?)');
  const unknown = [...posted].filter(t => !contract.messages.includes(t));
  assert.deepStrictEqual(unknown, [], 'page sends messages the APK does not know -> REQUIRES AN APK REBUILD: ' + unknown.join(', '));
  assert.ok(sent.size >= posted.size);
});

test('every callback the APK invokes exists in the page', () => {
  const missing = contract.callbacks.filter(cb => !new RegExp('window\\.' + cb + '\\s*=').test(app));
  assert.deepStrictEqual(missing, [], 'APK calls functions the page no longer defines: ' + missing.join(', '));
});

test('every buffering setting the server sends is one the APK accepts', () => {
  const route = fs.readFileSync(path.join(__dirname, '..', 'routes', 'nativeConfig.js'), 'utf8');
  const keys = [...route.matchAll(/^\s+([a-zA-Z]+Seconds):\s*intFromEnv/gm)].map(m => m[1]);
  assert.ok(keys.length >= 3);
  const app = fs.readFileSync(path.join(__dirname, '..', 'public', 'app.js'), 'utf8');
  const pageOnly = k => new RegExp('const \\{[^}]*\\b' + k + ': \\w+[^}]*\\.\\.\\.nativeValues \\} = cfg').test(app); // page strips it before it reaches the engine
  assert.deepStrictEqual(keys.filter(k => !contract.configKeys.includes(k) && !pageOnly(k)), [], 'server sends settings the APK ignores');
});

test('.env.example documents every NATIVE_* variable the server reads', () => {
  const route = fs.readFileSync(path.join(__dirname, '..', 'routes', 'nativeConfig.js'), 'utf8');
  const env = fs.readFileSync(path.join(__dirname, '..', '.env.example'), 'utf8');
  for (const m of route.matchAll(/'(NATIVE_[A-Z_]+)'/g)) assert.ok(env.includes(m[1] + '='), m[1] + ' missing from .env.example');
});
