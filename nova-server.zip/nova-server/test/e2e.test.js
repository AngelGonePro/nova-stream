// Starts the real server and drives the real page in a real browser. Skips (not fails) if Playwright/Chromium/ffmpeg are unavailable.
const test = require('node:test'), assert = require('node:assert'), fs = require('fs'), os = require('os'), path = require('path');
const { spawn, execFileSync } = require('child_process');

function findPlaywright() {
  for (const p of ['playwright', '/opt/npm-tools/node_modules/playwright']) { try { return require(p); } catch (e) {} }
  return null;
}
const pw = findPlaywright();
let haveFfmpeg = true; try { execFileSync('ffmpeg', ['-version'], { stdio: 'ignore' }); } catch (e) { haveFfmpeg = false; }
const skip = !pw || !haveFfmpeg ? 'needs playwright + ffmpeg' : false;

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-e2e-'));
const port = 4700 + Math.floor(Math.random() * 200), base = `http://127.0.0.1:${port}`;
let srv, browser;

test.before(async () => {
  if (skip) return;
  fs.mkdirSync(path.join(tmp, 'music'));
  for (let n = 1; n <= 6; n++) execFileSync('ffmpeg', ['-loglevel', 'error', '-y', '-f', 'lavfi', '-i', `sine=frequency=${200 + n * 80}:duration=20`, '-metadata', `title=Song${n}`, path.join(tmp, 'music', `song${n}.wav`)]);
  srv = spawn('node', ['server.js'], { cwd: path.join(__dirname, '..'), env: { ...process.env, PORT: String(port), SESSION_SECRET: 'x'.repeat(40), ENCRYPTION_KEY: 'a'.repeat(64), MUSIC_DIR: path.join(tmp, 'music'), DB_PATH: path.join(tmp, 'n.sqlite'), LOG_PATH: path.join(tmp, 'e.log'), PCM_CACHE_DIR: path.join(tmp, 'pcm'), ADMIN_USERNAME: 'admin', ADMIN_PASSWORD: 'password123', PUBLIC_ORIGIN: base, NATIVE_REBUFFER_SECONDS: '7' } });
  await new Promise(r => setTimeout(r, 2500));
  try { browser = await pw.chromium.launch(); } catch (e) { browser = await pw.chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' }); }
});
test.after(async () => { if (browser) await browser.close(); if (srv) srv.kill(); fs.rmSync(tmp, { recursive: true, force: true }); });

async function device(label, initScript) {
  const ctx = await browser.newContext();
  if (initScript) await ctx.addInitScript(initScript);
  const r = await ctx.request.post(base + '/api/auth/login', { data: { username: 'admin', password: 'password123', deviceLabel: label } });
  assert.ok(r.ok(), 'login failed');
  const p = await ctx.newPage(); const errors = [];
  p.on('pageerror', e => errors.push(e.message));
  await p.goto(base + '/'); await p.waitForSelector('.track-row', { timeout: 15000 });
  return { ctx, p, errors };
}
// Queue entries show a file name until their tags arrive, so a title can change under a test that reads it twice. Reading until two
// reads half a second apart agree keeps comparisons from catching a title mid-change.
const qNames = async p => {
  const read = () => p.$$eval('#queueList .qName', e => e.map(x => x.textContent));
  let prev = await read();
  for (let i = 0; i < 20; i++) {
    await p.waitForTimeout(500);
    const cur = await read();
    if (JSON.stringify(cur) === JSON.stringify(prev)) return cur;
    prev = cur;
  }
  return prev;
};

test('app.js and index.html are served uncached, so server updates reach the app immediately', { skip }, async () => {
  const ctx = await browser.newContext();
  for (const f of ['/app.js', '/']) { const r = await ctx.request.get(base + f); assert.match(r.headers()['cache-control'] || '', /no-store/); }
});

test('playlist shuffle, play-next / add-to-end popup, and edit sync across devices', { skip, timeout: 90000 }, async () => {
  const A = await device('DevA'), B = await device('DevB');
  const ids = await A.p.$$eval('.track-row', e => e.map(x => x.dataset.id));
  const pl = await (await A.ctx.request.post(base + '/api/playlists', { data: { name: 'Vibes' } })).json();
  for (const id of ids) await A.ctx.request.post(`${base}/api/playlists/${pl.id}/tracks`, { data: { trackPath: id.replace(/^local:/, '') } });
  await A.p.reload(); await A.p.waitForSelector('.playlist-row');
  assert.ok(await A.p.isHidden('#playlistShuffleBtn'), 'shuffle hidden in library view');
  await A.p.click('.playlist-row'); await A.p.waitForSelector('#playlistShuffleBtn', { state: 'visible' });
  const orders = new Set();
  await A.p.click('#playlistShuffleBtn');
  assert.deepStrictEqual(await A.p.$$eval('#addToPlaylistMenu.open .aptRow', e => e.map(x => x.textContent)), ['Replace the queue and play', 'Add shuffled to end of queue'], 'shuffle asks what to do');
  await A.p.keyboard.press('Escape'); await A.p.evaluate(() => document.getElementById('addToPlaylistMenu').classList.remove('open'));
  for (let i = 0; i < 8; i++) { await A.p.click('#playlistShuffleBtn'); await A.p.click('#addToPlaylistMenu [data-shuffle-where=replace]'); await A.p.waitForTimeout(300); orders.add((await qNames(A.p)).join()); }
  const q = await qNames(A.p);
  assert.strictEqual(new Set(q).size, 6, 'shuffled queue contains every playlist track once'); assert.ok(orders.size > 1, 'shuffle produces different orders');

  await A.p.click('.track-row:nth-child(6) [data-add-id]');
  assert.deepStrictEqual(await A.p.$$eval('#addToPlaylistMenu.open .aptRow', e => e.map(x => x.textContent)), ['Play next', 'Add to end of queue']);
  const target = await A.p.$eval('.track-row:nth-child(6) .tName', e => e.textContent);
  const pos = await A.p.$$eval('#queueList .queue-row', e => e.findIndex(x => x.classList.contains('active')));
  await A.p.click('#addToPlaylistMenu [data-q-where=next]');
  let q2 = await qNames(A.p); assert.strictEqual(q2.length, 7); assert.strictEqual(q2[pos + 1], target, 'play next inserts right after the current track');
  const first = await A.p.$eval('.track-row:nth-child(1) .tName', e => e.textContent);
  await A.p.click('.track-row:nth-child(1) [data-add-id]'); await A.p.click('#addToPlaylistMenu [data-q-where=end]');
  q2 = await qNames(A.p); assert.strictEqual(q2.length, 8); assert.strictEqual(q2[7], first, 'add to end appends');
  await A.p.waitForTimeout(400);
  assert.strictEqual((await (await A.ctx.request.get(base + '/api/state')).json()).queue.length, 8, 'queue edits reach the server');

  // pause A so it is idle, then B (nothing loaded) must pick up A's queue without reloading
  await A.p.evaluate(() => { const b = document.getElementById('playPauseBtn'); if (/[⏸❚]/.test(b.textContent)) b.click(); });
  await B.p.waitForTimeout(9500);
  assert.deepStrictEqual(await qNames(B.p), q2, 'idle device receives the other device\'s queue');
  // B edits its (restored, unplayed) queue: the edit is saved and A, which has a track loaded, keeps its own queue
  const before = (await (await B.ctx.request.get(base + '/api/state')).json()).queue;
  await B.p.click('#queueList .queue-row:nth-child(8) [data-q-action=up]'); await B.p.waitForTimeout(500);
  const stB = await (await B.ctx.request.get(base + '/api/state')).json();
  const expected = before.slice(); [expected[6], expected[7]] = [expected[7], expected[6]];
  assert.deepStrictEqual(stB.queue, expected, 'B\'s queue edit (move up) is saved to the server');
  assert.deepStrictEqual(await qNames(A.p), q2, 'a device with its own loaded track is never overwritten by another device');
  assert.deepStrictEqual(A.errors.concat(B.errors), [], 'no page errors');
});

for (const [name, ack] of [['new APK (acknowledges config)', true], ['old APK (ignores config)', false]]) {
  test(`${name}: page pushes the server's buffering settings and keeps working`, { skip, timeout: 40000 }, async () => {
    const D = await device('Phone', `window.__msgs=[]; window.NovaNative={postMessage:m=>{window.__msgs.push(m); ${ack ? `if(JSON.parse(m).type==='setConfig') window.__novaNativeConfigApplied=true;` : ''}}};`);
    await D.p.waitForTimeout(3000);
    const cfg = await D.p.evaluate(() => window.__msgs.map(m => JSON.parse(m)).filter(m => m.type === 'setConfig'));
    assert.strictEqual(cfg.length, 1); assert.deepStrictEqual(cfg[0].values, { prebufferSeconds: 15, rebufferSeconds: 7, lowMarginSeconds: 6, surroundOutput: true });
    assert.strictEqual(await D.p.evaluate(() => !!window.__novaNativeConfigApplied), ack);
    assert.deepStrictEqual(D.errors, []);
  });
}

test('buffering settings endpoint requires login', { skip }, async () => {
  const ctx = await browser.newContext();
  assert.strictEqual((await ctx.request.get(base + '/api/native-config')).status(), 401);
});

test('warnings that arrive after a LONG prebuffer wait (audio starts late) are still graced', { skip, timeout: 40000 }, async () => {
  const D = await device('Phone', `window.__logs=[]; window.NovaNative={postMessage:m=>{const j=JSON.parse(m); if(j.type==='debugLog') window.__logs.push(j.message);}};`);
  await D.p.click('.track-row'); await D.p.waitForTimeout(1500);
  // simulate the track having been requested long ago: the request-time grace has expired, then audio finally starts
  await D.p.evaluate(() => { window.__realNow = Date.now; Date.now = () => window.__realNow() + 60000; });
  await D.p.evaluate(() => { window.__novaTrackAudioStarted(); for (let i = 0; i < 6; i++) window.__novaBufferMarginLow(i * 3); });
  const logs = await D.p.evaluate(() => window.__logs);
  assert.ok(logs.filter(l => /IGNORED/.test(l)).length >= 6, 'warnings right after audio start are ignored');
  assert.ok(!logs.some(l => /stepping down/.test(l)), 'no downgrade from the startup ramp');
  assert.deepStrictEqual(D.errors, []);
});

test('playlist: move up/down buttons reorder (UI and server, survives reload) and "Add to queue" appends the whole playlist', { skip, timeout: 90000 }, async () => {
  const A = await device('DevPL');
  const ids = await A.p.$$eval('.track-row', e => e.map(x => x.dataset.id));
  const pl = await (await A.ctx.request.post(base + '/api/playlists', { data: { name: 'Order' } })).json();
  for (const id of ids.slice(0, 4)) await A.ctx.request.post(`${base}/api/playlists/${pl.id}/tracks`, { data: { trackPath: id.replace(/^local:/, '') } });
  await A.p.reload(); await A.p.waitForSelector('.playlist-row');
  await A.p.click(`.playlist-row[data-pl-id="${pl.id}"]`); await A.p.waitForSelector('#playlistQueueBtn', { state: 'visible' });
  const names = () => A.p.$$eval('.track-row .tName', e => e.map(x => x.textContent));
  await A.p.waitForFunction(() => [...document.querySelectorAll('.track-row .tName')].every(e => !/\.wav$/.test(e.textContent)), null, { timeout: 15000 }); // titles loaded
  const orig = await names(); assert.strictEqual(orig.length, 4);
  assert.ok(await A.p.$eval('.track-row:nth-child(1) [data-pl-move=up]', e => e.disabled), 'first row cannot move up');
  assert.ok(await A.p.$eval('.track-row:nth-child(4) [data-pl-move=down]', e => e.disabled), 'last row cannot move down');
  await A.p.click('.track-row:nth-child(1) [data-pl-move=down]'); await A.p.waitForTimeout(400);
  assert.deepStrictEqual(await names(), [orig[1], orig[0], orig[2], orig[3]], 'down swaps with the next row');
  await A.p.click('.track-row:nth-child(4) [data-pl-move=up]'); await A.p.waitForTimeout(400);
  assert.deepStrictEqual(await names(), [orig[1], orig[0], orig[3], orig[2]], 'up swaps with the previous row');
  const want = [orig[1], orig[0], orig[3], orig[2]];
  const server = await (await A.ctx.request.get(`${base}/api/playlists/${pl.id}`)).json();
  assert.deepStrictEqual(server.trackPaths.map(p => p.split('/').pop()), (await A.p.$$eval('.track-row', e => e.map(x => x.dataset.id))).map(p => p.replace(/^local:/, '').split('/').pop()), 'server order matches the screen');
  await A.p.reload(); await A.p.waitForSelector('.playlist-row'); await A.p.click(`.playlist-row[data-pl-id="${pl.id}"]`); await A.p.waitForSelector('.track-row');
  await A.p.waitForFunction(() => [...document.querySelectorAll('.track-row .tName')].every(e => !/\.wav$/.test(e.textContent)), null, { timeout: 15000 });
  await A.p.waitForFunction(() => [...document.querySelectorAll('.track-row .tName')].every(e => !/\\.wav$/.test(e.textContent)), null, { timeout: 15000 });
  assert.deepStrictEqual(await names(), want, 'order survives a reload');
  // bad input is rejected, not applied
  const bad = await A.ctx.request.post(`${base}/api/playlists/${pl.id}/tracks/move`, { data: { from: 0, to: 99 } });
  assert.strictEqual(bad.status(), 400);
  // add to queue: nothing playing, so the queue is exactly the playlist in its new order; a second press appends again
  const n0 = (await qNames(A.p)).length;   // the account's queue may already hold songs from earlier use
  await A.p.click('#playlistQueueBtn'); await A.p.waitForTimeout(300);
  let qq = await qNames(A.p);
  assert.strictEqual(qq.length, n0 + 4); assert.deepStrictEqual(qq.slice(n0), want, 'whole playlist appended in its (reordered) order after what was already queued');
  await A.p.click('#playlistQueueBtn'); await A.p.waitForTimeout(300);
  qq = await qNames(A.p);
  assert.strictEqual(qq.length, n0 + 8); assert.deepStrictEqual(qq.slice(n0 + 4), want);
  // shuffle -> "Add shuffled to end of queue": existing queue untouched, the playlist's tracks (shuffled) are appended
  await A.p.click('#playlistShuffleBtn'); await A.p.click('#addToPlaylistMenu [data-shuffle-where=end]'); await A.p.waitForTimeout(300);
  const after = await qNames(A.p);
  assert.strictEqual(after.length, n0 + 12, 'existing queue kept, 4 shuffled tracks added');
  assert.deepStrictEqual(after.slice(0, n0 + 8), qq, 'existing queue left alone');
  assert.deepStrictEqual([...after.slice(n0 + 8)].sort(), [...want].sort(), 'shuffled playlist appended once each');
  assert.deepStrictEqual(A.errors, []);
});
