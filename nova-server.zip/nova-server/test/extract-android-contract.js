// Regenerates test/native-contract.json from the Android project's Kotlin source.
// Run this ONLY when you rebuild the APK:  node test/extract-android-contract.js ../nova-android
// The contract is what the installed APK can do; the tests then fail if server-delivered JS ever
// needs something the APK doesn't have (i.e. an update that would require a rebuild).
const fs = require('fs'), path = require('path');
const root = process.argv[2];
if (!root) { console.error('usage: node test/extract-android-contract.js <path to nova-android>'); process.exit(1); }
function walk(d) { return fs.readdirSync(d, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]); }
const kt = walk(root).filter(f => f.endsWith('.kt'));
const bridge = kt.find(f => f.endsWith('NativeAudioBridge.kt'));
if (!bridge) { console.error('NativeAudioBridge.kt not found'); process.exit(1); }
const src = fs.readFileSync(bridge, 'utf8');
const whenStart = src.indexOf('when (json.optString("type"))');
if (whenStart < 0) { console.error('message dispatch `when` not found in NativeAudioBridge.kt'); process.exit(1); }
const whenEnd = src.indexOf('else -> Log.w', whenStart);
if (whenEnd < 0) { console.error('end of message dispatch not found'); process.exit(1); }
const dispatch = src.slice(whenStart, whenEnd);
// top-level branches of the `when` only (they all sit at the same indentation as the first one)
const firstBranch = dispatch.match(/\n(\s+)"[A-Za-z]+"\s*->/);
const indent = firstBranch ? firstBranch[1] : '';
const messages = [...dispatch.matchAll(new RegExp('\\n' + indent + '"([A-Za-z]+)"\\s*->', 'g'))].map(m => m[1]);
const callbacks = new Set();
for (const f of kt) for (const m of fs.readFileSync(f, 'utf8').matchAll(/window\.(__nova[A-Za-z]+)\s*(?:&&|\()/g)) callbacks.add(m[1]);
// config keys the engine accepts from the server (setConfig)
const configKeys = [...src.matchAll(/v\.has\("([A-Za-z]+)"\)/g)].map(m => m[1]);
const out = { generatedFrom: 'NativeAudioBridge.kt', messages: [...new Set(messages)].sort(), callbacks: [...callbacks].sort(), configKeys: [...new Set(configKeys)].sort() };
fs.writeFileSync(path.join(__dirname, 'native-contract.json'), JSON.stringify(out, null, 2) + '\n');
console.log(JSON.stringify(out, null, 2));
