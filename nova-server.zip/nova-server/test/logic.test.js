// Runs the page's real buffering-policy code (extracted from public/app.js) against simulated stall/warning events.
const test = require('node:test'), assert = require('node:assert'), fs = require('fs'), vm = require('vm'), path = require('path');
const src = fs.readFileSync(path.join(__dirname, '..', 'public', 'app.js'), 'utf8');
function region(from, to) {
  const a = src.indexOf(from), b = src.indexOf(to, a + 1);
  assert.ok(a >= 0 && b > a, 'markers not found: ' + from.slice(0, 40));
  return src.slice(a, b);
}
const strip = code => code.replace(/^\s*let /gm, 'var ').replace(/^\s*const /gm, 'var ');

function makeStruggleEnv() {
  const env = { now: 1e6, logs: [], swaps: [], window: {} };
  const ctx = {
    setInterval() {}, setTimeout() {}, Math,
    Date: { now: () => env.now },
    nativeDebugLog: m => env.logs.push(m), nativeCurrentTrackId: 't1', trackById: id => ({ id }),
    nextTrackPrefetchSent: true, triggerSeamlessQualityChange: (t, q) => env.swaps.push(q),
    nativeSetPlayOffset() {}, currentTimeSec: () => 0, nativeUpdateNowPlaying() {}, isPlaying: true,
    nativePaused: false, nativePause() { ctx.nativePaused = true; }, nativeResume() {}, setNpStatusText() {},
    window: env.window,
  };
  vm.createContext(ctx);
  const code = strip(region('  let recentBufferingStarts = [];', '  // Real, direct fix for a confirmed, severe bug — a non-seamless'));
  vm.runInContext('var qualityMode="auto",autoQualityTierIndex=0,nativeClockRunning=true,lastKnownNativePositionSeconds=null,lastKnownNativePositionTrackId=null,AUTO_QUALITY_STEPS=["full","reduced","ultra","minimal"];' + code +
    ';this.setGrace=v=>{marginWarnGraceUntilMs=v};this.getGrace=()=>marginWarnGraceUntilMs;', ctx);
  env.ctx = ctx; return env;
}

test('low-margin warnings during the startup/swap grace never cause a downgrade', () => {
  const e = makeStruggleEnv(); e.ctx.setGrace(e.now + 30000);
  for (let i = 0; i < 20; i++) { e.now += 1000; e.window.__novaBufferMarginLow(i); }
  assert.deepStrictEqual(e.swaps, []);
  assert.ok(e.logs.some(l => /IGNORED/.test(l)));
});

test('sustained low-margin warnings after the grace still downgrade (adaptive quality keeps working)', () => {
  const e = makeStruggleEnv(); e.ctx.setGrace(0);
  for (let i = 0; i < 5; i++) { e.now += 3000; e.window.__novaBufferMarginLow(i); }
  assert.deepStrictEqual(e.swaps, ['reduced']);
});

test('real stalls are never graced', () => {
  const e = makeStruggleEnv(); e.ctx.setGrace(e.now + 30000);
  for (let i = 0; i < 5; i++) { e.now += 1000; e.window.__novaBufferingStateChanged(true, i, true); }
  assert.deepStrictEqual(e.swaps, ['reduced']);
});

function makeHoldEnv(configApplied) {
  const env = { now: 1e6, timers: [], log: [], window: { __novaNativeConfigApplied: configApplied } };
  const ctx = {
    Date: { now: () => env.now }, Math, window: env.window, nativeCurrentTrackId: 't', nativePaused: false,
    setTimeout: (f, ms) => { env.timers.push({ f, at: env.now + ms }); return env.timers.length - 1; },
    clearTimeout: id => { if (env.timers[id]) env.timers[id].dead = true; },
    nativeDebugLog: m => env.log.push(m), setNpStatusText() {},
    nativePause() { ctx.nativePaused = true; env.log.push('PAUSE'); },
    nativeResume() { env.log.push('RESUME'); ctx.nativePaused = false; },
  };
  vm.createContext(ctx);
  vm.runInContext(strip(region('  let rebufferHold = false', '  /**\n   * Real, direct addition for a confirmed follow-up')) + ';this.start=startRebufferHold;this.cancel=cancelRebufferHold;', ctx);
  env.ctx = ctx;
  env.advance = ms => { env.now += ms; env.timers.filter(t => !t.dead && t.at <= env.now).forEach(t => { t.dead = true; t.f(); }); };
  return env;
}

test('old APK (no config ack): a stall flood pauses once, resumes after 6s, doubles on a repeat', () => {
  const e = makeHoldEnv(undefined);
  for (let i = 0; i < 10; i++) e.ctx.start();
  assert.strictEqual(e.log.filter(x => x === 'PAUSE').length, 1);
  e.advance(5900); assert.ok(!e.log.includes('RESUME'));
  e.advance(200); assert.ok(e.log.includes('RESUME'));
  e.now += 1000; e.ctx.start(); assert.ok(e.log.some(l => /pausing 12s/.test(l)));
  e.advance(11000); assert.ok(e.ctx.nativePaused); e.advance(1500); assert.ok(!e.ctx.nativePaused);
  e.now += 70000; e.ctx.start(); assert.ok(e.log.filter(l => /pausing/.test(l)).pop().includes('6s'));
});

test('old APK: cancelling (user acts) prevents the automatic resume', () => {
  const e = makeHoldEnv(undefined);
  e.ctx.start(); e.ctx.cancel(); e.ctx.nativePaused = false;
  e.advance(60000); assert.ok(!e.log.includes('RESUME'));
});

test('new APK (config acknowledged): the page does not add its own pause', () => {
  const e = makeHoldEnv(true);
  for (let i = 0; i < 10; i++) e.ctx.start();
  assert.deepStrictEqual(e.log.filter(x => x === 'PAUSE'), []);
});

test('server defaults keep low-margin below rebuffer below prebuffer (equal values made the warning fire from the first second)', () => {
  const route = require('../routes/nativeConfig.js');
  let body; route.stack.find(l => l.route).route.stack[1].handle({}, { json: b => { body = b; } });
  assert.ok(body.lowMarginSeconds < body.rebufferSeconds, JSON.stringify(body));
  assert.ok(body.rebufferSeconds < body.prebufferSeconds, JSON.stringify(body));
});
