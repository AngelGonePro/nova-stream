// Runs the page's real buffering-policy code (extracted from public/app.js) against simulated stall/warning events.
const test = require('node:test'), assert = require('node:assert'), fs = require('fs'), vm = require('vm'), path = require('path');
const src = fs.readFileSync(path.join(__dirname, '..', 'public', 'app.js'), 'utf8');
function region(from, to) {
  const a = src.indexOf(from), b = src.indexOf(to, a + 1);
  assert.ok(a >= 0 && b > a, 'markers not found: ' + from.slice(0, 40));
  return src.slice(a, b);
}
const strip = code => code.replace(/^\s*let /gm, 'var ').replace(/^\s*const /gm, 'var ');

function makeStruggleEnv() {
  const env = { now: 1e6, logs: [], swaps: [], window: {} };
  const ctx = {
    setInterval() {}, setTimeout() {}, Math,
    Date: { now: () => env.now },
    nativeDebugLog: m => env.logs.push(m), nativeCurrentTrackId: 't1', nativeTrackDurationSeconds: 200, bestKnownPositionSeconds: () => 40, trackById: id => ({ id }),
    nextTrackPrefetchSent: true, triggerSeamlessQualityChange: (t, q) => env.swaps.push(q),
    nativeSetPlayOffset() {}, currentTimeSec: () => 0, nativeUpdateNowPlaying() {}, isPlaying: true,
    nativePaused: false, nativePause() { ctx.nativePaused = true; }, nativeResume() {}, setNpStatusText() {},
    window: env.window,
  };
  vm.createContext(ctx);
  const code = strip(region('  let recentBufferingStarts = [];', '  // Real, direct fix for a confirmed, severe bug — a non-seamless'));
  vm.runInContext('var qualityMode="auto",autoQualityTierIndex=0,nativeClockRunning=true,lastKnownNativePositionSeconds=null,lastKnownNativePositionTrackId=null,AUTO_QUALITY_STEPS=["full","reduced","ultra","minimal"];' + code +
    ';this.setGrace=v=>{marginWarnGraceUntilMs=v};this.getGrace=()=>marginWarnGraceUntilMs;', ctx);
  env.ctx = ctx; return env;
}

test('low-margin warnings during the startup/swap grace never cause a downgrade', () => {
  const e = makeStruggleEnv(); e.ctx.setGrace(e.now + 30000);
  for (let i = 0; i < 20; i++) { e.now += 1000; e.window.__novaBufferMarginLow(i); }
  assert.deepStrictEqual(e.swaps, []);
  assert.ok(e.logs.some(l => /IGNORED/.test(l)));
});

test('sustained low-margin warnings after the grace still downgrade (adaptive quality keeps working)', () => {
  const e = makeStruggleEnv(); e.ctx.setGrace(0);
  for (let i = 0; i < 5; i++) { e.now += 3000; e.window.__novaBufferMarginLow(i); }
  assert.deepStrictEqual(e.swaps, ['reduced']);
});

test('real stalls are never graced', () => {
  const e = makeStruggleEnv(); e.ctx.setGrace(e.now + 30000);
  for (let i = 0; i < 5; i++) { e.now += 1000; e.window.__novaBufferingStateChanged(true, i, true); }
  assert.deepStrictEqual(e.swaps, ['reduced']);
});

function makeHoldEnv(configApplied) {
  const env = { now: 1e6, timers: [], log: [], window: { __novaNativeConfigApplied: configApplied } };
  const ctx = {
    Date: { now: () => env.now }, Math, window: env.window, nativeCurrentTrackId: 't', nativePaused: false,
    setTimeout: (f, ms) => { env.timers.push({ f, at: env.now + ms }); return env.timers.length - 1; },
    clearTimeout: id => { if (env.timers[id]) env.timers[id].dead = true; },
    nativeDebugLog: m => env.log.push(m), setNpStatusText() {},
    nativePause() { ctx.nativePaused = true; env.log.push('PAUSE'); },
    nativeResume() { env.log.push('RESUME'); ctx.nativePaused = false; },
  };
  vm.createContext(ctx);
  vm.runInContext(strip(region('  let rebufferHold = false', '  /**\n   * Real, direct addition for a confirmed follow-up')) + ';this.start=startRebufferHold;this.cancel=cancelRebufferHold;', ctx);
  env.ctx = ctx;
  env.advance = ms => { env.now += ms; env.timers.filter(t => !t.dead && t.at <= env.now).forEach(t => { t.dead = true; t.f(); }); };
  return env;
}

test('old APK (no config ack): a stall flood pauses once, resumes after 6s, doubles on a repeat', () => {
  const e = makeHoldEnv(undefined);
  for (let i = 0; i < 10; i++) e.ctx.start();
  assert.strictEqual(e.log.filter(x => x === 'PAUSE').length, 1);
  e.advance(5900); assert.ok(!e.log.includes('RESUME'));
  e.advance(200); assert.ok(e.log.includes('RESUME'));
  e.now += 1000; e.ctx.start(); assert.ok(e.log.some(l => /pausing 12s/.test(l)));
  e.advance(11000); assert.ok(e.ctx.nativePaused); e.advance(1500); assert.ok(!e.ctx.nativePaused);
  e.now += 70000; e.ctx.start(); assert.ok(e.log.filter(l => /pausing/.test(l)).pop().includes('6s'));
});

test('old APK: cancelling (user acts) prevents the automatic resume', () => {
  const e = makeHoldEnv(undefined);
  e.ctx.start(); e.ctx.cancel(); e.ctx.nativePaused = false;
  e.advance(60000); assert.ok(!e.log.includes('RESUME'));
});

test('new APK (config acknowledged): the page does not add its own pause', () => {
  const e = makeHoldEnv(true);
  for (let i = 0; i < 10; i++) e.ctx.start();
  assert.deepStrictEqual(e.log.filter(x => x === 'PAUSE'), []);
});

test('server defaults keep low-margin below rebuffer below prebuffer (equal values made the warning fire from the first second)', () => {
  const route = require('../routes/nativeConfig.js');
  let body; route.stack.find(l => l.route).route.stack[1].handle({}, { json: b => { body = b; } });
  assert.ok(body.lowMarginSeconds < body.rebufferSeconds, JSON.stringify(body));
  assert.ok(body.rebufferSeconds < body.prebufferSeconds, JSON.stringify(body));
});

test('low margin while the next track downloads alongside: cancel that download first, do not downgrade; later warnings still count', () => {
  const e = makeStruggleEnv(); e.ctx.setGrace(0);
  const sent = []; e.window.NovaNative = { postMessage: m => sent.push(JSON.parse(m).type) };
  for (let i = 0; i < 5; i++) { e.now += 3000; e.window.__novaBufferMarginLow(i); }
  assert.deepStrictEqual(sent, ['stopNextTrackDownload'], 'prefetch cancelled exactly once');
  assert.deepStrictEqual(e.swaps, [], 'the first warning (caused by the competing download) must not count');
  for (let i = 0; i < 5; i++) { e.now += 3000; e.window.__novaBufferMarginLow(i); }
  assert.deepStrictEqual(e.swaps, ['reduced'], 'with the prefetch out of the way a real shortfall still steps down');
  assert.strictEqual(sent.length, 1);
});

test('a cancelled next-track download stays held until the current track is nearly over, then is released', () => {
  const e = makeStruggleEnv(); e.ctx.setGrace(0);
  e.window.NovaNative = { postMessage() {} };
  e.window.__novaBufferMarginLow(1);
  const { vm: _v } = {}; // (harness context is shared)
  const run = c => require('vm').runInContext(c, e.ctx);
  assert.strictEqual(run('prefetchStillHeld()'), true, 'held at 40s of a 200s track');
  run('bestKnownPositionSeconds = () => 150');
  assert.strictEqual(run('prefetchStillHeld()'), false, 'released with 50s left (<60)');
  run('bestKnownPositionSeconds = () => 40; resetPrefetchYield();');
  assert.strictEqual(run('prefetchYieldedThisTrack'), false, 'a new track starts clean');
});

test('a new track\'s next-track download is held from the start and only released in the final stretch', () => {
  const e = makeStruggleEnv();
  const run = c => require('vm').runInContext(c, e.ctx);
  run('resetPrefetchYield()');                       // what every track start / seamless swap does
  assert.strictEqual(run('prefetchStillHeld()'), true, 'held at 40s of a 200s track — must not compete with the current download');
  run('bestKnownPositionSeconds = () => 109');
  assert.strictEqual(run('prefetchStillHeld()'), true, '91s left, still held (lead is 90)');
  run('bestKnownPositionSeconds = () => 111');
  assert.strictEqual(run('prefetchStillHeld()'), false, '89s left, released');
});

test('a track shorter than the lead releases its prefetch immediately (no gap at the end of short songs)', () => {
  const e = makeStruggleEnv();
  const run = c => require('vm').runInContext(c, e.ctx);
  run('nativeTrackDurationSeconds = 70; bestKnownPositionSeconds = () => 2; resetPrefetchYield();');
  assert.strictEqual(run('prefetchStillHeld()'), false);
});

test('the real scheduling code never posts the prefetch while held, and posts it once released', () => {
  const e = makeStruggleEnv();
  const sent = []; e.window.NovaNative = { postMessage: m => sent.push(JSON.parse(m).type) };
  const run = c => require('vm').runInContext(c, e.ctx);
  const code = strip(region('  function scheduleOrSendNextTrackPrefetch(delayMs) {', '  window.__novaTrackDurationKnown'));
  run('var repeatMode="off",queue=["a","b"],queuePos=0,nextTrackPrefetchSent=false;function trackById(id){return {id,localPath:"/"+id}};function effectiveQuality(){return "full"};' + code);
  run('resetPrefetchYield(); scheduleOrSendNextTrackPrefetch(0);');
  assert.deepStrictEqual(sent, [], 'held: nothing sent');
  run('bestKnownPositionSeconds = () => 150; scheduleOrSendNextTrackPrefetch(0); scheduleOrSendNextTrackPrefetch(0);');
  assert.deepStrictEqual(sent, ['prepareNextTrackDownload'], 'released: sent exactly once');
});
