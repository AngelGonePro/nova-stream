// Runs the page's real buffering-policy code (extracted from public/app.js) against simulated stall/warning events.
const test = require('node:test'), assert = require('node:assert'), fs = require('fs'), vm = require('vm'), path = require('path');
const src = fs.readFileSync(path.join(__dirname, '..', 'public', 'app.js'), 'utf8');
function region(from, to) {
  const a = src.indexOf(from), b = src.indexOf(to, a + 1);
  assert.ok(a >= 0 && b > a, 'markers not found: ' + from.slice(0, 40));
  return src.slice(a, b);
}
const strip = code => code.replace(/^\s*let /gm, 'var ').replace(/^\s*const /gm, 'var ');

function makeStruggleEnv() {
  const env = { now: 1e6, logs: [], swaps: [], window: {} };
  const ctx = {
    setInterval() {}, setTimeout() {}, Math,
    Date: { now: () => env.now },
    nativeDebugLog: m => env.logs.push(m), nativeCurrentTrackId: 't1', api: () => Promise.reject(new Error('no server in this harness')), nativeTrackDurationSeconds: 200, bestKnownPositionSeconds: () => 40, trackById: id => ({ id }),
    nextTrackPrefetchSent: true, triggerSeamlessQualityChange: (t, q) => env.swaps.push(q),
    nativeSetPlayOffset() {}, currentTimeSec: () => 0, nativeUpdateNowPlaying() {}, isPlaying: true,
    nativePaused: false, nativePause() { ctx.nativePaused = true; }, nativeResume() {}, setNpStatusText() {},
    window: env.window,
  };
  vm.createContext(ctx);
  const code = strip(region('  let recentBufferingStarts = [];', '  // Real, direct fix for a confirmed, severe bug — a non-seamless'));
  vm.runInContext('var qualityMode="auto",autoQualityTierIndex=0,nativeClockRunning=true,lastKnownNativePositionSeconds=null,lastKnownNativePositionTrackId=null,AUTO_QUALITY_STEPS=["full","reduced","ultra","minimal"];' + code +
    ';this.setGrace=v=>{marginWarnGraceUntilMs=v};this.getGrace=()=>marginWarnGraceUntilMs;', ctx);
  env.ctx = ctx; return env;
}

test('low-margin warnings during the startup/swap grace never cause a downgrade', () => {
  const e = makeStruggleEnv(); e.ctx.setGrace(e.now + 30000);
  for (let i = 0; i < 20; i++) { e.now += 1000; e.window.__novaBufferMarginLow(i); }
  assert.deepStrictEqual(e.swaps, []);
  assert.ok(e.logs.some(l => /IGNORED/.test(l)));
});

test('sustained low-margin warnings after the grace still downgrade (adaptive quality keeps working)', () => {
  const e = makeStruggleEnv(); e.ctx.setGrace(0);
  for (let i = 0; i < 5; i++) { e.now += 3000; e.window.__novaBufferMarginLow(i); }
  assert.deepStrictEqual(e.swaps, ['reduced']);
});

test('real stalls are never graced', () => {
  const e = makeStruggleEnv(); e.ctx.setGrace(e.now + 30000);
  for (let i = 0; i < 5; i++) { e.now += 1000; e.window.__novaBufferingStateChanged(true, i, true); }
  assert.deepStrictEqual(e.swaps, ['reduced']);
});

function makeHoldEnv(configApplied) {
  const env = { now: 1e6, timers: [], log: [], window: { __novaNativeConfigApplied: configApplied } };
  const ctx = {
    Date: { now: () => env.now }, Math, window: env.window, nativeCurrentTrackId: 't', nativePaused: false,
    setTimeout: (f, ms) => { env.timers.push({ f, at: env.now + ms }); return env.timers.length - 1; },
    clearTimeout: id => { if (env.timers[id]) env.timers[id].dead = true; },
    nativeDebugLog: m => env.log.push(m), setNpStatusText() {},
    nativePause() { ctx.nativePaused = true; env.log.push('PAUSE'); },
    nativeResume() { env.log.push('RESUME'); ctx.nativePaused = false; },
  };
  vm.createContext(ctx);
  vm.runInContext(strip(region('  let rebufferHold = false', '  /**\n   * Real, direct addition for a confirmed follow-up')) + ';this.start=startRebufferHold;this.cancel=cancelRebufferHold;', ctx);
  env.ctx = ctx;
  env.advance = ms => { env.now += ms; env.timers.filter(t => !t.dead && t.at <= env.now).forEach(t => { t.dead = true; t.f(); }); };
  return env;
}

test('old APK (no config ack): a stall flood pauses once, resumes after 6s, doubles on a repeat', () => {
  const e = makeHoldEnv(undefined);
  for (let i = 0; i < 10; i++) e.ctx.start();
  assert.strictEqual(e.log.filter(x => x === 'PAUSE').length, 1);
  e.advance(5900); assert.ok(!e.log.includes('RESUME'));
  e.advance(200); assert.ok(e.log.includes('RESUME'));
  e.now += 1000; e.ctx.start(); assert.ok(e.log.some(l => /pausing 12s/.test(l)));
  e.advance(11000); assert.ok(e.ctx.nativePaused); e.advance(1500); assert.ok(!e.ctx.nativePaused);
  e.now += 70000; e.ctx.start(); assert.ok(e.log.filter(l => /pausing/.test(l)).pop().includes('6s'));
});

test('old APK: cancelling (user acts) prevents the automatic resume', () => {
  const e = makeHoldEnv(undefined);
  e.ctx.start(); e.ctx.cancel(); e.ctx.nativePaused = false;
  e.advance(60000); assert.ok(!e.log.includes('RESUME'));
});

test('new APK (config acknowledged): the page does not add its own pause', () => {
  const e = makeHoldEnv(true);
  for (let i = 0; i < 10; i++) e.ctx.start();
  assert.deepStrictEqual(e.log.filter(x => x === 'PAUSE'), []);
});

test('server defaults keep low-margin below rebuffer below prebuffer (equal values made the warning fire from the first second)', () => {
  const route = require('../routes/nativeConfig.js');
  let body; route.stack.find(l => l.route).route.stack[1].handle({}, { json: b => { body = b; } });
  assert.ok(body.lowMarginSeconds < body.rebufferSeconds, JSON.stringify(body));
  assert.ok(body.rebufferSeconds < body.prebufferSeconds, JSON.stringify(body));
});

test('low margin while the next track downloads alongside: cancel that download first, do not downgrade; later warnings still count', () => {
  const e = makeStruggleEnv(); e.ctx.setGrace(0);
  const sent = []; e.window.NovaNative = { postMessage: m => sent.push(JSON.parse(m).type) };
  for (let i = 0; i < 5; i++) { e.now += 3000; e.window.__novaBufferMarginLow(i); }
  assert.deepStrictEqual(sent, ['stopNextTrackDownload'], 'prefetch cancelled exactly once');
  assert.deepStrictEqual(e.swaps, [], 'the first warning (caused by the competing download) must not count');
  for (let i = 0; i < 5; i++) { e.now += 3000; e.window.__novaBufferMarginLow(i); }
  assert.deepStrictEqual(e.swaps, ['reduced'], 'with the prefetch out of the way a real shortfall still steps down');
  assert.strictEqual(sent.length, 1);
});

test('a cancelled next-track download stays held until the current track is nearly over, then is released', () => {
  const e = makeStruggleEnv(); e.ctx.setGrace(0);
  e.window.NovaNative = { postMessage() {} };
  e.window.__novaBufferMarginLow(1);
  const { vm: _v } = {}; // (harness context is shared)
  const run = c => require('vm').runInContext(c, e.ctx);
  assert.strictEqual(run('prefetchStillHeld()'), true, 'held at 40s of a 200s track');
  run('bestKnownPositionSeconds = () => 150');
  assert.strictEqual(run('prefetchStillHeld()'), false, 'released with 50s left (<60)');
  run('bestKnownPositionSeconds = () => 40; resetPrefetchYield();');
  assert.strictEqual(run('prefetchYieldedThisTrack'), false, 'a new track starts clean');
});

test('a new track\'s next-track download is held from the start and only released in the final stretch', () => {
  const e = makeStruggleEnv();
  const run = c => require('vm').runInContext(c, e.ctx);
  run('resetPrefetchYield()');                       // what every track start / seamless swap does
  assert.strictEqual(run('prefetchStillHeld()'), true, 'held at 40s of a 200s track — must not compete with the current download');
  run('bestKnownPositionSeconds = () => 109');
  assert.strictEqual(run('prefetchStillHeld()'), true, '91s left, still held (lead is 90)');
  run('bestKnownPositionSeconds = () => 111');
  assert.strictEqual(run('prefetchStillHeld()'), false, '89s left, released');
});

test('a track shorter than the lead releases its prefetch immediately (no gap at the end of short songs)', () => {
  const e = makeStruggleEnv();
  const run = c => require('vm').runInContext(c, e.ctx);
  run('nativeTrackDurationSeconds = 70; bestKnownPositionSeconds = () => 2; resetPrefetchYield();');
  assert.strictEqual(run('prefetchStillHeld()'), false);
});

test('the real scheduling code never posts the prefetch while held, and posts it once released', () => {
  const e = makeStruggleEnv();
  const sent = []; e.window.NovaNative = { postMessage: m => sent.push(JSON.parse(m).type) };
  const run = c => require('vm').runInContext(c, e.ctx);
  const code = strip(region('  function scheduleOrSendNextTrackPrefetch(delayMs) {', '  window.__novaTrackDurationKnown'));
  run('var repeatMode="off",queue=["a","b"],queuePos=0,nextTrackPrefetchSent=false;function trackById(id){return {id,localPath:"/"+id}};function effectiveQuality(){return "full"};' + code);
  run('resetPrefetchYield(); scheduleOrSendNextTrackPrefetch(0);');
  assert.deepStrictEqual(sent, [], 'held: nothing sent');
  run('bestKnownPositionSeconds = () => 150; scheduleOrSendNextTrackPrefetch(0); scheduleOrSendNextTrackPrefetch(0);');
  assert.deepStrictEqual(sent, ['prepareNextTrackDownload'], 'released: sent exactly once');
});

test('one real stall steps the quality down at once; the new stream\'s own start-up cannot cascade into another step', () => {
  const e = makeStruggleEnv(); e.ctx.setGrace(0);
  e.window.__novaBufferingStateChanged(true, 20, true);
  assert.deepStrictEqual(e.swaps, ['reduced'], 'first real stall steps down immediately');
  e.now += 10000; e.window.__novaBufferingStateChanged(true, 21, true);
  assert.deepStrictEqual(e.swaps, ['reduced'], 'a stall 10s later (inside the cooldown) does not step again');
  e.now += 30000; e.window.__novaBufferingStateChanged(true, 60, true);
  assert.deepStrictEqual(e.swaps, ['reduced', 'ultra'], 'a stall after the cooldown steps again');
});

test('the tier is remembered, and a step up that does not hold makes the next attempt wait twice as long', () => {
  const e = makeStruggleEnv(); e.ctx.setGrace(0);
  const stored = {}; const run = c => require('vm').runInContext(c, e.ctx);
  e.ctx.localStorage = { setItem: (k, v) => { stored[k] = v; } };
  e.window.__novaBufferingStateChanged(true, 20, true);
  assert.strictEqual(JSON.parse(stored.novaAutoTier).i, 1, 'tier persisted for the next session');
  run('lastUpgradeMs = Date.now() - 60000'); // pretend a climb happened a minute ago
  e.now += 30000; e.window.__novaBufferingStateChanged(true, 80, true);
  assert.strictEqual(run('upgradeQuietMs'), 180000, 'failed climb: wait doubles from 90s to 180s');
});

// ---- connection probe -----------------------------------------------------------------------------------------
function makeProbeEnv(startIdx) {
  const env = makeStruggleEnv();
  const ctx = env.ctx, run = c => require('vm').runInContext(c, ctx);
  ctx.AbortController = AbortController; ctx.fetch = undefined;
  ctx.trackById = id => ({ id, numChannels: 8 }); ctx.queue = []; ctx.queuePos = -1;
  run(`autoQualityTierIndex=${startIdx};AUTO_QUALITY_STEPS=["full","stereo","stereo-reduced","stereo-ultra","stereo-minimal"];`);
  env.measure = kbps => { ctx.measureConnectionBytesPerSec = async () => ({ bytesPerSec: kbps * 1024, bytes: 1e6, secs: 2 }); };
  env.idx = () => run('autoQualityTierIndex');
  env.window.NovaNative = { postMessage() {} };
  return env;
}
test('probe: WiFi-class link keeps full; cellular-class links pick the highest stereo tier they can carry with headroom', async () => {
  const cases = [[3000, 0], [1200, 0], [700, 1], [300, 1], [200, 2], [150, 3], [120, 4], [40, 4]]; // KB/s -> tier index (full 8ch needs 750KB/s x1.5)
  for (const [kbps, want] of cases) {
    const e = makeProbeEnv(0); e.measure(kbps); e.ctx.isPlaying = false; e.ctx.nativeCurrentTrackId = null;
    await require('vm').runInContext('probeConnectionAndApplyQuality("login")', e.ctx);
    assert.strictEqual(e.idx(), want, `${kbps}KB/s should give tier ${want}`);
  }
});
test('probe: moving from cellular back to WiFi climbs straight to the right tier, and a swap is requested while playing', async () => {
  const e = makeProbeEnv(3); e.measure(4000); e.ctx.isPlaying = true; e.ctx.nativeCurrentTrackId = 't1';
  await require('vm').runInContext('probeConnectionAndApplyQuality("network-change")', e.ctx);
  assert.strictEqual(e.idx(), 0);
  assert.deepStrictEqual(e.swaps, ['full']);
});
test('probe: a reading taken while a song is downloading is treated as a floor (not as proof the link is slow)', async () => {
  const idle = makeProbeEnv(0); idle.measure(800); idle.ctx.isPlaying = false; idle.ctx.nativeCurrentTrackId = null;
  await require('vm').runInContext('probeConnectionAndApplyQuality("login")', idle.ctx);
  const busy = makeProbeEnv(0); busy.measure(800); busy.ctx.isPlaying = true; busy.ctx.nativeCurrentTrackId = 't1';
  await require('vm').runInContext('probeConnectionAndApplyQuality("network-change")', busy.ctx);
  assert.ok(busy.idx() < idle.idx(), 'busy link gets a better tier than the same reading on an idle one (idle=' + idle.idx() + ', busy=' + busy.idx() + ')');
});
test('probe: a failed probe changes nothing', async () => {
  const e = makeProbeEnv(2); e.ctx.measureConnectionBytesPerSec = async () => { throw new Error('offline'); };
  await require('vm').runInContext('probeConnectionAndApplyQuality("online")', e.ctx);
  assert.strictEqual(e.idx(), 2); assert.deepStrictEqual(e.swaps, []);
});
test('probe: manual quality mode is never touched', async () => {
  const e = makeProbeEnv(0); e.measure(40); require('vm').runInContext('qualityMode="full"', e.ctx);
  await require('vm').runInContext('probeConnectionAndApplyQuality("login")', e.ctx);
  assert.strictEqual(e.idx(), 0);
});
