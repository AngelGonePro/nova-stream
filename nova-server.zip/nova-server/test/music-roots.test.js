// MUSIC_ROOTS: several folders and hand-picked files under one virtual library (desktop "Local library"); unset = unchanged.
const test = require('node:test'), assert = require('node:assert'), fs = require('fs'), os = require('os'), path = require('path');
const { spawnSync } = require('child_process');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-roots-'));
test.after(() => fs.rmSync(tmp, { recursive: true, force: true }));
const touch = (...p) => { fs.mkdirSync(path.dirname(path.join(tmp, ...p)), { recursive: true }); fs.writeFileSync(path.join(tmp, ...p), 'x'); };
touch('A', 'one.flac'); touch('A', 'sub', 'two.nova'); touch('A', 'sub', 'notes.txt'); touch('B', 'x.wav'); touch('loose', 'p', 'same.mp3'); touch('loose', 'q', 'same.mp3'); touch('loose', 'q', 'other.flac');
fs.writeFileSync(path.join(os.tmpdir(), 'nova-roots-secret.flac'), 'secret'); // outside every root
fs.symlinkSync(path.join(os.tmpdir(), 'nova-roots-secret.flac'), path.join(tmp, 'A', 'link.flac'));

// each case runs in a fresh process: the module reads its env once, when loaded
const run = (env, code) => {
  const r = spawnSync(process.execPath, ['-e', `const mb=require(${JSON.stringify(path.join(__dirname, '..', 'lib', 'musicBrowser'))});const out=(()=>{${code}})();console.log(JSON.stringify(out));`], { env: { ...process.env, ...env }, encoding: 'utf8' });
  if (r.status !== 0) throw new Error(r.stderr);
  return JSON.parse(r.stdout);
};
const ROOTS = JSON.stringify([{ name: 'Music A', dir: path.join(tmp, 'A') }, { name: 'B', dir: path.join(tmp, 'B') }, { name: 'Picked', files: [path.join(tmp, 'loose', 'p', 'same.mp3'), path.join(tmp, 'loose', 'q', 'same.mp3'), path.join(tmp, 'loose', 'q', 'other.flac'), path.join(tmp, 'A', 'sub', 'notes.txt')] }]);

test('the top level lists the roots; folders and picked files list like the normal library, with root-prefixed ids', () => {
  assert.deepStrictEqual(run({ MUSIC_ROOTS: ROOTS }, `return mb.listDirectory('')`), { path: '', dirs: [{ name: 'B', path: 'B' }, { name: 'Music A', path: 'Music A' }, { name: 'Picked', path: 'Picked' }], files: [] });
  const a = run({ MUSIC_ROOTS: ROOTS }, `return mb.listDirectory('Music A')`);
  assert.deepStrictEqual(a.dirs, [{ name: 'sub', path: 'Music A/sub' }]);
  assert.deepStrictEqual(a.files.map((f) => f.path), ['Music A/one.flac'] /* a symlink is not listed, as in the normal library */);
  assert.deepStrictEqual(run({ MUSIC_ROOTS: ROOTS }, `return mb.listDirectory('Music A/sub').files.map(f=>f.path)`), ['Music A/sub/two.nova'], 'non-audio files are left out');
  const p = run({ MUSIC_ROOTS: ROOTS }, `return mb.listDirectory('Picked').files.map(f=>f.path)`);
  assert.deepStrictEqual(p, ['Picked/other.flac', 'Picked/same (2).mp3', 'Picked/same.mp3'], 'two picked files with one name both stay, and non-audio picks are ignored');
  assert.strictEqual(run({ MUSIC_ROOTS: ROOTS }, `return mb.fileAbsPath('Picked/same (2).mp3')`), path.join(tmp, 'loose', 'q', 'same.mp3'));
  assert.strictEqual(run({ MUSIC_ROOTS: ROOTS }, `return mb.fileAbsPath('B/x.wav')`), path.join(tmp, 'B', 'x.wav'));
});
test('nothing outside the roots can be reached: traversal, symlinks out, the virtual top level, unknown roots', () => {
  const code = (c) => `try { ${c}; return 'reached'; } catch (e) { return e.code; }`;
  assert.strictEqual(run({ MUSIC_ROOTS: ROOTS }, code(`mb.fileAbsPath('Music A/../B/x.wav')`)), 'EOUTOFBOUNDS');
  assert.strictEqual(run({ MUSIC_ROOTS: ROOTS }, code(`mb.fileAbsPath('Music A/link.flac')`)), 'EOUTOFBOUNDS');
  assert.strictEqual(run({ MUSIC_ROOTS: ROOTS }, code(`mb.fileAbsPath('')`)), 'EOUTOFBOUNDS');
  assert.strictEqual(run({ MUSIC_ROOTS: ROOTS }, code(`mb.fileAbsPath('Nope/x.wav')`)), 'ENOENT');
  assert.strictEqual(run({ MUSIC_ROOTS: ROOTS }, code(`mb.fileAbsPath('Picked/notes.txt')`)), 'ENOENT', 'a picked non-audio file is not in the library');
  assert.strictEqual(run({ MUSIC_ROOTS: ROOTS }, code(`mb.listDirectory('Picked/sub')`)), 'ENOTDIR');
  assert.strictEqual(run({ MUSIC_ROOTS: ROOTS }, code(`mb.fileAbsPath('Music A/missing.flac')`)), 'ENOENT');
});
test('without MUSIC_ROOTS the server library works exactly as before', () => {
  assert.deepStrictEqual(run({ MUSIC_DIR: path.join(tmp, 'A'), MUSIC_ROOTS: '' }, `return mb.listDirectory('sub')`), { path: 'sub', dirs: [], files: [{ name: 'two.nova', path: 'sub/two.nova', sizeBytes: 1, ext: '.nova' }] });
  assert.strictEqual(run({ MUSIC_DIR: path.join(tmp, 'A'), MUSIC_ROOTS: '' }, `try { mb.fileAbsPath('../B/x.wav'); return 'reached'; } catch (e) { return e.code; }`), 'EOUTOFBOUNDS');
});
