// The compressed transport (/api/stream/pcm?enc=z): every tier, live-decode and cache paths, with and without a skip /
// segment length, must decode back to exactly the bytes the plain PCM response carries, and be smaller on the wire.
const test = require('node:test'), assert = require('node:assert'), fs = require('fs'), os = require('os'), path = require('path');
const { spawn } = require('child_process');
const NovaCodec = require('../lib/novaCodec');
const toAB = (b) => b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-z-'));
const port = 5100 + Math.floor(Math.random() * 40), base = `http://127.0.0.1:${port}`;
const SR = 48000, SECS = 11, CH = 8;
let srv, cookie, errOut = '';

function writeNova(name) {
  const frames = SR * SECS, data = Buffer.alloc(frames * CH * 2);
  let seed = 12345; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff - 0.5;
  for (let i = 0; i < frames; i++) for (let c = 0; c < CH; c++) data.writeInt16LE(Math.round(6000 * Math.sin(2 * Math.PI * (200 + c * 90) * i / SR) + 900 * rnd()), (i * CH + c) * 2);
  const h = Buffer.alloc(44);
  h.write('RIFF', 0); h.writeUInt32LE(36 + data.length, 4); h.write('WAVEfmt ', 8); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20);
  h.writeUInt16LE(CH, 22); h.writeUInt32LE(SR, 24); h.writeUInt32LE(SR * CH * 2, 28); h.writeUInt16LE(CH * 2, 32); h.writeUInt16LE(16, 34);
  h.write('data', 36); h.writeUInt32LE(data.length, 40);
  const wav = NovaCodec.parseWav(toAB(Buffer.concat([h, data])));
  fs.writeFileSync(path.join(tmp, 'music', name + '.nova'), Buffer.from(NovaCodec.encode(wav, { tags: { title: name }, picture: null }).buffer));
}
test.before(async () => {
  fs.mkdirSync(path.join(tmp, 'music')); writeNova('song');
  srv = spawn('node', ['server.js'], { cwd: path.join(__dirname, '..'), env: { ...process.env, PORT: String(port), SESSION_SECRET: 'x'.repeat(40), ENCRYPTION_KEY: 'a'.repeat(64), MUSIC_DIR: path.join(tmp, 'music'), DB_PATH: path.join(tmp, 'n.sqlite'), LOG_PATH: '/tmp/novaz-e.log', PCM_CACHE_DIR: path.join(tmp, 'pcm'), ADMIN_USERNAME: 'admin', ADMIN_PASSWORD: 'password123', PUBLIC_ORIGIN: base } });
  srv.stderr.on('data', d => errOut += d); srv.stdout.on('data', d => errOut += d);
  for (let i = 0; i < 60; i++) { try { await fetch(base + '/api/auth/login', { method: 'OPTIONS' }); break; } catch (e) { await new Promise(r => setTimeout(r, 250)); } }
  const r = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: 'admin', password: 'password123', deviceLabel: 't' }) });
  assert.ok(r.ok, 'login ' + r.status); cookie = r.headers.getSetCookie().map(c => c.split(';')[0]).join('; ');
});
test.after(() => { if (srv) srv.kill(); fs.rmSync(tmp, { recursive: true, force: true }); });

async function get(quality, skip, dur, z) {
  const q = `path=song.nova&quality=${quality}&skipToSeconds=${skip}` + (dur ? `&maxDurationSeconds=${dur}` : '') + (z ? '&enc=z' : '');
  const r = await fetch(`${base}/api/stream/pcm?${q}`, { headers: { cookie } });
  assert.strictEqual(r.status, 200, `${quality} HTTP ${r.status} ${await r.clone().text()} ${errOut.slice(-900)}`);
  return { r, buf: Buffer.from(await r.arrayBuffer()) };
}
function unframe(buf, ch) { // [u32 length][NOVA file]... -> interleaved s16le
  const out = []; let o = 0;
  while (o < buf.length) {
    const n = buf.readUInt32BE(o); o += 4;
    const d = NovaCodec.decode(new Uint8Array(buf.subarray(o, o + n))); o += n;
    assert.strictEqual(d.numChannels, ch);
    const pcm = Buffer.alloc(d.numFrames * ch * 2);
    for (let i = 0; i < d.numFrames; i++) for (let c = 0; c < ch; c++) pcm.writeInt16LE(d.channels[c][i], (i * ch + c) * 2);
    out.push(pcm);
  }
  assert.strictEqual(o, buf.length, 'frames must end exactly at the end of the body');
  return Buffer.concat(out);
}
for (const pass of ['live decode', 'cache']) {
  for (const [quality, skip, dur] of [['full', 0, null], ['full', 3, 5], ['reduced', 0, 7], ['stereo', 2, null], ['minimal', 0, null]]) {
    test(`enc=z is bit-exact: ${quality} skip=${skip} dur=${dur} (${pass})`, async () => {
      const plain = await get(quality, skip, dur, false);
      const z = await get(quality, skip, dur, true);
      assert.strictEqual(z.r.headers.get('x-pcm-encoding'), 'nova-z');
      for (const h of ['x-pcm-sample-rate', 'x-pcm-channels', 'x-pcm-total-frames', 'x-pcm-skip-samples']) assert.strictEqual(z.r.headers.get(h), plain.r.headers.get(h), h);
      const ch = +plain.r.headers.get('x-pcm-channels');
      const back = unframe(z.buf, ch);
      assert.strictEqual(back.length, plain.buf.length, 'decoded length');
      assert.ok(back.equals(plain.buf), 'decoded audio differs from the plain stream');
      assert.ok(z.buf.length < plain.buf.length * 0.8, `compressed ${z.buf.length} vs raw ${plain.buf.length}`);
      assert.strictEqual(plain.r.headers.get('x-pcm-encoding'), null);
    });
  }
}
