// Real server, real files: a request that starts in the middle of a song must (a) carry exactly the audio a
// decode from the start would, and (b) not have to decode everything before it once the track has been indexed.
const test = require('node:test'), assert = require('node:assert'), fs = require('fs'), os = require('os'), path = require('path');
const { spawn } = require('child_process');
const NovaCodec = require('../lib/novaCodec');
const toAB = (b) => b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);

const SR = 48000, CH = 8, SECS = 45, SKIP = 38;
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-seek-'));
const servers = {};

function writeTrack() {
  fs.mkdirSync(path.join(tmp, 'music'));
  const frames = SR * SECS, data = Buffer.alloc(frames * CH * 2); let seed = 3;
  const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296 - 0.5; };
  for (let i = 0; i < frames; i++) for (let c = 0; c < CH; c++) data.writeInt16LE(Math.round(5000 * Math.sin(2 * Math.PI * (200 + c * 50) * i / SR) + 2500 * Math.sin(2 * Math.PI * (1500 + c * 9) * i / SR) + 1500 * rnd()), (i * CH + c) * 2);
  const h = Buffer.alloc(44); h.write('RIFF', 0); h.writeUInt32LE(36 + data.length, 4); h.write('WAVEfmt ', 8); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20);
  h.writeUInt16LE(CH, 22); h.writeUInt32LE(SR, 24); h.writeUInt32LE(SR * CH * 2, 28); h.writeUInt16LE(CH * 2, 32); h.writeUInt16LE(16, 34); h.write('data', 36); h.writeUInt32LE(data.length, 40);
  fs.writeFileSync(path.join(tmp, 'music', 'song.nova'), Buffer.from(NovaCodec.encode(NovaCodec.parseWav(toAB(Buffer.concat([h, data]))), { tags: { title: 'song' }, picture: null }).buffer));
}
async function startServer(name, port, extraEnv) {
  const dir = path.join(tmp, name); fs.mkdirSync(dir);
  const base = `http://127.0.0.1:${port}`;
  const srv = spawn('node', ['server.js'], { cwd: path.join(__dirname, '..'), env: { ...process.env, PORT: String(port), SESSION_SECRET: 'x'.repeat(40), ENCRYPTION_KEY: 'a'.repeat(64), MUSIC_DIR: path.join(tmp, 'music'), DB_PATH: path.join(dir, 'n.sqlite'), LOG_PATH: path.join(dir, 'e.log'),
    PCM_CACHE_DIR: path.join(dir, 'pcm'), SPOOL_DIR: path.join(dir, 'spool'), SEEK_INDEX_DIR: path.join(dir, 'index'), SEEK_CHECKPOINT_SECONDS: '5', ADMIN_USERNAME: 'admin', ADMIN_PASSWORD: 'password123', PUBLIC_ORIGIN: base, ...extraEnv } });
  let out = ''; srv.stderr.on('data', d => out += d); srv.stdout.on('data', d => out += d);
  for (let i = 0; i < 80; i++) { try { await fetch(base + '/api/auth/login', { method: 'OPTIONS' }); break; } catch (e) { await new Promise(r => setTimeout(r, 250)); } }
  const r = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: 'admin', password: 'password123', deviceLabel: 't' }) });
  assert.ok(r.ok, 'login ' + r.status + ' ' + out.slice(-600));
  servers[name] = { srv, base, dir, cookie: r.headers.getSetCookie().map(c => c.split(';')[0]).join('; '), out: () => out };
  return servers[name];
}
async function get(S, quality, skip, dur) {
  const t0 = Date.now();
  const r = await fetch(`${S.base}/api/stream/pcm?path=song.nova&quality=${quality}&skipToSeconds=${skip}` + (dur ? `&maxDurationSeconds=${dur}` : ''), { headers: { cookie: S.cookie } });
  assert.strictEqual(r.status, 200);
  const rd = r.body.getReader(), parts = []; let first = null;
  for (;;) { const { done, value } = await rd.read(); if (done) break; if (first === null) first = Date.now() - t0; parts.push(Buffer.from(value)); }
  return { first, buf: Buffer.concat(parts) };
}

test.before(() => { writeTrack(); });
test.after(() => { for (const s of Object.values(servers)) s.srv.kill(); fs.rmSync(tmp, { recursive: true, force: true }); });

test('after one full pass the track is indexed, and a request from the middle is fast and carries exactly the audio a decode from the start would', { timeout: 280000 }, async () => {
  const port = 5600 + Math.floor(Math.random() * 100);
  // B: never saw the track -> must decode from 0 to reach SKIP (this is what every quality switch used to cost)
  const B = await startServer('b', port + 200, { SPOOL_IDLE_CANCEL_MS: '200', SPOOL_LINGER_MS: '300' });
  await get(B, 'full', 0, 1);                              // sets the same first-play gain A will have
  await new Promise(r => setTimeout(r, 800));
  const slow = await get(B, 'full', SKIP, 3);
  assert.deepStrictEqual(fs.readdirSync(path.join(B.dir, 'index')), [], 'a partial decode must not write an index');

  // A: a full pass from the start builds the index; the finished decode is then dropped so the next request cannot reuse it
  const A = await startServer('a', port, { SPOOL_LINGER_MS: '300' });
  const whole = await get(A, 'full', 0);
  assert.strictEqual(whole.buf.length, SR * SECS * CH * 2);
  await new Promise(r => setTimeout(r, 1200));
  const idx = fs.readdirSync(path.join(A.dir, 'index')).filter(f => f.endsWith('.nsi'));
  assert.strictEqual(idx.length, 1, 'index file written after a complete pass: ' + A.out().slice(-400));
  for (const f of fs.readdirSync(path.join(A.dir, 'pcm'))) fs.rmSync(path.join(A.dir, 'pcm', f), { force: true }); // the PCM cache must not hide the effect of the index
  const fast = await get(A, 'full', SKIP, 3);

  assert.ok(fast.buf.equals(slow.buf), 'audio resumed from a checkpoint differs from audio decoded from the start');
  assert.strictEqual(fast.buf.length, 3 * SR * CH * 2);
  assert.ok(fast.first < slow.first / 2, `indexed first byte ${fast.first}ms should be far below un-indexed ${slow.first}ms`);
  // and the stream carried through the real response matches the whole-song stream at that offset
  assert.ok(fast.buf.equals(whole.buf.subarray(SKIP * SR * CH * 2, (SKIP + 3) * SR * CH * 2)), 'differs from the whole-song stream at that offset');
});

test('seeking after a server restart uses the saved index (it is not lost with the temporary files)', { timeout: 120000 }, async () => {
  const A = servers.a; A.srv.kill(); await new Promise(r => setTimeout(r, 500));
  const R = await startServer('a2', 5800 + Math.floor(Math.random() * 100), { SPOOL_DIR: path.join(A.dir, 'spool2'), SEEK_INDEX_DIR: path.join(A.dir, 'index'), SPOOL_IDLE_CANCEL_MS: '200', SPOOL_LINGER_MS: '300' });
  const r = await get(R, 'stereo', SKIP, 2);
  assert.ok(r.first < 5000, 'first byte after restart ' + r.first + 'ms');
  assert.ok(r.buf.length > 0);
});
