// Starts the real server, encodes a real 7.1 .nova file, and requests every quality tier from /api/stream/pcm:
// checks the headers, exact byte counts, seeking, the downmix maths (against the same matrix the Android engine uses)
// and that loud material is limited rather than clipped. Covers both the live-decode path and the cache path.
const test = require('node:test'), assert = require('node:assert'), fs = require('fs'), os = require('os'), path = require('path');
const { spawn, execFileSync } = require('child_process');
const NovaCodec = require('../lib/novaCodec');
const toAB = (b) => b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);
const { QUALITY_PRESETS } = require('../lib/pcmStream');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-tiers-'));
const port = 4950 + Math.floor(Math.random() * 40), base = `http://127.0.0.1:${port}`;
const SR = 48000, SECS = 8, CH = 8;
let srv, cookie, errOut = '';

function makeWav(amp) {
  const frames = SR * SECS, data = Buffer.alloc(frames * CH * 2);
  for (let i = 0; i < frames; i++) for (let c = 0; c < CH; c++) {
    const v = Math.round(amp * 32767 * Math.sin(2 * Math.PI * (220 + c * 137) * i / SR + c));
    data.writeInt16LE(v, (i * CH + c) * 2);
  }
  const h = Buffer.alloc(44);
  h.write('RIFF', 0); h.writeUInt32LE(36 + data.length, 4); h.write('WAVEfmt ', 8); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20);
  h.writeUInt16LE(CH, 22); h.writeUInt32LE(SR, 24); h.writeUInt32LE(SR * CH * 2, 28); h.writeUInt16LE(CH * 2, 32); h.writeUInt16LE(16, 34);
  h.write('data', 36); h.writeUInt32LE(data.length, 40);
  return Buffer.concat([h, data]);
}
function writeLong(name, secs) {
  const frames = SR * secs, data = Buffer.alloc(frames * CH * 2);
  for (let i = 0; i < frames; i++) for (let c = 0; c < CH; c++) data.writeInt16LE(Math.round(3000 * Math.sin(2 * Math.PI * (200 + c * 90) * i / SR)), (i * CH + c) * 2);
  const h = Buffer.alloc(44);
  h.write('RIFF', 0); h.writeUInt32LE(36 + data.length, 4); h.write('WAVEfmt ', 8); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20);
  h.writeUInt16LE(CH, 22); h.writeUInt32LE(SR, 24); h.writeUInt32LE(SR * CH * 2, 28); h.writeUInt16LE(CH * 2, 32); h.writeUInt16LE(16, 34);
  h.write('data', 36); h.writeUInt32LE(data.length, 40);
  const wav = NovaCodec.parseWav(toAB(Buffer.concat([h, data])));
  fs.writeFileSync(path.join(tmp, 'music', name + '.nova'), Buffer.from(NovaCodec.encode(wav, { tags: { title: name }, picture: null }).buffer));
}
function writeNova(name, amp) {
  const wav = NovaCodec.parseWav(toAB(makeWav(amp)));
  const out = NovaCodec.encode(wav, { tags: { title: name }, picture: null });
  fs.writeFileSync(path.join(tmp, 'music', name + '.nova'), Buffer.from(out.buffer));
}

test.before(async () => {
  fs.mkdirSync(path.join(tmp, 'music'));
  writeNova('quiet', 0.05); // downmix sum stays under the limiter threshold -> must match the matrix exactly
  writeNova('loud', 0.9);   // downmix sum is ~3x full scale -> must be limited, not clipped
  writeLong('slow', 45);     // long enough that a paused client keeps the live decode running
  srv = spawn('node', ['server.js'], { cwd: path.join(__dirname, '..'), env: { ...process.env, PORT: String(port), SESSION_SECRET: 'x'.repeat(40), ENCRYPTION_KEY: 'a'.repeat(64), MUSIC_DIR: path.join(tmp, 'music'), DB_PATH: path.join(tmp, 'n.sqlite'), LOG_PATH: path.join(tmp, 'e.log'), PCM_CACHE_DIR: path.join(tmp, 'pcm'), ADMIN_USERNAME: 'admin', ADMIN_PASSWORD: 'password123', PUBLIC_ORIGIN: base } });
  srv.stderr.on('data', d => errOut += d); srv.stdout.on('data', d => errOut += d);
  for (let i = 0; i < 60; i++) { try { await fetch(base + '/api/auth/login', { method: 'OPTIONS' }); break; } catch (e) { await new Promise(r => setTimeout(r, 250)); } }
  const r = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: 'admin', password: 'password123', deviceLabel: 't' }) });
  assert.ok(r.ok, 'login ' + r.status + ' ' + errOut.slice(-800)); cookie = r.headers.getSetCookie().map(c => c.split(';')[0]).join('; ');
});
test.after(() => { if (srv) srv.kill(); fs.rmSync(tmp, { recursive: true, force: true }); });

async function pcm(name, quality, skip = 0, dur = null) {
  const q = `path=${encodeURIComponent(name + '.nova')}&quality=${quality}&skipToSeconds=${skip}` + (dur ? `&maxDurationSeconds=${dur}` : '');
  let r; try { r = await fetch(`${base}/api/stream/pcm?${q}`, { headers: { cookie } }); } catch (e) { throw new Error(quality + ' fetch failed: ' + (e.cause && e.cause.message) + ' | server: ' + errOut.slice(-1500)); }
  assert.strictEqual(r.status, 200, `${quality}: HTTP ${r.status}`);
  return { sr: +r.headers.get('x-pcm-sample-rate'), ch: +r.headers.get('x-pcm-channels'), frames: +r.headers.get('x-pcm-total-frames'), buf: Buffer.from(await r.arrayBuffer()) };
}
const sampleAt = (b, i) => b.readInt16LE(i * 2);
function refDownmix(full, f) { // same matrix as NativeAudioEngine.processChunk
  const s = c => c < CH ? sampleAt(full, f * CH + c) : 0;
  return [s(0) + 0.707 * s(2) + 0.5 * s(3) + 0.707 * s(4) + 0.707 * s(6), s(1) + 0.707 * s(2) + 0.5 * s(3) + 0.707 * s(5) + 0.707 * s(7)];
}

const TIERS = Object.entries(QUALITY_PRESETS).filter(([k]) => k !== 'full').map(([k]) => k);
for (const pass of ['first request (live decode)', 'second request (cache)']) {
  test(`every tier: headers and exact byte counts — ${pass}`, async () => {
    const full = await pcm('quiet', 'full');
    assert.deepStrictEqual([full.sr, full.ch, full.frames], [SR, 8, SR * SECS]);
    assert.strictEqual(full.buf.length, SR * SECS * 8 * 2);
    for (const q of TIERS) {
      const p = QUALITY_PRESETS[q], t = await pcm('quiet', q);
      const wantSr = p.sampleRate || SR, wantCh = p.channels || 8;
      assert.deepStrictEqual([t.sr, t.ch], [wantSr, wantCh], q);
      assert.strictEqual(t.frames, wantSr * SECS, q + ' total frames');
      assert.ok(Math.abs(t.buf.length - t.frames * wantCh * 2) <= wantCh * 2 * 4, `${q}: body ${t.buf.length} vs ${t.frames * wantCh * 2}`);
    }
  });
}

test('stereo tiers carry far less data, and each step down is smaller', async () => {
  const size = async q => (await pcm('quiet', q)).buf.length;
  const [full, st, sr, su, sm] = [await size('full'), await size('stereo'), await size('stereo-reduced'), await size('stereo-ultra'), await size('stereo-minimal')];
  assert.ok(st < full / 3.5, `stereo ${st} vs full ${full}`);
  assert.ok(full > st && st > sr && sr > su && su > sm, [full, st, sr, su, sm].join(' > '));
  assert.ok(sr < (await size('reduced')) / 3, 'stereo-reduced is much smaller than the old 8-channel reduced');
});

test('stereo downmix at the source rate matches the Android engine\'s matrix (quiet material, limiter idle)', async () => {
  const full = await pcm('quiet', 'full'), st = await pcm('quiet', 'stereo');
  assert.strictEqual(st.sr, SR);
  let maxErr = 0;
  for (let f = 2000; f < 40000; f += 7) {
    const [l, r] = refDownmix(full.buf, f);
    maxErr = Math.max(maxErr, Math.abs(sampleAt(st.buf, f * 2) - l), Math.abs(sampleAt(st.buf, f * 2 + 1) - r));
  }
  assert.ok(maxErr <= 3, 'max difference from the reference downmix: ' + maxErr + ' LSB');
});

test('loud material is limited, not clipped', async () => {
  for (const q of ['stereo', 'stereo-reduced', 'stereo-minimal']) {
    const t = await pcm('loud', q); let peak = 0, atRail = 0;
    for (let i = 0; i < t.buf.length / 2; i++) { const a = Math.abs(t.buf.readInt16LE(i * 2)); if (a > peak) peak = a; if (a >= 32767) atRail++; }
    assert.ok(atRail === 0 && peak < 32000, `${q}: peak ${peak}, samples at the rail ${atRail}`);
    assert.ok(peak > 8000, `${q}: not silent/over-attenuated (peak ${peak})`);
  }
});

test('seeking inside a stereo tier returns exactly the requested window, aligned with the full stream', async () => {
  const full = await pcm('quiet', 'full'), w = await pcm('quiet', 'stereo', 3, 2);
  assert.strictEqual(w.ch, 2); assert.ok(Math.abs(w.buf.length - 2 * SR * 2 * 2) <= 16, 'window length ' + w.buf.length);
  const skip = Math.round(3 * SR); let maxErr = 0;
  for (let f = 0; f < 60000; f += 11) {
    const [l] = refDownmix(full.buf, skip + f); maxErr = Math.max(maxErr, Math.abs(sampleAt(w.buf, f * 2) - l));
  }
  assert.ok(maxErr <= 3, 'seeked window drifts from the full stream by ' + maxErr + ' LSB');
});

test('a stereo (non-multichannel) source passes through unchanged in the stereo tier', async () => {
  // reuse the 8ch file's stereo tiers vs a true stereo source: encode a 2ch file
  const frames = SR * 3, data = Buffer.alloc(frames * 4);
  for (let i = 0; i < frames; i++) { data.writeInt16LE(Math.round(8000 * Math.sin(i / 20)), i * 4); data.writeInt16LE(Math.round(8000 * Math.sin(i / 31)), i * 4 + 2); }
  const h = Buffer.alloc(44); h.write('RIFF', 0); h.writeUInt32LE(36 + data.length, 4); h.write('WAVEfmt ', 8); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(2, 22); h.writeUInt32LE(SR, 24); h.writeUInt32LE(SR * 4, 28); h.writeUInt16LE(4, 32); h.writeUInt16LE(16, 34); h.write('data', 36); h.writeUInt32LE(data.length, 40);
  fs.writeFileSync(path.join(tmp, 'music', 'plain.nova'), Buffer.from(NovaCodec.encode(NovaCodec.parseWav(toAB(Buffer.concat([h, data]))), { tags: {}, picture: null }).buffer));
  const a = await pcm('plain', 'full'), b = await pcm('plain', 'stereo');
  assert.deepStrictEqual([b.ch, b.sr], [2, SR]); assert.ok(a.buf.equals(b.buf), 'stereo tier of a stereo source must be bit-identical to full');
});

test('every step of the app\'s adaptive ladder is a quality the server accepts, ordered from most to least data', () => {
  const app = fs.readFileSync(path.join(__dirname, '..', 'public', 'app.js'), 'utf8');
  const steps = JSON.parse(app.match(/const AUTO_QUALITY_STEPS = (\[[^\]]*\])/)[1].replace(/'/g, '"'));
  const route = fs.readFileSync(path.join(__dirname, '..', 'routes', 'stream.js'), 'utf8');
  const valid = route.match(/VALID_PCM_QUALITIES = new Set\((\[[^\]]*\])/)[1].replace(/'/g, '"');
  for (const s of steps) { assert.ok(JSON.parse(valid).includes(s), s + ' not accepted by the route'); assert.ok(s === 'full' || QUALITY_PRESETS[s], s + ' has no preset'); }
  assert.deepStrictEqual(steps.slice(0, 4), ['full', 'reduced', 'ultra', 'stereo'], 'surround stays surround (at falling sample rates) before the stereo downmix');
  const bytesPerSec = s => { const p = s === 'full' ? {} : QUALITY_PRESETS[s]; return (p.sampleRate || 48000) * (p.channels || 8) * 2; };   // 7.1 source
  for (let i = 1; i < steps.length; i++) assert.ok(bytesPerSec(steps[i]) < bytesPerSec(steps[i - 1]), steps[i] + ' must carry less data than ' + steps[i - 1]);
});

test('the background cache fill does not decode the same song while its live stream is still running, and runs once it ends', async () => {
  const dir = path.join(tmp, 'pcm'), listing = () => (fs.existsSync(dir) ? fs.readdirSync(dir) : []).sort().join(',');
  for (let i = 0, same = 0, last = ''; i < 120 && same < 6; i++) {   // let earlier tests' cache fills finish first
    await new Promise(res => setTimeout(res, 500));
    const now = listing(); same = (now === last && !now.includes('.tmp')) ? same + 1 : 0; last = now;
  }
  const before = listing();
  const r = await fetch(`${base}/api/stream/pcm?path=slow.nova&quality=full&skipToSeconds=0`, { headers: { cookie } });
  assert.strictEqual(r.status, 200);
  const rd = r.body.getReader();
  await rd.read();                                  // client takes one chunk, then stops reading (a slow connection)
  await new Promise(res => setTimeout(res, 3500));  // the old code started the cache fill immediately
  assert.strictEqual(listing(), before, 'cache fill must not have started while the live stream is open');
  let got = 0; for (;;) { const x = await rd.read(); if (x.done) break; got += x.value.length; }   // client catches up; stream ends
  let filled = false;
  for (let i = 0; i < 60 && !filled; i++) { await new Promise(res => setTimeout(res, 500)); filled = listing() !== before; }
  assert.ok(filled, 'cache fill should start after the live stream has finished');
  const stats = await (await fetch(`${base}/api/stream/stats`, { headers: { cookie } })).json();
  const mine = stats.filter(x => x.track === 'slow.nova' && x.source === 'live-decode').pop();
  assert.ok(mine, 'stream summary recorded');
  assert.ok(mine.pausedMs >= 2500, 'time spent waiting on the client is reported (was ' + mine.pausedMs + 'ms)');
  assert.ok(mine.KB > 30000 && mine.serverKBps > 0 && mine.firstByteMs >= 0);
});

test('connection probe endpoint sends exactly the requested bytes (capped), uncompressed, uncached, and needs a login', async () => {
  const anon = await fetch(`${base}/api/native-config/probe`);
  assert.strictEqual(anon.status, 401);
  const r = await fetch(`${base}/api/native-config/probe?bytes=500000`, { headers: { cookie, 'accept-encoding': 'gzip' } });
  assert.strictEqual(r.status, 200);
  assert.ok(/no-store/.test(r.headers.get('cache-control')));
  const buf = Buffer.from(await r.arrayBuffer());
  assert.strictEqual(buf.length, 500000);
  assert.ok(require('zlib').gzipSync(buf.subarray(0, 100000)).length > 95000, 'random data, cannot be compressed into a faster-looking transfer');
  const big = await fetch(`${base}/api/native-config/probe?bytes=999999999`, { headers: { cookie } });
  assert.strictEqual(Buffer.from(await big.arrayBuffer()).length, 12000000, 'capped at NATIVE_PROBE_MAX_BYTES');
});
