// A cache/spool folder that cannot be created must not freeze the server (fs.mkdirSync recursive never returns under /proc).
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs'), os = require('os'), path = require('path');
const { spawnSync } = require('child_process');
const ensureDir = require('../lib/ensureDir');
const NovaCodec = require('../lib/novaCodec');

test('ensureDir creates nested folders, and fails with an error (instead of hanging) where that is impossible', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'ensure-'));
  ensureDir(path.join(root, 'a', 'b', 'c')); ensureDir(path.join(root, 'a', 'b', 'c'));
  assert.ok(fs.statSync(path.join(root, 'a', 'b', 'c')).isDirectory());
  fs.writeFileSync(path.join(root, 'file'), 'x');
  assert.throws(() => ensureDir(path.join(root, 'file', 'sub')), /ENOTDIR|not a directory/);
  assert.throws(() => ensureDir('/proc/nope/cache'));
  fs.rmSync(root, { recursive: true, force: true });
});

test('a stream still works when PCM_CACHE_DIR cannot be created', { timeout: 60000 }, () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'nocache-'));
  const frames = 44100, ch = new Int32Array(frames).map((_, i) => Math.round(Math.sin(i / 20) * 8000));
  const enc = NovaCodec.encode({ sampleRate: 44100, numChannels: 1, bitsPerSample: 16, numFrames: frames, channels: [ch] }, { tags: {}, picture: null }, () => {}, {});
  fs.writeFileSync(path.join(root, 't.nova'), Buffer.from(enc.buffer ? Buffer.from(enc.buffer, enc.byteOffset || 0, enc.byteLength) : enc));
  const code = `
    const http = require('http'); const pcm = require(${JSON.stringify(path.join(__dirname, '..', 'lib', 'pcmStream'))});
    const srv = http.createServer((q, res) => { res.on('error', () => {}); pcm.streamFileAsPCM(${JSON.stringify(path.join(root, 't.nova'))}, res, 'full', 0, 1).catch(() => res.end()); }).listen(0, () => {
      http.get({ port: srv.address().port }, (r) => { let n = 0; r.on('data', (d) => n += d.length); r.on('end', () => { console.log('BYTES ' + n); process.exit(0); }); });
    });`;
  const r = spawnSync(process.execPath, ['-e', code], { encoding: 'utf8', timeout: 40000, env: { ...process.env, PCM_CACHE_DIR: '/proc/nope/cache', SPOOL_DIR: '', SEEK_INDEX_DIR: '', DB_PATH: path.join(root, 'db.sqlite'), LOG_PATH: path.join(root, 'log.txt'), ENCRYPTION_KEY: '0'.repeat(64) } });
  assert.ok(!r.error, 'did not hang: ' + (r.error && r.error.message));
  assert.match(r.stdout, /BYTES 88200/);
  fs.rmSync(root, { recursive: true, force: true });
});
